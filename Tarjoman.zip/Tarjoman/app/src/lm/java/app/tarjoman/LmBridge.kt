package app.tarjoman

import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.SamplerConfig
import java.io.File

/** LiteRT-LM engine for .litertlm models (newer Gemma / Qwen3 releases). Only compiled with -Plitertlm. */
object LmBridge {
    const val available = true

    private var engine: Engine? = null
    private var loaded: String? = null

    @Synchronized
    fun load(ctx: Context, f: File) {
        if (loaded == f.absolutePath && engine != null) return
        try { engine?.close() } catch (_: Throwable) {}
        engine = null
        loaded = null
        val cfg = EngineConfig(
            modelPath = f.absolutePath,
            backend = Backend.CPU(),
            cacheDir = ctx.applicationContext.cacheDir.path
        )
        val e = Engine(cfg)
        e.initialize()
        engine = e
        loaded = f.absolutePath
    }

    @Synchronized
    fun gen(system: String, user: String, slow: Boolean): String {
        val e = engine ?: throw IllegalStateException("model not loaded")
        val cc = ConversationConfig(
            systemInstruction = Contents.of(system),
            samplerConfig = SamplerConfig(
                topK = if (slow) 24 else 1,
                topP = 0.95,
                temperature = if (slow) 0.35 else 0.1
            )
        )
        return e.createConversation(cc).use { c -> c.sendMessage(user).toString() }
    }
}
