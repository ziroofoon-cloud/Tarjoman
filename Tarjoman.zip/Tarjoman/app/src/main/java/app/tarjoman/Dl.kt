package app.tarjoman

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.widget.Toast
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/**
 * All downloads live here, not in the screen: they keep running (inside a foreground service with a notification)
 * when the app is closed or in the background, retry by themselves and continue from the saved part.
 */
object Dl {
    class Job(val id: String, val title: String, val dl: Downloader) {
        @Volatile var have = 0L
        @Volatile var total = -1L
        @Volatile var note = ""
        @Volatile var speed = 0L   // bytes per second
        @Volatile var wipe = false // true = cancel: the downloaded part is deleted too
    }

    val jobs = ConcurrentHashMap<String, Job>()

    /** (id, finished). Called from worker threads; the screen must post to its own thread. */
    @Volatile var listener: ((String, Boolean) -> Unit)? = null

    private val main = Handler(Looper.getMainLooper())
    private var keep = 0

    @Synchronized fun keepBegin(ctx: Context) {
        keep++
        if (keep == 1) try { ctx.applicationContext.startForegroundService(Intent(ctx.applicationContext, DlService::class.java)) } catch (_: Throwable) {}
    }

    @Synchronized fun keepEnd(ctx: Context) {
        if (keep > 0) keep--
        val app = ctx.applicationContext
        // A short delay: stopping a service right after starting it can crash on new Android versions.
        main.postDelayed({
            synchronized(this) { if (keep == 0) try { app.stopService(Intent(app, DlService::class.java)) } catch (_: Throwable) {} }
        }, 1500)
    }

    @Synchronized fun busy(): Boolean = keep > 0

    fun toast(ctx: Context, m: String) {
        val app = ctx.applicationContext
        main.post { Toast.makeText(app, m, Toast.LENGTH_LONG).show() }
    }

    fun partBytes(dest: File): Long = File(dest.path + ".part").let { if (it.exists()) it.length() else 0L }

    /** Removes a half-finished download completely. */
    fun deletePart(dest: File) {
        File(dest.path + ".part").delete()
        File(dest.path + ".meta").delete()
    }

    fun start(ctx: Context, id: String, title: String, url: String, dest: File) {
        val app = ctx.applicationContext
        if (jobs.containsKey(id)) return
        dest.parentFile?.mkdirs()
        val dl = Downloader(Cfg(app), app)
        val job = Job(id, title, dl)
        job.have = partBytes(dest)
        jobs[id] = job
        dl.onNote = { job.note = it; listener?.invoke(id, false) }
        keepBegin(app)
        Thread {
            var err: Throwable? = null
            var lastT = System.currentTimeMillis()
            var lastB = job.have
            try {
                dl.download(url, dest) { a, b ->
                    job.have = a
                    job.total = b
                    job.note = ""
                    val n = System.currentTimeMillis()
                    if (n - lastT >= 700 || (b > 0 && a >= b)) {
                        val dt = n - lastT
                        if (dt > 0 && a >= lastB) job.speed = (a - lastB) * 1000 / dt
                        lastT = n
                        lastB = a
                        listener?.invoke(id, false)
                    }
                }
            } catch (e: Throwable) {
                err = e
            }
            jobs.remove(id)
            val fail = err
            val wiped = job.wipe && dl.cancelled
            if (wiped) deletePart(dest)
            toast(app, if (fail == null) L("دانلود کامل شد") else if (wiped) L("دانلود لغو شد و بخش دانلودشده حذف شد") else if (dl.cancelled) L("دانلود متوقف شد؛ با «ادامه دانلود» از همان‌جا ادامه پیدا می‌کند") else L("خطا: ") + (fail.message ?: fail.toString()))
            listener?.invoke(id, true)
            keepEnd(app)
        }.start()
        listener?.invoke(id, false)
    }

    /** Stops the transfer; the downloaded part stays so it can be continued later. */
    fun cancel(id: String) { jobs[id]?.dl?.cancelled = true }

    /** Cancel = stop and delete the downloaded part (use [cancel] to only pause). */
    fun abort(id: String) { jobs[id]?.let { it.wipe = true; it.dl.cancelled = true } }

    fun cancelAll() { for (j in jobs.values) j.dl.cancelled = true }
}

/** Keeps the process alive and shows the progress while a download runs. */
class DlService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var wl: PowerManager.WakeLock? = null
    private val tick = object : Runnable {
        override fun run() {
            try { (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(2, build()) } catch (_: Throwable) {}
            h.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "app.tarjoman.DL_CANCEL") { Dl.cancelAll(); return START_NOT_STICKY }
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("dl", "Tarjoman downloads", NotificationManager.IMPORTANCE_LOW))
        val n = build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC) else startForeground(2, n)
        if (wl == null) {
            try {
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "tarjoman:dl").also { it.acquire(6 * 60 * 60 * 1000L) }
            } catch (_: Throwable) {}
        }
        h.removeCallbacks(tick)
        h.postDelayed(tick, 1000)
        return START_NOT_STICKY
    }

    private fun build(): Notification {
        Cfg(this)   // makes sure the app language is loaded
        val cancel = PendingIntent.getService(
            this, 3, Intent(this, DlService::class.java).setAction("app.tarjoman.DL_CANCEL"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(this, 4, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val j = Dl.jobs.values.firstOrNull()
        val title = L("ترجمان — در حال دانلود")
        val text: String
        var p = 0
        var known = false
        if (j == null) {
            text = L("دانلود بستهٔ زبان یا مدل در حال انجام است…")
        } else {
            known = j.total > 0
            if (known) p = (j.have * 1000 / j.total).toInt().coerceIn(0, 1000)
            val more = Dl.jobs.size - 1
            text = j.title + (if (known) "  " + (p / 10) + "%  (" + (j.have / 1048576) + "/" + (j.total / 1048576) + " MB)" else "") +
                (if (j.note.isNotEmpty()) "  ·  " + j.note else "") + (if (more > 0) "  +" + more else "")
        }
        @Suppress("DEPRECATION")
        return Notification.Builder(this, "dl")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setProgress(1000, p, !known)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, L("توقف"), cancel)
            .build()
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        try { wl?.let { if (it.isHeld) it.release() } } catch (_: Throwable) {}
        super.onDestroy()
    }
}
