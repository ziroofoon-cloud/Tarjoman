package app.tarjoman

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import java.io.File

/**
 * Lets other apps receive a translated file (picture, .srt, .cbz, .pdf, text) through the Share sheet: the file is copied to
 * cache/share and handed out read-only for that one share. Nothing else of the app is reachable through it.
 */
class ShareProvider : ContentProvider() {
    override fun onCreate(): Boolean = true

    private fun fileOf(uri: Uri): File? {
        val ctx = context ?: return null
        val dir = File(ctx.cacheDir, "share")
        val f = File(dir, uri.lastPathSegment ?: return null)
        return try { if (f.canonicalPath.startsWith(dir.canonicalPath + File.separator) && f.isFile) f else null } catch (_: Throwable) { null }
    }

    override fun query(uri: Uri, projection: Array<out String>?, selection: String?, selectionArgs: Array<out String>?, sortOrder: String?): Cursor? {
        val f = fileOf(uri) ?: return null
        val cols = projection ?: arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE)
        val c = MatrixCursor(cols)
        c.addRow(Array<Any?>(cols.size) { i -> if (cols[i] == OpenableColumns.DISPLAY_NAME) f.name else if (cols[i] == OpenableColumns.SIZE) f.length() else null })
        return c
    }

    override fun getType(uri: Uri): String? {
        val n = uri.lastPathSegment ?: return null
        val ext = n.substringAfterLast('.', "").lowercase()
        return android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: when (ext) {
            "srt" -> "application/x-subrip"
            "cbz" -> "application/vnd.comicbook+zip"
            else -> "application/octet-stream"
        }
    }

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor? {
        val f = fileOf(uri) ?: throw java.io.FileNotFoundException(uri.toString())
        return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = 0
}
