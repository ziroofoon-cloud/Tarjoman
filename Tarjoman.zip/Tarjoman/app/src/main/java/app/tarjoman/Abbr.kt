package app.tarjoman

/** Abbreviations and chat / tech short forms: what they stand for, and the Persian meaning. */
object Abbr {
    class E(val full: String, val fa: String)

    private val DATA = """
LOL|laughing out loud|بلند می‌خندم؛ خیلی خنده‌دار
LMAO|laughing my ass off|از خنده روده‌بر شدم
ROFL|rolling on the floor laughing|از خنده غش کردم
GG|good game|بازی خوبی بود
GL|good luck|موفق باشی
HF|have fun|خوش بگذره
BRB|be right back|الان برمی‌گردم
AFK|away from keyboard|پشت سیستم نیستم
BTW|by the way|راستی؛ ضمناً
IMO|in my opinion|به نظر من
IMHO|in my humble opinion|به نظر ناقص من
IDK|I don't know|نمی‌دونم
IDC|I don't care|برام مهم نیست
OMG|oh my god|وای خدای من
OMW|on my way|تو راهم
TBH|to be honest|راستش
FYI|for your information|برای اطلاعت
ASAP|as soon as possible|هر چه زودتر
DM|direct message|پیام خصوصی
PM|private message|پیام خصوصی
TL;DR|too long; didn't read|خلاصه‌اش
TLDR|too long; didn't read|خلاصه‌اش
FOMO|fear of missing out|ترس از جا ماندن
YOLO|you only live once|فقط یک بار زندگی می‌کنی
SMH|shaking my head|سرم رو تکون میدم؛ باورم نمی‌شه
NVM|never mind|بیخیال
THX|thanks|ممنون
TY|thank you|ممنون
YW|you're welcome|خواهش می‌کنم
NP|no problem|مشکلی نیست
GTG|got to go|باید برم
TTYL|talk to you later|بعداً حرف می‌زنیم
BFF|best friends forever|بهترین دوست همیشگی
IRL|in real life|در دنیای واقعی
ICYMI|in case you missed it|اگر از دستت رفته
AKA|also known as|معروف به
ETA|estimated time of arrival|زمان تقریبی رسیدن
RSVP|please reply|لطفاً پاسخ بدهید
DIY|do it yourself|خودت بساز
FAQ|frequently asked questions|پرسش‌های متداول
NSFW|not safe for work|نامناسب محیط کار (محتوای بزرگسال)
SFW|safe for work|مناسب محیط کار
NSFL|not safe for life|محتوای خیلی ناراحت‌کننده
BDSM|bondage, discipline, dominance, submission, sadism, masochism|اصطلاحی برای روابط جنسی مبتنی بر بندوبست، انضباط و سلطه
OP|original poster|نویسندهٔ پست اصلی
AMA|ask me anything|هر چه می‌خواهی از من بپرس
ELI5|explain like I'm five|مثل یک بچهٔ پنج‌ساله توضیح بده
NPC|non-player character|شخصیت غیرقابل‌بازی
PVP|player versus player|بازیکن در برابر بازیکن
PVE|player versus environment|بازیکن در برابر محیط (بازی)
RPG|role-playing game|بازی نقش‌آفرینی
FPS|frames per second / first-person shooter|فریم بر ثانیه / تیراندازی اول‌شخص
MMO|massively multiplayer online|آنلاین چندنفرهٔ عظیم
DLC|downloadable content|محتوای قابل‌دانلود
AI|artificial intelligence|هوش مصنوعی
ML|machine learning|یادگیری ماشین
HD|high definition|وضوح بالا
FHD|full high definition|وضوح کامل بالا (۱۹۲۰×۱۰۸۰)
QHD|quad high definition|وضوح چهار برابر HD (۲۵۶۰×۱۴۴۰)
UHD|ultra high definition|وضوح فوق‌العاده بالا (۴K)
SD|standard definition|وضوح استاندارد
4K|four thousand (horizontal pixels)|وضوح حدود ۴۰۰۰ پیکسل افقی
HDR|high dynamic range|دامنهٔ دینامیکی بالا
SDR|standard dynamic range|دامنهٔ دینامیکی استاندارد
OLED|organic light-emitting diode|نمایشگر دیود آلی نورانی
LED|light-emitting diode|دیود نورانی
LCD|liquid crystal display|نمایشگر کریستال مایع
UI|user interface|رابط کاربری
UX|user experience|تجربهٔ کاربری
GUI|graphical user interface|رابط کاربری گرافیکی
CLI|command-line interface|رابط خط فرمان
OS|operating system|سیستم‌عامل
CPU|central processing unit|پردازندهٔ مرکزی
GPU|graphics processing unit|پردازندهٔ گرافیکی
RAM|random access memory|حافظهٔ تصادفی (رم)
ROM|read-only memory|حافظهٔ فقط‌خواندنی
SSD|solid-state drive|حافظهٔ حالت‌جامد
HDD|hard disk drive|هارددیسک
USB|universal serial bus|گذرگاه سریال همگانی
HDMI|high-definition multimedia interface|درگاه تصویر و صدای دیجیتال
Wi-Fi|wireless fidelity (wireless network)|شبکهٔ بی‌سیم
WiFi|wireless network|شبکهٔ بی‌سیم
VPN|virtual private network|شبکهٔ خصوصی مجازی
URL|uniform resource locator|نشانی وب
HTML|hypertext markup language|زبان نشانه‌گذاری ابرمتن
PDF|portable document format|قالب سند قابل‌حمل
GPS|global positioning system|سامانهٔ موقعیت‌یاب جهانی
SMS|short message service|پیامک
MMS|multimedia messaging service|پیام چندرسانه‌ای
QR|quick response (code)|کد پاسخ سریع
APK|Android package|بستهٔ نصب اندروید
API|application programming interface|رابط برنامه‌نویسی
SDK|software development kit|کیت توسعهٔ نرم‌افزار
IP|internet protocol (address)|پروتکل اینترنت (نشانی)
ISP|internet service provider|ارائه‌دهندهٔ اینترنت
DNS|domain name system|سامانهٔ نام دامنه
LAN|local area network|شبکهٔ محلی
CPU|central processing unit|پردازنده
PC|personal computer|رایانهٔ شخصی
TV|television|تلویزیون
DVD|digital versatile disc|دیسک دیجیتال
CD|compact disc|لوح فشرده
MP3|MPEG audio layer 3|قالب صوتی فشرده
GIF|graphics interchange format|تصویر متحرک
JPEG|Joint Photographic Experts Group|قالب تصویر فشرده
PNG|portable network graphics|قالب تصویر
Hz|hertz (cycles per second)|هرتز؛ تعداد دور در ثانیه (مثلاً نرخ تازه‌سازی صفحه)
kHz|kilohertz|کیلوهرتز
MHz|megahertz|مگاهرتز
GHz|gigahertz|گیگاهرتز
ms|millisecond (1/1000 second)|میلی‌ثانیه (هزارم ثانیه)
s|second|ثانیه
min|minute|دقیقه
hr|hour|ساعت
KB|kilobyte|کیلوبایت
MB|megabyte|مگابایت
GB|gigabyte|گیگابایت
TB|terabyte|ترابایت
Kbps|kilobits per second|کیلوبیت بر ثانیه
Mbps|megabits per second|مگابیت بر ثانیه
Gbps|gigabits per second|گیگابیت بر ثانیه
dB|decibel|دسی‌بل (شدت صدا)
km|kilometre|کیلومتر
cm|centimetre|سانتی‌متر
mm|millimetre|میلی‌متر
kg|kilogram|کیلوگرم
mg|milligram|میلی‌گرم
ml|millilitre|میلی‌لیتر
mph|miles per hour|مایل بر ساعت
km/h|kilometres per hour|کیلومتر بر ساعت
rpm|revolutions per minute|دور در دقیقه
mAh|milliampere-hour (battery capacity)|میلی‌آمپرساعت (ظرفیت باتری)
Ph.D|doctor of philosophy|دکترای تخصصی
PhD|doctor of philosophy|دکترای تخصصی
MSc|master of science|کارشناسی ارشد (علوم)
BSc|bachelor of science|کارشناسی (علوم)
CEO|chief executive officer|مدیرعامل
CFO|chief financial officer|مدیر مالی
CTO|chief technology officer|مدیر فناوری
HR|human resources|منابع انسانی
PR|public relations|روابط عمومی
R&D|research and development|تحقیق و توسعه
Q&A|questions and answers|پرسش و پاسخ
Inc|incorporated|شرکت سهامی
Ltd|limited|شرکت با مسئولیت محدود
Co|company|شرکت
vs|versus|در برابر
etc|et cetera|و غیره
e.g|for example (exempli gratia)|برای مثال
i.e|that is (id est)|یعنی؛ به عبارت دیگر
approx|approximately|تقریباً
Dr|doctor|دکتر
Mr|mister|آقای
Mrs|missus|خانم (متأهل)
Ms|miss / ms.|خانم
Prof|professor|استاد
St|street / saint|خیابان / قدیس
USA|United States of America|ایالات متحده
UK|United Kingdom|بریتانیا
UN|United Nations|سازمان ملل
EU|European Union|اتحادیهٔ اروپا
NATO|North Atlantic Treaty Organization|ناتو
UFO|unidentified flying object|شیء پرنده ناشناس
SOS|distress signal (save our souls)|درخواست کمک
ER|emergency room|اورژانس
ICU|intensive care unit|بخش مراقبت‌های ویژه
CPR|cardiopulmonary resuscitation|احیای قلبی‌ریوی
DNA|deoxyribonucleic acid|دی‌ان‌ای
RNA|ribonucleic acid|آران‌ای
HIV|human immunodeficiency virus|ویروس نقص ایمنی انسان
MRI|magnetic resonance imaging|تصویربرداری تشدید مغناطیسی
IQ|intelligence quotient|ضریب هوشی
GDP|gross domestic product|تولید ناخالص داخلی
ATM|automated teller machine|خودپرداز
PIN|personal identification number|رمز شخصی
ID|identification|شناسه؛ کارت شناسایی
AM|ante meridiem (before noon)|قبل از ظهر
PM|post meridiem (after noon)|بعد از ظهر
AD|anno Domini (common era)|میلادی
BC|before Christ|پیش از میلاد
TBA|to be announced|اعلام می‌شود
TBD|to be determined|مشخص می‌شود
N/A|not applicable / not available|مرتبط نیست / موجود نیست
WTF|what the f***|این دیگه چیه؟! (عامیانه و خشن)
WTH|what the heck|این دیگه چیه؟!
FFS|for f***'s sake|به خاطر خدا! (عامیانه و خشن)
STFU|shut the f*** up|خفه شو (توهین‌آمیز)
BS|bullshit|مزخرف؛ چرند (عامیانه)
LMK|let me know|بهم خبر بده
JK|just kidding|شوخی کردم
NGL|not gonna lie|راستش رو بخوای
ILY|I love you|دوستت دارم
XOXO|hugs and kisses|بغل و بوسه
HBD|happy birthday|تولدت مبارک
RIP|rest in peace|روحش شاد
OTP|one true pairing / one-time password|زوج ایده‌آل (طرفداران) / رمز یک‌بارمصرف
MC|main character / master of ceremonies|شخصیت اصلی / مجری
OVA|original video animation|انیمیشن ویدیویی اصلی
AMV|anime music video|ویدیوی موسیقی انیمه
""".trim()

    private val map: Map<String, E> by lazy {
        val m = HashMap<String, E>()
        for (ln in DATA.lines()) {
            val p = ln.split("|")
            if (p.size >= 3 && p[0] !in m) m[p[0]] = E(p[1], p[2])
        }
        m
    }
    private val ci: Map<String, E> by lazy { val m = HashMap<String, E>(); for ((k, v) in map) m.putIfAbsent(k.lowercase(), v); m }

    private val plainWords = setOf("pin", "ram", "rom", "led", "lan", "rip", "min", "api", "url", "sos", "dna", "rna", "era", "mmo")

    /** A whole input that is one abbreviation (any case). */
    fun whole(t: String): Pair<String, E>? {
        val x = t.trim().trimEnd('.', '!', '?')
        if (x.isEmpty() || x.length > 8 || x.contains(' ')) return null
        map[x]?.let { return Pair(x, it) }
        ci[x.lowercase()]?.let { e -> return Pair(x.uppercase(), e) }
        return null
    }

    /** Abbreviations inside a longer text (exact spelling only, so "ms" or "St" in a normal word are not mistaken). Max 6. */
    fun inText(t: String): List<Pair<String, E>> {
        val out = LinkedHashMap<String, E>()
        for (w in Regex("[A-Za-z0-9][A-Za-z0-9&/.;-]*").findAll(t)) {
            var k = w.value.trimEnd('.', ';', '-')
            Regex("^[0-9]+([.][0-9]+)?([A-Za-z/]+)$").find(k)?.let { k = it.groupValues[2] }   // 144Hz -> Hz
            if (k.length < 2 || k in out) continue
            var e = map[k]
            if (e == null && k.length >= 3 && k == k.lowercase() && k.lowercase() !in plainWords) {
                val u = ci[k]
                if (u != null && map.keys.any { it == k.uppercase() }) { e = u; k = k.uppercase() }
            }
            if (e == null) continue
            if (k.length <= 2 && k == k.lowercase() && k != "ms") continue
            // short ordinary-looking words stay normal words (Dr, St, Co, s, min …) unless written like an abbreviation
            if (k in setOf("Co", "St", "Dr", "Mr", "Ms", "Mrs", "min", "hr", "Inc", "Ltd", "Prof", "ID", "AM", "PM", "IP", "OP", "MC", "BC", "AD", "OS", "ER", "PR", "HR", "PC", "CD", "TV", "SD", "ML", "AI", "Q&A")) continue
            out[k] = e
            if (out.size >= 6) break
        }
        return out.map { Pair(it.key, it.value) }
    }

    fun line(k: String, e: E, d: String): String =
        if (d == "fa") "$k = ${e.full} — ${e.fa}" else "$k = ${e.full}"
}
