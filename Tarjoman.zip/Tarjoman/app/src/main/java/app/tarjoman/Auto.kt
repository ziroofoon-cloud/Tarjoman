package app.tarjoman

/**
 * Global "Auto" mode: when it is on, the engine (Normal / AI), the style (casual / formal) and the speed (fast / accurate)
 * are chosen for every text from the text itself and from where it comes from (live screen = fast and casual).
 * The user's own choices stay saved and come back when Auto is switched off.
 */
object Auto {
    @Volatile var mode: String? = null
    @Volatile var style: String? = null
    @Volatile var speed: String? = null
    @Volatile private var liveUntil = 0L

    /** The floating bubble / live camera call this on every pass: those need quick answers. */
    fun markLive() { liveUntil = System.currentTimeMillis() + 20_000 }
    private fun live() = System.currentTimeMillis() < liveUntil

    private val chatty = Regex("(?i)\\b(gonna|wanna|gotta|yeah|yep|nope|hey|lol|dude|ok|okay|damn|shit|fuck\\w*|c'mon|ain't|y'all|bro)\\b|\\b\\w+n't\\b|\\b(i|you|we|they|it|that|there)'(m|re|ll|ve|d|s)\\b|!|\\.\\.\\.")

    fun decide(cfg: Cfg, text: String, hasAi: Boolean) {
        if (cfg.auto == 0) { mode = null; style = null; speed = null; return }
        val len = text.length
        val live = live()
        val words = text.split(Regex("\\s+")).count { it.isNotBlank() }
        val sentences = text.split(Regex("[.!?؟]+\\s")).count { it.isNotBlank() }.coerceAtLeast(1)
        val avg = words.toFloat() / sentences
        val chat = chatty.containsMatchIn(text)
        style = when {
            live || chat -> "casual"
            avg >= 18f && len > 200 -> "formal"
            len < 120 -> "casual"
            else -> "formal"
        }
        mode = if (hasAi && !live && len <= 2500) "advanced" else "normal"
        speed = when {
            live -> "fast"
            len > 800 -> "fast"
            else -> "slow"
        }
    }
}
