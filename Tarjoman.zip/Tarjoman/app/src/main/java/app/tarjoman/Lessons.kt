package app.tarjoman

/** A step-by-step English course for Persian speakers (A1 -> B1). Format: "#level|title|note" then "word|meaning|example|example in Persian". */
object Lessons {
    class Item(val w: String, val fa: String, val ex: String, val exFa: String)
    class Unit(val id: Int, val level: String, val title: String, val note: String, val items: List<Item>)

    val units: List<Unit> by lazy {
        val out = ArrayList<Unit>()
        var lv = ""; var t = ""; var n = ""; var cur = ArrayList<Item>()
        fun flush() { if (t.isNotEmpty() && cur.isNotEmpty()) out.add(Unit(out.size, lv, t, n, cur)); cur = ArrayList() }
        for (line in DATA.lines()) {
            if (line.isBlank()) continue
            val p = line.split('|')
            if (line.startsWith("#")) {
                flush(); lv = p[0].substring(1); t = p[1]; n = p.getOrElse(2) { "" }
            } else if (p.size >= 4) cur.add(Item(p[0].trim(), p[1].trim(), p[2].trim(), p[3].trim()))
        }
        flush()
        out
    }

    private const val DATA = """
#A1|سلام و معرفی|فعل to be: I am / you are / he-she-it is / we-they are. برای سؤال جای فعل و فاعل عوض می‌شود: Are you ready؟ برای منفی not می‌گیرد: I am not tired.
hello|سلام|Hello, my name is Sara.|سلام، اسم من سارا است.
goodbye|خداحافظ|Goodbye, see you tomorrow.|خداحافظ، فردا می‌بینمت.
please|لطفاً|Please sit down.|لطفاً بنشین.
thanks|ممنون|Thanks for your help.|بابت کمکت ممنون.
sorry|ببخشید / متأسف|I am sorry I am late.|ببخشید که دیر کردم.
name|اسم|What is your name?|اسمت چیست؟
friend|دوست|He is my friend.|او دوست من است.
nice|خوب / دوست‌داشتنی|Nice to meet you.|از آشنایی با تو خوشحالم.
yes|بله|Yes, I am a student.|بله، من دانش‌آموزم.
no|نه|No, I am not hungry.|نه، من گرسنه نیستم.
#A1|اعداد ۱ تا ۱۰|اعداد را با هم و با اسم جمع به کار ببر: three books. بعد از عدد بالاتر از یک، اسم s جمع می‌گیرد.
one|یک|I have one brother.|من یک برادر دارم.
two|دو|Two coffees, please.|دو تا قهوه لطفاً.
three|سه|She has three cats.|او سه تا گربه دارد.
four|چهار|There are four chairs.|چهار تا صندلی هست.
five|پنج|It costs five dollars.|پنج دلار قیمت دارد.
six|شش|I wake up at six.|ساعت شش بیدار می‌شوم.
seven|هفت|There are seven days in a week.|یک هفته هفت روز دارد.
eight|هشت|School starts at eight.|مدرسه ساعت هشت شروع می‌شود.
nine|نه (عدد)|I have nine books.|من نه تا کتاب دارم.
ten|ده|Count to ten.|تا ده بشمار.
#A1|خانواده|my / your / his / her یعنی «مال من / تو / او». بعد از آن‌ها اسم می‌آید: my mother, her brother.
mother|مادر|My mother is a teacher.|مادرم معلم است.
father|پدر|My father works at a bank.|پدرم در بانک کار می‌کند.
brother|برادر|His brother is tall.|برادرش قدبلند است.
sister|خواهر|Her sister lives in Tehran.|خواهرش در تهران زندگی می‌کند.
son|پسر (فرزند)|They have a son.|آن‌ها یک پسر دارند.
daughter|دختر (فرزند)|Their daughter is five.|دخترشان پنج ساله است.
husband|شوهر|Her husband is a doctor.|شوهرش دکتر است.
wife|همسر (زن)|His wife is kind.|همسرش مهربان است.
parents|پدر و مادر|My parents are at home.|پدر و مادرم خانه‌اند.
family|خانواده|I love my family.|من خانواده‌ام را دوست دارم.
#A1|غذا و نوشیدنی|I like / I want بعد از خود اسم می‌آید. با اسم‌هایی که نمی‌شمریم (water, rice) a به کار نمی‌رود.
water|آب|Can I have some water?|می‌شود کمی آب بخورم؟
bread|نان|I eat bread for breakfast.|برای صبحانه نان می‌خورم.
rice|برنج|We have rice for dinner.|برای شام برنج داریم.
milk|شیر|She drinks milk every day.|او هر روز شیر می‌خورد.
tea|چای|Would you like some tea?|چای می‌خواهی؟
coffee|قهوه|I need a coffee.|یک قهوه لازم دارم.
apple|سیب|This apple is sweet.|این سیب شیرین است.
chicken|مرغ|The chicken is delicious.|مرغ خوشمزه است.
egg|تخم‌مرغ|I want two eggs.|دو تا تخم‌مرغ می‌خواهم.
hungry|گرسنه|I am very hungry.|من خیلی گرسنه‌ام.
#A1|رنگ‌ها و توصیف|صفت قبل از اسم می‌آید و جمع نمی‌شود: a red car, two red cars.
red|قرمز|She has a red bag.|او کیف قرمز دارد.
blue|آبی|The sky is blue.|آسمان آبی است.
green|سبز|I like green tea.|چای سبز دوست دارم.
black|سیاه|He wears a black coat.|او کت مشکی می‌پوشد.
white|سفید|The wall is white.|دیوار سفید است.
big|بزرگ|It is a big house.|خانهٔ بزرگی است.
small|کوچک|I have a small room.|اتاق کوچکی دارم.
new|جدید|This is my new phone.|این گوشی جدید من است.
old|قدیمی / پیر|That is an old car.|آن ماشین قدیمی است.
beautiful|زیبا|What a beautiful day!|چه روز زیبایی!
#A1|فعل‌های روزمره|برای he / she / it به فعل s می‌چسبد: I work, she works. منفی با do not / does not ساخته می‌شود: She does not work.
eat|خوردن|We eat lunch at one.|ساعت یک ناهار می‌خوریم.
drink|نوشیدن|I drink tea every morning.|هر صبح چای می‌نوشم.
sleep|خوابیدن|He sleeps eight hours.|او هشت ساعت می‌خوابد.
work|کار کردن|She works in a shop.|او در یک مغازه کار می‌کند.
go|رفتن|I go to school by bus.|با اتوبوس به مدرسه می‌روم.
come|آمدن|Come here, please.|لطفاً بیا اینجا.
read|خواندن|I read a book every week.|هر هفته یک کتاب می‌خوانم.
write|نوشتن|Write your name here.|اسمت را اینجا بنویس.
like|دوست داشتن|I like football.|فوتبال را دوست دارم.
live|زندگی کردن|They live in Shiraz.|آن‌ها در شیراز زندگی می‌کنند.
#A1|مکان‌ها و حرف اضافه|in = داخل، on = روی، at = در (نقطه)، under = زیر، next to = کنار. The book is on the table.
home|خانه|I am at home.|من در خانه‌ام.
school|مدرسه|The school is near here.|مدرسه نزدیک اینجاست.
shop|مغازه|The shop is closed.|مغازه بسته است.
street|خیابان|Our street is quiet.|خیابان ما ساکت است.
city|شهر|Tehran is a big city.|تهران شهر بزرگی است.
room|اتاق|My room is clean.|اتاقم تمیز است.
table|میز|The keys are on the table.|کلیدها روی میز هستند.
door|در|Close the door.|در را ببند.
near|نزدیک|The bank is near the park.|بانک نزدیک پارک است.
far|دور|The airport is far.|فرودگاه دور است.
#A1|زمان و روزها|برای ساعت از at، برای روز از on و برای ماه از in استفاده کن: at 5, on Monday, in May.
today|امروز|Today is Friday.|امروز جمعه است.
tomorrow|فردا|See you tomorrow.|فردا می‌بینمت.
yesterday|دیروز|I was busy yesterday.|دیروز سرم شلوغ بود.
morning|صبح|Good morning!|صبح بخیر!
night|شب|I study at night.|شب‌ها درس می‌خوانم.
week|هفته|I go there every week.|هر هفته آنجا می‌روم.
month|ماه (تقویمی)|This month is busy.|این ماه شلوغ است.
year|سال|He is twenty years old.|او بیست ساله است.
now|حالا|I am busy now.|الان سرم شلوغ است.
early|زود|I wake up early.|زود بیدار می‌شوم.
#A2|گذشتهٔ ساده|فعل‌های باقاعده ed می‌گیرند: walk → walked. فعل‌های بی‌قاعده شکل خاصی دارند: go → went, eat → ate. منفی و سؤال با did: Did you go؟ I did not go.
went|رفتم (گذشتهٔ go)|I went to Isfahan last year.|پارسال به اصفهان رفتم.
ate|خوردم (گذشتهٔ eat)|We ate pizza yesterday.|دیروز پیتزا خوردیم.
saw|دیدم (گذشتهٔ see)|I saw him at the park.|او را در پارک دیدم.
bought|خریدم (گذشتهٔ buy)|She bought a new dress.|او یک لباس نو خرید.
made|ساختم (گذشتهٔ make)|He made a cake.|او کیک درست کرد.
took|گرفتم (گذشتهٔ take)|I took a taxi.|تاکسی گرفتم.
had|داشتم (گذشتهٔ have)|We had a great time.|خیلی خوش گذشت.
said|گفتم (گذشتهٔ say)|She said nothing.|او چیزی نگفت.
came|آمدم (گذشتهٔ come)|They came late.|آن‌ها دیر آمدند.
knew|دانستم (گذشتهٔ know)|I knew the answer.|جواب را می‌دانستم.
#A2|آینده با will و going to|will برای تصمیم لحظه‌ای و پیش‌بینی، going to برای برنامه‌ای که از قبل داری: I am going to visit my aunt. It will rain.
plan|برنامه / قصد داشتن|We plan to travel in summer.|قصد داریم تابستان سفر کنیم.
maybe|شاید|Maybe I will call you.|شاید بهت زنگ بزنم.
soon|به زودی|He will arrive soon.|او به زودی می‌رسد.
later|بعداً|I will tell you later.|بعداً بهت می‌گویم.
next|بعدی|See you next week.|هفتهٔ بعد می‌بینمت.
decide|تصمیم گرفتن|I decided to stay.|تصمیم گرفتم بمانم.
promise|قول دادن|I promise I will come.|قول می‌دهم بیایم.
hope|امیدوار بودن|I hope you feel better.|امیدوارم حالت بهتر شود.
expect|انتظار داشتن|I expect it to rain.|انتظار دارم بارانی شود.
ready|آماده|Are you ready to go?|آماده‌ای برویم؟
#A2|خرید و پول|How much is it؟ = قیمتش چقدر است؟ How many + اسم قابل شمارش، How much + اسم غیرقابل شمارش.
price|قیمت|The price is too high.|قیمت خیلی بالاست.
cheap|ارزان|This shirt is cheap.|این پیراهن ارزان است.
expensive|گران|That phone is expensive.|آن گوشی گران است.
pay|پرداخت کردن|Can I pay by card?|می‌توانم با کارت پرداخت کنم؟
buy|خریدن|I want to buy a jacket.|می‌خواهم یک ژاکت بخرم.
sell|فروختن|They sell fresh fruit.|آن‌ها میوهٔ تازه می‌فروشند.
change|پول خرد / تغییر|Keep the change.|بقیه‌اش مال شما.
size|اندازه / سایز|What size do you wear?|چه سایزی می‌پوشی؟
discount|تخفیف|Is there a discount?|تخفیف دارد؟
receipt|رسید|Can I have the receipt?|رسید می‌شود؟
#A2|سفر و راه‌یابی|برای سؤال مسیر: Where is...؟ How can I get to...؟ Turn left / right, go straight.
ticket|بلیت|I need two tickets.|دو تا بلیت لازم دارم.
station|ایستگاه|Where is the station?|ایستگاه کجاست؟
airport|فرودگاه|We arrive at the airport at six.|ساعت شش به فرودگاه می‌رسیم.
map|نقشه|Do you have a map?|نقشه داری؟
straight|مستقیم|Go straight for two blocks.|دو بلوک مستقیم برو.
corner|گوشه / پیچ|The bank is on the corner.|بانک سر گوشه است.
lost|گم‌شده|I am lost.|گم شده‌ام.
luggage|بار / چمدان|Where is my luggage?|چمدانم کجاست؟
passport|گذرنامه|Show me your passport.|گذرنامه‌ات را نشان بده.
hotel|هتل|We stayed at a small hotel.|در یک هتل کوچک ماندیم.
#A2|سلامت و بدن|I have a headache = سردرد دارم (فعل have، نه be). It hurts = درد می‌کند.
head|سر|My head hurts.|سرم درد می‌کند.
hand|دست|Wash your hands.|دست‌هایت را بشور.
eye|چشم|She has blue eyes.|او چشم‌های آبی دارد.
stomach|معده / شکم|My stomach hurts.|دل‌درد دارم.
fever|تب|He has a high fever.|او تب بالایی دارد.
cough|سرفه|I have a bad cough.|سرفهٔ بدی دارم.
medicine|دارو|Take this medicine twice a day.|این دارو را روزی دو بار بخور.
doctor|دکتر|I need to see a doctor.|باید دکتر بروم.
sick|بیمار|She is sick today.|او امروز مریض است.
rest|استراحت|You need to rest.|باید استراحت کنی.
#A2|مقایسه|صفت کوتاه + er: taller. صفت بلند: more interesting. بالاترین: the tallest / the most interesting. than یعنی «از».
better|بهتر|This is better than that.|این از آن بهتر است.
worse|بدتر|The weather is worse today.|هوا امروز بدتر است.
faster|سریع‌تر|A car is faster than a bike.|ماشین از دوچرخه سریع‌تر است.
bigger|بزرگ‌تر|My room is bigger than yours.|اتاق من از اتاق تو بزرگ‌تر است.
cheaper|ارزان‌تر|This one is cheaper.|این یکی ارزان‌تر است.
easier|آسان‌تر|English is easier than I thought.|انگلیسی از چیزی که فکر می‌کردم آسان‌تر است.
the best|بهترین|She is the best student.|او بهترین دانش‌آموز است.
the most|بیشترین|He has the most books.|او بیشترین کتاب را دارد.
same|یکسان|We have the same phone.|ما گوشی یکسانی داریم.
different|متفاوت|This is different from that.|این با آن متفاوت است.
#A2|عادت و تکرار|قید تکرار قبل از فعل اصلی می‌آید: I always wake up early. (always, usually, often, sometimes, never)
always|همیشه|She always smiles.|او همیشه لبخند می‌زند.
usually|معمولاً|I usually walk to work.|معمولاً پیاده به سر کار می‌روم.
often|اغلب|We often eat out.|اغلب بیرون غذا می‌خوریم.
sometimes|گاهی|Sometimes I stay home.|گاهی خانه می‌مانم.
never|هرگز|He never drinks coffee.|او هرگز قهوه نمی‌خورد.
every day|هر روز|I study every day.|هر روز درس می‌خوانم.
habit|عادت|Reading is a good habit.|مطالعه عادت خوبی است.
routine|روال روزانه|My morning routine is simple.|روال صبح من ساده است.
once|یک بار|I go there once a week.|هفته‌ای یک بار آنجا می‌روم.
twice|دو بار|I called him twice.|دو بار بهش زنگ زدم.
#B1|حال کامل: have / has + p.p.|برای تجربه و نتیجهٔ حاضر: I have seen it. She has lost her keys. با for (مدت) و since (از چه زمانی): I have lived here for 5 years / since 2020.
experience|تجربه|I have a lot of experience.|تجربهٔ زیادی دارم.
already|قبلاً / تا حالا|I have already eaten.|قبلاً غذا خورده‌ام.
yet|هنوز (در سؤال و منفی)|Have you finished yet?|هنوز تمام نکرده‌ای؟
ever|تا به حال|Have you ever been to Turkey?|تا به حال ترکیه رفته‌ای؟
just|همین الان|I have just arrived.|همین الان رسیده‌ام.
since|از (زمان)|I have known him since 2015.|از سال ۲۰۱۵ او را می‌شناسم.
for|به مدت|We waited for an hour.|یک ساعت منتظر ماندیم.
recently|اخیراً|I have recently moved.|اخیراً اسباب‌کشی کرده‌ام.
so far|تا حالا|So far, so good.|تا اینجا که خوب است.
finish|تمام کردن|I have finished my work.|کارم را تمام کرده‌ام.
#B1|کار و شغل|job = شغل (قابل شمارش)، work = کار (غیرقابل شمارش): I have a job. I have a lot of work.
job|شغل|He is looking for a job.|او دنبال کار می‌گردد.
manager|مدیر|The manager is busy.|مدیر سرش شلوغ است.
meeting|جلسه|We have a meeting at ten.|ساعت ده جلسه داریم.
salary|حقوق|The salary is good.|حقوقش خوب است.
colleague|همکار|My colleague helped me.|همکارم کمکم کرد.
deadline|ضرب‌الاجل|The deadline is Friday.|مهلت تحویل جمعه است.
apply|درخواست دادن|I applied for the job.|برای این کار درخواست دادم.
experience|سابقه|She has five years of experience.|او پنج سال سابقه دارد.
interview|مصاحبه|I have an interview tomorrow.|فردا مصاحبه دارم.
resign|استعفا دادن|He decided to resign.|او تصمیم گرفت استعفا بدهد.
#B1|نظر دادن و موافقت|I think / I believe / In my opinion + جمله. موافقت: I agree. مخالفت مؤدبانه: I see your point, but...
opinion|نظر|In my opinion, it is a good idea.|به نظر من ایدهٔ خوبی است.
agree|موافق بودن|I agree with you.|با تو موافقم.
disagree|مخالف بودن|I disagree with that.|با آن مخالفم.
suggest|پیشنهاد دادن|I suggest we leave early.|پیشنهاد می‌کنم زود برویم.
argue|بحث کردن|They argue about money.|آن‌ها سر پول بحث می‌کنند.
believe|باور داشتن|I believe you.|باورت می‌کنم.
depend|بستگی داشتن|It depends on the weather.|بستگی به هوا دارد.
prefer|ترجیح دادن|I prefer tea to coffee.|چای را به قهوه ترجیح می‌دهم.
matter|مهم بودن|It does not matter.|مهم نیست.
point|نکته|That is a good point.|نکتهٔ خوبی است.
#B1|عبارت‌های دوکلمه‌ای (Phrasal verbs)|فعل + حرف اضافه معنی تازه می‌سازد: give up = تسلیم شدن، look for = دنبال گشتن. حفظ کردنش با جمله بهتر است.
give up|تسلیم شدن / ترک کردن|Never give up on your dreams.|هرگز رؤیاهایت را رها نکن.
look for|دنبال ... گشتن|I am looking for my keys.|دنبال کلیدهایم می‌گردم.
find out|فهمیدن / کشف کردن|I found out the truth.|حقیقت را فهمیدم.
turn on|روشن کردن|Turn on the light.|چراغ را روشن کن.
turn off|خاموش کردن|Turn off the TV.|تلویزیون را خاموش کن.
get up|بلند شدن از خواب|I get up at six.|ساعت شش بیدار می‌شوم.
carry on|ادامه دادن|Carry on, please.|لطفاً ادامه بده.
run out of|تمام شدن|We ran out of milk.|شیرمان تمام شد.
come back|برگشتن|When will you come back?|کی برمی‌گردی؟
take care of|مراقبت کردن از|She takes care of her mother.|او از مادرش مراقبت می‌کند.
#B1|احساسات|صفت‌های ed حال خود فرد را می‌گویند (bored) و صفت‌های ing ویژگی چیز را (boring): I am bored. The film is boring.
excited|هیجان‌زده|I am excited about the trip.|دربارهٔ سفر هیجان‌زده‌ام.
bored|بی‌حوصله|I am bored.|حوصله‌ام سر رفته.
worried|نگران|She is worried about the exam.|او نگران امتحان است.
proud|مفتخر|I am proud of you.|به تو افتخار می‌کنم.
jealous|حسود|He is jealous of his friend.|او به دوستش حسودی می‌کند.
embarrassed|خجالت‌زده|I felt embarrassed.|خجالت کشیدم.
nervous|مضطرب|I am nervous before exams.|قبل از امتحان استرس دارم.
confused|گیج|I am confused.|گیج شده‌ام.
lonely|تنها (احساس تنهایی)|He felt lonely.|او احساس تنهایی کرد.
relieved|خیالش راحت شد|I am so relieved.|خیلی خیالم راحت شد.
"""
}
