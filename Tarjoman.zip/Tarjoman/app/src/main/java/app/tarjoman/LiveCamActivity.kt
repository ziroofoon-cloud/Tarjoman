package app.tarjoman

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.YuvImage
import android.hardware.Camera
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.Executors

/**
 * Live camera translation: the camera preview with the translation drawn on top of the text, like Google Lens.
 * About twice a second one preview frame is read (OCR) and the new texts are translated; texts that did not change
 * keep their translation. "Freeze" holds the picture (tap a text to copy it); "High quality photo" takes a full
 * size picture and hands it to the Image tab (zoomable viewer, save, translate again).
 * Uses the classic Camera API, so no extra library is needed.
 */
@Suppress("DEPRECATION")
class LiveCamActivity : Activity(), SurfaceHolder.Callback, Camera.PreviewCallback {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var cfg: Cfg
    private lateinit var tr: Tr
    private lateinit var ui: Ui
    private var savedMode: String? = null

    private var cam: Camera? = null
    private var camInfo = Camera.CameraInfo()
    private var rot = 90
    private var pw = 0
    private var ph = 0
    private var holder: SurfaceHolder? = null
    private var surfaceReady = false
    private var permOk = false

    private lateinit var stage: FrameLayout
    private lateinit var surface: SurfaceView
    private lateinit var overlay: OverlayView
    private lateinit var status: TextView
    private lateinit var srcBtn: TextView
    private lateinit var dstBtn: TextView
    private lateinit var freezeBtn: TextView
    private lateinit var flashBtn: TextView

    private val worker = Executors.newSingleThreadExecutor()
    @Volatile private var busy = false
    @Volatile private var frozen = false
    @Volatile private var lastMs = 0L
    @Volatile private var shown: List<OBlock> = emptyList()
    @Volatile private var lastBmp: Bitmap? = null
    private var emptyN = 0
    private var torch = false

    override fun onCreate(savedInstanceState: Bundle?) {
        cfg = Cfg(this)
        C.setup(this, cfg)
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        ui = Ui(this)
        tr = Tr.get(this)
        // Live translation has to be quick: the fast Normal engine is used while this screen is open.
        if (cfg.mode == "advanced") { savedMode = cfg.mode; cfg.mode = "normal" }
        try {
            val old = System.currentTimeMillis() - 24L * 3600 * 1000
            cacheDir.listFiles()?.filter { it.name.startsWith("live_") && it.lastModified() < old }?.forEach { it.delete() }
        } catch (_: Throwable) {}

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        stage = FrameLayout(this)
        surface = SurfaceView(this)
        surface.holder.addCallback(this)
        stage.addView(surface, FrameLayout.LayoutParams(-1, -1))
        overlay = OverlayView(this)
        overlay.setOnTouchListener { _, e ->
            if (frozen && e.actionMasked == MotionEvent.ACTION_UP) {
                val x = (e.x / overlay.sc).toInt()
                val y = (e.y / overlay.sc).toInt()
                shown.firstOrNull { it.rect.contains(x, y) }?.let { showBlock(it) }
            }
            true
        }
        stage.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        root.addView(stage, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))

        val top = ui.hbox()
        top.setPadding(ui.dp(8), ui.dp(30), ui.dp(8), ui.dp(8))
        top.setBackgroundColor(0x99000000.toInt())
        top.addView(ui.btn(L("بستن"), false) { finish() }, ui.hlp(0.8f))
        srcBtn = ui.btn("", false) { cfg.src = nextLang(cfg.src, cfg.dst); refreshLang() }
        dstBtn = ui.btn("", false) { cfg.dst = nextLang(cfg.dst, cfg.src); refreshLang() }
        top.addView(srcBtn, ui.hlp(1f, 6))
        top.addView(ui.btn("⇄", false) { val a = cfg.src; cfg.src = cfg.dst; cfg.dst = a; refreshLang() }, ui.hlp(0.6f, 6))
        top.addView(dstBtn, ui.hlp(1f, 6))
        flashBtn = ui.btn(L("چراغ"), false) { toggleTorch() }
        top.addView(flashBtn, ui.hlp(0.8f, 6))
        root.addView(top, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        val bottom = ui.vbox()
        bottom.setPadding(ui.dp(12), ui.dp(8), ui.dp(12), ui.dp(22))
        bottom.setBackgroundColor(0x99000000.toInt())
        status = ui.tv(L("دوربین را روی متن بگیر؛ ترجمه روی نوشته‌ها می‌نشیند."), 12f, Color.WHITE)
        bottom.addView(status)
        val br = ui.hbox()
        freezeBtn = ui.btn(L("ثابت کن"), false) { toggleFreeze() }
        br.addView(freezeBtn, ui.hlp())
        br.addView(ui.btn(L("عکس با کیفیت بالا")) { capture() }, ui.hlp(1.4f, 8))
        bottom.addView(br, ui.lp(top = 6))
        root.addView(bottom, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)
        refreshLang()

        permOk = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        if (!permOk) requestPermissions(arrayOf(Manifest.permission.CAMERA), 1)
    }

    private fun toast(m: String) { h.post { Toast.makeText(this, m, Toast.LENGTH_LONG).show() } }

    private fun refreshLang() {
        srcBtn.text = Lang.name(cfg.src).substringBefore(" ·")
        dstBtn.text = Lang.name(cfg.dst).substringBefore(" ·")
        // the old translations belong to the old languages
        shown = emptyList()
        overlay.blocks = emptyList()
        overlay.invalidate()
    }

    private fun nextLang(cur: String, other: String): String {
        val all = Lang.all
        var i = all.indexOf(cur)
        repeat(all.size) {
            i = (i + 1) % all.size
            if (all[i] != other) return all[i]
        }
        return cur
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        permOk = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        if (permOk) tryOpen() else { toast(L("اجازهٔ دوربین داده نشد.")); finish() }
    }

    // ------------------------------------------------------------ camera
    private fun tryOpen() {
        if (cam != null || !permOk || !surfaceReady) return
        try {
            var id = -1
            for (i in 0 until Camera.getNumberOfCameras()) {
                val inf = Camera.CameraInfo()
                Camera.getCameraInfo(i, inf)
                if (inf.facing == Camera.CameraInfo.CAMERA_FACING_BACK) { id = i; camInfo = inf; break }
            }
            if (id < 0) { toast(L("دوربین پشت پیدا نشد.")); finish(); return }
            val c = Camera.open(id)
            val p = c.parameters
            val dm = resources.displayMetrics
            val want = dm.heightPixels.toFloat() / dm.widthPixels
            val all = p.supportedPreviewSizes
            val small = all.filter { it.width <= 1280 }
            val list = if (small.isEmpty()) all else small
            val bestRatio = list.minOf { Math.abs(it.width.toFloat() / it.height - want) }
            val best = list.filter { Math.abs(it.width.toFloat() / it.height - want) <= bestRatio + 0.12f }.maxByOrNull { it.width * it.height } ?: list[0]
            p.setPreviewSize(best.width, best.height)
            p.previewFormat = ImageFormat.NV21
            pw = best.width
            ph = best.height
            if (p.supportedFocusModes?.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE) == true) p.focusMode = Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE
            // the big picture of the "high quality photo" button
            val pic = p.supportedPictureSizes.filter { it.width.toLong() * it.height <= 13_000_000L }.maxByOrNull { it.width.toLong() * it.height }
            if (pic != null) p.setPictureSize(pic.width, pic.height)
            p.setRotation(camInfo.orientation)
            c.parameters = p
            rot = camInfo.orientation
            c.setDisplayOrientation(rot)
            cam = c
            layoutStage()
            c.setPreviewCallback(this)
            startPreview()
        } catch (e: Throwable) {
            toast(L("باز کردن دوربین ممکن نشد: ") + (e.message ?: ""))
            finish()
        }
    }

    /** The preview and the overlay share one box that keeps the picture's shape, so text positions map 1:1. */
    private fun layoutStage() {
        val swap = rot % 180 != 0
        val uw = if (swap) ph else pw
        val uh = if (swap) pw else ph
        if (uw <= 0 || uh <= 0) return
        val dm = resources.displayMetrics
        val k = Math.min(dm.widthPixels.toFloat() / uw, dm.heightPixels.toFloat() / uh)
        val w = (uw * k).toInt()
        val hh = (uh * k).toInt()
        stage.layoutParams = FrameLayout.LayoutParams(w, hh, Gravity.CENTER)
        overlay.sc = w.toFloat() / uw
    }

    private fun startPreview() {
        val c = cam ?: return
        val hd = holder ?: return
        try { c.stopPreview() } catch (_: Throwable) {}
        try {
            c.setPreviewDisplay(hd)
            c.startPreview()
        } catch (e: Throwable) {
            toast(L("باز کردن دوربین ممکن نشد: ") + (e.message ?: ""))
        }
    }

    private fun releaseCam() {
        val c = cam ?: return
        cam = null
        try { c.setPreviewCallback(null); c.stopPreview() } catch (_: Throwable) {}
        try { c.release() } catch (_: Throwable) {}
    }

    override fun surfaceCreated(hd: SurfaceHolder) { holder = hd; surfaceReady = true; tryOpen() }
    override fun surfaceChanged(hd: SurfaceHolder, format: Int, width: Int, height: Int) { holder = hd; if (cam != null && !frozen) startPreview() }
    override fun surfaceDestroyed(hd: SurfaceHolder) { surfaceReady = false; holder = null; releaseCam() }

    override fun onResume() { super.onResume(); tryOpen() }
    override fun onPause() { releaseCam(); super.onPause() }

    override fun onDestroy() {
        savedMode?.let { cfg.mode = it }
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun toggleTorch() {
        val c = cam ?: return
        try {
            val p = c.parameters
            torch = !torch
            p.flashMode = if (torch) Camera.Parameters.FLASH_MODE_TORCH else Camera.Parameters.FLASH_MODE_OFF
            c.parameters = p
        } catch (_: Throwable) { torch = false; toast(L("این گوشی چراغ ندارد یا روشن نشد.")) }
    }

    // ------------------------------------------------------------ live reading + translating
    override fun onPreviewFrame(data: ByteArray?, camera: Camera?) {
        if (data == null || frozen || busy) return
        val now = SystemClock.uptimeMillis()
        if (now - lastMs < 500) return
        lastMs = now
        busy = true
        val copy = data.copyOf()
        val s = cfg.src
        val d = cfg.dst
        val w = pw
        val hh = ph
        val r = rot
        worker.execute {
            try { process(copy, w, hh, r, s, d) } catch (_: Throwable) {} finally { busy = false }
        }
    }

    private fun toBitmap(data: ByteArray, w: Int, hh: Int, r: Int): Bitmap? {
        val yuv = YuvImage(data, ImageFormat.NV21, w, hh, null)
        val os = ByteArrayOutputStream()
        yuv.compressToJpeg(Rect(0, 0, w, hh), 85, os)
        val b = BitmapFactory.decodeByteArray(os.toByteArray(), 0, os.size()) ?: return null
        if (r == 0) return b
        val m = Matrix()
        m.postRotate(r.toFloat())
        return Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
    }

    private fun key(t: String): String = t.lowercase().filter { it.isLetterOrDigit() }

    private fun iou(a: Rect, b: Rect): Float {
        val i = Rect()
        if (!i.setIntersect(a, b)) return 0f
        val ia = i.width() * i.height().toFloat()
        val u = a.width() * a.height() + b.width() * b.height() - ia
        return if (u <= 0f) 0f else ia / u
    }

    private fun process(data: ByteArray, w: Int, hh: Int, r: Int, s: String, d: String) {
        val bmp = toBitmap(data, w, hh, r) ?: return
        val t0 = SystemClock.uptimeMillis()
        val blocks = try {
            Ocr.readLive(bmp, s)
        } catch (e: Throwable) {
            h.post { status.text = L("خطا: ") + (e.message ?: "") }
            return
        }
        if (frozen) return
        val prev = shown
        val todo = ArrayList<OBlock>()
        for (b in blocks) {
            val k = key(b.text)
            val old = prev.firstOrNull { it.out.isNotEmpty() && key(it.text) == k && iou(it.rect, b.rect) > 0.3f }
            if (old != null) b.out = old.out else todo.add(b)
        }
        var err: String? = null
        if (todo.isNotEmpty()) {
            val res = tr.translateMany(todo.map { it.text }, s, d, false) { }
            err = res.second
            todo.forEachIndexed { i, b -> b.out = res.first.getOrElse(i) { b.text } }
        }
        if (frozen) return
        val keep = blocks.filter { it.out.isNotEmpty() }
        val ms = SystemClock.uptimeMillis() - t0
        h.post {
            if (frozen) return@post
            if (keep.isEmpty() && shown.isNotEmpty() && emptyN < 2) {
                emptyN++   // one empty frame is often just a blur: keep the last result a little longer
            } else {
                emptyN = 0
                shown = keep
                lastBmp = bmp
                overlay.blocks = keep
                overlay.invalidate()
            }
            status.text = if (err != null) L("خطا: ") + err
            else L("ترجمهٔ زنده") + " · " + Lang.name(s).substringBefore(" ·") + " → " + Lang.name(d).substringBefore(" ·") + " · " + keep.size + L(" متن") + " · " + ms + " ms"
        }
    }

    // ------------------------------------------------------------ freeze / capture
    private fun toggleFreeze() {
        if (!frozen) {
            val b = lastBmp
            if (b == null || shown.isEmpty()) { toast(L("هنوز چیزی ترجمه نشده؛ دوربین را روی متن بگیر.")); return }
            frozen = true
            overlay.back = b
            overlay.invalidate()
            try { cam?.stopPreview() } catch (_: Throwable) {}
            freezeBtn.text = L("ادامه")
            status.text = L("ثابت شد؛ روی هر متن بزن تا کپی کنی.")
        } else {
            frozen = false
            overlay.back = null
            overlay.invalidate()
            freezeBtn.text = L("ثابت کن")
            startPreview()
        }
    }

    private fun showBlock(b: OBlock) {
        val msg = L("اصل:") + "\n" + b.text + "\n\n" + L("ترجمه:") + "\n" + b.out
        AlertDialog.Builder(this).setMessage(msg)
            .setPositiveButton(L("کپی ترجمه")) { _, _ ->
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("tr", b.out)); toast(L("کپی شد"))
            }
            .setNeutralButton(L("کپی متن اصلی")) { _, _ ->
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("src", b.text)); toast(L("کپی شد"))
            }
            .setNegativeButton(L("بستن"), null).show()
    }

    /** Full size picture -> Image tab (better reading, zoomable Lens-style viewer, save, translate again). */
    private fun capture() {
        val c = cam ?: return
        frozen = true
        status.text = L("در حال گرفتن عکس…")
        try {
            c.takePicture(null, null, Camera.PictureCallback { data, _ ->
                try {
                    val f = File(cacheDir, "live_" + System.currentTimeMillis() + ".jpg")
                    f.writeBytes(data)
                    setResult(RESULT_OK, Intent().putExtra("path", f.absolutePath))
                } catch (e: Throwable) {
                    toast(L("ذخیرهٔ عکس ممکن نشد."))
                }
                finish()
            })
        } catch (e: Throwable) {
            frozen = false
            toast(L("خطا: ") + (e.message ?: ""))
        }
    }

    /** Draws the (frozen) picture and, on top, every translation over its text. */
    private class OverlayView(c: Context) : View(c) {
        @Volatile var blocks: List<OBlock> = emptyList()
        @Volatile var back: Bitmap? = null
        var sc = 1f
        override fun onDraw(cv: Canvas) {
            cv.save()
            cv.scale(sc, sc)
            back?.let { cv.drawBitmap(it, 0f, 0f, null) }
            for (b in blocks) Ocr.draw(cv, b, 1f)
            cv.restore()
        }
    }
}
