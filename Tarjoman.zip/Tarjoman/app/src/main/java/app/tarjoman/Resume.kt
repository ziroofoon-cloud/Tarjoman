package app.tarjoman

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Rect
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

/**
 * Keeps unfinished work (subtitle file, PDF, picture) on the phone, so closing the app does not lose
 * what was already translated and the work can be continued later. Files live in filesDir/resume.
 */
object Resume {
    private val io = Executors.newSingleThreadExecutor()
    private fun dir(ctx: Context) = File(ctx.filesDir, "resume").apply { mkdirs() }

    /** Runs the (slow) disk work on one background thread, in order. */
    fun async(f: () -> Unit) { io.execute { try { f() } catch (_: Throwable) {} } }

    private fun write(f: File, s: String) {
        val t = File(f.path + ".tmp")
        t.writeText(s, Charsets.UTF_8)
        if (!t.renameTo(f)) { f.delete(); t.renameTo(f) }
    }

    // ---------------------------------------------------------------- subtitles
    class SrtState(val cues: List<Cue>, val texts: List<String?>, val s: String, val d: String)

    @Synchronized
    fun saveSrt(ctx: Context, cues: List<Cue>, texts: List<String?>, s: String, d: String) {
        val o = JSONObject()
        o.put("s", s)
        o.put("d", d)
        val c = JSONArray()
        for (q in cues) c.put(JSONArray().put(q.idx).put(q.time).put(q.text))
        o.put("cues", c)
        val t = JSONArray()
        for (x in texts) t.put(x ?: JSONObject.NULL)
        o.put("texts", t)
        write(File(dir(ctx), "srt.json"), o.toString())
    }

    @Synchronized
    fun loadSrt(ctx: Context): SrtState? {
        val f = File(dir(ctx), "srt.json")
        if (!f.exists()) return null
        return try {
            val o = JSONObject(f.readText(Charsets.UTF_8))
            val c = o.getJSONArray("cues")
            val cues = ArrayList<Cue>()
            for (i in 0 until c.length()) {
                val a = c.getJSONArray(i)
                cues.add(Cue(a.getString(0), a.getString(1), a.getString(2)))
            }
            val t = o.getJSONArray("texts")
            val texts = ArrayList<String?>()
            for (i in 0 until t.length()) texts.add(if (t.isNull(i)) null else t.getString(i))
            if (cues.isEmpty()) null else SrtState(cues, texts, o.optString("s", "en"), o.optString("d", "fa"))
        } catch (_: Throwable) { null }
    }

    @Synchronized
    fun clearSrt(ctx: Context) { File(dir(ctx), "srt.json").delete() }

    // ---------------------------------------------------------------- PDF
    class PdfState(
        val uri: String, val name: String, val pages: Int, val next: Int,
        val tr: String, val orig: String, val bi: String, val s: String, val d: String
    )

    @Synchronized
    fun savePdf(ctx: Context, uri: String, name: String, pages: Int, next: Int, tr: String, orig: String, bi: String, s: String, d: String) {
        val o = JSONObject()
        o.put("uri", uri); o.put("name", name); o.put("pages", pages); o.put("next", next)
        o.put("tr", tr); o.put("orig", orig); o.put("bi", bi); o.put("s", s); o.put("d", d)
        write(File(dir(ctx), "pdf.json"), o.toString())
    }

    @Synchronized
    fun loadPdf(ctx: Context): PdfState? {
        val f = File(dir(ctx), "pdf.json")
        if (!f.exists()) return null
        return try {
            val o = JSONObject(f.readText(Charsets.UTF_8))
            PdfState(
                o.getString("uri"), o.optString("name", "PDF"), o.optInt("pages", 0), o.optInt("next", 0),
                o.optString("tr", ""), o.optString("orig", ""), o.optString("bi", ""), o.optString("s", "en"), o.optString("d", "fa")
            )
        } catch (_: Throwable) { null }
    }

    @Synchronized
    fun clearPdf(ctx: Context) { File(dir(ctx), "pdf.json").delete() }

    // ---------------------------------------------------------------- picture
    class ImgState(val bmp: Bitmap, val blocks: List<OBlock>, val s: String, val d: String)

    fun imageFile(ctx: Context) = File(dir(ctx), "img.jpg")

    /** [withPicture]: also store the picture itself (needed once, right after it was read). */
    @Synchronized
    fun saveImage(ctx: Context, bmp: Bitmap, blocks: List<OBlock>, s: String, d: String, withPicture: Boolean) {
        val jf = imageFile(ctx)
        if (withPicture || !jf.exists()) {
            jf.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        }
        val o = JSONObject()
        o.put("s", s)
        o.put("d", d)
        val a = JSONArray()
        for (b in blocks) {
            val j = JSONObject()
            j.put("l", b.rect.left); j.put("t", b.rect.top); j.put("r", b.rect.right); j.put("b", b.rect.bottom)
            j.put("text", b.text); j.put("bg", b.bg); j.put("out", b.out)
            a.put(j)
        }
        o.put("blocks", a)
        write(File(dir(ctx), "img.json"), o.toString())
    }

    @Synchronized
    fun loadImage(ctx: Context): ImgState? {
        val jf = imageFile(ctx)
        val f = File(dir(ctx), "img.json")
        if (!jf.exists() || !f.exists()) return null
        return try {
            val o = JSONObject(f.readText(Charsets.UTF_8))
            val bmp = BitmapFactory.decodeFile(jf.path) ?: return null
            val a = o.getJSONArray("blocks")
            val list = ArrayList<OBlock>()
            for (i in 0 until a.length()) {
                val j = a.getJSONObject(i)
                val b = OBlock(Rect(j.getInt("l"), j.getInt("t"), j.getInt("r"), j.getInt("b")), j.getString("text"), j.getInt("bg"))
                b.out = j.optString("out", "")
                list.add(b)
            }
            if (list.isEmpty()) null else ImgState(bmp, list, o.optString("s", "en"), o.optString("d", "fa"))
        } catch (_: Throwable) { null }
    }

    @Synchronized
    fun clearImage(ctx: Context) {
        File(dir(ctx), "img.json").delete()
        imageFile(ctx).delete()
    }
}
