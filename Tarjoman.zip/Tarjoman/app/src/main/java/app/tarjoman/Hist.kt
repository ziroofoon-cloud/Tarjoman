package app.tarjoman

import android.content.Context
import org.json.JSONObject
import java.io.File

/** One saved translation. */
class HEntry(val id: Long, val kind: String, val s: String, val d: String, val src: String, val out: String)

/**
 * Translation history: one JSON object per line in files/history.jsonl.
 * The file never grows past the size chosen in Settings: the oldest entries are dropped first.
 */
object Hist {
    private const val NAME = "history.jsonl"
    private const val MAX_TEXT = 20000      // one side of one entry is cut at this many characters
    private var last = 0L
    private var lastKey = ""                // the same translation twice in a row is saved once

    private fun file(ctx: Context): File = File(ctx.applicationContext.filesDir, NAME)

    @Synchronized
    fun size(ctx: Context): Long = file(ctx).let { if (it.isFile) it.length() else 0L }

    @Synchronized
    fun count(ctx: Context): Int {
        val f = file(ctx)
        if (!f.isFile) return 0
        var n = 0
        f.bufferedReader(Charsets.UTF_8).useLines { ls -> for (l in ls) if (l.isNotBlank()) n++ }
        return n
    }

    private fun enc(e: HEntry): String = JSONObject()
        .put("id", e.id).put("k", e.kind).put("s", e.s).put("d", e.d).put("a", e.src).put("b", e.out).toString()

    private fun dec(line: String): HEntry? = try {
        val o = JSONObject(line)
        HEntry(o.getLong("id"), o.optString("k", "text"), o.optString("s"), o.optString("d"), o.optString("a"), o.optString("b"))
    } catch (_: Exception) { null }

    /** Saves one translation (call from a worker thread). [maxMb] <= 0 means history is off. */
    @Synchronized
    fun add(ctx: Context, maxMb: Int, kind: String, s: String, d: String, src0: String, out0: String) {
        if (maxMb <= 0) return
        val src = src0.trim().take(MAX_TEXT)
        val out = out0.trim().take(MAX_TEXT)
        if (src.isEmpty() || out.isEmpty()) return
        val key = "$kind|$s|$d|$src|$out"
        if (key == lastKey) return
        lastKey = key
        var id = System.currentTimeMillis()
        if (id <= last) id = last + 1
        last = id
        val f = file(ctx)
        try {
            f.parentFile?.mkdirs()
            f.appendText(enc(HEntry(id, kind, s, d, src, out)) + "\n", Charsets.UTF_8)
            trim(ctx, maxMb)
        } catch (_: Throwable) {
        }
    }

    /** Drops the oldest lines until the file fits in [maxMb]. */
    @Synchronized
    fun trim(ctx: Context, maxMb: Int) {
        val f = file(ctx)
        val cap = maxMb.toLong() * 1024L * 1024L
        if (!f.isFile || f.length() <= cap) return
        var excess = f.length() - cap + cap / 10      // free 10% extra so we do not rewrite on every translation
        val tmp = File(f.path + ".tmp")
        f.bufferedReader(Charsets.UTF_8).use { r ->
            tmp.bufferedWriter(Charsets.UTF_8).use { w ->
                while (true) {
                    val l = r.readLine() ?: break
                    if (excess > 0) { excess -= (l.toByteArray(Charsets.UTF_8).size + 1).toLong(); continue }
                    w.write(l); w.write("\n")
                }
            }
        }
        f.delete()
        tmp.renameTo(f)
    }

    /** Newest first, at most [limit] entries whose text contains [q] (case-insensitive). */
    @Synchronized
    fun list(ctx: Context, q: String, limit: Int): List<HEntry> {
        val f = file(ctx)
        if (!f.isFile) return emptyList()
        val query = q.trim().lowercase()
        val keep = java.util.ArrayDeque<HEntry>()
        f.bufferedReader(Charsets.UTF_8).useLines { ls ->
            for (l in ls) {
                if (l.isBlank()) continue
                if (query.isNotEmpty() && !l.lowercase().contains(query)) continue   // cheap pre-filter
                val e = dec(l) ?: continue
                if (query.isNotEmpty() && !e.src.lowercase().contains(query) && !e.out.lowercase().contains(query)) continue
                keep.addLast(e)
                if (keep.size > limit) keep.removeFirst()
            }
        }
        return keep.toList().asReversed()
    }

    @Synchronized
    fun delete(ctx: Context, ids: Set<Long>) {
        if (ids.isEmpty()) return
        val f = file(ctx)
        if (!f.isFile) return
        val tmp = File(f.path + ".tmp")
        f.bufferedReader(Charsets.UTF_8).use { r ->
            tmp.bufferedWriter(Charsets.UTF_8).use { w ->
                while (true) {
                    val l = r.readLine() ?: break
                    if (l.isBlank()) continue
                    val e = dec(l)
                    if (e != null && e.id in ids) continue
                    w.write(l); w.write("\n")
                }
            }
        }
        f.delete()
        tmp.renameTo(f)
    }

    @Synchronized
    fun clear(ctx: Context) {
        file(ctx).delete()
    }
}
