package app.tarjoman

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.net.Uri
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * A ZIP / CBZ of manga pages is translated page by page (read the archive once, in order) and written to a new CBZ with the
 * translated pictures. A picture without text, or one that failed, is copied unchanged; other files (ComicInfo.xml ...) are copied too.
 */
object MangaZip {
    private val imgExt = listOf(".jpg", ".jpeg", ".png", ".webp")

    class Result(val pages: Int, val translated: Int, val err: String?)

    fun run(ctx: Context, tr: Tr, cfg: Cfg, uri: Uri, out: File, stop: () -> Boolean, progress: (String) -> Unit): Result {
        Vision.resetStory()
        Smart.task = "manga"
        var pages = 0
        var translated = 0
        var firstErr: String? = null
        val used = HashSet<String>()
        fun unique(n: String): String {
            var x = n
            var i = 1
            while (!used.add(x.lowercase())) { x = n.substringBeforeLast('.') + "_" + i + "." + n.substringAfterLast('.', "jpg"); i++ }
            return x
        }
        val ins = ctx.contentResolver.openInputStream(uri) ?: return Result(0, 0, "open")
        ZipInputStream(BufferedInputStream(ins, 256 * 1024)).use { zin ->
            ZipOutputStream(BufferedOutputStream(FileOutputStream(out), 256 * 1024)).use { zout ->
                zout.setLevel(1)
                while (!stop()) {
                    val e = zin.nextEntry ?: break
                    if (e.isDirectory) continue
                    val name = e.name
                    val low = name.lowercase()
                    val bytes = zin.readBytes()
                    val isImg = imgExt.any { low.endsWith(it) } && !low.contains("__macosx") && !name.substringAfterLast('/').startsWith(".")
                    if (!isImg) {
                        zout.putNextEntry(ZipEntry(unique(name))); zout.write(bytes); zout.closeEntry()
                        continue
                    }
                    pages++
                    val n = pages
                    progress(L("صفحهٔ ") + n + L(" … (خواندن متن)"))
                    var png: ByteArray? = null
                    try {
                        val r = page(ctx, cfg, tr, bytes) { p -> progress(L("صفحهٔ ") + n + " · " + p) }
                        png = r.first
                        if (r.second != null && firstErr == null) firstErr = r.second
                    } catch (t: Throwable) {
                        if (firstErr == null) firstErr = t.message ?: t.javaClass.simpleName
                    }
                    // rest between pages (the phone stays cooler); stop works during the rest too
                    var rest = cfg.mzPause * 10
                    while (rest > 0 && !stop()) { try { Thread.sleep(100) } catch (_: InterruptedException) { break }; rest-- }
                    if (png != null) {
                        translated++
                        zout.putNextEntry(ZipEntry(unique(name.substringBeforeLast('.') + (if (cfg.mzFmt == "webp") ".webp" else ".jpg")))); zout.write(png); zout.closeEntry()
                    } else {
                        zout.putNextEntry(ZipEntry(unique(name))); zout.write(bytes); zout.closeEntry()
                    }
                }
            }
        }
        return Result(pages, translated, firstErr)
    }

    /** Translates only the first page that has text and returns its JPEG bytes (a preview to check the settings before the whole archive). */
    fun preview(ctx: Context, tr: Tr, cfg: Cfg, uri: Uri, progress: (String) -> Unit): ByteArray? {
        val ins = ctx.contentResolver.openInputStream(uri) ?: return null
        var n = 0
        ZipInputStream(BufferedInputStream(ins, 256 * 1024)).use { zin ->
            while (n < 6) {
                val e = zin.nextEntry ?: break
                if (e.isDirectory) continue
                val low = e.name.lowercase()
                if (!imgExt.any { low.endsWith(it) } || low.contains("__macosx") || e.name.substringAfterLast('/').startsWith(".")) continue
                val bytes = zin.readBytes()
                n++
                progress(L("صفحهٔ ") + n + " …")
                val r = try { page(ctx, cfg, tr, bytes) { p -> progress(p) } } catch (_: Throwable) { null }
                if (r?.first != null) return r.first
            }
        }
        return null
    }

    /** One picture: JPEG bytes of the translated page, or null when it has no text. Second = the first translation error, if any. */
    private fun page(ctx: Context, cfg: Cfg, tr: Tr, bytes: ByteArray, prog: (String) -> Unit): Pair<ByteArray?, String?> {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var sample = 1
        val cap = cfg.mzMaxPx.coerceIn(800, 2400)
        val tall = !Smart.safe && o.outHeight > o.outWidth * 2.4f   // webtoon / long strip: limit by width only, read in slices
        if (tall) { while (o.outWidth / sample > cap || o.outHeight / sample > 16000) sample *= 2 }
        else while (o.outWidth / sample > cap || o.outHeight / sample > cap) sample *= 2
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return Pair(null, null)
        var work: Bitmap? = null
        try {
            val s0 = cfg.src
            val d0 = cfg.dst
            val ar = if (tall) readTall(bmp, s0) else Ocr.readAuto(bmp, s0)
            val blocks = ar.blocks
            if (blocks.isEmpty()) return Pair(null, null)
            val s = ar.lang
            val d = if (s == d0) (if (s == "fa") "en" else "fa") else d0
            prog(L("ترجمه…") + " (" + blocks.size + ")")
            // Optional cloud vision model: one request per page, with what was said on the earlier pages as context
            val vis = if (Vision.usable(cfg, ctx)) { try { Vision.translateBlocks(tr, cfg, bmp, blocks, s, d, false, true) { p -> prog(p) } } catch (_: Throwable) { null } } else null
            val (outs, err) = vis ?: tr.translateMany(blocks.map { it.text }, s, d, false, "") { }
            val w = bmp.copy(Bitmap.Config.ARGB_8888, true)
            work = w
            val canvas = Canvas(w)
            val sc = cfg.fontScale / 100f
            blocks.forEachIndexed { i, b -> b.out = Translit.names(outs[i]) }
            Ocr.drawAll(canvas, blocks, sc)
            val bo = java.io.ByteArrayOutputStream()
            if (cfg.mzFmt == "webp") w.compress(if (android.os.Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else @Suppress("DEPRECATION") Bitmap.CompressFormat.WEBP, 90, bo)
            else w.compress(Bitmap.CompressFormat.JPEG, 92, bo)
            return Pair(bo.toByteArray(), err)
        } finally {
            work?.recycle()
            bmp.recycle()
        }
    }

    /** Cut a tall strip into slices at the emptiest rows (so no line of text is cut), read each, and put the blocks back in full-page coordinates. */
    fun readTall(bmp: Bitmap, s0: String): Ocr.AutoRes {
        val w = bmp.width
        val h = bmp.height
        val step = (w * 1.8f).toInt().coerceAtLeast(600)
        val cuts = ArrayList<Int>()
        cuts.add(0)
        var y = 0
        val row = IntArray(w)
        while (h - y > step * 1.25f) {
            val target = y + step
            var best = target
            var bestInk = Int.MAX_VALUE
            var yy = target - (step * 0.3f).toInt()
            val end = minOf(h - 1, target + (step * 0.3f).toInt())
            while (yy <= end) {
                bmp.getPixels(row, 0, w, 0, yy, w, 1)
                var sum = 0L
                var x = 0
                while (x < w) { val p = row[x]; sum += ((p shr 16 and 255) * 3 + (p shr 8 and 255) * 6 + (p and 255)) / 10; x += 4 }
                val mean = sum / ((w + 3) / 4)
                var ink = 0
                x = 0
                while (x < w) { val p = row[x]; val l = ((p shr 16 and 255) * 3 + (p shr 8 and 255) * 6 + (p and 255)) / 10; if (Math.abs(l - mean) > 40) ink++; x += 4 }
                if (ink < bestInk) { bestInk = ink; best = yy }
                yy += 3
            }
            cuts.add(best)
            y = best
        }
        cuts.add(h)
        val all = ArrayList<OBlock>()
        var lang = s0
        for (i in 0 until cuts.size - 1) {
            val top = cuts[i]
            val hh = cuts[i + 1] - top
            if (hh < 40) continue
            val part = Bitmap.createBitmap(bmp, 0, top, w, hh)
            try {
                val r = Ocr.readAuto(part, s0)
                if (r.blocks.isNotEmpty()) lang = r.lang
                for (b in r.blocks) all.add(OBlock(android.graphics.Rect(b.rect.left, b.rect.top + top, b.rect.right, b.rect.bottom + top), b.text, b.bg))
            } finally { part.recycle() }
        }
        return Ocr.AutoRes(all, lang)
    }
}
