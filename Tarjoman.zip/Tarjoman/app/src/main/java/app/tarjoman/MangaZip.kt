package app.tarjoman

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.net.Uri
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * A ZIP / CBZ of manga pages is translated page by page (read the archive once, in order) and written to a new CBZ with the
 * translated pictures. A picture without text, or one that failed, is copied unchanged; other files (ComicInfo.xml ...) are copied too.
 */
object MangaZip {
    private val imgExt = listOf(".jpg", ".jpeg", ".png", ".webp")

    class Result(val pages: Int, val translated: Int, val err: String?)

    fun run(ctx: Context, tr: Tr, cfg: Cfg, uri: Uri, out: File, stop: () -> Boolean, progress: (String) -> Unit): Result {
        var pages = 0
        var translated = 0
        var firstErr: String? = null
        val ins = ctx.contentResolver.openInputStream(uri) ?: return Result(0, 0, "open")
        ZipInputStream(BufferedInputStream(ins, 256 * 1024)).use { zin ->
            ZipOutputStream(BufferedOutputStream(FileOutputStream(out), 256 * 1024)).use { zout ->
                zout.setLevel(1)
                while (!stop()) {
                    val e = zin.nextEntry ?: break
                    if (e.isDirectory) continue
                    val name = e.name
                    val low = name.lowercase()
                    val bytes = zin.readBytes()
                    val isImg = imgExt.any { low.endsWith(it) } && !low.contains("__macosx") && !name.substringAfterLast('/').startsWith(".")
                    if (!isImg) {
                        zout.putNextEntry(ZipEntry(name)); zout.write(bytes); zout.closeEntry()
                        continue
                    }
                    pages++
                    val n = pages
                    progress(L("صفحهٔ ") + n + L(" … (خواندن متن)"))
                    var png: ByteArray? = null
                    try {
                        val r = page(cfg, tr, bytes) { p -> progress(L("صفحهٔ ") + n + " · " + p) }
                        png = r.first
                        if (r.second != null && firstErr == null) firstErr = r.second
                    } catch (t: Throwable) {
                        if (firstErr == null) firstErr = t.message ?: t.javaClass.simpleName
                    }
                    if (png != null) {
                        translated++
                        zout.putNextEntry(ZipEntry(name.substringBeforeLast('.') + ".jpg")); zout.write(png); zout.closeEntry()
                    } else {
                        zout.putNextEntry(ZipEntry(name)); zout.write(bytes); zout.closeEntry()
                    }
                }
            }
        }
        return Result(pages, translated, firstErr)
    }

    /** One picture: JPEG bytes of the translated page, or null when it has no text. Second = the first translation error, if any. */
    private fun page(cfg: Cfg, tr: Tr, bytes: ByteArray, prog: (String) -> Unit): Pair<ByteArray?, String?> {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var sample = 1
        while (o.outWidth / sample > 2200 || o.outHeight / sample > 2200) sample *= 2
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return Pair(null, null)
        var work: Bitmap? = null
        try {
            val s0 = cfg.src
            val d0 = cfg.dst
            val ar = Ocr.readAuto(bmp, s0)
            val blocks = ar.blocks
            if (blocks.isEmpty()) return Pair(null, null)
            val s = ar.lang
            val d = if (s == d0) (if (s == "fa") "en" else "fa") else d0
            prog(L("ترجمه…") + " (" + blocks.size + ")")
            val (outs, err) = tr.translateMany(blocks.map { it.text }, s, d, false, "") { }
            val w = bmp.copy(Bitmap.Config.ARGB_8888, true)
            work = w
            val canvas = Canvas(w)
            val sc = cfg.fontScale / 100f
            blocks.forEachIndexed { i, b -> b.out = outs[i]; Ocr.draw(canvas, b, sc) }
            val bo = java.io.ByteArrayOutputStream()
            w.compress(Bitmap.CompressFormat.JPEG, 92, bo)
            return Pair(bo.toByteArray(), err)
        } finally {
            work?.recycle()
            bmp.recycle()
        }
    }
}
