package app.tarjoman

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View

/** Picture viewer: pinch to zoom, drag to move, double tap to zoom in / back; a single tap reports the spot in picture coordinates. */
class ZoomView(ctx: Context) : View(ctx) {
    var onTap: ((Float, Float) -> Unit)? = null
    private var bmp: Bitmap? = null
    private val m = Matrix()
    private val inv = Matrix()
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private var fitScale = 1f
    private val vals = FloatArray(9)

    private val scaler = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            zoomBy(d.scaleFactor, d.focusX, d.focusY)
            return true
        }
    })

    private val gestures = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
            if (scaler.isInProgress) return false
            m.postTranslate(-dx, -dy)
            clamp()
            invalidate()
            return true
        }
        override fun onDoubleTap(e: MotionEvent): Boolean {
            val cur = scale()
            if (cur > fitScale * 1.3f) fit() else zoomBy(2.5f, e.x, e.y)
            return true
        }
        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            val b = bmp ?: return false
            m.invert(inv)
            val p = floatArrayOf(e.x, e.y)
            inv.mapPoints(p)
            if (p[0] >= 0 && p[1] >= 0 && p[0] <= b.width && p[1] <= b.height) onTap?.invoke(p[0], p[1])
            return true
        }
    })

    fun setBitmap(b: Bitmap?, keepView: Boolean = false) {
        val old = bmp
        bmp = b
        if (b == null) { invalidate(); return }
        if (!keepView || old == null || old.width != b.width || old.height != b.height) fit() else invalidate()
    }

    private fun scale(): Float { m.getValues(vals); return vals[Matrix.MSCALE_X] }

    private fun fit() {
        val b = bmp ?: return
        if (width == 0 || height == 0) return
        fitScale = minOf(width.toFloat() / b.width, height.toFloat() / b.height)
        m.reset()
        m.postScale(fitScale, fitScale)
        m.postTranslate((width - b.width * fitScale) / 2f, (height - b.height * fitScale) / 2f)
        invalidate()
    }

    private fun zoomBy(f: Float, cx: Float, cy: Float) {
        val cur = scale()
        val target = (cur * f).coerceIn(fitScale * 0.95f, fitScale * 8f)
        val k = target / cur
        m.postScale(k, k, cx, cy)
        clamp()
        invalidate()
    }

    /** Keeps the picture from being dragged out of the screen. */
    private fun clamp() {
        val b = bmp ?: return
        m.getValues(vals)
        val s = vals[Matrix.MSCALE_X]
        val w = b.width * s
        val h = b.height * s
        var tx = vals[Matrix.MTRANS_X]
        var ty = vals[Matrix.MTRANS_Y]
        tx = if (w <= width) (width - w) / 2f else tx.coerceIn(width - w, 0f)
        ty = if (h <= height) (height - h) / 2f else ty.coerceIn(height - h, 0f)
        vals[Matrix.MTRANS_X] = tx
        vals[Matrix.MTRANS_Y] = ty
        m.setValues(vals)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { super.onSizeChanged(w, h, ow, oh); fit() }

    override fun onDraw(c: Canvas) {
        val b = bmp ?: return
        if (!b.isRecycled) c.drawBitmap(b, m, paint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        scaler.onTouchEvent(e)
        gestures.onTouchEvent(e)
        return true
    }
}
