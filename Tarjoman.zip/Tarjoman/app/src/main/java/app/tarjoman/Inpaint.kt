package app.tarjoman

import ai.onnxruntime.OnnxJavaType
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import java.io.File
import java.nio.ByteBuffer
import java.nio.FloatBuffer

/**
 * Erases the original writing from a picture (manga, posters, photos) so the translation sits on a clean background.
 * Model: LaMa (Carve/LaMa-ONNX, lama_fp32.onnx, Apache-2.0), run with ONNX Runtime on the phone. It works on 512x512 squares:
 * around every text box a square is cut out, the text box is the hole (mask = 1), the model paints the hole, and the
 * result is pasted back inside the hole only. Plain-coloured surroundings (white speech bubbles) are skipped: the normal
 * flat fill is faster and just as good there ("smart" mode).
 */
object Inpaint {
    private const val N = 512
    @Volatile var base: File? = null    // filesDir/inpaint

    @Volatile var cfg: Cfg? = null

    // LaMa (big, best on busy backgrounds) and MI-GAN (small, made for phones; Picsart, MIT licence, 28 MB)
    fun file(): File? = base?.let { File(it, "lama_fp32.onnx") }
    fun lamaReady(): Boolean = file()?.let { it.isFile && it.length() > 150_000_000L } ?: false
    fun miganFile(): File? = base?.let { File(it, "migan_pipeline_v2.onnx") }
    fun miganReady(): Boolean = miganFile()?.let { it.isFile && it.length() > 20_000_000L } ?: false

    /** The model that is used now: the user's choice when it is installed, else the other one; null = none installed. */
    fun engine(): String? {
        val pick = cfg?.eraser ?: "auto"
        val l = lamaReady()
        val m = miganReady()
        return when (pick) {
            "migan" -> if (m) "migan" else if (l) "lama" else null
            "lama" -> if (l) "lama" else if (m) "migan" else null
            else -> if (l) "lama" else if (m) "migan" else null
        }
    }

    fun ready(): Boolean = engine() != null

    private var openEngine = ""
    private var env: OrtEnvironment? = null
    private var session: OrtSession? = null
    private var imgName = "image"
    private var maskName = "mask"
    private val idle = Handler(Looper.getMainLooper())
    private val idleRun = Runnable { release() }

    @Synchronized
    private fun open(): OrtSession {
        val eng = engine() ?: throw IllegalStateException("model missing")
        if (session != null && openEngine != eng) release()      // the user switched the model
        session?.let { return it }
        val f = (if (eng == "migan") miganFile() else file()) ?: throw IllegalStateException("model missing")
        val e = OrtEnvironment.getEnvironment()
        val so = OrtSession.SessionOptions()
        so.setIntraOpNumThreads(4)
        val s = e.createSession(f.absolutePath, so)
        val names = s.inputNames.toList()
        maskName = names.firstOrNull { it.contains("mask", true) } ?: names.getOrElse(1) { "mask" }
        imgName = names.firstOrNull { it != maskName } ?: names[0]
        env = e
        session = s
        openEngine = eng
        return s
    }

    /** Frees the model (about 1 GB of memory). Called automatically 45 s after the last use. */
    @Synchronized
    fun release() {
        try { session?.close() } catch (_: Throwable) {}
        session = null
    }

    /** True when the ring just outside the text box is (almost) one colour: nothing to rebuild, a flat fill is enough. */
    private fun flat(b: Bitmap, r: Rect): Boolean {
        val g = 4
        val x0 = (r.left - g).coerceAtLeast(0)
        val x1 = (r.right + g).coerceAtMost(b.width - 1)
        val y0 = (r.top - g).coerceAtLeast(0)
        val y1 = (r.bottom + g).coerceAtMost(b.height - 1)
        if (x1 <= x0 || y1 <= y0) return true
        val vals = ArrayList<Int>()
        val steps = 14
        for (i in 0..steps) {
            val x = x0 + (x1 - x0) * i / steps
            val y = y0 + (y1 - y0) * i / steps
            vals.add(b.getPixel(x, y0)); vals.add(b.getPixel(x, y1))
            vals.add(b.getPixel(x0, y)); vals.add(b.getPixel(x1, y))
        }
        var worst = 0.0
        for (ch in 0..2) {
            var sum = 0.0
            var sq = 0.0
            for (c in vals) {
                val v = (if (ch == 0) Color.red(c) else if (ch == 1) Color.green(c) else Color.blue(c)).toDouble()
                sum += v
                sq += v * v
            }
            val m = sum / vals.size
            val sd = Math.sqrt(Math.max(0.0, sq / vals.size - m * m))
            if (sd > worst) worst = sd
        }
        return worst < 14.0
    }

    /**
     * A copy of [src] with the writing of the blocks erased. Blocks that were erased by the model get noFill = true
     * (the translation is then drawn without the flat background patch). At most [maxBlocks] blocks go through the model.
     */
    fun clean(src: Bitmap, blocks: List<OBlock>, maxBlocks: Int, stop: () -> Boolean, force: Boolean = false, progress: (done: Int, total: Int) -> Unit): Bitmap {
        val out = src.copy(Bitmap.Config.ARGB_8888, true)
        val todo = blocks.filter { it.out.isNotEmpty() && (force || !flat(src, it.rect)) }.take(maxBlocks)
        if (todo.isEmpty()) return out
        val s = open()
        val e = env ?: return out
        var n = 0
        try {
            for (b in todo) {
                if (stop()) break
                try {
                    if (openEngine == "migan") eraseMigan(e, s, out, b.rect) else erase(e, s, out, b.rect)
                    b.noFill = true
                } catch (t: OutOfMemoryError) {
                    throw t
                } catch (_: Throwable) {
                    // this block keeps the flat fill
                }
                n++
                progress(n, todo.size)
            }
        } finally {
            idle.removeCallbacks(idleRun)
            idle.postDelayed(idleRun, 45000)
        }
        return out
    }

    /**
     * MI-GAN pipeline (migan_pipeline_v2.onnx): image uint8 [1,3,H,W] and mask uint8 [1,1,H,W] (0 = erase, 255 = keep),
     * answer uint8 [1,3,H,W] with the hole already filled. Same 512 x 512 square around the text box as for LaMa.
     */
    private fun eraseMigan(e: OrtEnvironment, s: OrtSession, bmp: Bitmap, r: Rect) {
        val pad = maxOf(5, (minOf(r.width(), r.height()) * 0.12f).toInt())
        val hole = Rect(r.left - pad, r.top - pad, r.right + pad, r.bottom + pad)
        if (!hole.intersect(0, 0, bmp.width, bmp.height)) return
        val side = (maxOf(hole.width(), hole.height()) * 2.2f).toInt().coerceAtLeast(160).coerceAtMost(minOf(bmp.width, bmp.height))
        val x0 = (hole.centerX() - side / 2).coerceIn(0, bmp.width - side)
        val y0 = (hole.centerY() - side / 2).coerceIn(0, bmp.height - side)
        val crop = Bitmap.createBitmap(bmp, x0, y0, side, side)
        val small = Bitmap.createScaledBitmap(crop, N, N, true)
        val k = N.toFloat() / side
        val px = IntArray(N * N)
        small.getPixels(px, 0, N, 0, 0, N, N)
        val nn = N * N
        val img = ByteArray(3 * nn)
        for (i in 0 until nn) {
            val c = px[i]
            img[i] = Color.red(c).toByte()
            img[nn + i] = Color.green(c).toByte()
            img[2 * nn + i] = Color.blue(c).toByte()
        }
        val msk = ByteArray(nn) { 255.toByte() }
        val mx0 = ((hole.left - x0) * k).toInt().coerceIn(0, N)
        val mx1 = ((hole.right - x0) * k).toInt().coerceIn(0, N)
        val my0 = ((hole.top - y0) * k).toInt().coerceIn(0, N)
        val my1 = ((hole.bottom - y0) * k).toInt().coerceIn(0, N)
        for (y in my0 until my1) for (x in mx0 until mx1) msk[y * N + x] = 0
        val t1 = OnnxTensor.createTensor(e, ByteBuffer.wrap(img), longArrayOf(1, 3, N.toLong(), N.toLong()), OnnxJavaType.UINT8)
        val t2 = OnnxTensor.createTensor(e, ByteBuffer.wrap(msk), longArrayOf(1, 1, N.toLong(), N.toLong()), OnnxJavaType.UINT8)
        try {
            val res = s.run(mapOf(imgName to t1, maskName to t2))
            try {
                @Suppress("UNCHECKED_CAST")
                val o = (res.get(0).value as Array<Array<Array<ByteArray>>>)[0]
                val outPx = IntArray(nn)
                for (y in 0 until N) for (x in 0 until N) {
                    outPx[y * N + x] = Color.rgb(o[0][y][x].toInt() and 255, o[1][y][x].toInt() and 255, o[2][y][x].toInt() and 255)
                }
                val fixed = Bitmap.createBitmap(N, N, Bitmap.Config.ARGB_8888)
                fixed.setPixels(outPx, 0, N, 0, 0, N, N)
                val back = Bitmap.createScaledBitmap(fixed, side, side, true)
                val cv = Canvas(bmp)
                cv.save()
                cv.clipRect(hole)
                cv.drawBitmap(back, x0.toFloat(), y0.toFloat(), null)
                cv.restore()
            } finally {
                res.close()
            }
        } finally {
            t1.close()
            t2.close()
        }
    }

    private fun erase(e: OrtEnvironment, s: OrtSession, bmp: Bitmap, r: Rect) {
        val pad = maxOf(5, (minOf(r.width(), r.height()) * 0.12f).toInt())
        val hole = Rect(r.left - pad, r.top - pad, r.right + pad, r.bottom + pad)
        if (!hole.intersect(0, 0, bmp.width, bmp.height)) return
        val side = (maxOf(hole.width(), hole.height()) * 2.2f).toInt().coerceAtLeast(160).coerceAtMost(minOf(bmp.width, bmp.height))
        val x0 = (hole.centerX() - side / 2).coerceIn(0, bmp.width - side)
        val y0 = (hole.centerY() - side / 2).coerceIn(0, bmp.height - side)
        val crop = Bitmap.createBitmap(bmp, x0, y0, side, side)
        val small = Bitmap.createScaledBitmap(crop, N, N, true)
        val k = N.toFloat() / side
        val px = IntArray(N * N)
        small.getPixels(px, 0, N, 0, 0, N, N)
        val nn = N * N
        val a = FloatArray(3 * nn)
        for (i in 0 until nn) {
            val c = px[i]
            a[i] = Color.red(c) / 255f
            a[nn + i] = Color.green(c) / 255f
            a[2 * nn + i] = Color.blue(c) / 255f
        }
        val m = FloatArray(nn)
        val mx0 = ((hole.left - x0) * k).toInt().coerceIn(0, N)
        val mx1 = ((hole.right - x0) * k).toInt().coerceIn(0, N)
        val my0 = ((hole.top - y0) * k).toInt().coerceIn(0, N)
        val my1 = ((hole.bottom - y0) * k).toInt().coerceIn(0, N)
        for (y in my0 until my1) for (x in mx0 until mx1) m[y * N + x] = 1f
        val shape = longArrayOf(1, 3, N.toLong(), N.toLong())
        val t1 = OnnxTensor.createTensor(e, FloatBuffer.wrap(a), shape)
        val t2 = OnnxTensor.createTensor(e, FloatBuffer.wrap(m), longArrayOf(1, 1, N.toLong(), N.toLong()))
        try {
            val res = s.run(mapOf(imgName to t1, maskName to t2))
            try {
                @Suppress("UNCHECKED_CAST")
                val o = (res.get(0).value as Array<Array<Array<FloatArray>>>)[0]
                // the model answers 0..255 (some exports 0..1)
                var top = 0f
                for (y in 0 until N) for (x in 0 until N) if (o[0][y][x] > top) top = o[0][y][x]
                val sc = if (top <= 1.5f) 255f else 1f
                val outPx = IntArray(nn)
                for (y in 0 until N) for (x in 0 until N) {
                    val rr = (o[0][y][x] * sc).toInt().coerceIn(0, 255)
                    val gg = (o[1][y][x] * sc).toInt().coerceIn(0, 255)
                    val bb = (o[2][y][x] * sc).toInt().coerceIn(0, 255)
                    outPx[y * N + x] = Color.rgb(rr, gg, bb)
                }
                val fixed = Bitmap.createBitmap(N, N, Bitmap.Config.ARGB_8888)
                fixed.setPixels(outPx, 0, N, 0, 0, N, N)
                val back = Bitmap.createScaledBitmap(fixed, side, side, true)
                // paste back only inside the hole: the rest of the picture stays exactly as it was
                val cv = Canvas(bmp)
                cv.save()
                cv.clipRect(hole)
                cv.drawBitmap(back, x0.toFloat(), y0.toFloat(), null)
                cv.restore()
            } finally {
                res.close()
            }
        } finally {
            t1.close()
            t2.close()
        }
    }
}
