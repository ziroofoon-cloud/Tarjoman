package app.tarjoman

/** Common English words that the built-in dictionary (Dic) does not have: "Download more words" fetches their meanings from the internet and keeps them on the phone. */
object Words {
    val MORE: List<String> by lazy { DATA.split(' ', '\n').filter { it.isNotBlank() } }

    private const val DATA = """
abroad absence absolute abuse academic access accurate achieve acid acquire actor actual adapt addition adjust
admire admit adopt adult advance advantage adventure advertise advice advise affair affect afford agency agent
aggressive aim airport album alcohol alert alien alliance alternative altogether amount amuse analysis
anniversary annoy annual anxious apart apartment apology apparently appeal appearance apple application apply
appoint appreciate approach approve arrange arrival article artist ashamed assassin assault assist assistant
associate assume atmosphere attach attempt attend attitude attract audience author authority available average
avoid award axe backpack background bacon badge balance ban banner barely bargain barrel basement basket bath
bathroom battery bay beam beauty bedroom beer beginning behavior being bell belt bench bend benefit bet betray
beyond bid bind birth birthday biscuit bitter blade blanket bless blessing blond bloody blossom blouse boil
bold bolt bond bonus boot bored borrow bow brand bravery breakfast breast breed brick bride brief brilliant
broad broadcast brother brown budget bullet bunch burden burst bus business butter butterfly cabin cable cafe
cake calculate calendar campaign candidate candle candy canvas capable capacity capital capture career carpet
cartoon cash casual category cattle cave ceiling cent central ceremony certain certainly chalk challenge
channel chaos chapter charity charm chart chat cheek cheese chemical chicken childhood chocolate chop chorus
cigarette cinema citizen civil claim classic classroom clerk click client cliff climate clinic closet clue
coal coast code coin collapse college colony column combat combine comedy comfort comic comment commit
committee communicate community compare compete complain complex compose compromise computer concentrate
concept concern concert conclude condition conduct confess confidence confirm conflict confuse connect
conscious consider consist constant contact contain contest continue contract contrast contribute conversation
convince cookie copper cord core cottage cotton council countryside county couple coupon cousin craft cream
credit crew crisis critic crop crush crystal cult culture curious curtain curve cushion custom cute cycle
daily dam damn dare darling dash data daughter dawn deadline dealer decade declare decline decorate deed deer
defense definitely delay delicate delicious delight deliver demand democracy departure deposit depth describe
deserve design desk despite dessert destiny determine develop device diamond diary dictionary digital dignity
dimension diplomat direct director disaster discipline discount discuss dismiss display distant district
disturb dive divide divorce doll dollar domestic dominate donate doom doorway dose double download drag drama
drawer dread dressing drift drown drum dull dynamic eagle earn earthquake east eastern economy edition editor
educate education elbow elect electric electricity element elephant elevator eliminate elite embarrass embrace
emerge emergency emperor emphasis employ employee employer enable encounter encourage ending enormous ensure
entertain entire entrance entry envelope environment equal equipment era error essay essential establish
estate eternal evidence evolve exact exchange exciting executive exercise exhibit expand expense expert expire
explore export expose extend extra extreme fabric facility factor factory faculty fade fairly fairy false fame
familiar fancy fantasy farmer fashion fate favor feature federal fee feed fellow fiction fierce finance
finding fist fitness flavor flee fluid flute focus folk fond footstep forbid foreign forever formal former
formula forth fortunate forward foundation fountain fox fragile frank freely frequent friendly frighten frog
frozen frustrate function fund funeral furniture further gallery gamble gang garbage garlic gather gender
general generate generation generous genius genre gentleman genuine gesture gleam glove glow goat golden
goodbye gossip govern government grace gradual graduate grain grand grandfather grandmother grass gravity
greedy grin grip groan grocery gross grumble guarantee guilt guitar gun gym hall halt hammer handle handsome
happiness harbor hardly harsh harvest haste hatch hawk headache headline headquarters heap heat heel height
helicopter helmet helpless herb hesitate highway hill hint hip hire historic holiday hollow homework honey
horizon horrible horror hotel household huge humble humor hunter hut hypothesis identify identity idiot ignore
illegal illusion image immune impact impatient imply impress improve incident include income increase indeed
independent index indicate individual industry infant infection influence inform inherit initial injure injury
inner insist inspect inspire install instance instant institute instruct instrument insult insurance
intelligence intend intense interest interfere internal international internet interrupt interview introduce
invade invent invest investigate involve isolate item jacket jaw jazz jelly jet jewelry judgment juice junior
jungle jury keen kidney kingdom kitchen knight knot label labor laboratory lack ladder landscape lane laptop
laser latter launch lawn lawyer layer league leak leather lecture legal legend leisure lemon lend length
lesson liberty library license lighten lightning likely limb liquid literature litter loan local locate logic
lonesome loop lottery lover lower loyalty luggage lump lunch luxury magazine magnet maid mail main maintain
major majority mansion marathon march marine marriage mass massive mate material math maximum mayor measure
mechanic medal media medical medium melody member mental merchant mere mess method midnight might mild
military milk mill million mineral minimum minister minor mixture mobile modern modest moment monitor monkey
moral motion motor mount mouse movement mule multiple mummy museum musician mutual naked narrow nation
national native navy neat necessary needle negative nephew nest network neutral newspaper niece noon north
northern notebook novel nowhere nuclear nurse obey observe obtain obvious occasion occupy occur ocean offense
official onion online opponent oppose option orange orchestra organ organize origin outcome outfit output oven
overcome overseas owe owner oxygen package painful painting pants parade paradise parcel pardon parking
particular passage passenger passion passport pasta pastry patch pattern pause pavement payment peach peak
pearl peasant pedestrian peer penalty pencil pepper percent perform perfume period permanent permission permit
persuade phase philosophy photo physical piano pie pig pill pillow pilot pin pine pipe pirate pizza plastic
platform pleasant pleasure plenty plot plug plus poem poet poetry politics poll pollution pond pony popular
population port portrait position positive possess possibility possible potato powder powerful practice praise
precious predict prefer pregnant premium presence preserve pretend prevent previous price primary principle
priority privacy probable procedure process produce product profession professor profile profit program
progress project promote proof proper property proposal protest protein provide province psychology purchase
purple puzzle quality quantity quarrel queue quote rabbit rainbow rapid rather ray razor reaction reader
recall recent reception recipe recognize recommend recover reduce reflect reform refrigerator regard region
register regular reject relate relation relationship relative relevant reliable relief religion rely remark
remind remote remove rent repair replace represent republic reputation request require research reserve
resident resist resource response responsible restaurant result retire reveal reverse review revolution rib
ribbon rice rid ridiculous rifle rigid riot ripe roar roast rob robot role romantic rotate route routine royal
rub rubber rubbish ruin rumor runner rural rust ruthless sack sacred saddle sail salad salary salmon sample
sandwich satisfy sauce sausage scandal scar scarf schedule scheme scholar science scissors scope screw script
sculpture section sector secure security seek select senior sensible sensitive separate sequence series
service session settle severe sew shallow shark sheep shelf shelter shirt shoe shore shortage sight signal
signature significant similar sin singer single skate ski skirt skull slam slice slide slight slope snake
sneak soap social society sock sofa software soil solar solid solution somewhere sophisticated sore sour
source south southern spade spark species specific spectacular speech speed spice spider spill spine spiral
spoil spoon sport spray squeeze stable stadium standard statement statue status steady steam steer stem stereo
stiff stimulate sting stir stocking storage straight strategy straw stripe structure studio style subject
submit substance substitute subtle succeed success suck sugar suggest suitcase sum summit superior supper
surface surgeon surgery surprise surrender survey suspend sustain swallow swamp swan sway sweep swell swim
symbol sympathy symptom system tablet tactic tale target tax tea teenager telephone television temper
temperature tender tennis tension tent terrify territory text theater theme theory therapy thorough thread
thrill throne thumb ticket tide tidy timber tin tiny tissue title toast tobacco toe toilet tomato ton tone
tongue topic torch tortoise total tour tourist tournament toward towel toy tradition traffic tragedy training
transfer transform translate transport travel tray tremble trend trial tribe tribute trigger trim triumph
troop tropical truck trumpet tune tunnel turkey typical umbrella unable uncertain undergo underground unfair
uniform union unique unit universe university unless unlike unusual upper upset urban urge urgent usage usual
utility vacation vague valid valley valuable value van vanish variety various vast vegetable vehicle venture
version vertical vessel veteran via vice video vigorous violent violin virtue virus visible vision visitor
vital vitamin vocabulary volume volunteer vow voyage wagon waist waiter wallet wander warehouse warn warning
wash waste wealth wealthy weave web website weigh welfare western wet wheat whistle widow width wisdom wit
witness wizard wooden wool workshop worship worth wrist writer wrong yawn yogurt youth zebra zero zip fuck
fucking shit bitch bastard asshole ass dick pussy cock slut whore hell crap piss bullshit motherfucker dumbass
jerk moron retard freak creep pervert scum trash filth kinda gonna gotta wanna dunno gimme lemme ain't y'all
dude bro buddy pal sis bruh nope yep yup nah huh wow oops ouch yay hurray cheers sorry hereby thereby whereas
notwithstanding pursuant hence therefore thus moreover furthermore nevertheless nonetheless consequently
accordingly respectively
"""
}
