package app.tarjoman

import android.content.Context
import org.json.JSONObject
import java.io.File

/**
 * The learner's word list (saved from the Text tab, typed by hand or taken from the history) with a simple spaced-repetition
 * schedule (Leitner boxes): a card you know comes back later and later, a card you miss comes back soon.
 */
object Vocab {
    class Card(val id: Long, val s: String, val d: String, var a: String, var b: String, var box: Int, var due: Long, var seen: Int, var ok: Int)

    private const val NAME = "vocab.jsonl"
    private const val DAY = 24L * 3600 * 1000
    private val days = longArrayOf(0, 1, 3, 7, 14, 30)       // wait before a card in box 0..5 is shown again
    private var cards: MutableList<Card>? = null

    private fun file(ctx: Context) = File(ctx.applicationContext.filesDir, NAME)

    @Synchronized
    private fun load(ctx: Context): MutableList<Card> {
        cards?.let { return it }
        val list = ArrayList<Card>()
        val f = file(ctx)
        if (f.isFile) {
            try {
                f.bufferedReader(Charsets.UTF_8).useLines { ls ->
                    for (l in ls) {
                        if (l.isBlank()) continue
                        try {
                            val o = JSONObject(l)
                            list.add(Card(o.getLong("id"), o.optString("s"), o.optString("d"), o.optString("a"), o.optString("b"),
                                o.optInt("box"), o.optLong("due"), o.optInt("seen"), o.optInt("ok")))
                        } catch (_: Exception) {}
                    }
                }
            } catch (_: Exception) {}
        }
        cards = list
        return list
    }

    @Synchronized
    private fun save(ctx: Context) {
        val list = cards ?: return
        try {
            val tmp = File(file(ctx).path + ".tmp")
            tmp.bufferedWriter(Charsets.UTF_8).use { w ->
                for (c in list) w.write(JSONObject().put("id", c.id).put("s", c.s).put("d", c.d).put("a", c.a).put("b", c.b)
                    .put("box", c.box).put("due", c.due).put("seen", c.seen).put("ok", c.ok).toString() + "\n")
            }
            file(ctx).delete()
            tmp.renameTo(file(ctx))
        } catch (_: Exception) {}
    }

    @Synchronized fun all(ctx: Context): List<Card> = load(ctx).toList()

    @Synchronized fun count(ctx: Context): Int = load(ctx).size

    @Synchronized fun due(ctx: Context): List<Card> {
        val now = System.currentTimeMillis()
        return load(ctx).filter { it.due <= now }.sortedBy { it.due }
    }

    @Synchronized fun learned(ctx: Context): Int = load(ctx).count { it.box >= 4 }

    /** False when the same text is already in the list. */
    @Synchronized
    fun add(ctx: Context, s: String, d: String, a0: String, b0: String): Boolean {
        val a = a0.trim().replace("\n", " ")
        val b = b0.trim().replace("\n", " ")
        if (a.isEmpty() || b.isEmpty()) return false
        val list = load(ctx)
        val k = Idm.norm(a)
        if (list.any { it.s == s && Idm.norm(it.a) == k }) return false
        var id = System.currentTimeMillis()
        while (list.any { it.id == id }) id++
        list.add(Card(id, s, d, a, b, 0, 0L, 0, 0))
        save(ctx)
        return true
    }

    @Synchronized
    fun remove(ctx: Context, id: Long) {
        load(ctx).removeAll { it.id == id }
        save(ctx)
    }

    @Synchronized
    fun clear(ctx: Context) {
        load(ctx).clear()
        save(ctx)
    }

    /** [g]: 0 = missed (comes back in 5 minutes), 1 = hard (same box, comes back later), 2 = easy (next box). */
    @Synchronized
    fun grade(ctx: Context, c: Card, g: Int) {
        val now = System.currentTimeMillis()
        c.seen++
        when (g) {
            0 -> { c.box = 0; c.due = now + 5 * 60 * 1000 }
            1 -> { c.ok++; c.due = now + maxOf(days[c.box], 1L) * DAY / 2 }
            else -> { c.ok++; c.box = minOf(5, c.box + 1); c.due = now + days[c.box] * DAY }
        }
        save(ctx)
    }
}
