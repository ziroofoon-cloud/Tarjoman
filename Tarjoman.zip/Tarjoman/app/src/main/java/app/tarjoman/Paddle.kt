package app.tarjoman

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import java.io.File
import java.nio.FloatBuffer

/**
 * A second, complete reader that runs on the phone with ONNX Runtime: PaddleOCR (Apache-2.0), exported to ONNX by the community
 * (huggingface.co/monkt/paddleocr-onnx). Two small models work together:
 *  1. a text DETECTOR (DBNet, 2 MB or 84 MB) that finds every line of writing on the page, any size, any angle of the page;
 *  2. a RECOGNIZER (CRNN + CTC, 7 to 81 MB, one per script) that reads each line.
 * Languages: English, Latin (Spanish ...), Korean, Chinese + Japanese, Arabic + Persian. Each recognizer is a separate download,
 * so the user chooses by size / speed. The lines come back as (text, box) and the normal grouping puts them into bubbles.
 */
object Paddle {
    class Line(val text: String, val rect: Rect, val score: Float)

    @Volatile var cfg: Cfg? = null

    fun dir(): File? = Ocr.base?.let { File(it, "paddle") }
    fun detFile(big: Boolean): File? = dir()?.let { File(it, if (big) "det_v5.onnx" else "det_v3.onnx") }
    fun detReady(): Boolean {
        val s = detFile(false); val b = detFile(true)
        return (s?.let { it.isFile && it.length() > 1_000_000L } ?: false) || (b?.let { it.isFile && it.length() > 50_000_000L } ?: false)
    }

    /** Which recognizer reads language [lang] (null = none for it). */
    fun key(lang: String): String? = when (lang) {
        "en" -> "en"
        "es" -> "latin"
        "ko" -> "ko"
        "zh", "ja" -> "zh"
        "ar", "fa" -> "ar"
        else -> null
    }

    fun recFile(key: String): File? = dir()?.let { File(it, "rec_$key.onnx") }
    fun dictFile(key: String): File? = dir()?.let { File(it, "dict_$key.txt") }
    fun recReady(key: String): Boolean =
        (recFile(key)?.let { it.isFile && it.length() > 1_000_000L } ?: false) && (dictFile(key)?.let { it.isFile && it.length() > 50L } ?: false)

    fun ready(lang: String): Boolean = key(lang)?.let { detReady() && recReady(it) } ?: false

    private var env: OrtEnvironment? = null
    private var det: OrtSession? = null
    private var detBig = false
    private val recs = HashMap<String, OrtSession>()
    private val chars = HashMap<String, List<String>>()
    private val idle = Handler(Looper.getMainLooper())
    private val idleRun = Runnable { release() }

    @Synchronized
    fun release() {
        try { det?.close() } catch (_: Throwable) {}
        for (s in recs.values) try { s.close() } catch (_: Throwable) {}
        det = null
        recs.clear()
    }

    private fun environment(): OrtEnvironment = env ?: OrtEnvironment.getEnvironment().also { env = it }

    private fun opts(): OrtSession.SessionOptions = OrtSession.SessionOptions().apply { setIntraOpNumThreads(4) }

    private fun detector(): OrtSession {
        val wantBig = (cfg?.paddleDet ?: "auto") != "small"
        val big = detFile(true)?.let { it.isFile && it.length() > 50_000_000L } ?: false
        val small = detFile(false)?.let { it.isFile && it.length() > 1_000_000L } ?: false
        val useBig = if (big && small) wantBig else big   // both installed: "auto" and "big" use the accurate one
        det?.let { if (detBig == useBig) return it; try { it.close() } catch (_: Throwable) {}; det = null }
        val f = (if (useBig) detFile(true) else detFile(false)) ?: throw IllegalStateException("det missing")
        val s = environment().createSession(f.absolutePath, opts())
        det = s
        detBig = useBig
        return s
    }

    private fun recognizer(key: String): OrtSession =
        recs[key] ?: environment().createSession((recFile(key) ?: throw IllegalStateException("rec missing")).absolutePath, opts()).also { recs[key] = it }

    private fun charset(key: String): List<String> = chars.getOrPut(key) {
        val f = dictFile(key) ?: throw IllegalStateException("dict missing")
        val l = ArrayList<String>()
        l.add("")                                   // index 0 = CTC blank
        for (ln in f.readLines(Charsets.UTF_8)) l.add(ln.trimEnd('\r', '\n'))
        l
    }

    /** All lines of writing on [bmp], read in language [lang]. Throws when a model cannot run; the caller then uses another reader. */
    @Synchronized
    fun readLines(bmp: Bitmap, lang: String): List<Line> {
        val k = key(lang) ?: throw IllegalStateException("language")
        try {
            val boxes = detect(bmp)
            val out = ArrayList<Line>()
            val cs = charset(k)
            val rs = recognizer(k)
            for (r in boxes) {
                val t = try { recognize(bmp, r, rs, cs, k == "zh" || k == "ko") } catch (_: Throwable) { null } ?: continue
                if (t.first.isBlank() || t.second < 0.45f) continue
                out.add(Line(t.first.trim(), r, t.second))
            }
            return out
        } finally {
            idle.removeCallbacks(idleRun)
            idle.postDelayed(idleRun, 45000)
        }
    }

    // ------------------------------------------------------------------ detection (DBNet)
    private fun detect(bmp: Bitmap): List<Rect> {
        val s = detector()
        val e = environment()
        val maxSide = (cfg?.paddleSide ?: 1280).coerceIn(640, 2048)
        val longSide = maxOf(bmp.width, bmp.height).toFloat()
        val sc = if (longSide < 640f) 640f / longSide else minOf(1f, maxSide / longSide)
        val nw = (Math.round(bmp.width * sc / 32f) * 32).coerceAtLeast(32)
        val nh = (Math.round(bmp.height * sc / 32f) * 32).coerceAtLeast(32)
        val small = Bitmap.createScaledBitmap(bmp, nw, nh, true)
        val px = IntArray(nw * nh)
        small.getPixels(px, 0, nw, 0, 0, nw, nh)
        if (small !== bmp) small.recycle()
        val n = nw * nh
        val a = FloatArray(3 * n)
        val mean = floatArrayOf(0.485f, 0.456f, 0.406f)
        val std = floatArrayOf(0.229f, 0.224f, 0.225f)
        for (i in 0 until n) {
            val c = px[i]
            // PaddleOCR feeds the picture as BGR with these means
            a[i] = ((c and 255) / 255f - mean[0]) / std[0]
            a[n + i] = (((c shr 8) and 255) / 255f - mean[1]) / std[1]
            a[2 * n + i] = (((c shr 16) and 255) / 255f - mean[2]) / std[2]
        }
        val name = s.inputNames.first()
        val t = OnnxTensor.createTensor(e, FloatBuffer.wrap(a), longArrayOf(1, 3, nh.toLong(), nw.toLong()))
        try {
            val res = s.run(mapOf(name to t))
            try {
                val o = res[0] as OnnxTensor
                val sh = o.info.shape
                val mh = sh[sh.size - 2].toInt()
                val mw = sh[sh.size - 1].toInt()
                val fb = o.floatBuffer
                val prob = FloatArray(mh * mw)
                fb.get(prob, 0, minOf(prob.size, fb.remaining()))
                return boxes(prob, mw, mh, bmp.width, bmp.height)
            } finally {
                res.close()
            }
        } finally {
            t.close()
        }
    }

    /** Probability map -> boxes: pixels above 0.3 that touch each other form a line; the box is grown a little (DB shrinks the text kernel). */
    private fun boxes(p: FloatArray, w: Int, h: Int, ow: Int, oh: Int): List<Rect> {
        val lab = BooleanArray(w * h)
        val q = IntArray(w * h)
        val out = ArrayList<Rect>()
        val fx = ow / w.toFloat()
        val fy = oh / h.toFloat()
        for (i0 in 0 until w * h) {
            if (lab[i0] || p[i0] <= 0.3f) continue
            var qh = 0; var qt = 0
            q[qt++] = i0; lab[i0] = true
            var x0 = w; var y0 = h; var x1 = 0; var y1 = 0; var cnt = 0; var sum = 0f
            while (qh < qt) {
                val i = q[qh++]
                val x = i % w; val y = i / w
                cnt++; sum += p[i]
                if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y
                if (x > 0 && !lab[i - 1] && p[i - 1] > 0.3f) { lab[i - 1] = true; q[qt++] = i - 1 }
                if (x < w - 1 && !lab[i + 1] && p[i + 1] > 0.3f) { lab[i + 1] = true; q[qt++] = i + 1 }
                if (y > 0 && !lab[i - w] && p[i - w] > 0.3f) { lab[i - w] = true; q[qt++] = i - w }
                if (y < h - 1 && !lab[i + w] && p[i + w] > 0.3f) { lab[i + w] = true; q[qt++] = i + w }
            }
            val bw = x1 - x0 + 1; val bh = y1 - y0 + 1
            if (cnt < 12 || minOf(bw, bh) < 3 || sum / cnt < 0.5f) continue
            // unclip: distance = area * 1.6 / perimeter of the (shrunk) box
            val d = (bw * bh * 1.6f) / (2f * (bw + bh))
            val r = Rect(((x0 - d) * fx).toInt(), ((y0 - d) * fy).toInt(), ((x1 + 1 + d) * fx).toInt(), ((y1 + 1 + d) * fy).toInt())
            if (!r.intersect(0, 0, ow, oh)) continue
            if (r.width() < 6 || r.height() < 6) continue
            out.add(r)
        }
        return out.sortedWith(compareBy({ it.top }, { it.left }))
    }

    // ------------------------------------------------------------------ recognition (CRNN + CTC)
    private fun recognize(bmp: Bitmap, r0: Rect, s: OrtSession, cs: List<String>, vertical: Boolean): Pair<String, Float>? {
        val e = environment()
        val r = Rect(r0)
        if (!r.intersect(0, 0, bmp.width, bmp.height) || r.width() < 4 || r.height() < 4) return null
        var crop = Bitmap.createBitmap(bmp, r.left, r.top, r.width(), r.height())
        if (vertical && crop.height >= crop.width * 3 / 2) {          // a tall box = vertical writing: turned like PaddleOCR does
            val m = Matrix().apply { postRotate(-90f) }
            val rot = Bitmap.createBitmap(crop, 0, 0, crop.width, crop.height, m, true)
            if (rot !== crop) { crop.recycle(); crop = rot }
        }
        val inName = s.inputNames.first()
        val info = s.inputInfo[inName]?.info as? ai.onnxruntime.TensorInfo
        val hh = info?.shape?.getOrNull(2)?.toInt()?.takeIf { it > 0 } ?: 48
        val ww = Math.ceil((hh * crop.width / crop.height.toDouble())).toInt().coerceIn(hh / 2, 1280)
        val scaled = Bitmap.createScaledBitmap(crop, ww, hh, true)
        if (scaled !== crop) crop.recycle()
        val px = IntArray(ww * hh)
        scaled.getPixels(px, 0, ww, 0, 0, ww, hh)
        scaled.recycle()
        val n = ww * hh
        val a = FloatArray(3 * n)
        for (i in 0 until n) {
            val c = px[i]
            a[i] = ((c and 255) / 255f - 0.5f) / 0.5f
            a[n + i] = (((c shr 8) and 255) / 255f - 0.5f) / 0.5f
            a[2 * n + i] = (((c shr 16) and 255) / 255f - 0.5f) / 0.5f
        }
        val t = OnnxTensor.createTensor(e, FloatBuffer.wrap(a), longArrayOf(1, 3, hh.toLong(), ww.toLong()))
        try {
            val res = s.run(mapOf(inName to t))
            try {
                val o = res[0] as OnnxTensor
                val sh = o.info.shape
                val classes = sh[sh.size - 1].toInt()
                val steps = sh[sh.size - 2].toInt()
                val fb = o.floatBuffer
                val all = FloatArray(steps * classes)
                fb.get(all, 0, minOf(all.size, fb.remaining()))
                val space = classes == cs.size + 1          // the model has one more class after the dictionary: the space
                val sb = StringBuilder()
                var last = 0
                var conf = 0f
                var kept = 0
                for (st in 0 until steps) {
                    var best = 0
                    var bv = -1e30f
                    val off = st * classes
                    for (c in 0 until classes) { val v = all[off + c]; if (v > bv) { bv = v; best = c } }
                    if (best != 0 && best != last) {
                        val ch = if (best < cs.size) cs[best] else if (space && best == cs.size) " " else ""
                        sb.append(ch)
                        conf += if (bv in 0f..1.0001f) bv else 1f
                        kept++
                    }
                    last = best
                }
                return Pair(sb.toString(), if (kept == 0) 0f else conf / kept)
            } finally {
                res.close()
            }
        } finally {
            t.close()
        }
    }
}
