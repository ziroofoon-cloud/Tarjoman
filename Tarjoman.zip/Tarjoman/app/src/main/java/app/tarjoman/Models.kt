package app.tarjoman

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.URL

class Mdl(
    val id: String, val title: String, val tier: String, val file: String, val url: String,
    val mb: Int, val fam: String, val gated: Boolean, val note: String
)

object Models {
    private const val HF = "https://huggingface.co/"

    /** A getter (not a stored value) so the notes follow the app language when it changes. */
    val catalog: List<Mdl> get() = listOf(
        Mdl("smollm-135m", "SmolLM · 135M (q8)", L("فوق‌سبک"), "SmolLM-135M-Instruct_multi-prefill-seq_q8_ekv1280.task",
            HF + "litert-community/SmolLM-135M-Instruct/resolve/main/SmolLM-135M-Instruct_multi-prefill-seq_q8_ekv1280.task",
            160, "qwen", false, L("کوچک‌ترین مدل فهرست؛ بدون نیاز به توکن. انگلیسی ساده را می‌فهمد ولی فارسی و ژاپنی را عملاً بلد نیست؛ بیشتر برای آزمایش و گوشی‌های ضعیف است. اگر لینک ۴۰۴ داد، از «از لینک» استفاده کن.")),
        Mdl("gemma3-270m", "Gemma 3 · 270M (q8)", L("خیلی سبک"), "gemma3-270m-it-q8.task",
            HF + "litert-community/gemma-3-270m-it/resolve/main/gemma3-270m-it-q8.task",
            290, "gemma", true, L("خیلی سریع و کم‌مصرف ولی ضعیف‌ترین کیفیت (برای متن کوتاه و مواقع فوری). توکن Hugging Face و قبول لایسنس Gemma لازم است.")),
        Mdl("qwen25-0.5b", "Qwen 2.5 · 0.5B (q8)", L("سبک"), "Qwen2.5-0.5B-Instruct_multi-prefill-seq_q8_ekv1280.task",
            HF + "litert-community/Qwen2.5-0.5B-Instruct/resolve/main/Qwen2.5-0.5B-Instruct_multi-prefill-seq_q8_ekv1280.task",
            547, "qwen", false, L("بدون نیاز به توکن. انگلیسی و ژاپنی قابل‌قبول، فارسی ضعیف.")),
        Mdl("gemma3-1b", "Gemma 3 · 1B (int4)", L("متوسط"), "Gemma3-1B-IT_multi-prefill-seq_q4_ekv2048.task",
            HF + "litert-community/Gemma3-1B-IT/resolve/main/Gemma3-1B-IT_multi-prefill-seq_q4_ekv2048.task",
            555, "gemma", true, L("کیفیت بهتر، به‌خصوص فارسی. توکن Hugging Face و قبول لایسنس Gemma لازم است.")),
        Mdl("gemma3-1b-q8", "Gemma 3 · 1B (q8)", L("سنگین · دقیق‌تر"), "Gemma3-1B-IT_multi-prefill-seq_q8_ekv2048.task",
            HF + "litert-community/Gemma3-1B-IT/resolve/main/Gemma3-1B-IT_multi-prefill-seq_q8_ekv2048.task",
            1074, "gemma", true, L("همان Gemma 3 · 1B ولی با دقت بالاتر (q8): فارسی کمی بهتر از نسخهٔ int4، دو برابر حجم و کندتر. توکن Hugging Face و قبول لایسنس Gemma لازم است.")),
        Mdl("qwen25-1.5b", "Qwen 2.5 · 1.5B (q8)", L("سنگین"), "Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv1280.task",
            HF + "litert-community/Qwen2.5-1.5B-Instruct/resolve/main/Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv1280.task",
            1600, "qwen", false, L("بزرگ‌ترین و معمولاً بهترین کیفیت برای انگلیسی و ژاپنی؛ کندتر و رم‌خور است. بدون نیاز به توکن. اگر برنامه روی گوشی بسته شد، مدل سبک‌تر را بگذار.")),
        // .litertlm models run only in builds made with LiteRT-LM (-Plitertlm); they are listed in every build with a warning.
        Mdl("gemma4-e2b-lm", "Gemma 4 · E2B (LiteRT-LM)", L("فوق‌سنگین · بدون توکن"), "gemma-4-E2B-it.litertlm",
            HF + "litert-community/gemma-4-E2B-it-litert-lm/resolve/main/gemma-4-E2B-it.litertlm",
            2590, "gemma", false, L("جدیدترین Gemma؛ بدون نیاز به توکن و لایسنس (Apache-2.0). کیفیت بالا و چندزبانه ولی سنگین و کندتر. فقط در نسخه‌ای که با LiteRT-LM ساخته شده کار می‌کند.")),
        Mdl("gemma3n-e2b-lm", "Gemma 3n · E2B (LiteRT-LM)", L("فوق‌سنگین"), "gemma-3n-E2B-it-int4.litertlm",
            HF + "google/gemma-3n-E2B-it-litert-lm/resolve/main/gemma-3n-E2B-it-int4.litertlm",
            3650, "gemma", true, L("بهترین کیفیت در فهرست (به‌خصوص فارسی و ژاپنی) ولی خیلی سنگین و کند است؛ فقط برای متن کوتاه یا حالت «کند و دقیق». حداقل ۶ گیگ رم لازم است. فقط در نسخه‌ای که با LiteRT-LM ساخته شده کار می‌کند. توکن Hugging Face و قبول لایسنس Gemma لازم است.")),
        Mdl("qwen3-0.6b-lm", "Qwen 3 · 0.6B (LiteRT-LM)", L("سبک (نسل جدید)"), "Qwen3-0.6B.litertlm",
            HF + "litert-community/Qwen3-0.6B/resolve/main/Qwen3-0.6B.litertlm",
            600, "qwen3", false, L("نسل جدید Qwen با فرمت .litertlm؛ فقط در نسخه‌ای که با LiteRT-LM ساخته شده کار می‌کند. بدون نیاز به توکن."))
    )

    /** Quality 1..5 (mostly Persian + Japanese + English together) and speed 1..5 on a mid-range phone. */
    fun quality(id: String): Int = when (id) {
        "gemma4-e2b-lm" -> 5
        "gemma3n-e2b-lm" -> 5
        "gemma3-1b" -> 4
        "gemma3-1b-q8" -> 4
        "qwen25-1.5b" -> 3
        "qwen3-0.6b-lm" -> 3
        "qwen25-0.5b" -> 2
        else -> 1
    }

    fun speed(id: String): Int = when (id) {
        "gemma3n-e2b-lm" -> 1
        "gemma4-e2b-lm" -> 2
        "qwen25-1.5b" -> 2
        "gemma3-1b" -> 3
        "gemma3-1b-q8" -> 2
        "qwen25-0.5b", "qwen3-0.6b-lm" -> 4
        else -> 5
    }

    /** Small labels on the cards: the three levels (light / medium / heavy), the single best pick and the extremes. */
    fun badges(id: String): List<String> = when (id) {
        "smollm-135m" -> listOf(L("سبک‌ترین"))
        "gemma3-270m" -> listOf(L("سریع‌ترین"))
        "qwen25-0.5b" -> listOf(L("پیشنهاد · سبک"))
        "gemma3-1b" -> listOf("⭐ " + L("پیشنهاد ویژه"), L("پیشنهاد · متوسط"))
        "gemma3-1b-q8" -> listOf(L("پیشنهاد · سنگین"))
        "gemma4-e2b-lm" -> listOf(L("بهترین کیفیت"))
        "gemma3n-e2b-lm" -> listOf(L("سنگین‌ترین"))
        else -> emptyList()
    }

    /** Best first. */
    val ranked: List<Mdl> get() = catalog.sortedWith(compareByDescending<Mdl> { quality(it.id) }.thenByDescending { speed(it.id) })

    private fun internalDir(ctx: Context) = File(ctx.filesDir, "models")

    /** The folder with the downloaded models (see Settings: private, app folder on shared storage, or any folder). */
    fun dir(ctx: Context): File {
        val c = Cfg(ctx).modelDir
        val f = when {
            c == "ext" -> ctx.getExternalFilesDir("models") ?: internalDir(ctx)
            c.startsWith("/") -> File(c)
            else -> internalDir(ctx)
        }
        if (!f.exists() && !f.mkdirs()) return internalDir(ctx).apply { mkdirs() }
        return f
    }

    /** Folder for a setting value (without creating it). */
    fun dirFor(ctx: Context, v: String): File = when {
        v == "ext" -> ctx.getExternalFilesDir("models") ?: internalDir(ctx)
        v.startsWith("/") -> File(v)
        else -> internalDir(ctx)
    }

    /** Side folders ("inpaint" = LaMa, "ocr" = Tesseract data) follow the models folder; with the default setting they stay where older versions put them. */
    fun auxDirFor(ctx: Context, v: String, name: String): File =
        if (v.isEmpty()) File(ctx.filesDir, name) else File(dirFor(ctx, v), name)

    fun auxDir(ctx: Context, name: String): File = auxDirFor(ctx, Cfg(ctx).modelDir, name)

    /** Moves a file: a rename first (same storage: instant, no extra space); otherwise copy and delete at once, so only this one file is ever doubled. */
    fun moveFile(src: File, dst: File): Boolean {
        dst.parentFile?.mkdirs()
        if (src.renameTo(dst)) return true
        return try {
            src.inputStream().use { i -> dst.outputStream().use { o -> i.copyTo(o, 256 * 1024) } }
            if (dst.length() == src.length()) { src.delete(); true } else { dst.delete(); false }
        } catch (_: Throwable) {
            dst.delete()
            false
        }
    }

    /** Moves a file or a whole folder; returns (moved, failed). */
    fun moveTree(src: File, dst: File): Pair<Int, Int> {
        if (!src.exists() || src.absolutePath == dst.absolutePath) return Pair(0, 0)
        var ok = 0
        var bad = 0
        if (src.isDirectory) {
            dst.mkdirs()
            for (c in src.listFiles() ?: emptyArray()) {
                val r = moveTree(c, File(dst, c.name))
                ok += r.first
                bad += r.second
            }
            src.delete()
        } else if (moveFile(src, dst)) ok++ else bad++
        return Pair(ok, bad)
    }

    fun file(ctx: Context, m: Mdl): File = File(dir(ctx), m.file)

    private val exts = listOf(".task", ".bin", ".litertlm", ".tflite")
    /** Only real model files; helper files such as "<model>.xnnpack_cache" (made by the engine) and ".part" are not models. */
    fun isModelFile(f: File): Boolean = f.isFile && f.length() > 0 && exts.any { f.name.endsWith(it, true) }

    // ---- crash guard: a native crash of the AI engine cannot be caught, so a marker is written before a model is used and removed after
    private fun gp(ctx: Context) = ctx.getSharedPreferences("modelguard", Context.MODE_PRIVATE)
    private fun key(f: File) = f.name + "|" + f.length() + "|" + f.lastModified()

    fun markUse(ctx: Context, f: File) { gp(ctx).edit().putString("using", key(f)).commit() }
    fun markDone(ctx: Context, f: File) { gp(ctx).edit().remove("using").remove("s:" + key(f)).commit() }
    fun markFail(ctx: Context) { gp(ctx).edit().remove("using").commit() }

    /** Called at app start: if the last use of a model never finished, the app was killed (crash). First time: caches are removed and it is tried again; second time in a row: the model is set aside. Returns a message, or null. */
    fun settleCrash(ctx: Context): String? {
        val p = gp(ctx)
        val k = p.getString("using", null) ?: return null
        val strikes = p.getInt("s:" + k, 0) + 1
        val name = k.substringBefore("|")
        val f = File(dir(ctx), name)
        val e = p.edit().remove("using")
        if (f.exists()) deleteCaches(f)
        val msg: String
        if (strikes >= 2) { e.putBoolean("bad:" + k, true).remove("s:" + k); msg = "bad:" + name } else { e.putInt("s:" + k, strikes); msg = "once:" + name }
        e.commit()
        return msg
    }

    fun isBad(ctx: Context, f: File): Boolean = knownBad(f.name) || gp(ctx).getBoolean("bad:" + key(f), false)

    /** Cheap check that a file is complete before the engine touches it (a .task file is a zip; a cut-off copy has no end record). Null = looks fine. */
    fun check(f: File): String? {
        if (!f.isFile || f.length() < 1024 * 1024) return L("فایل مدل خالی یا خیلی کوچک است؛ حذفش کن و دوباره دانلود کن.")
        val cat = catalog.firstOrNull { it.file == f.name }
        if (cat != null && cat.mb > 0 && f.length() < cat.mb * 1048576L * 85 / 100) return L("فایل مدل ناقص است (کامل دانلود یا کپی نشده)؛ حذفش کن و دوباره بگیر.")
        if (f.name.endsWith(".task", true)) {
            // Android's ZipFile is stricter than the engine's own reader (big or zip64 files, odd entries): a failure there
            // is accepted when the end-of-archive record is still at the end of the file (a cut-off copy never has it).
            try { java.util.zip.ZipFile(f).close() } catch (_: Throwable) { if (!hasZipEnd(f)) return L("فایل مدل ناقص یا خراب است؛ حذفش کن و دوباره بگیر.") }
        }
        return null
    }

    private fun hasZipEnd(f: File): Boolean = try {
        java.io.RandomAccessFile(f, "r").use { r ->
            val n = minOf(r.length(), 70_000L).toInt()
            val buf = ByteArray(n)
            r.seek(r.length() - n); r.readFully(buf)
            var ok = false
            for (i in n - 22 downTo 0) if (buf[i] == 0x50.toByte() && buf[i + 1] == 0x4b.toByte() && buf[i + 2] == 0x05.toByte() && buf[i + 3] == 0x06.toByte()) { ok = true; break }
            ok
        }
    } catch (_: Throwable) { false }

    /** The engine's speed cache(s) that sit next to a model; safe to delete (rebuilt on the next load). */
    fun deleteCaches(model: File) {
        val dir = model.parentFile ?: return
        (dir.listFiles() ?: emptyArray()).filter { it.isFile && it.name.startsWith(model.name + ".") && it.name.endsWith("cache") }.forEach { it.delete() }
    }

    /** Removes caches whose model is no longer there. */
    fun cleanOrphanCaches(ctx: Context) {
        val all = dir(ctx).listFiles() ?: return
        for (c in all) {
            if (!c.isFile || !c.name.endsWith("cache")) continue
            val i = c.name.indexOf(".task.").let { if (it >= 0) it + 5 else c.name.indexOf(".litertlm.").let { j -> if (j >= 0) j + 9 else -1 } }
            if (i > 0 && !File(c.parentFile, c.name.substring(0, i)).exists()) c.delete()
        }
    }

    val badNames = setOf("Qwen3-0.6B_dynamic_wi4b32_afp32.litertlm")
    fun knownBad(name: String): Boolean = name in badNames

    fun manualFiles(ctx: Context): List<File> {
        val known = catalog.map { it.file }.toSet()
        return (dir(ctx).listFiles() ?: emptyArray()).filter { isModelFile(it) && it.name !in known }.sortedBy { it.name }
    }

    fun installedFiles(ctx: Context): List<File> =
        (dir(ctx).listFiles() ?: emptyArray()).filter { isModelFile(it) && !knownBad(it.name) && !gp(ctx).getBoolean("bad:" + key(it), false) }.sortedBy { it.name }

    fun famOf(cfg: Cfg, f: File): String {
        catalog.firstOrNull { it.file == f.name }?.let { return it.fam }
        val saved = cfg.fam(f.name)
        if (saved.isNotEmpty()) return saved
        val n = f.name.lowercase()
        return when {
            n.contains("gemma") -> "gemma"
            n.contains("qwen3") -> "qwen3"
            n.contains("qwen") -> "qwen"
            else -> "raw"
        }
    }

    fun titleOf(f: File): String = catalog.firstOrNull { it.file == f.name }?.title ?: f.name
}

/** Errors that retrying cannot fix (wrong token, file not found). */
class FatalIo(msg: String) : IOException(msg)

/**
 * Resumable downloader. The partly downloaded file (.part) is never thrown away: after a cut connection, a timeout or
 * a bad network it waits, retries by itself and continues from the same byte (HTTP Range). It only gives up when many
 * retries in a row bring no new data, and even then the .part file stays so the next tap continues from there.
 * Redirects are followed by hand so the HF token is not sent to the CDN.
 */
class Downloader(private val cfg: Cfg, private val ctx: Context) {
    @Volatile var cancelled = false
    @Volatile var onNote: (String) -> Unit = {}

    private fun mb(b: Long): String = (b / 1048576).toString() + " MB"

    fun download(url0: String, dest: File, onProgress: (Long, Long) -> Unit) {
        val part = File(dest.path + ".part")
        var tries = 0
        var lastHave = -1L
        while (true) {
            if (cancelled) throw IOException(L("لغو شد"))
            try {
                attempt(url0, dest, onProgress)
                return
            } catch (e: FatalIo) {
                throw e
            } catch (e: Exception) {
                if (cancelled) throw IOException(L("لغو شد"))
                val have = if (part.exists()) part.length() else 0L
                // New data arrived since the last failure: a slow but moving download never gives up.
                if (have > lastHave) tries = 0
                lastHave = have
                tries++
                if (tries > 12) throw IOException((e.message ?: e.toString()) + " — " + L("دانلود ناقص ماند؛ دوباره بزن تا ادامه پیدا کند"))
                waitBeforeRetry(minOf(3 * tries, 20), have, tries)
            }
        }
    }

    private fun waitBeforeRetry(sec: Int, have: Long, n: Int) {
        for (i in sec downTo 1) {
            if (cancelled) return
            onNote(L("قطع شد؛ تلاش مجدد تا ") + i + L(" ثانیه دیگر (ادامه از ") + mb(have) + L("، تلاش ") + n + ")")
            try { Thread.sleep(1000) } catch (_: InterruptedException) {}
        }
        while (!cancelled && !Net.isOnline(ctx)) {
            onNote(L("منتظر اتصال اینترنت… (ادامه از ") + mb(have) + ")")
            try { Thread.sleep(2000) } catch (_: InterruptedException) {}
        }
    }

    private fun attempt(url0: String, dest: File, onProgress: (Long, Long) -> Unit) {
        val part = File(dest.path + ".part")
        val meta = File(dest.path + ".meta")      // total size + ETag of the file the .part belongs to
        var cur = url0
        val mirror = cfg.mirror.trim()
        if (mirror.isNotEmpty() && mirror != "huggingface.co") cur = cur.replace("huggingface.co", mirror)
        var have = if (part.exists()) part.length() else 0L
        var savedTotal = -1L
        var savedTag = ""
        try {
            if (meta.exists()) {
                val l = meta.readLines()
                savedTotal = l.getOrNull(0)?.toLongOrNull() ?: -1L
                savedTag = l.getOrNull(1) ?: ""
            }
        } catch (_: Exception) {}
        if (have > 0 && savedTotal > 0 && have > savedTotal) { part.delete(); have = 0L; savedTag = "" }
        var redirects = 0
        while (true) {
            if (cancelled) throw IOException(L("لغو شد"))
            val h = Net.open(cur, cfg, 30000)
            h.instanceFollowRedirects = false
            h.setRequestProperty("Accept-Encoding", "identity")
            val host = URL(cur).host
            if (cfg.hfToken.isNotBlank() && (host.endsWith("huggingface.co") || host == mirror)) {
                h.setRequestProperty("Authorization", "Bearer " + cfg.hfToken.trim())
            } else if (cfg.hfCookie.isNotBlank() && (host.endsWith("huggingface.co") || host == mirror)) {
                // signed in through the in-app browser: the session cookie replaces the token
                h.setRequestProperty("Cookie", cfg.hfCookie)
            }
            if (have > 0) {
                // No If-Range: some servers answer it with the whole file, which restarted a stopped download from zero.
                // The size check below makes sure the file on the server is still the same one.
                h.setRequestProperty("Range", "bytes=$have-")
            }
            val code = h.responseCode
            if (code in 300..399) {
                val loc = h.getHeaderField("Location") ?: throw IOException("redirect without location")
                cur = URL(URL(cur), loc).toString()
                h.disconnect()
                redirects++
                if (redirects > 8) throw IOException("too many redirects")
                continue
            }
            if (code == 401 || code == 403) { h.disconnect(); throw FatalIo("HTTP $code - " + (if (cfg.hfToken.isBlank() && cfg.hfCookie.isBlank()) L("این مدل قفل است؛ دکمهٔ «ورود با حساب Hugging Face» را بزن (یا توکن بگذار).") else if (cfg.hfToken.isBlank()) L("ورود یا لایسنس قبول نشد؛ دوباره وارد شو و در صفحهٔ مدل Acknowledge license را بزن.") else L("توکن قبول نشد یا لایسنس همین مدل در صفحهٔ مدل قبول نشده؛ «صفحهٔ مدل» را باز کن و قبول کن (توکن باید نوع Read باشد)."))) }
            if (code == 404 || code == 410) { h.disconnect(); throw FatalIo("HTTP $code") }
            if (code == 416) {
                h.disconnect()
                if (savedTotal > 0 && have == savedTotal) { dest.delete(); part.renameTo(dest); meta.delete(); return }
                // The .part does not fit the file on the server: only then start again from zero.
                part.delete(); meta.delete(); have = 0L; savedTag = ""; savedTotal = -1L
                continue
            }
            if (code !in 200..299) { h.disconnect(); throw IOException("HTTP $code") }
            val append: Boolean
            val total: Long
            if (code == 206) {
                val cr = h.getHeaderField("Content-Range") ?: ""
                val m = Regex("bytes (\\d+)-(\\d+)/(\\d+|\\*)").find(cr)
                val start = m?.groupValues?.get(1)?.toLongOrNull() ?: have
                if (start != have) { h.disconnect(); part.delete(); meta.delete(); have = 0L; savedTag = ""; continue }
                total = m?.groupValues?.get(3)?.toLongOrNull() ?: (if (h.contentLengthLong > 0) have + h.contentLengthLong else -1L)
                if (savedTotal > 0 && total > 0 && total != savedTotal) {
                    h.disconnect(); part.delete(); meta.delete(); have = 0L; savedTag = ""; savedTotal = -1L
                    Dl.toast(ctx, L("فایل روی سرور عوض شده؛ از اول شروع شد"))
                    continue
                }
                append = true
            } else {
                // 200: the server sent the whole file (it cannot resume, or the file changed): start from zero.
                if (have > 0) Dl.toast(ctx, L("سرور ادامه دادن را قبول نکرد؛ از اول شروع شد"))
                have = 0L
                total = h.contentLengthLong
                append = false
            }
            try { meta.writeText(total.toString() + "\n" + (h.getHeaderField("ETag") ?: "")) } catch (_: Exception) {}
            try {
                h.inputStream.use { ins ->
                    FileOutputStream(part, append).use { out ->
                        val buf = ByteArray(64 * 1024)
                        onProgress(have, total)
                        while (true) {
                            if (cancelled) throw IOException(L("لغو شد"))
                            val n = ins.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            have += n
                            onProgress(have, total)
                        }
                    }
                }
            } finally {
                h.disconnect()
            }
            if (total > 0 && part.length() > total) { part.delete(); meta.delete(); throw IOException("size mismatch") }
            if (total > 0 && part.length() < total) throw IOException(L("دانلود ناقص ماند؛ دوباره بزن تا ادامه پیدا کند"))
            dest.delete()
            part.renameTo(dest)
            meta.delete()
            return
        }
    }
}
