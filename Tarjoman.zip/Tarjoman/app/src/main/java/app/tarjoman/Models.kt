package app.tarjoman

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.URL

class Mdl(
    val id: String, val title: String, val tier: String, val file: String, val url: String,
    val mb: Int, val fam: String, val gated: Boolean, val note: String
)

object Models {
    private const val HF = "https://huggingface.co/"

    val catalog = listOf(
        Mdl("gemma3-270m", "Gemma 3 · 270M (q8)", "فوق‌سبک", "gemma3-270m-it-q8.task",
            HF + "litert-community/gemma-3-270m-it/resolve/main/gemma3-270m-it-q8.task",
            290, "gemma", true, "خیلی سریع و کم‌مصرف ولی ضعیف‌ترین کیفیت (برای متن کوتاه و مواقع فوری). توکن Hugging Face و قبول لایسنس Gemma لازم است."),
        Mdl("qwen25-0.5b", "Qwen 2.5 · 0.5B (q8)", "سبک", "Qwen2.5-0.5B-Instruct_multi-prefill-seq_q8_ekv1280.task",
            HF + "litert-community/Qwen2.5-0.5B-Instruct/resolve/main/Qwen2.5-0.5B-Instruct_multi-prefill-seq_q8_ekv1280.task",
            547, "qwen", false, "بدون نیاز به توکن. انگلیسی و ژاپنی قابل‌قبول، فارسی ضعیف."),
        Mdl("gemma3-1b", "Gemma 3 · 1B (int4)", "متوسط", "Gemma3-1B-IT_multi-prefill-seq_q4_ekv2048.task",
            HF + "litert-community/Gemma3-1B-IT/resolve/main/Gemma3-1B-IT_multi-prefill-seq_q4_ekv2048.task",
            555, "gemma", true, "کیفیت بهتر، به‌خصوص فارسی. توکن Hugging Face و قبول لایسنس Gemma لازم است."),
        Mdl("qwen3-0.6b", "Qwen 3 · 0.6B (int8)", "سبک+", "Qwen3-0.6B.litertlm",
            HF + "litert-community/Qwen3-0.6B/resolve/main/Qwen3-0.6B.litertlm",
            586, "qwen3", false, "نسل جدیدتر Qwen با پشتیبانی چندزبانه بهتر. بدون نیاز به توکن. فرمت جدید .litertlm.")
    )

    fun dir(ctx: Context): File = File(ctx.filesDir, "models").apply { mkdirs() }

    fun file(ctx: Context, m: Mdl): File = File(dir(ctx), m.file)

    fun isModelFile(f: File): Boolean = f.isFile && f.length() > 0 && !f.name.endsWith(".part")

    fun manualFiles(ctx: Context): List<File> {
        val known = catalog.map { it.file }.toSet()
        return (dir(ctx).listFiles() ?: emptyArray()).filter { isModelFile(it) && it.name !in known }.sortedBy { it.name }
    }

    fun installedFiles(ctx: Context): List<File> =
        (dir(ctx).listFiles() ?: emptyArray()).filter { isModelFile(it) }.sortedBy { it.name }

    fun famOf(cfg: Cfg, f: File): String {
        catalog.firstOrNull { it.file == f.name }?.let { return it.fam }
        val saved = cfg.fam(f.name)
        if (saved.isNotEmpty()) return saved
        val n = f.name.lowercase()
        return when {
            n.contains("gemma") -> "gemma"
            n.contains("qwen3") -> "qwen3"
            n.contains("qwen") -> "qwen"
            else -> "raw"
        }
    }

    fun titleOf(f: File): String = catalog.firstOrNull { it.file == f.name }?.title ?: f.name
}

/** Resumable downloader (follows redirects by hand so the HF token is not sent to the CDN). */
class Downloader(private val cfg: Cfg) {
    @Volatile
    var cancelled = false

    fun download(url0: String, dest: File, onProgress: (Long, Long) -> Unit) {
        val part = File(dest.path + ".part")
        var cur = url0
        val mirror = cfg.mirror.trim()
        if (mirror.isNotEmpty() && mirror != "huggingface.co") cur = cur.replace("huggingface.co", mirror)
        var have = if (part.exists()) part.length() else 0L
        var redirects = 0
        while (true) {
            val h = Net.open(cur, cfg, 30000)
            h.instanceFollowRedirects = false
            val host = URL(cur).host
            if (cfg.hfToken.isNotBlank() && (host.endsWith("huggingface.co") || host == mirror)) {
                h.setRequestProperty("Authorization", "Bearer " + cfg.hfToken.trim())
            }
            if (have > 0) h.setRequestProperty("Range", "bytes=$have-")
            val code = h.responseCode
            if (code in 300..399) {
                val loc = h.getHeaderField("Location") ?: throw IOException("redirect without location")
                cur = URL(URL(cur), loc).toString()
                h.disconnect()
                redirects++
                if (redirects > 8) throw IOException("too many redirects")
                continue
            }
            if (code == 401 || code == 403) { h.disconnect(); throw IOException("HTTP $code - توکن یا قبول لایسنس لازم است") }
            if (code == 416) { h.disconnect(); dest.delete(); part.renameTo(dest); return }
            if (code !in 200..299) { h.disconnect(); throw IOException("HTTP $code") }
            val append = code == 206
            if (!append) have = 0L
            val len = h.contentLengthLong
            val total = if (len > 0) (if (append) have + len else len) else -1L
            try {
                h.inputStream.use { ins ->
                    FileOutputStream(part, append).use { out ->
                        val buf = ByteArray(256 * 1024)
                        while (true) {
                            if (cancelled) throw IOException("لغو شد")
                            val n = ins.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            have += n
                            onProgress(have, total)
                        }
                    }
                }
            } finally {
                h.disconnect()
            }
            if (total > 0 && part.length() < total) throw IOException("دانلود ناقص ماند؛ دوباره بزن تا ادامه پیدا کند")
            dest.delete()
            part.renameTo(dest)
            return
        }
    }
}
