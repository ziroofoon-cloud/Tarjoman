package app.tarjoman

/** A typed number written in words: English, Persian, Japanese. */
object NumWords {
    private val rx = Regex("^[-+−]?[0-9٠-٩۰-۹][0-9٠-٩۰-۹,٬،]*([.٫][0-9٠-٩۰-۹]+)?$")

    private fun norm(s: String): String {
        val sb = StringBuilder()
        for (c in s) when (c) {
            in '٠'..'٩' -> sb.append('0' + (c - '٠'))
            in '۰'..'۹' -> sb.append('0' + (c - '۰'))
            ',', '٬', '،' -> {}
            '٫' -> sb.append('.')
            '−' -> sb.append('-')
            else -> sb.append(c)
        }
        return sb.toString()
    }

    fun isNumber(t: String): Boolean = rx.matches(t.trim()) && norm(t.trim()).trimStart('-', '+').substringBefore('.').length <= 18

    /** [lang] en / fa / ja; null when [t] is not a plain number. */
    fun words(t: String, lang: String): String? {
        if (!isNumber(t)) return null
        val n = norm(t.trim())
        val neg = n.startsWith("-")
        val body = n.trimStart('-', '+')
        val ip = body.substringBefore('.')
        val fp = if (body.contains('.')) body.substringAfter('.') else ""
        val v = ip.toLong()
        val sb = StringBuilder()
        when (lang) {
            "fa" -> {
                if (neg) sb.append("منفی ")
                sb.append(fa(v))
                if (fp.isNotEmpty()) { sb.append(" ممیز "); sb.append(fp.map { fa((it - '0').toLong()) }.joinToString(" ")) }
            }
            "ja" -> {
                if (neg) sb.append("マイナス")
                sb.append(ja(v))
                if (fp.isNotEmpty()) { sb.append("点"); sb.append(fp.map { jaD[it - '0'] }.joinToString("")) }
            }
            else -> {
                if (neg) sb.append("minus ")
                sb.append(en(v))
                if (fp.isNotEmpty()) { sb.append(" point "); sb.append(fp.map { en((it - '0').toLong()) }.joinToString(" ")) }
            }
        }
        return sb.toString()
    }

    private val inRx = Regex("(?<![0-9٠-٩۰-۹.:/,٫٬-])[0-9٠-٩۰-۹]{1,12}(?![0-9٠-٩۰-۹.:/,٫٬%])")

    /** Every whole number inside [t] written in words ([lang] en / fa / ja). Times, dates, decimals, prices with separators stay. */
    fun inText(t: String, lang: String): String =
        inRx.replace(t) { m ->
            val n = norm(m.value)
            if (n.length > 1 && n.startsWith("0")) m.value else (words(m.value, lang) ?: m.value)
        }

    // ---- English
    private val e1 = arrayOf("zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen")
    private val e10 = arrayOf("", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety")
    private val eS = arrayOf("", " thousand", " million", " billion", " trillion", " quadrillion", " quintillion")
    private fun en3(n: Int): String {
        val parts = ArrayList<String>()
        if (n >= 100) parts.add(e1[n / 100] + " hundred")
        val r = n % 100
        if (r > 0) parts.add(if (r < 20) e1[r] else e10[r / 10] + (if (r % 10 > 0) "-" + e1[r % 10] else ""))
        return parts.joinToString(" ")
    }
    fun en(v: Long): String {
        if (v == 0L) return "zero"
        var x = v
        val out = ArrayList<String>()
        var i = 0
        while (x > 0) { val g = (x % 1000).toInt(); if (g > 0) out.add(0, en3(g) + eS[i]); x /= 1000; i++ }
        return out.joinToString(" ")
    }

    // ---- Persian
    private val f1 = arrayOf("صفر", "یک", "دو", "سه", "چهار", "پنج", "شش", "هفت", "هشت", "نه", "ده", "یازده", "دوازده", "سیزده", "چهارده", "پانزده", "شانزده", "هفده", "هجده", "نوزده")
    private val f10 = arrayOf("", "", "بیست", "سی", "چهل", "پنجاه", "شصت", "هفتاد", "هشتاد", "نود")
    private val f100 = arrayOf("", "صد", "دویست", "سیصد", "چهارصد", "پانصد", "ششصد", "هفتصد", "هشتصد", "نهصد")
    private val fS = arrayOf("", "هزار", "میلیون", "میلیارد", "تریلیون", "کوادریلیون", "کوینتیلیون")
    private fun fa3(n: Int): String {
        val parts = ArrayList<String>()
        if (n >= 100) parts.add(f100[n / 100])
        val r = n % 100
        if (r > 0) { if (r < 20) parts.add(f1[r]) else { parts.add(f10[r / 10]); if (r % 10 > 0) parts.add(f1[r % 10]) } }
        return parts.joinToString(" و ")
    }
    fun fa(v: Long): String {
        if (v == 0L) return "صفر"
        var x = v
        val out = ArrayList<String>()
        var i = 0
        while (x > 0) { val g = (x % 1000).toInt(); if (g > 0) out.add(0, if (i == 1 && g == 1) "هزار" else fa3(g) + (if (i > 0) " " + fS[i] else "")); x /= 1000; i++ }
        return out.joinToString(" و ")
    }

    // ---- Japanese
    private val jaD = arrayOf("零", "一", "二", "三", "四", "五", "六", "七", "八", "九")
    private fun ja4(n: Int): String {
        val sb = StringBuilder()
        val th = n / 1000; val h = n / 100 % 10; val te = n / 10 % 10; val o = n % 10
        if (th > 0) sb.append(if (th == 1) "" else jaD[th]).append("千")
        if (h > 0) sb.append(if (h == 1) "" else jaD[h]).append("百")
        if (te > 0) sb.append(if (te == 1) "" else jaD[te]).append("十")
        if (o > 0) sb.append(jaD[o])
        return sb.toString()
    }
    fun ja(v: Long): String {
        if (v == 0L) return "零"
        val units = arrayOf("", "万", "億", "兆", "京")
        var x = v
        val out = ArrayList<String>()
        var i = 0
        while (x > 0) { val g = (x % 10000).toInt(); if (g > 0) out.add(0, (if (g == 1 && i > 0) "一" else ja4(g)) + units[i]); x /= 10000; i++ }
        return out.joinToString("")
    }
}
