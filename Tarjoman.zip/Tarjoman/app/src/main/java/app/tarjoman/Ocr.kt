package app.tarjoman

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.google.android.gms.tasks.Tasks
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/** One recognized text block (position on the image, source text, translated text, background colour). */
class OBlock(val rect: Rect, val text: String, val bg: Int) {
    @Volatile var out: String = ""
    var sl: StaticLayout? = null
    var box: Rect = Rect()
    var fg: Int = Color.BLACK
    var usedScale: Float = -1f
}

object Ocr {
    @Volatile var base: File? = null   // set by Tr: filesDir/ocr (contains tessdata/fas.traineddata)

    fun faFile(): File? = base?.let { File(it, "tessdata/fas.traineddata") }
    fun faReady(): Boolean = faFile()?.let { it.isFile && it.length() > 0 } ?: false

    /** Optional more accurate (bigger) Persian model, kept in its own folder; used instead of the fast one when installed. */
    fun faBestFile(): File? = base?.let { File(it, "best/tessdata/fas.traineddata") }
    fun faBestReady(): Boolean = faBestFile()?.let { it.isFile && it.length() > 0 } ?: false
    /** Any Persian model installed (fast or best). */
    fun faAny(): Boolean = faReady() || faBestReady()

    /** Black text on white from a grey picture (Otsu threshold). White text on a dark background is inverted first, Tesseract expects dark on light. */
    private fun binarize(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val lum = ByteArray(px.size)
        val hist = IntArray(256)
        for (i in px.indices) {
            val p = px[i]
            val l = ((p shr 16 and 0xFF) * 77 + (p shr 8 and 0xFF) * 151 + (p and 0xFF) * 28) shr 8
            lum[i] = l.toByte()
            hist[l]++
        }
        val total = px.size
        var sumAll = 0L
        for (i in 0..255) sumAll += i.toLong() * hist[i]
        var wB = 0
        var sumB = 0L
        var best = 0.0
        var thr = 128
        for (t in 0..255) {
            wB += hist[t]
            if (wB == 0) continue
            val wF = total - wB
            if (wF == 0) break
            sumB += t.toLong() * hist[t]
            val mB = sumB.toDouble() / wB
            val mF = (sumAll - sumB).toDouble() / wF
            val v = wB.toDouble() * wF * (mB - mF) * (mB - mF)
            if (v > best) { best = v; thr = t }
        }
        var dark = 0
        for (l in lum) if ((l.toInt() and 0xFF) <= thr) dark++
        val darkBg = dark * 2 > total
        for (i in px.indices) {
            val l = lum[i].toInt() and 0xFF
            val isText = if (darkBg) l > thr else l <= thr
            px[i] = if (isText) -0x1000000 else -0x1
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    /** Persian text is thin and small on manga / screenshots: grayscale, stretched contrast and at least ~1800 px on the long side help Tesseract a lot. */
    private fun prepFa(bmp: Bitmap): Pair<Bitmap, Float> {
        val longSide = maxOf(bmp.width, bmp.height)
        var k = 1f
        if (longSide < 1800) k = minOf(3f, 1800f / longSide)
        if (k > 3f) k = 3f
        val w = (bmp.width * k).toInt().coerceAtLeast(1)
        val h = (bmp.height * k).toInt().coerceAtLeast(1)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val cm = android.graphics.ColorMatrix()
        cm.setSaturation(0f)
        val con = android.graphics.ColorMatrix(floatArrayOf(
            1.4f, 0f, 0f, 0f, -40f,
            0f, 1.4f, 0f, 0f, -40f,
            0f, 0f, 1.4f, 0f, -40f,
            0f, 0f, 0f, 1f, 0f
        ))
        cm.postConcat(con)
        val p = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        p.colorFilter = android.graphics.ColorMatrixColorFilter(cm)
        c.drawBitmap(bmp, null, Rect(0, 0, w, h), p)
        return Pair(out, k)
    }

    /** Blocking. Persian OCR with Tesseract (offline). Two versions of the picture are read (grey + contrast, and black-on-white) and the one Tesseract is more sure about wins. */
    private fun readFa(orig: Bitmap): List<OBlock> {
        val root = base ?: throw IllegalStateException(L("OCR آماده نیست"))
        if (!faAny()) throw IllegalStateException(L("مدل OCR فارسی نصب نیست؛ از تب «مدل‌ها» دانلودش کن."))
        val dir = if (faBestReady()) File(root, "best") else root
        val (bmp, k) = prepFa(orig)
        var bin: Bitmap? = null
        try { bin = binarize(bmp) } catch (_: Throwable) { bin = null }
        val api = TessBaseAPI()
        try {
            if (!api.init(dir.absolutePath, "fas")) throw IllegalStateException(L("OCR فارسی بارگذاری نشد"))
            api.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO)
            var bestItems: List<Pair<String, Rect>> = emptyList()
            var bestScore = -1.0
            for (v in listOfNotNull(bmp, bin)) {
                api.setImage(v)
                api.getUTF8Text()
                val conf = api.meanConfidence()
                val items = ArrayList<Pair<String, Rect>>()
                val iter = api.getResultIterator()
                if (iter != null) {
                    iter.begin()
                    do {
                        val txt = iter.getUTF8Text(TessBaseAPI.PageIteratorLevel.RIL_PARA)
                        val r0 = iter.getBoundingRect(TessBaseAPI.PageIteratorLevel.RIL_PARA)
                        if (txt != null && r0 != null) items.add(Pair(txt, Rect(r0)))
                    } while (iter.next(TessBaseAPI.PageIteratorLevel.RIL_PARA))
                    iter.delete()
                }
                var letters = 0
                for (it in items) letters += it.first.count { c -> c.isLetter() }
                val score = conf * Math.log(1.0 + letters)
                if (score > bestScore) { bestScore = score; bestItems = items }
            }
            val res = ArrayList<OBlock>()
            for ((txt, r0) in bestItems) {
                // back to the coordinates of the original picture
                val r = Rect((r0.left / k).toInt(), (r0.top / k).toInt(), (r0.right / k).toInt(), (r0.bottom / k).toInt())
                val clean = Fa.fix(OcrFix.fa(txt.replace("\n", " ").trim()))
                if (worthKeeping(clean)) res.add(OBlock(r, clean, sampleBg(orig, r)))
            }
            return res
        } finally {
            try { api.recycle() } catch (_: Throwable) {}
            if (bmp !== orig) try { bmp.recycle() } catch (_: Throwable) {}
            try { bin?.recycle() } catch (_: Throwable) {}
        }
    }

    class AutoRes(val blocks: List<OBlock>, val lang: String)

    /** True when the recognized text really is in language [l] (a Latin reader fed Persian / Japanese pages returns junk). */
    private fun scriptOk(blocks: List<OBlock>, l: String): Boolean {
        val g = Fa.guess(blocks.joinToString(" ") { it.text }) ?: return true
        return g == l
    }

    /** Drops noise: single marks, sound-effect scribbles, boxes where most characters are not letters. A lone "I" / "A" is a real word. */
    private fun worthKeeping(t: String): Boolean {
        val letters = t.count { it.isLetter() }
        if (letters < 1) return false
        if (letters < 2 && t.none { it.code >= 0x3040 }) {
            val w = t.trim().trim('.', ',', '!', '?', '"', '\'', ' ')
            if (w != "I" && w != "A") return false
        }
        val chars = t.count { !it.isWhitespace() }
        return letters * 100 >= chars * 40
    }

    /**
     * Like [read], but when nothing is found in the chosen language, or the text found is in another script
     * (junk from the wrong reader), it tries the other ones (en / ja / fa) and reports which worked.
     */
    fun readAuto(bmp: Bitmap, s: String): AutoRes {
        var err: Throwable? = null
        var weak: AutoRes? = null
        try {
            val first = read(bmp, s)
            if (first.isNotEmpty()) {
                if (scriptOk(first, s)) return AutoRes(first, s)
                weak = AutoRes(first, s)
            }
        } catch (e: Throwable) {
            if (s == "fa") throw e
            err = e
        }
        val order = when (s) { "en" -> listOf("ja", "fa"); "ja" -> listOf("en", "fa"); else -> listOf("en", "ja") }
        for (l in order) {
            if (l == "fa" && !faAny()) continue
            try {
                val b = read(bmp, l)
                if (b.isNotEmpty() && scriptOk(b, l)) return AutoRes(b, l)
            } catch (_: Throwable) {
            }
        }
        if (weak != null) return weak
        if (err != null) throw err
        return AutoRes(emptyList(), s)
    }

    /** Share of the characters that belong to real-looking words (letters with a vowel, numbers). Used to compare two OCR passes. */
    private fun quality(blocks: List<OBlock>): Float {
        var good = 0
        var all = 0
        for (b in blocks) for (tok in b.text.split(Regex("\\s+"))) {
            val core = tok.trim { !it.isLetterOrDigit() }
            if (core.isEmpty()) continue
            val n = core.length
            all += n
            val wordLike = core.all { it.isLetter() || it == '\'' || it == '-' }
            val vowel = n <= 2 || core.any { it.lowercaseChar() in "aeiouy" }
            if ((wordLike && vowel) || core.all { it.isDigit() }) good += n
        }
        return if (all == 0) 0f else good.toFloat() / all
    }

    /** Small pictures and thin / low-contrast text read better when enlarged, in grey, with stronger contrast. */
    private fun prepLatin(bmp: Bitmap): Pair<Bitmap, Float> {
        val longSide = maxOf(bmp.width, bmp.height)
        val k = if (longSide >= 1800) 1f else minOf(2.5f, 1800f / longSide)
        val w = (bmp.width * k).toInt().coerceAtLeast(1)
        val h = (bmp.height * k).toInt().coerceAtLeast(1)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cm = android.graphics.ColorMatrix()
        cm.setSaturation(0f)
        cm.postConcat(android.graphics.ColorMatrix(floatArrayOf(
            1.3f, 0f, 0f, 0f, -30f,
            0f, 1.3f, 0f, 0f, -30f,
            0f, 0f, 1.3f, 0f, -30f,
            0f, 0f, 0f, 1f, 0f
        )))
        val p = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        p.colorFilter = android.graphics.ColorMatrixColorFilter(cm)
        Canvas(out).drawBitmap(bmp, null, Rect(0, 0, w, h), p)
        return Pair(out, k)
    }

    /** One ML Kit pass over [img] (which is [orig] enlarged by [k]); boxes are mapped back to [orig]. */
    private fun pass(rec: com.google.mlkit.vision.text.TextRecognizer, img: Bitmap, k: Float, orig: Bitmap, s: String): List<OBlock> {
        val vt = Tasks.await(rec.process(InputImage.fromBitmap(img, 0)))
        val res = ArrayList<OBlock>()
        for (b in vt.textBlocks) {
            val bb = b.boundingBox ?: continue
            val lines = b.lines.map { it.text }
            var raw = if (s == "ja") lines.joinToString("") else OcrFix.joinLines(lines)
            if (raw.isBlank()) raw = if (s == "ja") b.text.replace("\n", "") else b.text.replace("\n", " ")
            if (s == "en") raw = OcrFix.en(raw)
            if (!worthKeeping(raw)) continue
            val r = Rect((bb.left / k).toInt(), (bb.top / k).toInt(), (bb.right / k).toInt(), (bb.bottom / k).toInt())
            res.add(OBlock(r, raw, sampleBg(orig, r)))
        }
        return res
    }

    /** Blocking. Reads text blocks from a bitmap (English/Latin or Japanese). English gets a second, enhanced pass when the first looks doubtful. */
    fun read(bmp: Bitmap, s: String): List<OBlock> {
        if (s == "fa") return readFa(bmp)
        val rec = if (s == "ja") TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
        else TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        try {
            var res = pass(rec, bmp, 1f, bmp, s)
            if (s == "en") {
                val q1 = quality(res)
                if (res.isEmpty() || q1 < 0.93f || maxOf(bmp.width, bmp.height) < 1500) {
                    var enh: Bitmap? = null
                    try {
                        val (eb, k) = prepLatin(bmp)
                        enh = eb
                        val second = pass(rec, eb, k, bmp, s)
                        val q2 = quality(second)
                        if (res.isEmpty() || q2 > q1 + 0.02f) { if (second.isNotEmpty()) res = second }
                    } catch (_: Throwable) {
                        // not enough memory or the second reader failed: keep the first result
                    } finally {
                        if (enh != null && enh !== bmp) try { enh.recycle() } catch (_: Throwable) {}
                    }
                }
            }
            // Manga is read from the top right to the bottom left, which matters for the context given to the AI.
            if (s == "ja" && res.size > 1) {
                val band = (bmp.height / 8).coerceAtLeast(1)
                return res.sortedWith(compareBy<OBlock>({ it.rect.top / band }, { -it.rect.centerX() }))
            }
            return res
        } finally {
            try { rec.close() } catch (_: Throwable) {}
        }
    }

    /** Background colour = median of pixels just outside the text box. */
    fun sampleBg(b: Bitmap, r: Rect): Int {
        val px = ArrayList<Int>()
        fun add(x: Int, y: Int) { px.add(b.getPixel(x.coerceIn(0, b.width - 1), y.coerceIn(0, b.height - 1))) }
        for (i in 0..9) {
            val x = r.left + r.width() * i / 9
            add(x, r.top - 2)
            add(x, r.bottom + 2)
        }
        for (i in 0..3) {
            val y = r.top + r.height() * i / 3
            add(r.left - 2, y)
            add(r.right + 2, y)
        }
        fun med(f: (Int) -> Int): Int {
            val l = px.map(f).sorted()
            return l[l.size / 2]
        }
        return Color.rgb(med { Color.red(it) }, med { Color.green(it) }, med { Color.blue(it) })
    }

    fun prepare(b: OBlock, scale: Float) {
        val r = Rect(b.rect)
        r.inset(-4, -4)
        // Tall, narrow boxes (vertical Japanese text): give the translation a wider box so it does not become a thin column.
        if (r.height() > r.width() * 3 / 2) {
            val nw = minOf((r.height() * 0.7f).toInt(), r.width() * 3)
            if (nw > r.width()) r.inset(-(nw - r.width()) / 2, 0)
        }
        val lum = 0.299 * Color.red(b.bg) + 0.587 * Color.green(b.bg) + 0.114 * Color.blue(b.bg)
        b.fg = if (lum > 140) Color.BLACK else Color.WHITE
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = b.fg }
        val w = maxOf(r.width(), 40)
        val minSize = 20f * scale
        var size = minOf(r.height().toFloat(), 72f) * scale
        if (size < minSize) size = minSize
        var sl: StaticLayout
        while (true) {
            tp.textSize = size
            sl = StaticLayout.Builder.obtain(b.out, 0, b.out.length, tp, w).setAlignment(Layout.Alignment.ALIGN_CENTER).build()
            if (sl.height <= r.height() || size <= minSize) break
            size -= 2f
        }
        val hgt = maxOf(r.height(), sl.height)
        val cy = r.centerY()
        b.box = Rect(r.left, cy - hgt / 2, r.right, cy + hgt / 2)
        b.sl = sl
        b.usedScale = scale
    }

    fun draw(c: Canvas, b: OBlock, scale: Float) {
        if (b.out.isEmpty()) return
        if (b.sl == null || b.usedScale != scale) prepare(b, scale)
        val paint = Paint().apply { color = b.bg; style = Paint.Style.FILL }
        val r0 = Rect(b.rect)
        r0.inset(-4, -4)
        c.drawRect(r0, paint)
        c.drawRect(b.box, paint)
        val sl = b.sl ?: return
        c.save()
        c.translate(b.box.left.toFloat(), b.box.top.toFloat() + (b.box.height() - sl.height) / 2f)
        sl.draw(c)
        c.restore()
    }
}
