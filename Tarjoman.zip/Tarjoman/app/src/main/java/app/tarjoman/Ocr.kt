package app.tarjoman

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/** One recognized text block (position on the image, source text, translated text, background colour). */
class OBlock(val rect: Rect, val text: String, val bg: Int) {
    @Volatile var out: String = ""
    var sl: StaticLayout? = null
    var box: Rect = Rect()
    var fg: Int = Color.BLACK
    var usedScale: Float = -1f
}

object Ocr {
    /** Blocking. Reads text blocks from a bitmap (English/Latin or Japanese). */
    fun read(bmp: Bitmap, s: String): List<OBlock> {
        val rec = if (s == "ja") TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
        else TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        try {
            val vt = Tasks.await(rec.process(InputImage.fromBitmap(bmp, 0)))
            val res = ArrayList<OBlock>()
            for (b in vt.textBlocks) {
                val bb = b.boundingBox ?: continue
                if (b.text.none { it.isLetter() }) continue
                val raw = if (s == "ja") b.text.replace("\n", "") else b.text.replace("\n", " ")
                res.add(OBlock(Rect(bb), raw, sampleBg(bmp, bb)))
            }
            return res
        } finally {
            try { rec.close() } catch (_: Throwable) {}
        }
    }

    /** Background colour = median of pixels just outside the text box. */
    fun sampleBg(b: Bitmap, r: Rect): Int {
        val px = ArrayList<Int>()
        fun add(x: Int, y: Int) { px.add(b.getPixel(x.coerceIn(0, b.width - 1), y.coerceIn(0, b.height - 1))) }
        for (i in 0..9) {
            val x = r.left + r.width() * i / 9
            add(x, r.top - 2)
            add(x, r.bottom + 2)
        }
        for (i in 0..3) {
            val y = r.top + r.height() * i / 3
            add(r.left - 2, y)
            add(r.right + 2, y)
        }
        fun med(f: (Int) -> Int): Int {
            val l = px.map(f).sorted()
            return l[l.size / 2]
        }
        return Color.rgb(med { Color.red(it) }, med { Color.green(it) }, med { Color.blue(it) })
    }

    fun prepare(b: OBlock, scale: Float) {
        val r = Rect(b.rect)
        r.inset(-4, -4)
        val lum = 0.299 * Color.red(b.bg) + 0.587 * Color.green(b.bg) + 0.114 * Color.blue(b.bg)
        b.fg = if (lum > 140) Color.BLACK else Color.WHITE
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = b.fg }
        val w = maxOf(r.width(), 40)
        val minSize = 20f * scale
        var size = minOf(r.height().toFloat(), 72f) * scale
        if (size < minSize) size = minSize
        var sl: StaticLayout
        while (true) {
            tp.textSize = size
            sl = StaticLayout.Builder.obtain(b.out, 0, b.out.length, tp, w).setAlignment(Layout.Alignment.ALIGN_CENTER).build()
            if (sl.height <= r.height() || size <= minSize) break
            size -= 2f
        }
        val hgt = maxOf(r.height(), sl.height)
        val cy = r.centerY()
        b.box = Rect(r.left, cy - hgt / 2, r.right, cy + hgt / 2)
        b.sl = sl
        b.usedScale = scale
    }

    fun draw(c: Canvas, b: OBlock, scale: Float) {
        if (b.out.isEmpty()) return
        if (b.sl == null || b.usedScale != scale) prepare(b, scale)
        val paint = Paint().apply { color = b.bg; style = Paint.Style.FILL }
        val r0 = Rect(b.rect)
        r0.inset(-4, -4)
        c.drawRect(r0, paint)
        c.drawRect(b.box, paint)
        val sl = b.sl ?: return
        c.save()
        c.translate(b.box.left.toFloat(), b.box.top.toFloat() + (b.box.height() - sl.height) / 2f)
        sl.draw(c)
        c.restore()
    }
}
