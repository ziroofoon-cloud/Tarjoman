package app.tarjoman

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.google.android.gms.tasks.Tasks
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/** One recognized text block (position on the image, source text, translated text, background colour). */
class OBlock(val rect: Rect, var text: String, val bg: Int) {
    @Volatile var out: String = ""
    var sl: StaticLayout? = null
    var box: Rect = Rect()
    var fg: Int = Color.BLACK
    var usedScale: Float = -1f
    // manual look (set from the picture viewer); defaults = automatic
    var sizeMul: Float = 1f
    var fgOv: Int? = null
    var bgOv: Int? = null
    var bold: Boolean = true
    var fontOv: String? = null
    var usedKey: Int = 0
    var fgAuto: Int? = null  // colour of the original letters (taken from the picture), used for the translation
    var lineH: Int = 0       // height of one text line of the original (0 = unknown): the translation is not drawn much larger than this
    var zone: Rect? = null   // the speech bubble / clear area around the text (null = unknown or open page)
    var noFill: Boolean = false  // the old writing was erased from the picture (LaMa): no flat background patch behind the translation
}

object Ocr {
    @Volatile var base: File? = null   // set by Tr: filesDir/ocr (contains tessdata/fas.traineddata)
    @Volatile var cfg: Cfg? = null
    private val pool = java.util.concurrent.Executors.newCachedThreadPool()

    /** English Tesseract models (optional): a second reader that is compared with ML Kit. */
    fun enFile(): File? = base?.let { File(it, "tessdata/eng.traineddata") }
    fun enReady(): Boolean = enFile()?.let { it.isFile && it.length() > 0 } ?: false
    fun enBestFile(): File? = base?.let { File(it, "best/tessdata/eng.traineddata") }
    fun enBestReady(): Boolean = enBestFile()?.let { it.isFile && it.length() > 0 } ?: false
    fun enAny(): Boolean = enReady() || enBestReady()

    /** The small English Tesseract model (tessdata_fast, 4 MB) ships inside the app, so offline English reading works from the first start. */
    fun ensureBundled(ctx: android.content.Context) {
        try {
            if (enAny()) return
            val f = enFile() ?: return
            f.parentFile?.mkdirs()
            val tmp = File(f.path + ".part")
            ctx.assets.open("eng.traineddata").use { ins -> tmp.outputStream().use { ins.copyTo(it) } }
            if (tmp.length() > 1_000_000) { f.delete(); tmp.renameTo(f) } else tmp.delete()
        } catch (_: Throwable) {}
    }

    fun faFile(): File? = base?.let { File(it, "tessdata/fas.traineddata") }
    fun faReady(): Boolean = faFile()?.let { it.isFile && it.length() > 0 } ?: false

    /** Optional more accurate (bigger) Persian model, kept in its own folder; used instead of the fast one when installed. */
    fun faBestFile(): File? = base?.let { File(it, "best/tessdata/fas.traineddata") }
    fun faBestReady(): Boolean = faBestFile()?.let { it.isFile && it.length() > 0 } ?: false
    /** Any Persian model installed (fast or best). */
    fun faAny(): Boolean = faReady() || faBestReady()

    /** Black text on white from a grey picture (Otsu threshold). White text on a dark background is inverted first, Tesseract expects dark on light. */
    private fun binarize(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val lum = ByteArray(px.size)
        val hist = IntArray(256)
        for (i in px.indices) {
            val p = px[i]
            val l = ((p shr 16 and 0xFF) * 77 + (p shr 8 and 0xFF) * 151 + (p and 0xFF) * 28) shr 8
            lum[i] = l.toByte()
            hist[l]++
        }
        val total = px.size
        var sumAll = 0L
        for (i in 0..255) sumAll += i.toLong() * hist[i]
        var wB = 0
        var sumB = 0L
        var best = 0.0
        var thr = 128
        for (t in 0..255) {
            wB += hist[t]
            if (wB == 0) continue
            val wF = total - wB
            if (wF == 0) break
            sumB += t.toLong() * hist[t]
            val mB = sumB.toDouble() / wB
            val mF = (sumAll - sumB).toDouble() / wF
            val v = wB.toDouble() * wF * (mB - mF) * (mB - mF)
            if (v > best) { best = v; thr = t }
        }
        var dark = 0
        for (l in lum) if ((l.toInt() and 0xFF) <= thr) dark++
        val darkBg = dark * 2 > total
        for (i in px.indices) {
            val l = lum[i].toInt() and 0xFF
            val isText = if (darkBg) l > thr else l <= thr
            px[i] = if (isText) -0x1000000 else -0x1
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    /** Persian text is thin and small on manga / screenshots: grayscale, stretched contrast and at least ~1800 px on the long side help Tesseract a lot. */
    private fun prepFa(bmp: Bitmap): Pair<Bitmap, Float> {
        val longSide = maxOf(bmp.width, bmp.height)
        var k = 1f
        if (longSide < 1800) k = minOf(3f, 1800f / longSide)
        if (k > 3f) k = 3f
        val w = (bmp.width * k).toInt().coerceAtLeast(1)
        val h = (bmp.height * k).toInt().coerceAtLeast(1)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val cm = android.graphics.ColorMatrix()
        cm.setSaturation(0f)
        val con = android.graphics.ColorMatrix(floatArrayOf(
            1.4f, 0f, 0f, 0f, -40f,
            0f, 1.4f, 0f, 0f, -40f,
            0f, 0f, 1.4f, 0f, -40f,
            0f, 0f, 0f, 1f, 0f
        ))
        cm.postConcat(con)
        val p = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        p.colorFilter = android.graphics.ColorMatrixColorFilter(cm)
        c.drawBitmap(bmp, null, Rect(0, 0, w, h), p)
        return Pair(out, k)
    }

    /**
     * Blocking. Tesseract on one picture. [mode]: "auto" reads two versions of the picture (grey + contrast, and
     * black-on-white) and keeps the one Tesseract is more sure about; "gray" or "bw" reads only that one.
     */
    private fun tess(orig: Bitmap, lang: String, dir: File, mode: String, enhance: (Bitmap) -> Pair<Bitmap, Float>, clean: (String) -> String): List<OBlock> {
        val (bmp, k) = enhance(orig)
        var bin: Bitmap? = null
        if (mode != "gray") try { bin = binarize(bmp) } catch (_: Throwable) { bin = null }
        val api = TessBaseAPI()
        try {
            if (!api.init(dir.absolutePath, lang)) throw IllegalStateException(L("OCR بارگذاری نشد"))
            api.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO)
            var bestItems: List<Pair<String, Rect>> = emptyList()
            var bestScore = -1.0
            val versions = when (mode) { "gray" -> listOf(bmp); "bw" -> listOfNotNull(bin ?: bmp); else -> listOfNotNull(bmp, bin) }
            for (v in versions) {
                api.setImage(v)
                api.getUTF8Text()
                val conf = api.meanConfidence()
                val items = ArrayList<Pair<String, Rect>>()
                val iter = api.getResultIterator()
                if (iter != null) {
                    iter.begin()
                    do {
                        val txt = iter.getUTF8Text(TessBaseAPI.PageIteratorLevel.RIL_PARA)
                        val r0 = iter.getBoundingRect(TessBaseAPI.PageIteratorLevel.RIL_PARA)
                        if (txt != null && r0 != null) items.add(Pair(txt, Rect(r0)))
                    } while (iter.next(TessBaseAPI.PageIteratorLevel.RIL_PARA))
                    iter.delete()
                }
                var letters = 0
                for (it in items) letters += it.first.count { c -> c.isLetter() }
                val score = conf * Math.log(1.0 + letters)
                if (score > bestScore) { bestScore = score; bestItems = items }
            }
            val res = ArrayList<OBlock>()
            for ((txt, r0) in bestItems) {
                // back to the coordinates of the original picture
                val r = Rect((r0.left / k).toInt(), (r0.top / k).toInt(), (r0.right / k).toInt(), (r0.bottom / k).toInt())
                val c = clean(txt)
                if (worthKeeping(c)) res.add(OBlock(r, c, sampleBg(orig, r)))
            }
            return res
        } finally {
            try { api.recycle() } catch (_: Throwable) {}
            if (bmp !== orig) try { bmp.recycle() } catch (_: Throwable) {}
            try { bin?.recycle() } catch (_: Throwable) {}
        }
    }

    /** Blocking. Persian OCR with Tesseract (offline); the model (fast / best) and the picture handling come from the settings. */
    private fun readFa(orig: Bitmap): List<OBlock> {
        val root = base ?: throw IllegalStateException(L("OCR آماده نیست"))
        if (!faAny()) throw IllegalStateException(L("مدل OCR فارسی نصب نیست؛ از تب «مدل‌ها» دانلودش کن."))
        val c = cfg
        val pick = c?.ocrFaModel ?: "auto"
        val useBest = when (pick) { "fast" -> !faReady() && faBestReady(); "best" -> faBestReady() || !faReady(); else -> faBestReady() }
        val dir = if (useBest) File(root, "best") else root
        return tess(orig, "fas", dir, c?.ocrFaPre ?: "auto", { prepFa(it) }) { Fa.fix(OcrFix.fa(it.replace("\n", " ").trim())) }
    }

    private val tinyOk = setOf("I", "A", "OK", "NO", "AN", "IS", "IT", "TO", "OF", "ME", "MY", "WE", "HE", "US", "IN", "ON", "AT", "AS", "BE", "BY", "DO", "GO", "IF", "OR", "SO", "UP")

    /**
     * Tesseract reading of English text, word by word: only words the reader itself is sure about (confidence) are kept, then they
     * are put back into lines and bubbles by position. Page-level paragraphs (the old way) mix neighbouring bubbles and the
     * drawing into nonsense; unsure words are the nonsense.
     */
    private fun readEnTess(orig: Bitmap): List<OBlock> {
        val root = base ?: throw IllegalStateException(L("OCR آماده نیست"))
        if (!enAny()) throw IllegalStateException(L("مدل OCR انگلیسی نصب نیست؛ از تب «مدل‌ها» دانلودش کن."))
        val dir = if (enBestReady()) File(root, "best") else root
        val c = cfg
        val off = c?.ocrEnPre == "off"
        val (bmp, k) = if (off) Pair(orig, 1f) else prepLatin(orig)
        val api = TessBaseAPI()
        try {
            if (!api.init(dir.absolutePath, "eng")) throw IllegalStateException(L("OCR بارگذاری نشد"))
            api.setPageSegMode(TessBaseAPI.PageSegMode.PSM_SPARSE_TEXT)
            api.setImage(bmp)
            api.getUTF8Text()
            val words = ArrayList<Pair<String, Rect>>()
            val iter = api.getResultIterator()
            if (iter != null) {
                iter.begin()
                do {
                    val t = (iter.getUTF8Text(TessBaseAPI.PageIteratorLevel.RIL_WORD) ?: "").trim()
                    val cf = iter.confidence(TessBaseAPI.PageIteratorLevel.RIL_WORD)
                    val r0 = iter.getBoundingRect(TessBaseAPI.PageIteratorLevel.RIL_WORD)
                    if (t.isEmpty() || r0 == null || cf < 60f) continue
                    val letters = t.count { it.isLetter() }
                    if (letters == 0 && !t.all { it in ".!?…,-" }) continue
                    if (letters <= 2 && cf < 85f && t.uppercase().trim('.', ',', '!', '?') !in tinyOk) continue
                    words.add(Pair(t, Rect((r0.left / k).toInt(), (r0.top / k).toInt(), (r0.right / k).toInt(), (r0.bottom / k).toInt())))
                } while (iter.next(TessBaseAPI.PageIteratorLevel.RIL_WORD))
                iter.delete()
            }
            val res = ArrayList<OBlock>()
            for ((txt, r) in clusterLines(wordsToLines(words))) {
                val t = OcrFix.dropStray(OcrFix.en(txt, c?.ocrEnFix != 0))
                if (t.count { it.isLetter() } < 3 || !worthKeeping(t)) continue
                res.add(OBlock(r, t, sampleBg(orig, r)))
            }
            return res
        } finally {
            try { api.recycle() } catch (_: Throwable) {}
            if (bmp !== orig) try { bmp.recycle() } catch (_: Throwable) {}
        }
    }

    /** Words (text, box) of one reading put into lines: same row (centres level, heights alike) and close together. */
    private fun wordsToLines(ws: List<Pair<String, Rect>>): List<Pair<String, Rect>> {
        class Ln(var r: Rect, val w: ArrayList<Pair<String, Rect>>)
        val lines = ArrayList<Ln>()
        for ((t, r) in ws.sortedWith(compareBy({ it.second.top }, { it.second.left }))) {
            val h = r.height().coerceAtLeast(1)
            var placed = false
            for (ln in lines) {
                val lh = ln.r.height().coerceAtLeast(1)
                val ratio = h.toFloat() / lh
                if (Math.abs(r.centerY() - ln.r.centerY()) < 0.5f * maxOf(h, lh) && ratio in 0.6f..1.7f && r.left - ln.r.right <= 1.6f * maxOf(h, lh) && r.left >= ln.r.left - 5) {
                    ln.w.add(Pair(t, r)); ln.r = Rect(ln.r).also { it.union(r) }; placed = true; break
                }
            }
            if (!placed) lines.add(Ln(Rect(r), arrayListOf(Pair(t, r))))
        }
        return lines.map { ln -> Pair(ln.w.sortedBy { it.second.left }.joinToString(" ") { it.first }, ln.r) }
    }

    /** How well a reading looks like real English: known words, and words made of letters with a vowel. */
    private fun enScore(blocks: List<OBlock>): Float {
        if (blocks.isEmpty()) return 0f
        val t = blocks.joinToString(" ") { it.text }
        val letters = t.count { it.isLetter() }
        return (Lex.score(t) * 0.6f + quality(blocks) * 0.4f) * (1f + Math.log(1.0 + letters).toFloat() / 20f)
    }

    private fun overlap(a: Rect, b: Rect): Float {
        val l = maxOf(a.left, b.left); val t = maxOf(a.top, b.top)
        val r = minOf(a.right, b.right); val bt = minOf(a.bottom, b.bottom)
        if (r <= l || bt <= t) return 0f
        val inter = (r - l).toLong() * (bt - t)
        val small = minOf(a.width().toLong() * a.height(), b.width().toLong() * b.height()).coerceAtLeast(1)
        return inter.toFloat() / small
    }

    /**
     * Groups text lines into bubbles / paragraphs: a line joins a group when it is right below (or above) a line of that group,
     * about the same text height and either overlapping sideways or centred on it. Returns (text, box) per group, top to bottom.
     */
    private fun clusterLines(lines: List<Pair<String, Rect>>): List<Pair<String, Rect>> {
        val n = lines.size
        if (n == 0) return emptyList()
        val par = IntArray(n) { it }
        fun find(x: Int): Int { var a = x; while (par[a] != a) { par[a] = par[par[a]]; a = par[a] }; return a }
        for (i in 0 until n) for (j in i + 1 until n) {
            val a = lines[i].second; val b = lines[j].second
            val ha = a.height().coerceAtLeast(1); val hb = b.height().coerceAtLeast(1)
            val ratio = maxOf(ha, hb).toFloat() / minOf(ha, hb)
            if (ratio > 1.7f) continue
            val gap = if (b.top >= a.bottom) b.top - a.bottom else if (a.top >= b.bottom) a.top - b.bottom else -1
            if (gap < 0 || gap > minOf(ha, hb) * 0.9f) {
                // same line: boxes side by side and level
                val sameRow = Math.abs(a.centerY() - b.centerY()) < minOf(ha, hb) * 0.5f && (b.left - a.right) < minOf(ha, hb) * 1.2f && (a.left - b.right) < minOf(ha, hb) * 1.2f
                if (sameRow) par[find(i)] = find(j)
                continue
            }
            val ov = minOf(a.right, b.right) - maxOf(a.left, b.left)
            val wmin = minOf(a.width(), b.width()).coerceAtLeast(1)
            val cdist = Math.abs(a.centerX() - b.centerX())
            val wmax = maxOf(a.width(), b.width())
            if (ov * 100 >= wmin * 40 || cdist < wmax * 0.3f) par[find(i)] = find(j)
        }
        val groups = HashMap<Int, ArrayList<Int>>()
        for (i in 0 until n) groups.getOrPut(find(i)) { ArrayList() }.add(i)
        val out = ArrayList<Pair<String, Rect>>()
        for (g in groups.values) {
            val idx = g.sortedWith(Comparator { p, q ->
                val a = lines[p].second; val b = lines[q].second
                val tol = 0.5f * minOf(a.height(), b.height()).coerceAtLeast(1)
                if (Math.abs(a.centerY() - b.centerY()) < tol) a.left.compareTo(b.left) else a.centerY().compareTo(b.centerY())
            })
            val u = Rect(lines[idx[0]].second)
            for (i in idx) u.union(lines[i].second)
            out.add(Pair(OcrFix.joinLines(idx.map { lines[it].first }), u))
        }
        return out.sortedWith(compareBy({ it.second.top }, { it.second.left }))
    }

    /** A box is junk when it holds almost no real words (Tesseract on drawings, screentone, sound effects). */
    private fun junk(b: OBlock): Boolean {
        val toks = b.text.split(Regex("\\s+")).filter { t -> t.count { it.isLetter() } >= 2 }
        if (toks.isEmpty()) return b.text.count { it.isLetter() } < 2
        if (quality(listOf(b)) < 0.6f || !OcrFix.plausible(b.text)) return true
        // the built-in word list is small (rare words, names and captions such as "OCCULT RESEARCH CLUB" are not in it): only long boxes with almost no known word count as junk
        return toks.size >= 4 && Lex.score(b.text) < 0.15f
    }

    /** The better of two readings; blocks only the other reader saw (and that look like words) are added. */
    private fun bestOf(a: List<OBlock>, b: List<OBlock>): List<OBlock> {
        // Per box, not per page: the first reader's boxes are the base; the second reader only adds boxes that are
        // new (not on top of an existing one) and look like real words. Junk boxes of either reader are dropped.
        val first = enScore(a) >= enScore(b)
        val win = (if (first) a else b).filter { !junk(it) }
        val lose = (if (first) b else a).filter { !junk(it) }
        val out = ArrayList<OBlock>(win)
        for (x in lose) if (out.none { overlap(it.rect, x.rect) > 0.2f } && Lex.score(x.text) >= 0.6f) out.add(x)
        return out.sortedWith(compareBy({ it.rect.top }, { it.rect.left }))
    }

    class AutoRes(val blocks: List<OBlock>, val lang: String)

    /** True when the recognized text really is in language [l] (a Latin reader fed Persian / Japanese pages returns junk). */
    private fun scriptOk(blocks: List<OBlock>, l: String): Boolean {
        val g = Fa.guess(blocks.joinToString(" ") { it.text }) ?: return true
        return g == l
    }

    /** Drops noise: single marks, sound-effect scribbles, boxes where most characters are not letters. A lone "I" / "A" is a real word. */
    private fun worthKeeping(t: String): Boolean {
        val letters = t.count { it.isLetter() }
        if (letters < 1) return false
        if (letters < 2 && t.none { it.code >= 0x3040 }) {
            val w = t.trim().trim('.', ',', '!', '?', '"', '\'', ' ')
            if (w != "I" && w != "A") return false
        }
        val chars = t.count { !it.isWhitespace() }
        return letters * 100 >= chars * 40
    }

    /**
     * Like [read], but when nothing is found in the chosen language, or the text found is in another script
     * (junk from the wrong reader), it tries the other ones (en / ja / fa) and reports which worked.
     */
    fun readAuto(bmp: Bitmap, s: String): AutoRes {
        var err: Throwable? = null
        var weak: AutoRes? = null
        try {
            val first = read(bmp, s)
            if (first.isNotEmpty()) {
                if (scriptOk(first, s)) return AutoRes(first, s)
                weak = AutoRes(first, s)
            }
        } catch (e: Throwable) {
            if (s == "fa") throw e
            err = e
        }
        val order = when (s) { "en" -> listOf("ja", "fa"); "ja" -> listOf("en", "fa"); "ko", "zh" -> listOf("en", "ja"); else -> listOf("en", "ja") }
        for (l in order) {
            if (l == "fa" && !faAny()) continue
            try {
                val b = read(bmp, l)
                if (b.isNotEmpty() && scriptOk(b, l)) return AutoRes(b, l)
            } catch (_: Throwable) {
            }
        }
        if (weak != null) return weak
        if (err != null) throw err
        return AutoRes(emptyList(), s)
    }

    /** Share of the characters that belong to real-looking words (letters with a vowel, numbers). Used to compare two OCR passes. */
    private fun quality(blocks: List<OBlock>): Float {
        var good = 0
        var all = 0
        for (b in blocks) for (tok in b.text.split(Regex("\\s+"))) {
            val core = tok.trim { !it.isLetterOrDigit() }
            if (core.isEmpty()) continue
            val n = core.length
            all += n
            val wordLike = core.all { it.isLetter() || it == '\'' || it == '-' }
            val vowel = n <= 2 || core.any { it.lowercaseChar() in "aeiouy" }
            if ((wordLike && vowel) || core.all { it.isDigit() }) good += n
        }
        return if (all == 0) 0f else good.toFloat() / all
    }

    /** Small pictures and thin / low-contrast text read better when enlarged, in grey, with stronger contrast. */
    private fun prepLatin(bmp: Bitmap): Pair<Bitmap, Float> {
        val longSide = maxOf(bmp.width, bmp.height)
        val k = if (longSide >= 1800) 1f else minOf(2.5f, 1800f / longSide)
        val w = (bmp.width * k).toInt().coerceAtLeast(1)
        val h = (bmp.height * k).toInt().coerceAtLeast(1)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cm = android.graphics.ColorMatrix()
        cm.setSaturation(0f)
        cm.postConcat(android.graphics.ColorMatrix(floatArrayOf(
            1.3f, 0f, 0f, 0f, -30f,
            0f, 1.3f, 0f, 0f, -30f,
            0f, 0f, 1.3f, 0f, -30f,
            0f, 0f, 0f, 1f, 0f
        )))
        val p = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        p.colorFilter = android.graphics.ColorMatrixColorFilter(cm)
        Canvas(out).drawBitmap(bmp, null, Rect(0, 0, w, h), p)
        return Pair(out, k)
    }

    /** One ML Kit pass over [img] (which is [orig] enlarged by [k]); boxes are mapped back to [orig]. */
    private fun pass(rec: com.google.mlkit.vision.text.TextRecognizer, img: Bitmap, k: Float, orig: Bitmap, s: String): List<OBlock> {
        val vt = Tasks.await(rec.process(InputImage.fromBitmap(img, 0)))
        val res = ArrayList<OBlock>()
        if (s == "en") {
            // Speech bubbles: the reader's own blocks often join two bubbles (or cut one in two). The lines are grouped again by distance.
            val ln = linesOf(vt)
            for ((txt0, rr) in clusterLines(ln)) {
                var raw = txt0
                raw = OcrFix.en(raw, cfg?.ocrEnFix != 0)
                if (!worthKeeping(raw)) continue
                val r = Rect((rr.left / k).toInt(), (rr.top / k).toInt(), (rr.right / k).toInt(), (rr.bottom / k).toInt())
                val ob = OBlock(r, raw, sampleBg(orig, r))
                if (!OcrFix.plausible(raw)) continue   // art / scribbles read as letters ("I IY IY I NR ...") must not be translated or drawn on
                res.add(ob)
            }
            return res
        }
        for (b in vt.textBlocks) {
            val bb = b.boundingBox ?: continue
            val lines = b.lines.map { it.text }
            var raw = if (s == "ja" || s == "zh") lines.joinToString("") else OcrFix.joinLines(lines)
            if (raw.isBlank()) raw = if (s == "ja" || s == "zh") b.text.replace("\n", "") else b.text.replace("\n", " ")
            if (!worthKeeping(raw)) continue
            val r = Rect((bb.left / k).toInt(), (bb.top / k).toInt(), (bb.right / k).toInt(), (bb.bottom / k).toInt())
            res.add(OBlock(r, raw, sampleBg(orig, r)))
        }
        return res
    }

    /** Blocking. Reads text blocks from a bitmap (English/Latin or Japanese). English gets a second, enhanced pass when the first looks doubtful. */
    /** ALL-CAPS lettering becomes normal sentences (translators handle that much better); unknown words keep a capital (names). */
    private fun capsFix(t: String): String {
        val letters = t.filter { it.isLetter() }
        if (letters.length < 3 || letters.any { it.isLowerCase() }) return t
        val sb = StringBuilder()
        var start = true
        for (w0 in t.lowercase().split(' ')) {
            val core = w0.trim('.', ',', '!', '?', ':', ';', '"', '\'', '-', '\u2026')
            var w = w0
            if (core == "i") w = w0.replaceFirst("i", "I")
            else if (core.length > 1 && !Lex.hasWide(core) && core.all { it.isLetter() }) w = w0.replaceFirstChar { it.uppercase() }
            if (start && w.isNotEmpty()) w = w.replaceFirstChar { it.uppercase() }
            sb.append(w).append(' ')
            start = w.trimEnd().let { it.endsWith(".") || it.endsWith("!") || it.endsWith("?") || it.endsWith("\u2026") }
        }
        return sb.toString().trim()
    }

    /**
     * The text detector (Detector.kt) says where the text is; every place the reader did not already cover is read on its own
     * (enlarged, on a clean white margin) and added. At most 12 places per picture. Any problem = the blocks stay as they were.
     */
    private fun recoverWithDetector(bmp: Bitmap, have: List<OBlock>, s: String): List<OBlock> {
        val boxes = try { Detector.detect(bmp) } catch (_: Throwable) { return have }
        val add = ArrayList<OBlock>()
        for (bx in boxes.sortedByDescending { it.score }) {
            if (add.size >= 12) break
            if (bx.cls == 0) continue                                  // an empty bubble: nothing to read
            val rr = Rect(bx.rect)
            if (have.any { overlap(it.rect, rr) > 0.3f } || add.any { overlap(it.rect, rr) > 0.3f }) continue
            val pad = maxOf(6, minOf(rr.width(), rr.height()) / 8)
            val cr = Rect(rr)
            cr.inset(-pad, -pad)
            cr.intersect(0, 0, bmp.width, bmp.height)
            if (cr.width() < 12 || cr.height() < 10) continue
            var crop: Bitmap? = null
            var big: Bitmap? = null
            var padded: Bitmap? = null
            val got: List<OBlock> = try {
                crop = Bitmap.createBitmap(bmp, cr.left, cr.top, cr.width(), cr.height())
                val kk = (700f / maxOf(crop.width, crop.height)).coerceIn(1f, 3f)
                big = if (kk > 1.05f) Bitmap.createScaledBitmap(crop, (crop.width * kk).toInt(), (crop.height * kk).toInt(), true) else crop
                padded = Bitmap.createBitmap(big.width + 40, big.height + 40, Bitmap.Config.ARGB_8888)
                val cv = Canvas(padded)
                cv.drawColor(Color.WHITE)
                cv.drawBitmap(big, 20f, 20f, null)
                read(padded, s, false)
            } catch (_: Throwable) {
                emptyList()
            } finally {
                try { if (padded != null) padded.recycle() } catch (_: Throwable) {}
                try { if (big != null && big !== crop) big.recycle() } catch (_: Throwable) {}
                try { crop?.recycle() } catch (_: Throwable) {}
            }
            if (got.isEmpty()) continue
            val band = (cr.height() * 3 / 4).coerceAtLeast(1)
            val sorted = got.sortedWith(compareBy({ it.rect.top / band }, { if (s == "ja") -it.rect.left else it.rect.left }))
            var t = sorted.joinToString(" ") { it.text.trim() }.replace(Regex("-\\s+"), "-").replace(Regex("\\s+"), " ").trim()
            if (s == "en") t = capsFix(t)
            if (!worthKeeping(t) || t.count { it.isLetterOrDigit() } < 2) continue
            // writing in another script (Japanese captions, drawings) read as English comes out as nonsense ("ocut", "yerr"):
            // a recovered place must contain real English words, or it is dropped
            if (s == "en") {
                val ws = t.split(Regex("[^A-Za-z']+")).filter { it.length >= 3 }
                if (ws.isEmpty() || ws.count { Lex.has(it.lowercase()) } * 2 < ws.size) continue
            }
            val b = OBlock(rr, t, sampleBg(bmp, rr))
            add.add(b)
        }
        if (add.isEmpty()) return have
        val all = ArrayList<OBlock>(have)
        all.addAll(add)
        val band = (bmp.height / 14).coerceAtLeast(1)
        return all.sortedWith(compareBy({ it.rect.top / band }, { if (s == "ja") -it.rect.left else it.rect.left }))
    }

    /** Two blocks on the same place would be translated and drawn twice, one over the other: the one with more text stays. */
    private fun dedupe(l: List<OBlock>): List<OBlock> {
        val keep = ArrayList<OBlock>()
        for (b in l.sortedByDescending { it.text.count { c -> c.isLetterOrDigit() } }) {
            if (keep.none { overlap(it.rect, b.rect) > 0.2f }) keep.add(b)
        }
        return if (keep.size == l.size) l else l.filter { it in keep }
    }

    fun read(bmp: Bitmap, s: String, recover: Boolean = true): List<OBlock> {
        val r0 = read0(bmp, s)
        val r00 = if (s == "en") mergeParas(r0).mapNotNull { b ->
            // fragments of drawings are cut out of the sentence; a box that is nothing but fragments is dropped
            val t = OcrFix.dropStray(b.text)
            if (t.isBlank() || !OcrFix.plausible(t)) null else { b.text = t; b }
        } else r0
        val kind = cfg?.imgKind ?: "auto"
        val r = if (recover && kind != "screen" && Detector.ready() && (cfg?.ocrDetect ?: 1) == 1 && (s == "en" || s == "ja" || s == "ko" || s == "zh")) recoverWithDetector(bmp, r00, s) else r00
        // Phone screenshots: the status bar at the top and the navigation / tab bar at the bottom are the phone's own buttons
        // and labels (Home, Shorts, Subscribe ...), not the content; they only add noise to the translation.
        val skipBars = if (kind == "manga" || kind == "manhwa" || kind == "comic") false else (cfg?.ocrSkipBars ?: 1) == 1 && bmp.height >= bmp.width * 19 / 10
        val r1 = dedupe(if (skipBars) r.filter { val y = it.rect.centerY(); y >= bmp.height * 0.045f && y <= bmp.height * 0.955f } else r)
        for (b in r1) {
            if (b.zone == null) b.zone = try { bubbleZone(bmp, b.rect, b.bg) } catch (_: Throwable) { null }
            if (b.fgAuto == null) b.fgAuto = try { inkColor(bmp, b.rect, b.bg) } catch (_: Throwable) { null }
        }
        // reading order = story order: manga goes right to left inside a row of panels, the rest left to right
        if (kind == "manga" || kind == "manhwa" || kind == "comic") {
            val band = maxOf(80, bmp.height / 10)
            return r1.sortedWith(compareBy<OBlock>({ it.rect.top / band }, { if (kind == "manga") -it.rect.centerX() else it.rect.centerX() }))
        }
        return r1
    }

    /**
     * Finds the clear area (speech bubble interior) that holds a text box: flood fill over pixels that look like the box's
     * background colour, on a coarse grid. Returns its bounding box, or null when it leaks out (open page, no bubble).
     */
    /** Finishes a block that came from somewhere else (e.g. the cloud model): the bubble around it and the colour of its letters. */
    fun settle(bm: Bitmap, b: OBlock) {
        b.zone = try { bubbleZone(bm, b.rect, b.bg) } catch (_: Throwable) { null }
        b.fgAuto = try { inkColor(bm, b.rect, b.bg) } catch (_: Throwable) { null }
    }

    private fun bubbleZone(bm: Bitmap, r: Rect, bg: Int): Rect? {
        if (r.width() < 8 || r.height() < 8) return null
        val win = Rect(r.left - r.width(), r.top - r.height(), r.right + r.width(), r.bottom + r.height())
        win.intersect(0, 0, bm.width, bm.height)
        if (win.width() < 16 || win.height() < 16) return null
        val step = maxOf(1, maxOf(win.width(), win.height()) / 200)
        val gw = win.width() / step
        val gh = win.height() / step
        if (gw < 8 || gh < 8) return null
        val bl = 0.299 * Color.red(bg) + 0.587 * Color.green(bg) + 0.114 * Color.blue(bg)
        val ok = BooleanArray(gw * gh)
        for (gy in 0 until gh) for (gx in 0 until gw) {
            val c = bm.getPixel(win.left + gx * step, win.top + gy * step)
            val l = 0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)
            ok[gy * gw + gx] = Math.abs(l - bl) < 34
        }
        val seen = BooleanArray(gw * gh)
        val q = IntArray(gw * gh)
        var qh = 0; var qt = 0
        val rl = (r.left - win.left) / step; val rr = (r.right - win.left) / step
        val rt = (r.top - win.top) / step; val rb = (r.bottom - win.top) / step
        for (gy in rt.coerceAtLeast(0)..rb.coerceAtMost(gh - 1)) for (gx in rl.coerceAtLeast(0)..rr.coerceAtMost(gw - 1)) {
            val i = gy * gw + gx
            if (ok[i] && !seen[i]) { seen[i] = true; q[qt++] = i }
        }
        if (qt == 0) return null
        var minX = gw; var minY = gh; var maxX = 0; var maxY = 0; var edge = 0; var cnt = 0
        while (qh < qt) {
            val i = q[qh++]
            val x = i % gw; val y = i / gw
            cnt++
            if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y
            if (x == 0 || y == 0 || x == gw - 1 || y == gh - 1) edge++
            if (x > 0 && ok[i - 1] && !seen[i - 1]) { seen[i - 1] = true; q[qt++] = i - 1 }
            if (x < gw - 1 && ok[i + 1] && !seen[i + 1]) { seen[i + 1] = true; q[qt++] = i + 1 }
            if (y > 0 && ok[i - gw] && !seen[i - gw]) { seen[i - gw] = true; q[qt++] = i - gw }
            if (y < gh - 1 && ok[i + gw] && !seen[i + gw]) { seen[i + gw] = true; q[qt++] = i + gw }
        }
        if (edge > 4 || cnt > gw * gh * 0.85) return null
        return Rect(win.left + minX * step, win.top + minY * step, win.left + (maxX + 1) * step, win.top + (maxY + 1) * step)
    }

    /**
     * A sentence that the reader cut into two boxes (a line break in the middle of a sentence, a speech bubble split in two)
     * is translated as one: the translator needs the whole sentence, and the result is drawn over both boxes' union.
     */
    private fun mergeParas(bl: List<OBlock>): List<OBlock> {
        if (bl.size < 2) return bl
        val sorted = bl.sortedWith(compareBy({ it.rect.top }, { it.rect.left }))
        val used = BooleanArray(sorted.size)
        val out = ArrayList<OBlock>()
        for (i in sorted.indices) {
            if (used[i]) continue
            var cur = sorted[i]
            used[i] = true
            var again = true
            while (again) {
                again = false
                val t = cur.text.trimEnd()
                if (t.isEmpty() || t.last() in ".!?:\u201D\"\u2026;") break
                for (j in sorted.indices) {
                    if (used[j]) continue
                    val n = sorted[j]
                    val nt = n.text.trimStart()
                    if (nt.isEmpty() || !nt[0].isLowerCase()) continue
                    val lineH = minOf(cur.rect.height(), n.rect.height()).coerceAtLeast(1)
                    val gap = n.rect.top - cur.rect.bottom
                    val ov = minOf(cur.rect.right, n.rect.right) - maxOf(cur.rect.left, n.rect.left)
                    val wid = minOf(cur.rect.width(), n.rect.width()).coerceAtLeast(1)
                    if (gap in -lineH / 4..lineH && ov * 100 >= wid * 50) {
                        val u = Rect(cur.rect); u.union(n.rect)
                        cur = OBlock(u, t + " " + nt, cur.bg)
                        used[j] = true
                        again = true
                        break
                    }
                }
            }
            out.add(cur)
        }
        return out
    }

    /** PaddleOCR (detector + recognizer on the phone): lines -> bubbles, cleaned like the other readers. */
    private fun readPaddle(bmp: Bitmap, s: String): List<OBlock> {
        val lines = Paddle.readLines(bmp, s).map { Pair(it.text, it.rect) }
        val res = ArrayList<OBlock>()
        for ((text0, r) in clusterLines(lines)) {
            var t = text0
            if (s == "en") t = OcrFix.dropStray(OcrFix.en(t, cfg?.ocrEnFix != 0))
            if (s == "fa") t = Fa.fix(OcrFix.fa(t))
            if (t.isBlank() || !worthKeeping(t)) continue
            if (s == "en" && !OcrFix.plausible(t)) continue
            val ob = OBlock(r, t, sampleBg(bmp, r))
            val hs = lines.filter { Rect.intersects(it.second, r) }.map { it.second.height() }
            if (hs.isNotEmpty()) ob.lineH = hs.average().toInt()
            res.add(ob)
        }
        return res
    }

    private fun read0(bmp: Bitmap, s: String): List<OBlock> {
        val pm = cfg?.ocrPaddle ?: "auto"
        val pad = pm != "off" && Paddle.ready(s)
        // chosen as the only reader, or the only one that exists for this language (Arabic)
        if (pad && (pm == "only" || s == "ar")) { try { val p = readPaddle(bmp, s); if (p.isNotEmpty() || s == "ar") return p } catch (_: Throwable) {} }
        if (s == "fa") {
            if (pad && !faAny()) { try { return readPaddle(bmp, s) } catch (_: Throwable) {} }
            return readFa(bmp)
        }
        if (s == "en" && pad) {
            // a third reader: its lines are compared with the others per box and the best words win
            val base = try { read0Core(bmp, s) } catch (_: Throwable) { emptyList() }
            val p = try { readPaddle(bmp, s) } catch (_: Throwable) { emptyList() }
            if (base.any { it.zone != null }) return if (base.size >= p.size) base else bestOf(base, p)
            return if (p.isEmpty()) base else if (base.isEmpty()) p else bestOf(base, p)
        }
        val core = read0Core(bmp, s)
        if (core.isEmpty() && pad) { try { return readPaddle(bmp, s) } catch (_: Throwable) {} }
        return core
    }

    private fun read0Core(bmp: Bitmap, s: String): List<OBlock> {
        if (s == "fa") return readFa(bmp)
        if (s == "en") {
            val mode = cfg?.ocrEn ?: "auto"
            if (mode == "tess" && enAny()) return readEnTess(bmp)
            if (mode == "auto" && enAny()) {
                // Both readers work at the same time: the wait is the slower one, not the sum.
                val fut = pool.submit(java.util.concurrent.Callable<List<OBlock>> { try { readEnTess(bmp) } catch (_: Throwable) { emptyList() } })
                val m = try { readMlKit(bmp, "en") } catch (_: Throwable) { emptyList() }
                val t = try { fut.get() } catch (_: Throwable) { emptyList() }
                // balloons were found and read one by one (they carry a zone): that reading is clean, the whole-page Tesseract one is not
                if (m.any { it.zone != null }) return m
                return bestOf(m, t)
            }
        }
        return readMlKit(bmp, s)
    }

    private val recLatin by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val recKo by lazy { TextRecognition.getClient(com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions.Builder().build()) }
    private val recZh by lazy { TextRecognition.getClient(com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions.Builder().build()) }
    private val recJa by lazy { TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build()) }

    /** Fast single pass for the live camera: ML Kit (English / Japanese) or Tesseract (Persian), no second enhanced pass. */
    fun readLive(bmp: Bitmap, s: String): List<OBlock> = if (s == "fa") readFa(bmp) else readMlKit(bmp, s, true)

    /**
     * A tall picture (a phone screenshot of a manga page, a webtoon strip) is read in overlapping horizontal strips, each
     * enlarged: the reader sees small speech-bubble letters much better that way than in one big downscaled picture.
     * A box cut by a strip's inner edge is dropped (the neighbouring strip, which overlaps by 30%, has it whole).
     */
    private fun passTiled(rec: com.google.mlkit.vision.text.TextRecognizer, bmp: Bitmap, s: String): List<OBlock> {
        val w = bmp.width
        val h = bmp.height
        val th = minOf(h, maxOf(900, w * 95 / 100))
        val step = (th * 7 / 10).coerceAtLeast(1)
        val starts = ArrayList<Int>()
        var y = 0
        while (true) {
            if (y + th >= h) { starts.add(h - th); break }
            starts.add(y)
            y += step
        }
        val k = (1700f / maxOf(w, th)).coerceIn(1f, 2f)
        val all = ArrayList<OBlock>()
        for ((i, ty) in starts.withIndex()) {
            val crop = Bitmap.createBitmap(bmp, 0, ty, w, th)
            var big: Bitmap? = null
            try {
                big = if (k > 1.02f) Bitmap.createScaledBitmap(crop, (w * k).toInt(), (th * k).toInt(), true) else crop
                val first = i == 0
                val last = i == starts.size - 1
                for (b in pass(rec, big, k, crop, s)) {
                    if (!last && b.rect.bottom >= th - 6) continue
                    if (!first && b.rect.top <= 6) continue
                    b.rect.offset(0, ty)
                    all.add(b)
                }
            } finally {
                if (big != null && big !== crop) try { big.recycle() } catch (_: Throwable) {}
                try { crop.recycle() } catch (_: Throwable) {}
            }
        }
        val sorted = all.sortedWith(compareBy({ it.rect.top }, { it.rect.left }))
        val out = ArrayList<OBlock>()
        for (b in sorted) if (out.none { overlap(it.rect, b.rect) > 0.5f }) out.add(b)
        return out
    }

    /** The reader's own sureness for a line / word (asked through reflection so a different library version cannot break the build). */
    private fun conf(o: Any): Float = try { (o.javaClass.getMethod("getConfidence").invoke(o) as? Float) ?: 1f } catch (_: Throwable) { 1f }

    /**
     * Lines of a reading, each cut into pieces wherever two words on the same line are far apart. The reader joins words
     * that share a baseline even when they belong to two different speech bubbles side by side ("PRESIDENT" + "SPIRITS...");
     * a gap wider than ~2 letter heights means two separate texts. Unsure 1-2 letter words (bubble outlines, hatching) are dropped.
     */
    private fun linesOf(vt: com.google.mlkit.vision.text.Text): List<Pair<String, Rect>> {
        val out = ArrayList<Pair<String, Rect>>()
        for (b in vt.textBlocks) for (l in b.lines) {
            val whole = l.boundingBox ?: continue
            if (l.text.isBlank()) continue
            if (conf(l) < 0.45f && l.text.count { it.isLetter() } < 12) continue
            val els = l.elements.mapNotNull { e ->
                val bb = e.boundingBox ?: return@mapNotNull null
                if (e.text.count { it.isLetter() } <= 2 && conf(e) < 0.4f) null else Pair(e.text, bb)
            }.sortedBy { it.second.left }
            if (els.size < 2) { out.add(Pair(l.text, whole)); continue }
            val hh = els.map { it.second.height() }.sorted()[els.size / 2].coerceAtLeast(1)
            var cur = ArrayList<Pair<String, Rect>>()
            fun flush() {
                if (cur.isEmpty()) return
                val u = Rect(cur[0].second)
                for (c in cur) u.union(c.second)
                out.add(Pair(cur.joinToString(" ") { it.first }, u))
                cur = ArrayList()
            }
            for (e in els) {
                if (cur.isNotEmpty() && e.second.left - cur.last().second.right > hh * 2.0f) flush()
                cur.add(e)
            }
            flush()
        }
        return out
    }

    /**
     * Second reading: every text box is cut out (a little wider), enlarged and read on its own. Read alone, a speech bubble
     * comes out clean; read inside the whole page, its lines get mixed with neighbours. The new reading replaces the old one
     * when it is no less word-like and keeps (nearly) all the letters.
     */
    private fun refine(rec: com.google.mlkit.vision.text.TextRecognizer, bmp: Bitmap, blocks: List<OBlock>): List<OBlock> {
        if (blocks.isEmpty() || blocks.size > 40) return blocks
        for (b in blocks) {
            try {
                val r = Rect(b.rect)
                val pad = maxOf(8, minOf(r.width(), r.height()) / 8)
                r.inset(-pad, -pad)
                if (!r.intersect(0, 0, bmp.width, bmp.height) || r.width() < 24 || r.height() < 14) continue
                val crop = Bitmap.createBitmap(bmp, r.left, r.top, r.width(), r.height())
                var big: Bitmap? = null
                try {
                    val k = (1100f / maxOf(crop.width, crop.height)).coerceIn(1f, 3f)
                    big = if (k > 1.05f) Bitmap.createScaledBitmap(crop, (crop.width * k).toInt(), (crop.height * k).toInt(), true) else crop
                    val vt = Tasks.await(recLatin.process(InputImage.fromBitmap(big, 0)))
                    val parts = clusterLines(linesOf(vt)).sortedWith(compareBy({ it.second.top }, { it.second.left }))
                    if (parts.isEmpty()) continue
                    val t2 = OcrFix.dropStray(OcrFix.en(parts.joinToString(" ") { it.first }, cfg?.ocrEnFix != 0))
                    if (t2.isBlank() || !OcrFix.plausible(t2)) continue
                    val l1 = b.text.count { it.isLetter() }
                    val l2 = t2.count { it.isLetter() }
                    if (l2 * 10 >= l1 * 8 && Lex.score(t2) >= Lex.score(b.text) - 0.03f) b.text = t2
                } finally {
                    if (big != null && big !== crop) try { big.recycle() } catch (_: Throwable) {}
                    try { crop.recycle() } catch (_: Throwable) {}
                }
            } catch (_: Throwable) {
            }
        }
        return blocks
    }

    /** What the balloon reader did on the last picture (shown in the status line and the diagnostic report). */
    @Volatile var diag: String = ""

    /** Reads every balloon alone (see [Balloons]); boxes come back in the picture's own coordinates, with the balloon as the zone. */
    private fun readBalloons(bmp: Bitmap, cands: List<Balloons.Cand>): List<OBlock> {
        val res = ArrayList<OBlock>()
        var nEmpty = 0; var nBad = 0; var nErr = 0; var lastErr = ""
        try {
        for (c in cands) {
            val (crop, ox, oy) = Balloons.crop(bmp, c)
            var big: Bitmap? = null
            try {
                val k = (1100f / maxOf(crop.width, crop.height)).coerceIn(1f, 3f)
                big = if (k > 1.05f) Bitmap.createScaledBitmap(crop, (crop.width * k).toInt(), (crop.height * k).toInt(), true) else crop
                val vt = Tasks.await(recLatin.process(InputImage.fromBitmap(big, 0)))
                val parts = clusterLines(linesOf(vt)).sortedWith(compareBy({ it.second.top }, { it.second.left }))
                if (parts.isEmpty()) { nEmpty++; continue }
                val text = OcrFix.dropStray(OcrFix.en(parts.joinToString(" ") { it.first }, cfg?.ocrEnFix != 0))
                if (text.count { it.isLetter() } < 3 || !OcrFix.plausible(text) || !worthKeeping(text)) { nBad++; continue }
                val u = Rect(parts[0].second)
                for (p in parts) u.union(p.second)
                val r = Rect((u.left / k).toInt() + ox, (u.top / k).toInt() + oy, (u.right / k).toInt() + ox, (u.bottom / k).toInt() + oy)
                if (res.any { x -> overlap(x.rect, r) > 0.5f }) continue
                val ob = OBlock(r, text, sampleBg(bmp, r))
                // the zone is the balloon itself, found again from the text outward; a zone far bigger than the text is not trusted
                val z = try { bubbleZone(bmp, r, ob.bg) } catch (_: Throwable) { null }
                ob.zone = if (z != null && z.width().toLong() * z.height() <= r.width().toLong() * r.height() * 9) z else null
                ob.lineH = (parts.map { it.second.height() }.average() / k).toInt()
                res.add(ob)
            } catch (t: Throwable) {
                nErr++; lastErr = t.javaClass.simpleName + ":" + (t.message ?: "")
            } finally {
                if (big != null && big !== crop) try { big.recycle() } catch (_: Throwable) {}
                try { crop.recycle() } catch (_: Throwable) {}
            }
        }
        } finally {
            diag = "balloons=" + cands.size + " read=" + res.size + " empty=" + nEmpty + " dropped=" + nBad + " errors=" + nErr + (if (lastErr.isNotEmpty()) " (" + lastErr.take(60) + ")" else "")
        }
        return res
    }

    /** Balloons first (clean, one text each); then text that sits outside all of them (on the drawing: shouts, signs) when it is clearly words. */
    private fun readByBalloons(rec: com.google.mlkit.vision.text.TextRecognizer, bmp: Bitmap, s: String): List<OBlock>? {
        val cands = try { Balloons.find(bmp) } catch (t: Throwable) { diag = "balloon finder failed: " + t.javaClass.simpleName + ":" + (t.message ?: "").take(60); emptyList() }
        if (cands.isEmpty()) { if (diag.isEmpty() || !diag.startsWith("balloon finder failed")) diag = "balloons=0 (none found, " + bmp.width + "x" + bmp.height + ")"; return null }
        val bl = readBalloons(bmp, cands)
        if (bl.isEmpty()) return null
        val out = ArrayList<OBlock>(bl)
        try {
            for (b in pass(rec, bmp, 1f, bmp, s)) {
                if (bl.any { x -> overlap(x.zone ?: x.rect, b.rect) > 0.25f }) continue
                val t = OcrFix.dropStray(b.text)
                val letters = t.count { it.isLetter() }
                if (letters < 3 || !OcrFix.plausible(t)) continue
                if (Lex.score(t) < 0.5f && !(letters <= 14 && t == t.uppercase())) continue
                b.text = t
                out.add(b)
            }
        } catch (_: Throwable) {
        }
        return out.sortedWith(compareBy({ it.rect.top }, { it.rect.left }))
    }

    private fun readMlKit(bmp: Bitmap, s: String, fast: Boolean = false): List<OBlock> {
        val rec = when (s) { "ja" -> recJa; "ko" -> recKo; "zh" -> recZh; else -> recLatin }
        try {
            if (s == "en" && !fast) {
                diag = ""
                val byB = try { readByBalloons(rec, bmp, s) } catch (t: Throwable) { diag = "balloon reader failed: " + t.javaClass.simpleName + ":" + (t.message ?: "").take(60); null }
                if (byB != null && byB.isNotEmpty()) return byB
            }
            if (s != "en" || fast) diag = "balloon reader not used (language=" + s + (if (fast) ", fast mode" else "") + ")"
            if (s == "en" && !fast && bmp.height >= 1400 && bmp.height >= bmp.width * 3 / 2) {
                val t = try { passTiled(rec, bmp, s) } catch (_: Throwable) { null }
                if (t != null && t.isNotEmpty()) return refine(rec, bmp, t)
            }
            var res = pass(rec, bmp, 1f, bmp, s)
            if (s == "en" && !fast) {
                val q1 = quality(res)
                val pre = cfg?.ocrEnPre ?: "auto"
                if (pre != "off" && (pre == "on" || res.isEmpty() || q1 < 0.93f || maxOf(bmp.width, bmp.height) < 1500)) {
                    var enh: Bitmap? = null
                    try {
                        val (eb, k) = prepLatin(bmp)
                        enh = eb
                        val second = pass(rec, eb, k, bmp, s)
                        val q2 = quality(second)
                        if (res.isEmpty() || q2 > q1 + 0.02f) { if (second.isNotEmpty()) res = second }
                    } catch (_: Throwable) {
                        // not enough memory or the second reader failed: keep the first result
                    } finally {
                        if (enh != null && enh !== bmp) try { enh.recycle() } catch (_: Throwable) {}
                    }
                }
            }
            if (s == "en" && !fast) res = refine(rec, bmp, res)
            // Manga is read from the top right to the bottom left, which matters for the context given to the AI.
            if (s == "ja" && res.size > 1) {
                val band = (bmp.height / 8).coerceAtLeast(1)
                return res.sortedWith(compareBy<OBlock>({ it.rect.top / band }, { -it.rect.centerX() }))
            }
            return res
        } finally {
            // the recognizers are kept and reused: creating one for every picture / camera frame is slow
        }
    }

    /** Colour of the letters in [r]: average of the darkest (or, on a dark ground, brightest) pixels that clearly differ from the ground colour [bg]. Null when the box has no clear letters. */
    fun inkColor(bm: Bitmap, r: Rect, bg: Int): Int? {
        val x0 = r.left.coerceIn(0, bm.width - 1); val x1 = r.right.coerceIn(x0 + 1, bm.width)
        val y0 = r.top.coerceIn(0, bm.height - 1); val y1 = r.bottom.coerceIn(y0 + 1, bm.height)
        val sx = maxOf(1, (x1 - x0) / 40); val sy = maxOf(1, (y1 - y0) / 40)
        fun lum(c: Int) = (299 * Color.red(c) + 587 * Color.green(c) + 114 * Color.blue(c)) / 1000
        val bl = lum(bg)
        val far = ArrayList<Int>()
        var y = y0
        while (y < y1) {
            var x = x0
            while (x < x1) {
                val c = bm.getPixel(x, y)
                if (Math.abs(lum(c) - bl) > 70) far.add(c)
                x += sx
            }
            y += sy
        }
        if (far.size < 8) return null
        far.sortBy { Math.abs(lum(it) - bl) }
        val top = far.takeLast(maxOf(4, far.size * 3 / 10))
        return Color.rgb(top.sumOf { Color.red(it) } / top.size, top.sumOf { Color.green(it) } / top.size, top.sumOf { Color.blue(it) } / top.size)
    }

    /** Background colour = median of pixels just outside the text box. */
    fun sampleBg(b: Bitmap, r: Rect): Int {
        val px = ArrayList<Int>()
        fun add(x: Int, y: Int) { px.add(b.getPixel(x.coerceIn(0, b.width - 1), y.coerceIn(0, b.height - 1))) }
        for (i in 0..9) {
            val x = r.left + r.width() * i / 9
            add(x, r.top - 2)
            add(x, r.bottom + 2)
        }
        for (i in 0..3) {
            val y = r.top + r.height() * i / 3
            add(r.left - 2, y)
            add(r.right + 2, y)
        }
        fun med(f: (Int) -> Int): Int {
            val l = px.map(f).sorted()
            return l[l.size / 2]
        }
        return Color.rgb(med { Color.red(it) }, med { Color.green(it) }, med { Color.blue(it) })
    }

    private fun keyOf(b: OBlock, scale: Float): Int =
        ((scale * 100).toInt() * 31 + (b.sizeMul * 100).toInt()) * 31 + (b.fgOv ?: 1) * 17 + (b.bgOv ?: 2) * 13 + (if (b.bold) 1 else 0) + (b.fontOv ?: cfg?.ocrFont ?: "").hashCode() * 3 + b.out.hashCode() * 7

    /** Lays the translation out: the biggest size that fits the original box, times the size slider and the block's own size. */
    fun prepare(b: OBlock, scale: Float) {
        val r = Rect(b.rect)
        val pad = maxOf(4, (minOf(r.width(), r.height()) * 0.06f).toInt())
        r.inset(-pad, -pad)
        // Tall, narrow boxes (vertical Japanese text): give the translation a wider box so it does not become a thin column.
        if (r.height() > r.width() * 3 / 2) {
            val nw = minOf((r.height() * 0.7f).toInt(), r.width() * 3)
            if (nw > r.width()) r.inset(-(nw - r.width()) / 2, 0)
        }
        val bgc = b.bgOv ?: b.bg
        val lum = 0.299 * Color.red(bgc) + 0.587 * Color.green(bgc) + 0.114 * Color.blue(bgc)
        b.fg = b.fgOv ?: (if (b.bgOv == null) b.fgAuto else null) ?: (if (lum > 140) Color.BLACK else Color.WHITE)
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = b.fg
            typeface = Fonts.face(null, b.fontOv ?: cfg?.ocrFont ?: "", b.bold)
        }
        // inside a speech bubble: lay the text out in the bubble (a bit inset), not only in the old text's box
        val z = b.zone
        if (z != null && z.width() > r.width() && z.height() >= r.height()) {
            val zi = Rect(z)
            zi.inset((z.width() * 0.12f).toInt(), (z.height() * 0.12f).toInt())
            zi.union(r)
            r.set(zi)
        }
        val innerW = maxOf((r.width() * 0.94f).toInt(), 40)
        val innerH = (r.height() * 0.94f).toInt()
        fun layout(sz: Float): StaticLayout {
            tp.textSize = sz
            val letters = b.out.count { it.isLetter() }
            val rtl = letters > 0 && b.out.count { it.code in 0x0600..0x06FF } * 2 > letters
            // a Persian text with an English name inside must still run right to left
            return StaticLayout.Builder.obtain(b.out, 0, b.out.length, tp, innerW)
                .setTextDirection(if (rtl) android.text.TextDirectionHeuristics.RTL else android.text.TextDirectionHeuristics.FIRSTSTRONG_LTR)
                .setAlignment(Layout.Alignment.ALIGN_CENTER).setLineSpacing(0f, 1.08f).build()
        }
        // biggest size that fits (search from large to small), then the sliders on top
        var fit = 12f
        var sz = minOf(r.height().toFloat(), 96f, maxOf(r.width() / 6f, 16f), if (b.lineH > 0) maxOf(b.lineH * 1.3f, 14f) else 96f)
        while (sz >= 12f) {
            if (layout(sz).height <= innerH) { fit = sz; break }
            sz -= 2f
        }
        val sc = if (scale <= 0f) 1f else scale
        val finalSize = (fit * sc * b.sizeMul).coerceIn(9f, 160f)
        val sl = layout(finalSize)
        val hgt = maxOf(r.height(), sl.height + pad * 2)
        val cy = r.centerY()
        b.box = Rect(r.left, cy - hgt / 2, r.right, cy + hgt / 2)
        b.sl = sl
        b.usedScale = scale
        b.usedKey = keyOf(b, scale)
    }

    fun draw(c: Canvas, b: OBlock, scale: Float) {
        if (b.out.isEmpty()) return
        if (b.sl == null || b.usedKey != keyOf(b, scale)) prepare(b, scale)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = b.bgOv ?: b.bg; style = Paint.Style.FILL }
        val r0 = Rect(b.rect)
        val pad = maxOf(4, (minOf(r0.width(), r0.height()) * 0.06f).toInt())
        r0.inset(-pad, -pad)
        val rad = minOf(r0.width(), r0.height()) * 0.18f
        if (!b.noFill) c.drawRoundRect(android.graphics.RectF(r0), rad, rad, paint)
        val sl = b.sl ?: return
        var lw = 0f
        for (i in 0 until sl.lineCount) lw = maxOf(lw, sl.getLineWidth(i))
        val fw = lw + pad * 2f; val fh = sl.height + pad * 2f
        val fr = android.graphics.RectF(b.box.centerX() - fw / 2, b.box.centerY() - fh / 2, b.box.centerX() + fw / 2, b.box.centerY() + fh / 2)
        if (!b.noFill) c.drawRoundRect(fr, rad, rad, paint)
        c.save()
        c.translate(b.box.left + (b.box.width() - sl.width) / 2f, b.box.top.toFloat() + (b.box.height() - sl.height) / 2f)
        if (b.noFill) {
            // the background is the picture itself: a stroke in the opposite colour keeps the letters readable
            val tp = sl.paint
            val old = tp.color
            tp.style = Paint.Style.STROKE
            tp.strokeWidth = maxOf(2f, tp.textSize * 0.11f)
            tp.strokeJoin = Paint.Join.ROUND
            tp.color = if (Color.red(old) + Color.green(old) + Color.blue(old) > 380) Color.BLACK else Color.WHITE
            sl.draw(c)
            tp.style = Paint.Style.FILL
            tp.strokeWidth = 0f
            tp.color = old
        }
        sl.draw(c)
        c.restore()
    }
}
