package app.tarjoman

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.google.android.gms.tasks.Tasks
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/** One recognized text block (position on the image, source text, translated text, background colour). */
class OBlock(val rect: Rect, val text: String, val bg: Int) {
    @Volatile var out: String = ""
    var sl: StaticLayout? = null
    var box: Rect = Rect()
    var fg: Int = Color.BLACK
    var usedScale: Float = -1f
}

object Ocr {
    @Volatile var base: File? = null   // set by Tr: filesDir/ocr (contains tessdata/fas.traineddata)

    fun faFile(): File? = base?.let { File(it, "tessdata/fas.traineddata") }
    fun faReady(): Boolean = faFile()?.let { it.isFile && it.length() > 0 } ?: false

    /** Persian text is thin and small on manga / screenshots: grayscale, stretched contrast and at least ~1800 px on the long side help Tesseract a lot. */
    private fun prepFa(bmp: Bitmap): Pair<Bitmap, Float> {
        val longSide = maxOf(bmp.width, bmp.height)
        var k = 1f
        if (longSide < 1800) k = minOf(3f, 1800f / longSide)
        if (k > 3f) k = 3f
        val w = (bmp.width * k).toInt().coerceAtLeast(1)
        val h = (bmp.height * k).toInt().coerceAtLeast(1)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val cm = android.graphics.ColorMatrix()
        cm.setSaturation(0f)
        val con = android.graphics.ColorMatrix(floatArrayOf(
            1.4f, 0f, 0f, 0f, -40f,
            0f, 1.4f, 0f, 0f, -40f,
            0f, 0f, 1.4f, 0f, -40f,
            0f, 0f, 0f, 1f, 0f
        ))
        cm.postConcat(con)
        val p = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        p.colorFilter = android.graphics.ColorMatrixColorFilter(cm)
        c.drawBitmap(bmp, null, Rect(0, 0, w, h), p)
        return Pair(out, k)
    }

    /** Blocking. Persian OCR with Tesseract (offline). */
    private fun readFa(orig: Bitmap): List<OBlock> {
        val dir = base ?: throw IllegalStateException(L("OCR آماده نیست"))
        if (!faReady()) throw IllegalStateException(L("مدل OCR فارسی نصب نیست؛ از تب «مدل‌ها» دانلودش کن."))
        val (bmp, k) = prepFa(orig)
        val api = TessBaseAPI()
        try {
            if (!api.init(dir.absolutePath, "fas")) throw IllegalStateException(L("OCR فارسی بارگذاری نشد"))
            api.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO)
            api.setImage(bmp)
            api.getUTF8Text()
            val iter = api.getResultIterator()
            val res = ArrayList<OBlock>()
            if (iter != null) {
                iter.begin()
                do {
                    val txt = iter.getUTF8Text(TessBaseAPI.PageIteratorLevel.RIL_PARA)
                    val r0 = iter.getBoundingRect(TessBaseAPI.PageIteratorLevel.RIL_PARA)
                    if (txt != null && r0 != null && worthKeeping(txt)) {
                        // back to the coordinates of the original picture
                        val r = Rect((r0.left / k).toInt(), (r0.top / k).toInt(), (r0.right / k).toInt(), (r0.bottom / k).toInt())
                        res.add(OBlock(r, Fa.fix(txt.replace("\n", " ").trim()), sampleBg(orig, r)))
                    }
                } while (iter.next(TessBaseAPI.PageIteratorLevel.RIL_PARA))
                iter.delete()
            }
            return res
        } finally {
            try { api.recycle() } catch (_: Throwable) {}
            if (bmp !== orig) try { bmp.recycle() } catch (_: Throwable) {}
        }
    }

    class AutoRes(val blocks: List<OBlock>, val lang: String)

    /** True when the recognized text really is in language [l] (a Latin reader fed Persian / Japanese pages returns junk). */
    private fun scriptOk(blocks: List<OBlock>, l: String): Boolean {
        val g = Fa.guess(blocks.joinToString(" ") { it.text }) ?: return true
        return g == l
    }

    /** Drops noise: single marks, sound-effect scribbles, boxes where most characters are not letters. */
    private fun worthKeeping(t: String): Boolean {
        val letters = t.count { it.isLetter() }
        if (letters < 1 || (letters < 2 && t.none { it.code >= 0x3040 })) return false
        val chars = t.count { !it.isWhitespace() }
        return letters * 100 >= chars * 45
    }

    /**
     * Like [read], but when nothing is found in the chosen language, or the text found is in another script
     * (junk from the wrong reader), it tries the other ones (en / ja / fa) and reports which worked.
     */
    fun readAuto(bmp: Bitmap, s: String): AutoRes {
        var err: Throwable? = null
        var weak: AutoRes? = null
        try {
            val first = read(bmp, s)
            if (first.isNotEmpty()) {
                if (scriptOk(first, s)) return AutoRes(first, s)
                weak = AutoRes(first, s)
            }
        } catch (e: Throwable) {
            if (s == "fa") throw e
            err = e
        }
        val order = when (s) { "en" -> listOf("ja", "fa"); "ja" -> listOf("en", "fa"); else -> listOf("en", "ja") }
        for (l in order) {
            if (l == "fa" && !faReady()) continue
            try {
                val b = read(bmp, l)
                if (b.isNotEmpty() && scriptOk(b, l)) return AutoRes(b, l)
            } catch (_: Throwable) {
            }
        }
        if (weak != null) return weak
        if (err != null) throw err
        return AutoRes(emptyList(), s)
    }

    /** Blocking. Reads text blocks from a bitmap (English/Latin or Japanese). */
    fun read(bmp: Bitmap, s: String): List<OBlock> {
        if (s == "fa") return readFa(bmp)
        val rec = if (s == "ja") TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
        else TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        try {
            val vt = Tasks.await(rec.process(InputImage.fromBitmap(bmp, 0)))
            val res = ArrayList<OBlock>()
            for (b in vt.textBlocks) {
                val bb = b.boundingBox ?: continue
                if (!worthKeeping(b.text)) continue
                val raw = if (s == "ja") b.text.replace("\n", "") else b.text.replace("\n", " ")
                res.add(OBlock(Rect(bb), raw, sampleBg(bmp, bb)))
            }
            // Manga is read from the top right to the bottom left, which matters for the context given to the AI.
            if (s == "ja" && res.size > 1) {
                val band = (bmp.height / 8).coerceAtLeast(1)
                return res.sortedWith(compareBy<OBlock>({ it.rect.top / band }, { -it.rect.centerX() }))
            }
            return res
        } finally {
            try { rec.close() } catch (_: Throwable) {}
        }
    }

    /** Background colour = median of pixels just outside the text box. */
    fun sampleBg(b: Bitmap, r: Rect): Int {
        val px = ArrayList<Int>()
        fun add(x: Int, y: Int) { px.add(b.getPixel(x.coerceIn(0, b.width - 1), y.coerceIn(0, b.height - 1))) }
        for (i in 0..9) {
            val x = r.left + r.width() * i / 9
            add(x, r.top - 2)
            add(x, r.bottom + 2)
        }
        for (i in 0..3) {
            val y = r.top + r.height() * i / 3
            add(r.left - 2, y)
            add(r.right + 2, y)
        }
        fun med(f: (Int) -> Int): Int {
            val l = px.map(f).sorted()
            return l[l.size / 2]
        }
        return Color.rgb(med { Color.red(it) }, med { Color.green(it) }, med { Color.blue(it) })
    }

    fun prepare(b: OBlock, scale: Float) {
        val r = Rect(b.rect)
        r.inset(-4, -4)
        // Tall, narrow boxes (vertical Japanese text): give the translation a wider box so it does not become a thin column.
        if (r.height() > r.width() * 3 / 2) {
            val nw = minOf((r.height() * 0.7f).toInt(), r.width() * 3)
            if (nw > r.width()) r.inset(-(nw - r.width()) / 2, 0)
        }
        val lum = 0.299 * Color.red(b.bg) + 0.587 * Color.green(b.bg) + 0.114 * Color.blue(b.bg)
        b.fg = if (lum > 140) Color.BLACK else Color.WHITE
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = b.fg }
        val w = maxOf(r.width(), 40)
        val minSize = 20f * scale
        var size = minOf(r.height().toFloat(), 72f) * scale
        if (size < minSize) size = minSize
        var sl: StaticLayout
        while (true) {
            tp.textSize = size
            sl = StaticLayout.Builder.obtain(b.out, 0, b.out.length, tp, w).setAlignment(Layout.Alignment.ALIGN_CENTER).build()
            if (sl.height <= r.height() || size <= minSize) break
            size -= 2f
        }
        val hgt = maxOf(r.height(), sl.height)
        val cy = r.centerY()
        b.box = Rect(r.left, cy - hgt / 2, r.right, cy + hgt / 2)
        b.sl = sl
        b.usedScale = scale
    }

    fun draw(c: Canvas, b: OBlock, scale: Float) {
        if (b.out.isEmpty()) return
        if (b.sl == null || b.usedScale != scale) prepare(b, scale)
        val paint = Paint().apply { color = b.bg; style = Paint.Style.FILL }
        val r0 = Rect(b.rect)
        r0.inset(-4, -4)
        c.drawRect(r0, paint)
        c.drawRect(b.box, paint)
        val sl = b.sl ?: return
        c.save()
        c.translate(b.box.left.toFloat(), b.box.top.toFloat() + (b.box.height() - sl.height) / 2f)
        sl.draw(c)
        c.restore()
    }
}
