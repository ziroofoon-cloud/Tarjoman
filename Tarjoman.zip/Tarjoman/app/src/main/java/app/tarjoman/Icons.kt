package app.tarjoman

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View

/** Small line icons drawn with Canvas on a 24x24 grid (no emoji, no image files, follows the theme colour). */
class IconView(ctx: Context, private val kind: String, private var tint: Int = C.SUB) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()

    fun setTint(c: Int) { tint = c; invalidate() }

    private fun line(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float) { c.drawLine(x1, y1, x2, y2, p) }

    private fun dot(c: Canvas, x: Float, y: Float, r: Float) {
        p.style = Paint.Style.FILL
        c.drawCircle(x, y, r, p)
        p.style = Paint.Style.STROKE
    }

    private fun poly(c: Canvas, close: Boolean, vararg pts: Float) {
        path.reset()
        path.moveTo(pts[0], pts[1])
        var i = 2
        while (i + 1 < pts.size) { path.lineTo(pts[i], pts[i + 1]); i += 2 }
        if (close) path.close()
        c.drawPath(path, p)
    }

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height) / 24f
        c.save()
        c.translate((width - 24f * s) / 2f, (height - 24f * s) / 2f)
        c.scale(s, s)
        p.color = tint
        p.strokeWidth = 1.8f
        when (kind) {
            "text" -> {
                c.drawRoundRect(3f, 4f, 21f, 16f, 3f, 3f, p)
                poly(c, false, 8f, 16f, 8f, 20f, 12.5f, 16f)
                line(c, 7.5f, 8.5f, 16.5f, 8.5f)
                line(c, 7.5f, 12f, 13f, 12f)
            }
            "image" -> {
                c.drawRoundRect(3f, 4f, 21f, 20f, 3f, 3f, p)
                dot(c, 8.5f, 9.5f, 1.7f)
                poly(c, false, 3.5f, 17f, 9f, 12.5f, 13f, 15.5f, 16f, 13f, 20.5f, 17f)
            }
            "pdf" -> {
                poly(c, true, 6f, 3f, 14f, 3f, 19f, 8f, 19f, 21f, 6f, 21f)
                poly(c, false, 14f, 3f, 14f, 8f, 19f, 8f)
                line(c, 9f, 13f, 16f, 13f)
                line(c, 9f, 16.8f, 14f, 16.8f)
            }
            "sub" -> {
                c.drawRoundRect(3f, 5f, 21f, 19f, 3f, 3f, p)
                line(c, 7f, 12.5f, 12f, 12.5f)
                line(c, 14f, 12.5f, 17f, 12.5f)
                line(c, 7f, 15.8f, 9.5f, 15.8f)
                line(c, 11.5f, 15.8f, 17f, 15.8f)
            }
            "bubble" -> {
                c.drawCircle(12f, 12f, 9f, p)
                dot(c, 12f, 12f, 3.3f)
            }
            "model" -> {
                c.drawRoundRect(6f, 6f, 18f, 18f, 2.5f, 2.5f, p)
                c.drawRoundRect(9.6f, 9.6f, 14.4f, 14.4f, 1f, 1f, p)
                line(c, 9.7f, 3f, 9.7f, 6f); line(c, 14.3f, 3f, 14.3f, 6f)
                line(c, 9.7f, 18f, 9.7f, 21f); line(c, 14.3f, 18f, 14.3f, 21f)
                line(c, 3f, 9.7f, 6f, 9.7f); line(c, 3f, 14.3f, 6f, 14.3f)
                line(c, 18f, 9.7f, 21f, 9.7f); line(c, 18f, 14.3f, 21f, 14.3f)
            }
            "settings" -> {
                line(c, 4f, 7f, 20f, 7f)
                line(c, 4f, 12f, 20f, 12f)
                line(c, 4f, 17f, 20f, 17f)
                dot(c, 9f, 7f, 2.6f)
                dot(c, 15.5f, 12f, 2.6f)
                dot(c, 8f, 17f, 2.6f)
            }
            "swap" -> {
                line(c, 4f, 8f, 19.5f, 8f)
                poly(c, false, 15.5f, 4.5f, 19.5f, 8f, 15.5f, 11.5f)
                line(c, 20f, 16f, 4.5f, 16f)
                poly(c, false, 8.5f, 12.5f, 4.5f, 16f, 8.5f, 19.5f)
            }
            "check" -> {
                poly(c, false, 5f, 12.5f, 10f, 17f, 19f, 7f)
            }
            "paste" -> {
                c.drawRoundRect(5f, 5f, 19f, 21f, 2.5f, 2.5f, p)
                c.drawRoundRect(9f, 3f, 15f, 7f, 1.5f, 1.5f, p)
                line(c, 8.5f, 12f, 15.5f, 12f)
                line(c, 8.5f, 16f, 13.5f, 16f)
            }
            "mic" -> {
                c.drawRoundRect(9f, 3f, 15f, 14f, 3f, 3f, p)
                c.drawArc(RectF(6f, 7f, 18f, 18f), 0f, 180f, false, p)
                line(c, 12f, 18f, 12f, 21f)
                line(c, 9f, 21f, 15f, 21f)
            }
            "speaker" -> {
                poly(c, true, 4f, 9f, 8f, 9f, 12f, 5f, 12f, 19f, 8f, 15f, 4f, 15f)
                c.drawArc(RectF(10f, 8f, 18f, 16f), -55f, 110f, false, p)
                c.drawArc(RectF(8f, 5f, 22f, 19f), -55f, 110f, false, p)
            }
            "clear" -> {
                line(c, 4f, 7f, 20f, 7f)
                poly(c, false, 6.5f, 7f, 7.5f, 20f, 16.5f, 20f, 17.5f, 7f)
                line(c, 10f, 11f, 10f, 16f)
                line(c, 14f, 11f, 14f, 16f)
                poly(c, false, 9.5f, 7f, 9.5f, 4f, 14.5f, 4f, 14.5f, 7f)
            }
            "pen" -> {
                poly(c, true, 4f, 20f, 5f, 15f, 16f, 4f, 20f, 8f, 9f, 19f)
                line(c, 13.5f, 6.5f, 17.5f, 10.5f)
            }
            "copy" -> {
                c.drawRoundRect(9f, 9f, 20f, 20f, 2.5f, 2.5f, p)
                poly(c, false, 15f, 9f, 15f, 5f, 5f, 5f, 5f, 15f, 9f, 15f)
            }
            "retry" -> {
                c.drawArc(RectF(5f, 5f, 19f, 19f), 30f, 300f, false, p)
                poly(c, false, 18.4f, 4.5f, 18.06f, 8.5f, 14.4f, 6.8f)
            }
            "share" -> {
                dot(c, 18f, 5.5f, 2.3f)
                dot(c, 6f, 12f, 2.3f)
                dot(c, 18f, 18.5f, 2.3f)
                line(c, 8f, 11f, 16f, 6.6f)
                line(c, 8f, 13f, 16f, 17.4f)
            }
            "save" -> {
                c.drawRoundRect(4f, 4f, 20f, 20f, 2.5f, 2.5f, p)
                c.drawRect(8f, 4f, 15f, 9f, p)
                c.drawRect(8f, 14f, 16f, 20f, p)
            }
            "camera" -> {
                c.drawRoundRect(3f, 7f, 21f, 19f, 3f, 3f, p)
                c.drawCircle(12f, 13f, 3.3f, p)
                poly(c, false, 8.5f, 7f, 10f, 4.5f, 14f, 4.5f, 15.5f, 7f)
            }
            "eye" -> {
                c.drawOval(RectF(2.5f, 6.5f, 21.5f, 17.5f), p)
                c.drawCircle(12f, 12f, 3f, p)
            }
            "bookmark" -> {
                poly(c, true, 7f, 4f, 17f, 4f, 17f, 20f, 12f, 16f, 7f, 20f)
            }
            "list" -> {
                line(c, 9f, 7f, 20f, 7f); line(c, 9f, 12f, 20f, 12f); line(c, 9f, 17f, 20f, 17f)
                dot(c, 5f, 7f, 1.3f); dot(c, 5f, 12f, 1.3f); dot(c, 5f, 17f, 1.3f)
            }
            "plus" -> {
                line(c, 12f, 5f, 12f, 19f)
                line(c, 5f, 12f, 19f, 12f)
            }
            "close" -> {
                line(c, 6f, 6f, 18f, 18f)
                line(c, 18f, 6f, 6f, 18f)
            }
            "history" -> {
                c.drawCircle(12f, 12f, 8.5f, p)
                poly(c, false, 12f, 7f, 12f, 12f, 15.5f, 14f)
            }
            "cap" -> {
                poly(c, true, 2f, 9f, 12f, 4.5f, 22f, 9f, 12f, 13.5f)
                poly(c, false, 6.5f, 11f, 6.5f, 16f, 12f, 19f, 17.5f, 16f, 17.5f, 11f)
            }
            "stop" -> {
                c.drawRoundRect(7f, 7f, 17f, 17f, 2f, 2f, p)
            }
            "play" -> {
                poly(c, true, 8f, 5f, 19f, 12f, 8f, 19f)
            }
            "zip" -> {
                c.drawRoundRect(4f, 3f, 20f, 21f, 2.5f, 2.5f, p)
                line(c, 12f, 3f, 12f, 11f)
                line(c, 10f, 6f, 14f, 6f); line(c, 10f, 9f, 14f, 9f)
                c.drawRoundRect(9.5f, 13f, 14.5f, 18f, 1.2f, 1.2f, p)
            }
            "download" -> {
                line(c, 12f, 4f, 12f, 15f)
                poly(c, false, 7.5f, 10.8f, 12f, 15.3f, 16.5f, 10.8f)
                line(c, 5f, 20f, 19f, 20f)
            }
        }
        c.restore()
    }
}
