package app.tarjoman

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View

/** Small line icons drawn with Canvas on a 24x24 grid (no emoji, no image files, follows the theme colour). */
class IconView(ctx: Context, private val kind: String, private var tint: Int = C.SUB) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()

    fun setTint(c: Int) { tint = c; invalidate() }

    private fun line(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float) { c.drawLine(x1, y1, x2, y2, p) }

    private fun dot(c: Canvas, x: Float, y: Float, r: Float) {
        p.style = Paint.Style.FILL
        c.drawCircle(x, y, r, p)
        p.style = Paint.Style.STROKE
    }

    private fun poly(c: Canvas, close: Boolean, vararg pts: Float) {
        path.reset()
        path.moveTo(pts[0], pts[1])
        var i = 2
        while (i + 1 < pts.size) { path.lineTo(pts[i], pts[i + 1]); i += 2 }
        if (close) path.close()
        c.drawPath(path, p)
    }

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height) / 24f
        c.save()
        c.translate((width - 24f * s) / 2f, (height - 24f * s) / 2f)
        c.scale(s, s)
        p.color = tint
        p.strokeWidth = 1.8f
        when (kind) {
            "text" -> {
                c.drawRoundRect(3f, 4f, 21f, 16f, 3f, 3f, p)
                poly(c, false, 8f, 16f, 8f, 20f, 12.5f, 16f)
                line(c, 7.5f, 8.5f, 16.5f, 8.5f)
                line(c, 7.5f, 12f, 13f, 12f)
            }
            "image" -> {
                c.drawRoundRect(3f, 4f, 21f, 20f, 3f, 3f, p)
                dot(c, 8.5f, 9.5f, 1.7f)
                poly(c, false, 3.5f, 17f, 9f, 12.5f, 13f, 15.5f, 16f, 13f, 20.5f, 17f)
            }
            "pdf" -> {
                poly(c, true, 6f, 3f, 14f, 3f, 19f, 8f, 19f, 21f, 6f, 21f)
                poly(c, false, 14f, 3f, 14f, 8f, 19f, 8f)
                line(c, 9f, 13f, 16f, 13f)
                line(c, 9f, 16.8f, 14f, 16.8f)
            }
            "sub" -> {
                c.drawRoundRect(3f, 5f, 21f, 19f, 3f, 3f, p)
                line(c, 7f, 12.5f, 12f, 12.5f)
                line(c, 14f, 12.5f, 17f, 12.5f)
                line(c, 7f, 15.8f, 9.5f, 15.8f)
                line(c, 11.5f, 15.8f, 17f, 15.8f)
            }
            "bubble" -> {
                c.drawCircle(12f, 12f, 9f, p)
                dot(c, 12f, 12f, 3.3f)
            }
            "model" -> {
                c.drawRoundRect(6f, 6f, 18f, 18f, 2.5f, 2.5f, p)
                c.drawRoundRect(9.6f, 9.6f, 14.4f, 14.4f, 1f, 1f, p)
                line(c, 9.7f, 3f, 9.7f, 6f); line(c, 14.3f, 3f, 14.3f, 6f)
                line(c, 9.7f, 18f, 9.7f, 21f); line(c, 14.3f, 18f, 14.3f, 21f)
                line(c, 3f, 9.7f, 6f, 9.7f); line(c, 3f, 14.3f, 6f, 14.3f)
                line(c, 18f, 9.7f, 21f, 9.7f); line(c, 18f, 14.3f, 21f, 14.3f)
            }
            "settings" -> {
                line(c, 4f, 7f, 20f, 7f)
                line(c, 4f, 12f, 20f, 12f)
                line(c, 4f, 17f, 20f, 17f)
                dot(c, 9f, 7f, 2.6f)
                dot(c, 15.5f, 12f, 2.6f)
                dot(c, 8f, 17f, 2.6f)
            }
            "swap" -> {
                line(c, 4f, 8f, 19.5f, 8f)
                poly(c, false, 15.5f, 4.5f, 19.5f, 8f, 15.5f, 11.5f)
                line(c, 20f, 16f, 4.5f, 16f)
                poly(c, false, 8.5f, 12.5f, 4.5f, 16f, 8.5f, 19.5f)
            }
            "check" -> {
                poly(c, false, 5f, 12.5f, 10f, 17f, 19f, 7f)
            }
            "download" -> {
                line(c, 12f, 4f, 12f, 15f)
                poly(c, false, 7.5f, 10.8f, 12f, 15.3f, 16.5f, 10.8f)
                line(c, 5f, 20f, 19f, 20f)
            }
        }
        c.restore()
    }
}
