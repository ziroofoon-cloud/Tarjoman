package app.tarjoman

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Word meanings by part of speech (like "More translations" in Google Translate), from several online dictionaries,
 * saved on the phone so they also show offline, and the "auto learn" that adds what the translator did not know.
 */
object Dict {
    class Entry(val pos: String, val words: List<String>)
    class Result(val entries: List<Entry>, val important: List<String>) {
        fun all(): List<String> = entries.flatMap { it.words }.distinct()
    }

    private val lock = Any()
    private var data: JSONObject? = null

    private fun file(ctx: Context) = File(ctx.filesDir, "dict.json")

    private fun load(ctx: Context): JSONObject {
        data?.let { return it }
        val d = try { JSONObject(file(ctx).readText()) } catch (_: Throwable) { JSONObject() }
        data = d
        return d
    }

    private fun flush(ctx: Context) {
        try {
            val d = data ?: return
            if (d.length() > 4000) { val ks = d.keys().asSequence().toList(); for (k in ks.take(500)) d.remove(k) }
            file(ctx).writeText(d.toString())
        } catch (_: Throwable) {}
    }

    private fun key(s: String, d: String, t: String) = s + "|" + d + "|" + Idm.norm(t)

    /** True for a word or a short phrase (dictionary lookups make sense), false for a sentence. */
    fun isWord(t: String): Boolean {
        val x = t.trim()
        return x.isNotEmpty() && x.length <= 40 && x.split(Regex("\\s+")).size <= 3 && x.none { it in ".!?;:" }
    }

    fun canon(p: String): String {
        val x = p.lowercase().trim()
        return when {
            x.startsWith("noun") -> "noun"
            x.startsWith("verb") -> "verb"
            x.startsWith("adj") -> "adjective"
            x.startsWith("adv") -> "adverb"
            x.startsWith("pron") -> "pronoun"
            x.startsWith("prep") -> "preposition"
            x.startsWith("conj") -> "conjunction"
            x.startsWith("interj") || x.startsWith("exclam") -> "interjection"
            x.startsWith("det") || x.startsWith("art") -> "determiner"
            x.startsWith("modal") -> "modal"
            x == "alt" -> "alt"
            else -> "other"
        }
    }

    fun label(p: String): String = when (canon(p)) {
        "noun" -> L("اسم"); "verb" -> L("فعل"); "adjective" -> L("صفت"); "adverb" -> L("قید")
        "pronoun" -> L("ضمیر"); "preposition" -> L("حرف اضافه"); "conjunction" -> L("حرف ربط")
        "interjection" -> L("حرف ندا"); "determiner" -> L("حد / ادات"); "modal" -> L("فعل کمکی")
        "alt" -> L("ترجمه‌های مشابه"); else -> L("سایر")
    }

    private fun merge(lists: List<List<Entry>>): List<Entry> {
        val by = LinkedHashMap<String, ArrayList<String>>()
        for (l in lists) for (e in l) {
            val k = canon(e.pos)
            val dst = by.getOrPut(k) { ArrayList() }
            for (w in e.words) if (w.isNotBlank() && dst.none { it.equals(w, true) }) dst.add(w)
        }
        return by.map { Entry(it.key, it.value.toList()) }
    }

    fun saved(ctx: Context, t: String, s: String, d: String): Result? {
      return synchronized(lock) {
        val o = load(ctx).optJSONObject(key(s, d, t)) ?: return@synchronized null
        val ea = o.optJSONArray("e") ?: JSONArray()
        val es = ArrayList<Entry>()
        for (i in 0 until ea.length()) {
            val e = ea.optJSONObject(i) ?: continue
            val wa = e.optJSONArray("w") ?: continue
            es.add(Entry(e.optString("p"), (0 until wa.length()).map { wa.optString(it) }))
        }
        val ia = o.optJSONArray("i") ?: JSONArray()
        Result(es, (0 until ia.length()).map { ia.optString(it) })
      }
    }

    fun save(ctx: Context, t: String, s: String, d: String, r: Result) {
      synchronized(lock) {
        val o = JSONObject()
        val ea = JSONArray()
        for (e in r.entries) ea.put(JSONObject().put("p", e.pos).put("w", JSONArray(e.words)))
        o.put("e", ea).put("i", JSONArray(r.important))
        load(ctx).put(key(s, d, t), o)
        flush(ctx)
      }
    }

    /** From the internet: Microsoft dictionary, Google, Lingva (every one that answers; the lists are merged). Throws when none worked. */
    fun online(t: String, s: String, d: String, c: Cfg): List<Entry> {
        val got = ArrayList<List<Entry>>()
        var err: Throwable? = null
        if (isWord(t)) {
            try { got.add(Online.msDict(t, s, d, c).map { Entry(it.first, it.second) }) } catch (e: Throwable) { err = e }
        }
        try {
            val g = Online.senses(t, s, d, c)
            got.add(g.dict.map { Entry(it.first, it.second) })
            if (g.alts.isNotEmpty()) got.add(listOf(Entry("alt", g.alts)))
        } catch (e: Throwable) { err = e }
        if (got.none { it.isNotEmpty() } && isWord(t)) {
            try { got.add(Online.lingvaDict(t, s, d, c).map { Entry(it.first, it.second) }) } catch (e: Throwable) { err = e }
        }
        val m = merge(got)
        if (m.isEmpty() && err != null && got.isEmpty()) throw err
        return m
    }

    /**
     * Looks the text up (saved list + internet). With [learn], what the translator did not know is added and saved:
     * an untranslated word gets its best meaning (en -> fa), and a translation missing from the list is added to it.
     * Returns null when nothing is known.
     */
    fun lookup(ctx: Context, cfg: Cfg, t: String, s: String, d: String, out: String?, learn: Boolean, useNet: Boolean = true, deep: Boolean = false): Result? {
        val old = saved(ctx, t, s, d)
        // 1) the built-in offline dictionary, 2) what was saved earlier, 3) the internet (only when the first two know nothing,
        //    or when [deep]: the user asked for "more translations" and wants every source)
        val built = Dic.get(t, s, d)
        var fresh: List<Entry> = emptyList()
        if (useNet && (deep || (built.isEmpty() && old == null)) && Net.isOnline(ctx)) fresh = try { online(t, s, d, cfg) } catch (_: Throwable) { emptyList() }
        var entries = merge(listOf(built, old?.entries ?: emptyList(), fresh))
        if (entries.isEmpty() && out.isNullOrBlank()) return null
        val imp = old?.important ?: emptyList()
        if (learn && isWord(t)) {
            val o = (out ?: "").trim()
            val untranslated = o.isEmpty() || Idm.norm(o) == Idm.norm(t)
            val known = entries.flatMap { it.words }
            if (untranslated && known.isNotEmpty() && s == "en" && d == "fa" && Idm.mineAll(t).isEmpty()) {
                // the translator only repeated the word: the best meaning becomes its translation from now on
                cfg.userPhr = Idm.setMine(cfg.userPhr, t, listOf(known.first()))
                Idm.loadMine(cfg.userPhr)
            } else if (!untranslated && known.none { it.equals(o, true) }) {
                entries = merge(listOf(entries, listOf(Entry("other", listOf(o)))))
            }
            if (entries.isNotEmpty()) save(ctx, t, s, d, Result(entries, imp))
        } else if (fresh.isNotEmpty() && old == null) {
            // keep it in memory only (no write) when learning is off: shown on the page, nothing saved
        }
        return Result(entries, imp)
    }

    /** The meanings shown on the first page: important ones the user ticked, else the top words of the top groups. */
    fun firstPage(r: Result, maxGroups: Int = 4, perGroup: Int = 3): List<Pair<String, List<String>>> {
        if (r.important.isNotEmpty()) return listOf("" to r.important)
        return r.entries.filter { canon(it.pos) != "alt" }.take(maxGroups).map { label(it.pos) to it.words.take(perGroup) }
    }
}
