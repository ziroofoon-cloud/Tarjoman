package app.tarjoman

/**
 * More English -> Persian phrases (everyday talk, feelings, travel, work, school, idioms, phrasal verbs, comic / anime lines).
 * Same format as Idm.DATA: "english|persian", "_" = half-space, a phrase that is already in Idm.DATA keeps its older answer.
 */
object Idm2 {
    const val DATA = """
how are you doing|حالت چطوره؟
what is up|چه خبر؟
what is going on|چه خبره؟
what is going on here|اینجا چه خبره؟
long time no see|خیلی وقته ندیدمت
nice to meet you|از آشنایی باهات خوشحالم
pleased to meet you|از آشنایی باهاتون خوشحالم
see you later|بعداً می_بینمت
see you tomorrow|فردا می_بینمت
see you soon|به زودی می_بینمت
take care|مراقب خودت باش
take care of yourself|مراقب خودت باش
good luck|موفق باشی
best of luck|برات آرزوی موفقیت می_کنم
congratulations|تبریک می_گم
bless you|عافیت باشه
thank you so much|خیلی ممنون
thanks a lot|خیلی ممنون
thanks for everything|بابت همه_چی ممنون
you are welcome|خواهش می_کنم
do not mention it|قابلی نداره
my pleasure|باعث افتخاره
excuse me|ببخشید
i am sorry|متأسفم
i am so sorry|خیلی متأسفم
sorry for the trouble|ببخشید که زحمت دادم
sorry i am late|ببخشید دیر کردم
no problem|مشکلی نیست
never mind|بیخیال
forget it|ولش کن
it does not matter|مهم نیست
it is okay|اشکالی نداره
it is fine|اشکالی نداره
it is not your fault|تقصیر تو نیست
it is all my fault|همش تقصیر منه
i did not mean it|قصدم این نبود
i did not mean to hurt you|نمی_خواستم ناراحتت کنم
i forgive you|می_بخشمت
i will never forgive you|هیچ_وقت نمی_بخشمت
please forgive me|لطفاً منو ببخش
may i come in|اجازه هست بیام تو؟
can i help you|می_تونم کمکتون کنم؟
how can i help you|چطور می_تونم کمکتون کنم؟
do you need help|کمک می_خوای؟
i need your help|به کمکت احتیاج دارم
could you help me|می_تونی کمکم کنی؟
can you do me a favor|می_شه یه لطفی بهم بکنی؟
could you say that again|می_شه دوباره بگی؟
can you repeat that|می_تونی تکرار کنی؟
speak more slowly|آهسته_تر صحبت کن
i do not understand|نمی_فهمم
i do not know|نمی_دونم
i have no idea|هیچ ایده_ای ندارم
i do not remember|یادم نمیاد
i forgot|یادم رفت
i do not care|برام مهم نیست
i do not think so|فکر نکنم
i think so|فکر کنم آره
i hope so|امیدوارم
i hope not|امیدوارم نه
i guess so|فکر کنم همین طوره
i agree|موافقم
i disagree|مخالفم
you are right|حق با توئه
you are wrong|اشتباه می_کنی
that is true|درسته
that is not true|این درست نیست
that makes sense|منطقیه
that does not make sense|این منطقی نیست
of course|البته
of course not|البته که نه
not at all|اصلاً
by the way|راستی
in fact|در واقع
as a matter of fact|در واقع
as soon as possible|هرچه زودتر
right now|همین الان
just a moment|یه لحظه
wait a minute|یه دقیقه صبر کن
hold on|صبر کن
hang on|یه لحظه صبر کن
hang in there|دووم بیار
just kidding|شوخی کردم
i am kidding|شوخی می_کنم
i mean it|جدی می_گم
i am serious|جدی می_گم
are you serious|جدی می_گی؟
really|واقعاً؟
is that so|جدی؟
no way|محاله
no kidding|شوخی نداری؟
you are kidding|شوخی می_کنی
you must be kidding|حتماً شوخی می_کنی
that is amazing|عالیه
that is awesome|محشره
that is great|عالیه
that is terrible|افتضاحه
that is awful|وحشتناکه
that is disgusting|چندش_آوره
that is ridiculous|مسخره_ست
that is crazy|دیوونگیه
that is insane|دیوونگیه
what a surprise|عجب سورپرایزی
what a shame|چه حیف
what a pity|چه حیف
what a relief|چه آرامشی
how come|چطور ممکنه؟
how dare you|چطور جرئت می_کنی؟
how could you|چطور تونستی؟
how could this happen|چطور این اتفاق افتاد؟
what happened|چی شد؟
what happened to you|چی بر سرت اومد؟
what is wrong|چی شده؟
what is wrong with you|تو چت شده؟
what is the matter|مشکل چیه؟
what do you mean|منظورت چیه؟
what did you say|چی گفتی؟
what did you just say|الان چی گفتی؟
what are you talking about|درباره چی حرف می_زنی؟
what are you doing|داری چیکار می_کنی؟
what are you looking at|به چی نگاه می_کنی؟
what are you thinking|به چی فکر می_کنی؟
what do you think|نظرت چیه؟
what should i do|چیکار کنم؟
what do we do now|حالا چیکار کنیم؟
what is that|اون چیه؟
what is this|این چیه؟
what is your name|اسمت چیه؟
my name is|اسمم هست
where are you|کجایی؟
where is he|اون کجاست؟
where is she|اون کجاست؟
where did he go|کجا رفت؟
where do you live|کجا زندگی می_کنی؟
where did you come from|از کجا اومدی؟
who are you|تو کی هستی؟
who is that|اون کیه؟
who is there|کی اونجاست؟
who said that|کی اینو گفت؟
who did that|کی این کارو کرد؟
why are you here|چرا اینجایی؟
why did you do that|چرا این کارو کردی؟
why not|چرا که نه؟
why me|چرا من؟
why now|چرا حالا؟
when will you be back|کی برمی_گردی؟
when did it happen|کی اتفاق افتاد؟
how much is it|قیمتش چنده؟
how much does it cost|چقدر هزینه داره؟
how old are you|چند سالته؟
how long will it take|چقدر طول می_کشه؟
how far is it|چقدر دوره؟
how many|چندتا؟
how often|هر چند وقت یه بار؟
i am hungry|گشنمه
i am thirsty|تشنمه
i am tired|خسته_م
i am sleepy|خوابم میاد
i am bored|حوصله_م سر رفته
i am busy|سرم شلوغه
i am free|وقت آزاد دارم
i am ready|آماده_م
i am not ready|آماده نیستم
i am scared|می_ترسم
i am not afraid|نمی_ترسم
i am afraid|می_ترسم
i am nervous|استرس دارم
i am worried|نگرانم
i am angry|عصبانی_ام
i am happy|خوشحالم
i am sad|ناراحتم
i am lonely|تنهام
i am lost|گم شدم
i am fine|خوبم
i am okay|خوبم
i am not okay|حالم خوب نیست
i am sick|مریضم
i am hurt|آسیب دیدم
i am cold|سردمه
i am hot|گرممه
i am home|خونه_ام
i am here|اینجام
i am back|برگشتم
i am leaving|دارم می_رم
i am coming|دارم میام
i am going|دارم می_رم
i am done|کارم تموم شد
i am in|من هستم
i am out|من نیستم
i am with you|من باهاتم
i am on your side|من طرف توام
i am proud of you|بهت افتخار می_کنم
i am glad you are here|خوشحالم که اینجایی
i am glad you came|خوشحالم که اومدی
i am worried about you|نگرانتم
i am counting on you|روت حساب می_کنم
i am begging you|التماست می_کنم
i am telling you the truth|دارم راستشو می_گم
i love you|دوستت دارم
i like you|ازت خوشم میاد
i miss you|دلم برات تنگ شده
i hate you|ازت متنفرم
i need you|بهت نیاز دارم
i trust you|بهت اعتماد دارم
i believe you|باورت می_کنم
i do not believe you|باورت نمی_کنم
i do not trust you|بهت اعتماد ندارم
i want to go home|می_خوام برم خونه
i want to see you|می_خوام ببینمت
i want to know the truth|می_خوام حقیقتو بدونم
i want to be alone|می_خوام تنها باشم
i want to live|می_خوام زنده بمونم
i want to help|می_خوام کمک کنم
i want to talk to you|می_خوام باهات حرف بزنم
i have to go|باید برم
i have to leave|باید برم
i have to tell you something|باید یه چیزی بهت بگم
i have a question|یه سؤال دارم
i have a plan|یه نقشه دارم
i have an idea|یه ایده دارم
i have no choice|چاره_ای ندارم
i have nothing to say|حرفی برای گفتن ندارم
i have been waiting for you|منتظرت بودم
i have been looking for you|دنبالت می_گشتم
i have always loved you|همیشه دوستت داشتم
i have missed you|دلم برات تنگ شده بود
i have had enough|دیگه بسمه
i have got to go|باید برم
i have had enough of this|از این وضع خسته شدم
i can do it|از پسش برمیام
i can not do it|نمی_تونم
i can not believe it|باورم نمی_شه
i can not breathe|نمی_تونم نفس بکشم
i can not move|نمی_تونم تکون بخورم
i can not stand it|تحملشو ندارم
i can not take it anymore|دیگه نمی_تونم تحمل کنم
i can not wait|نمی_تونم صبر کنم
i can not wait to see you|بی_صبرانه منتظر دیدنتم
i can see you|می_تونم ببینمت
i can hear you|صداتو می_شنوم
i can feel it|حسش می_کنم
i could not sleep|نتونستم بخوابم
i will do it|انجامش می_دم
i will try|سعیمو می_کنم
i will be there|اونجا خواهم بود
i will be fine|خوب می_شم
i will find you|پیدات می_کنم
i will kill you|می_کشمت
i will protect you|ازت محافظت می_کنم
i will protect everyone|از همه محافظت می_کنم
i will never give up|هیچ_وقت تسلیم نمی_شم
i will never let you go|هیچ_وقت نمی_ذارم بری
i will never forget you|هیچ_وقت فراموشت نمی_کنم
i will show you|نشونت می_دم
i will tell you everything|همه چیزو بهت می_گم
i will think about it|بهش فکر می_کنم
i will see you there|اونجا می_بینمت
i will call you|بهت زنگ می_زنم
i will get it|من برش می_دارم
i will be back|برمی_گردم
i would like to|دوست دارم
i would love to|خیلی دوست دارم
i would rather stay|ترجیح می_دم بمونم
i was wrong|اشتباه می_کردم
i was right|حق با من بود
i was just kidding|فقط شوخی کردم
i was so scared|خیلی ترسیده بودم
i was thinking about you|داشتم به تو فکر می_کردم
i did it|انجامش دادم
i did not do it|من این کارو نکردم
i did not know that|نمی_دونستم
i did my best|تمام تلاشمو کردم
i found it|پیداش کردم
i got it|فهمیدم
i got you|گرفتمت
i see|می_فهمم
i know|می_دونم
i know that|اینو می_دونم
i know what you did|می_دونم چیکار کردی
i know how you feel|می_دونم چه حسی داری
i knew it|می_دونستم
i told you so|بهت گفته بودم
i thought so|فکر می_کردم همین طوره
i just want to say thank you|فقط می_خوام ازت تشکر کنم
you are the best|تو بهترینی
you are amazing|تو فوق_العاده_ای
you are crazy|تو دیوونه_ای
you are lying|داری دروغ می_گی
you are mine|تو مال منی
you are safe now|حالا در امانی
you are not alone|تو تنها نیستی
you are not alone in this|تو تو این ماجرا تنها نیستی
you are late|دیر کردی
you are fired|اخراجی
you are under arrest|شما بازداشتید
you are my friend|تو دوست منی
you are strong|تو قوی هستی
you are weak|تو ضعیفی
you are too slow|خیلی کندی
you are too late|خیلی دیر اومدی
you did well|خوب کار کردی
you did great|عالی بود
you did it|تونستی
you have changed|عوض شدی
you have to believe me|باید باورم کنی
you have no right|حقی نداری
you have my word|قول می_دم
you know what|می_دونی چیه؟
you do not understand|تو نمی_فهمی
you do not know anything|تو هیچی نمی_دونی
you can not run away|نمی_تونی فرار کنی
you can not hide|نمی_تونی قایم بشی
you can do it|می_تونی از پسش بربیای
you can count on me|می_تونی رو من حساب کنی
you should not have come|نباید می_اومدی
you should rest|باید استراحت کنی
you must be tired|حتماً خسته_ای
you must leave|باید بری
you will pay for this|تقاصشو پس می_دی
you will regret this|پشیمون می_شی
you will see|می_بینی
you will be fine|خوب می_شی
you never listen|تو هیچ_وقت گوش نمی_دی
you always do this|تو همیشه همین کارو می_کنی
you look tired|خسته به نظر میای
you look beautiful|زیبا شدی
you look great|عالی به نظر می_رسی
you look pale|رنگت پریده
you look different|فرق کردی
you remind me of someone|منو یاد یه نفر می_ندازی
let us go|بریم
let us start|شروع کنیم
let us do this|بیا این کارو بکنیم
let us eat|بیا غذا بخوریم
let us talk|بیا حرف بزنیم
let us get out of here|بیا از اینجا بریم
let me go|ولم کن
let me see|بذار ببینم
let me think|بذار فکر کنم
let me explain|بذار توضیح بدم
let me help you|بذار کمکت کنم
let me out|بذار برم بیرون
let me in|بذار بیام تو
let me handle this|بذار من این کارو انجام بدم
leave me alone|تنهام بذار
leave it to me|بسپرش به من
leave him alone|ولش کن
do not touch me|بهم دست نزن
do not touch it|بهش دست نزن
do not move|تکون نخور
do not run|فرار نکن
do not go|نرو
do not leave me|ترکم نکن
do not worry|نگران نباش
do not be afraid|نترس
do not be silly|بچه بازی در نیار
do not cry|گریه نکن
do not lie to me|بهم دروغ نگو
do not look at me|بهم نگاه نکن
do not say that|اینو نگو
do not say anything|چیزی نگو
do not give up|تسلیم نشو
do not do that|این کارو نکن
do not do anything stupid|کار احمقانه نکن
do not push yourself|به خودت فشار نیار
do not underestimate me|دست کم نگیرم
do not be late|دیر نکن
do not forget|فراموش نکن
do not make me laugh|نخندون منو
do not you dare|جرئت نکن
do not bother me|مزاحمم نشو
do not speak to me|باهام حرف نزن
do not blame yourself|خودتو سرزنش نکن
do not panic|هول نکن
do not get me wrong|بد برداشت نکن
do not mind me|به من توجه نکن
get out|برو بیرون
get out of here|برو از اینجا
get out of my way|برو کنار
get away from him|ازش دور شو
get down|بخواب رو زمین
get up|بلند شو
get ready|آماده شو
get back here|برگرد اینجا
get lost|گمشو
get a grip|خودتو جمع کن
get some rest|یکم استراحت کن
come here|بیا اینجا
come in|بیا تو
come on|بیا دیگه
come with me|با من بیا
come back|برگرد
come closer|نزدیک_تر بیا
come out|بیا بیرون
go away|برو
go back|برگرد
go ahead|بفرما
go home|برو خونه
go to sleep|برو بخواب
go and see|برو ببین
follow me|دنبالم بیا
wait for me|منتظرم باش
wait here|اینجا صبر کن
wait outside|بیرون منتظر بمون
look out|مواظب باش
look at me|به من نگاه کن
look at this|به این نگاه کن
look behind you|پشت سرتو نگاه کن
listen to me|به من گوش بده
listen carefully|با دقت گوش کن
watch out|مواظب باش
watch your step|مراقب قدم‌هات باش
watch your mouth|مواظب حرف زدنت باش
behind you|پشت سرته
be careful|مواظب باش
be quiet|ساکت باش
be serious|جدی باش
be brave|شجاع باش
be strong|قوی باش
be patient|صبور باش
be honest|صادق باش
be right back|الان برمی_گردم
be good|خوب باش
calm down|آروم باش
wake up|بیدار شو
hurry up|عجله کن
speed up|سریع_تر
slow down|آروم_تر
shut up|خفه شو
stand up|بلند شو
sit down|بشین
stop it|بس کن
stop right there|همون جا وایسا
stop crying|گریه نکن
stop lying|دروغ نگو
stop talking|حرف نزن
stop moving|تکون نخور
stay here|اینجا بمون
stay with me|پیشم بمون
stay away from me|ازم دور بمون
stay calm|آروم بمون
stay alive|زنده بمون
stay out of this|دخالت نکن
take it easy|راحت باش
take a seat|بشین
take a look|یه نگاه بنداز
take a break|یه استراحت بکن
take a deep breath|یه نفس عمیق بکش
take this|اینو بگیر
take me with you|منم با خودت ببر
take your time|عجله نکن
try again|دوباره امتحان کن
try it|امتحانش کن
try harder|بیشتر تلاش کن
tell me|بهم بگو
tell me the truth|حقیقتو بهم بگو
tell me everything|همه چیزو بهم بگو
tell me why|بگو چرا
tell him|بهش بگو
tell her|بهش بگو
tell them|بهشون بگو
give me a break|بیخیال شو
give me a hand|یه کمک کن
give me a second|یه لحظه بهم وقت بده
give me that|اونو بده بهم
give it to me|بده بهم
give up|تسلیم شو
give it a try|یه امتحان بکن
give him a chance|بهش یه فرصت بده
show me|نشونم بده
show yourself|خودتو نشون بده
help me|کمکم کن
help|کمک
save me|نجاتم بده
save yourself|خودتو نجات بده
trust me|بهم اعتماد کن
believe me|باور کن
forgive me|ببخشم
remember me|منو یادت باشه
promise me|بهم قول بده
call me|بهم زنگ بزن
call the police|به پلیس زنگ بزن
call an ambulance|آمبولانس خبر کن
call for help|کمک بخواه
open the door|در رو باز کن
close the door|در رو ببند
turn it off|خاموشش کن
turn it on|روشنش کن
turn around|برگرد
turn left|به چپ بپیچ
turn right|به راست بپیچ
pick it up|برش دار
put it down|بذارش زمین
put your hands up|دست‌هاتو ببر بالا
put that away|اونو بذار کنار
let go|ولش کن
let it go|بیخیالش شو
let me know|بهم خبر بده
make up your mind|تصمیمتو بگیر
make yourself at home|خودتو راحت کن
keep going|ادامه بده
keep quiet|ساکت بمون
keep it secret|مخفی نگهش دار
keep your eyes open|چشماتو باز نگه دار
keep away|دور بمون
keep up the good work|همین طور ادامه بده
pull yourself together|خودتو جمع کن
mind your own business|به تو چه
none of your business|به تو ربطی نداره
it is none of your business|به تو ربطی نداره
it is too late|خیلی دیر شده
it is too early|خیلی زوده
it is too dangerous|خیلی خطرناکه
it is too expensive|خیلی گرونه
it is too much|زیادیه
it is too hot|خیلی داغه
it is too cold|خیلی سرده
it is too loud|خیلی بلنده
it is too heavy|خیلی سنگینه
it is impossible|غیرممکنه
it is possible|ممکنه
it is not possible|ممکن نیست
it is not impossible|غیرممکن نیست
it is a trap|این یه تله_ست
it is a secret|این یه رازه
it is a surprise|این یه سورپرایزه
it is a promise|این یه قوله
it is a deal|قبوله
it is true|درسته
it is not true|درست نیست
it is not what you think|اون چیزی که فکر می_کنی نیست
it is not fair|این منصفانه نیست
it is not funny|خنده_دار نیست
it is not over yet|هنوز تموم نشده
it is not easy|آسون نیست
it is not safe here|اینجا امن نیست
it is not my fault|تقصیر من نیست
it is not worth it|ارزشش رو نداره
it is worth it|می_ارزه
it is up to you|بسته به خودته
it is my turn|نوبت منه
it is your turn|نوبت توئه
it is time to go|وقت رفتنه
it is time|وقتشه
it is getting dark|داره هوا تاریک می_شه
it is getting late|داره دیر می_شه
it is a long story|داستانش طولانیه
it is a long way|راهش دوره
it is a good idea|ایده_ی خوبیه
it is a bad idea|ایده_ی بدیه
it is a bad sign|نشانه_ی بدیه
it is a good sign|نشانه_ی خوبیه
it is a miracle|معجزه_ست
it is a disaster|فاجعه_ست
it is a pity|حیفه
it is a shame|حیف شد
it is a joke|شوخیه
it is my job|وظیفه_ی منه
it is my duty|وظیفه_ی منه
it is my fault|تقصیر منه
it is your fault|تقصیر توئه
it is all over|همه_چی تموم شد
it is all right|اشکالی نداره
it is all good|همه_چی خوبه
it is nothing|چیزی نیست
it is nothing serious|چیز جدی_ای نیست
it is none of my business|به من ربطی نداره
it is finally over|بالاخره تموم شد
it is about time|وقتشه دیگه
it is almost time|تقریباً وقتشه
it is going to be fine|درست می_شه
it is going to rain|بارون میاد
it is raining|داره بارون میاد
it is snowing|داره برف میاد
it is sunny|هوا آفتابیه
it is windy|باد میاد
it is freezing|هوا یخ_کرده
it is beautiful|قشنگه
it is delicious|خوشمزه_ست
it is heavy|سنگینه
it is easy|آسونه
it is hard|سخته
it is difficult|سخته
it is dangerous|خطرناکه
it is expensive|گرونه
it is cheap|ارزونه
it is broken|خراب شده
it is mine|مال منه
it is yours|مال توئه
it is his|مال اونه
it is hers|مال اونه
it is ours|مال ماست
it is open|بازه
it is closed|بسته_ست
it is full|پره
it is empty|خالیه
it is free|مجانیه
it is ready|آماده_ست
it is done|تموم شد
it is dead|مرده
it is alive|زنده_ست
it is real|واقعیه
it is fake|جعلیه
it is here|اینجاست
it is there|اونجاست
it is him|خودشه
it is her|خودشه
it is me|منم
it is you|خودتی
there is no time|وقت نداریم
there is no way|هیچ راهی نیست
there is no hope|هیچ امیدی نیست
there is nothing to be afraid of|چیزی برای ترسیدن نیست
there is nothing we can do|هیچ کاری از دستمون برنمیاد
there is nobody here|اینجا هیچ_کس نیست
there is someone behind you|یه نفر پشت سرته
there is a problem|یه مشکل هست
there is another way|راه دیگه_ای هست
there is still hope|هنوز امید هست
there is still time|هنوز وقت هست
there must be a way|حتماً راهی هست
there you go|بفرما
here you go|بفرما
here we go|بریم
here we go again|دوباره شروع شد
here comes trouble|دردسر اومد
this way|از این طرف
that way|از اون طرف
this is it|همینه
this is the end|این پایانه
this is the end for you|این پایان توئه
this is not over|این هنوز تموم نشده
this is my home|اینجا خونه_ی منه
this is my place|اینجا جای منه
this is my life|این زندگی منه
this is a mistake|این یه اشتباهه
this is impossible|این غیرممکنه
this is serious|این جدیه
this is important|این مهمه
this is for you|این برای توئه
this is not a game|این بازی نیست
this is not a joke|این شوخی نیست
this is not funny|این خنده_دار نیست
this is not happening|این داره اتفاق نمی_افته
this is just the beginning|این تازه اول کاره
this is all because of you|همش به خاطر توئه
this can not be happening|نمی_تونه واقعی باشه
this can not be true|نمی_تونه درست باشه
that is all|همین
that is enough|کافیه
that is it|همین
that is right|درسته
that is wrong|اشتباهه
that is not fair|این منصفانه نیست
that is not true|این درست نیست
that is not what i meant|منظورم این نبود
that is not possible|این ممکن نیست
that is a lie|این دروغه
that is a good question|سؤال خوبیه
that is a secret|اون یه رازه
that is my line|این حرف منه
that is my job|اون کار منه
that is none of your business|اون به تو ربطی نداره
that was close|نزدیک بود
that was a mistake|اشتباه بود
that was fun|خوش گذشت
that was amazing|فوق_العاده بود
that will not work|این جواب نمی_ده
that would be great|عالی می_شه
that would be nice|خوب می_شه
thank god|خدا رو شکر
thank goodness|خدا رو شکر
oh my god|وای خدای من
oh my goodness|وای خدای من
oh no|وای نه
oh yes|آره
oh come on|وای بیا دیگه
oh well|خب دیگه
oh dear|وای
good grief|وای خدا
holy shit|وای لعنتی
for god sake|تو رو خدا
for heaven sake|تو رو خدا
for real|جدی
for sure|حتماً
for now|فعلاً
for good|برای همیشه
for the last time|برای آخرین بار
for the first time|برای اولین بار
at last|بالاخره
at least|حداقل
at once|همین الان
at all|اصلاً
at the moment|در حال حاضر
at the same time|همزمان
at this point|تا اینجا
in a hurry|عجله دارم
in time|به موقع
in the end|در نهایت
in my opinion|به نظر من
in that case|در اون صورت
in any case|در هر صورت
on purpose|عمداً
on time|سر وقت
on my own|تنهایی
on the way|تو راه
on the other hand|از طرف دیگه
out of order|خراب
out of the question|غیرممکنه
out of control|از کنترل خارج
out of luck|بدشانس
out of my mind|عقلمو از دست دادم
all right|باشه
all of them|همه_شون
all of us|همه_ی ما
all day|تمام روز
all night|تمام شب
all the time|همیشه
all alone|کاملاً تنها
all together|همه با هم
after you|شما اول
ladies first|اول خانم‌ها
bottoms up|به سلامتی
cheers|به سلامتی
good morning|صبح بخیر
good afternoon|ظهر بخیر
good evening|عصر بخیر
good night|شب بخیر
sweet dreams|خواب‌های خوب ببینی
welcome back|خوش برگشتی
welcome home|خوش اومدی خونه
welcome aboard|خوش اومدی
happy birthday|تولدت مبارک
happy new year|سال نو مبارک
merry christmas|کریسمس مبارک
happy holidays|تعطیلات خوبی داشته باشی
have a nice day|روز خوبی داشته باشی
have a good trip|سفر خوبی داشته باشی
have a good time|خوش بگذره
have fun|خوش بگذره
enjoy your meal|نوش جان
enjoy yourself|خوش بگذره
get well soon|زود خوب شی
break a leg|موفق باشی
piece of cake|مثل آب خوردن
a piece of cake|مثل آب خوردنه
it is a piece of cake|مثل آب خوردنه
under the weather|کسل
once in a blue moon|خیلی به_ندرت
the ball is in your court|نوبت توئه
spill the beans|رازو لو بده
cost an arm and a leg|کلی خرج برمی_داره
it costs an arm and a leg|کلی خرج برمی_داره
let the cat out of the bag|رازو لو داد
kill two birds with one stone|با یه تیر دو نشون زدن
better late than never|دیر بهتر از هرگزه
actions speak louder than words|عمل از حرف مهم_تره
easier said than done|گفتنش آسون_تر از انجام دادنشه
time is money|وقت طلاست
no pain no gain|بی_رنج گنج میسر نمی_شه
practice makes perfect|تمرین استاد می_سازه
every cloud has a silver lining|هر ابری یه روشنی داره
when in rome do as the romans do|با هر کی بودی هم_رنگش باش
do not judge a book by its cover|از روی ظاهر قضاوت نکن
do not count your chickens before they hatch|جوجه رو آخر پاییز می_شمارن
do not cry over spilled milk|برای گذشته اشک نریز
you can not have your cake and eat it too|نمی_شه هم خورد و هم داشت
the sky is the limit|آسمون حد و مرزه
a blessing in disguise|نعمتی در لباس مبدل
beat around the bush|دور و بر موضوع چرخیدن
do not beat around the bush|حاشیه نرو
cut to the chase|بریم سر اصل مطلب
hit the nail on the head|درست گفتی
hit the road|راه بیفتیم
it takes two to tango|دست تنها صدا نداره
speak of the devil|سگ صاحبشو شناخت
the last straw|نقطه_ی پایان
the elephant in the room|مسئله_ای که همه ازش طفره می_رن
the best of both worlds|هر دو دنیا
the early bird catches the worm|سحرخیز باش تا کامروا شوی
once bitten twice shy|مار گزیده از ریسمون سیاه و سفید می_ترسه
birds of a feather flock together|کبوتر با کبوتر باز با باز
a friend in need is a friend indeed|دوست آن است که گیرد دست دوست در پریشان حالی و درماندگی
a penny for your thoughts|به چی فکر می_کنی؟
add insult to injury|نمک روی زخم پاشیدن
bite the bullet|دندون روی جگر گذاشتن
break the ice|یخ رو شکوندن
burn the midnight oil|تا دیروقت کار کردن
call it a day|بسه برای امروز
cry wolf|دروغ_ی هوار کشیدن
face the music|عواقبشو پذیرفتن
get cold feet|پشیمون شدن
go the extra mile|بیشتر از انتظار تلاش کردن
hang in there|دووم بیار
in the same boat|هم_سرنوشت
jump the gun|عجله کردن
keep an eye on|حواست بهش باشه
keep it up|ادامه بده
last but not least|آخر ولی نه کم_اهمیت_تر
let sleeping dogs lie|گربه رو دم حجله نکش
make a long story short|کوتاه بگم
miss the boat|فرصتو از دست دادن
on the fence|مردد
play it by ear|بسته به شرایط
pull someone leg|سر به سر کسی گذاشتن
rain or shine|در هر شرایطی
read between the lines|بین خطوط رو بخون
see eye to eye|هم_نظر بودن
sit tight|آروم بشین
sleep on it|بذار فکر کنم
so far so good|تا اینجا خوبه
take it with a grain of salt|زیاد جدی نگیرش
the whole nine yards|همه_چی
throw in the towel|تسلیم شدن
to make matters worse|بدتر از اون
turn a blind eye|چشم بستن روی
up in the air|نامعلوم
walk on eggshells|با احتیاط رفتار کردن
water under the bridge|گذشته گذشته
wrap it up|جمعش کن
you are on fire|داری می_درخشی
you took the words right out of my mouth|حرف دلمو زدی
i am all ears|گوش می_دم
i am on it|دارم رو این کار می_کنم
i am in trouble|تو دردسر افتادم
i am in love|عاشقم
i am in a hurry|عجله دارم
i am in a bad mood|اوضاع روحیم خرابه
i am out of here|من رفتم
i am fed up|حالم بهم می_خوره
i am fed up with this|از این وضع خسته شدم
i am sick of it|ازش خسته شدم
i am dying to know|دارم می_میرم تا بدونم
i am not in the mood|حوصله ندارم
i am not feeling well|حالم خوب نیست
i am not myself today|امروز حال خودمو ندارم
i am not that stupid|اون قدرا هم احمق نیستم
i am not gonna lie|دروغ نگم
i am not going anywhere|هیچ جا نمی_رم
i am not done yet|هنوز کارم تموم نشده
i am so proud|خیلی افتخار می_کنم
i am so happy|خیلی خوشحالم
i am so tired|خیلی خسته_م
i am so hungry|خیلی گشنمه
i am so excited|خیلی هیجان_زده_ام
i am so embarrassed|خیلی خجالت می_کشم
i am so glad|خیلی خوشحالم
i am really sorry|واقعاً متأسفم
i am just|فقط دارم
i am just looking|فقط دارم نگاه می_کنم
i am just asking|فقط می_پرسم
i am just saying|فقط دارم می_گم
i am just a student|من فقط یه دانش_آموزم
i am just an ordinary person|من فقط یه آدم معمولیم
i am going to be late|دیرم می_شه
i am going to be sick|دارم حالم بد می_شه
i am going to die|دارم می_میرم
i am going to win|من می_برم
i am going to kill him|می_کشمش
i am going to find out|می_فهمم
i am going to stop you|جلوتو می_گیرم
i am going to make it|از پسش برمیام
i am gonna make it|از پسش برمیام
i am gonna be fine|خوب می_شم
i am gonna be late|دیرم می_شه
i am gonna miss you|دلم برات تنگ می_شه
i am so sorry about that|بابتش خیلی متأسفم
good job|آفرین
nice job|کارت عالی بود
well done|آفرین
nice work|دمت گرم
nice try|تلاش خوبی بود
nice to see you|از دیدنت خوشحالم
nice one|عالی بود
nice shot|شلیک خوبی بود
nice catch|خوب گرفتی
good to see you|از دیدنت خوشحالم
good to know|خوب شد فهمیدم
good for you|خوش به حالت
good point|نکته_ی خوبیه
good idea|ایده_ی خوبیه
good boy|پسر خوب
good girl|دختر خوب
good game|بازی خوبی بود
great job|کارت عالی بود
great minds think alike|دل به دل راه داره
too bad|حیف شد
too late|دیره
too soon|زوده
too easy|خیلی آسونه
so what|که چی؟
so be it|پس همین
so far|تا حالا
so long|خداحافظ
so sorry|خیلی متأسفم
not bad|بد نیست
not yet|هنوز نه
not now|حالا نه
not really|راستش نه
not exactly|دقیقاً نه
not at all|اصلاً
not again|دوباره نه
not me|من نه
not you|تو نه
not today|امروز نه
not funny|خنده_دار نیست
not sure|مطمئن نیستم
nothing special|چیز خاصی نیست
nothing happened|هیچی نشد
nothing at all|هیچی
nothing to worry about|جای نگرانی نیست
no one|هیچ_کس
no one knows|هیچ_کس نمی_دونه
no one is perfect|هیچ_کس کامل نیست
nobody knows|هیچ_کس نمی_دونه
nobody is perfect|هیچ_کس کامل نیست
nobody cares|به کسی مربوط نیست
everyone is here|همه اینجان
everyone knows|همه می_دونن
everyone is waiting|همه منتظرن
everything is fine|همه_چی خوبه
everything will be fine|همه_چی درست می_شه
everything will be okay|همه_چی درست می_شه
everything is going to be okay|همه_چی درست می_شه
everything is under control|همه_چی تحت کنترله
everything is ready|همه_چی آماده_ست
everything has changed|همه_چی عوض شده
everything is my fault|همه_چی تقصیر منه
something is wrong|یه چیزی درست نیست
something is not right|یه چیزی درست نیست
something happened|یه اتفاقی افتاد
something is coming|یه چیزی داره میاد
somebody help|یکی کمک کنه
someone help me|یکی کمکم کنه
someone is coming|یکی داره میاد
someone is watching us|یکی داره ما رو می_پاد
anything else|چیز دیگه_ای هم هست؟
anything you say|هر چی تو بگی
anyone there|کسی اونجاست؟
anytime|هر وقت
anyway|به هر حال
anyways|به هر حال
whatever|هر چی
whatever you say|هر چی تو بگی
whatever you want|هر چی تو بخوای
whatever it takes|به هر قیمتی
whenever you are ready|هر وقت آماده بودی
wherever you go|هر جا بری
whoever you are|هر کی که هستی
as you wish|هر طور که مایلی
as you like|هر طور دوست داری
as usual|مثل همیشه
as always|مثل همیشه
as far as i know|تا جایی که می_دونم
as long as you are here|تا وقتی که اینجایی
as expected|همون طور که انتظار می_رفت
as planned|طبق نقشه
just in case|محض احتیاط
just in time|درست به موقع
just like that|همین طوری
just let it go|بیخیالش شو
just do it|فقط انجامش بده
just a little|فقط یه کم
just a bit|فقط یه کم
just wait|فقط صبر کن
just relax|فقط آروم باش
just try|فقط امتحان کن
just you wait|بذار ببینم چی می_شه
just for fun|فقط برای تفریح
just between us|بین خودمون بمونه
once more|یه بار دیگه
one more time|یه بار دیگه
one more thing|یه چیز دیگه
one last thing|یه چیز آخر
one at a time|یکی یکی
one by one|یکی یکی
once and for all|یه بار برای همیشه
once upon a time|روزی روزگاری
twice as much|دو برابر
all of a sudden|ناگهان
all at once|یهو
all in all|روی هم رفته
in a way|به یه شکلی
in a minute|الان
in a while|یه ذره دیگه
in no time|خیلی زود
in front of me|جلوی من
in front of you|جلوی تو
in the middle of nowhere|وسط ناکجاآباد
in the middle of the night|وسط شب
in the meantime|در این فاصله
in the future|در آینده
in the past|در گذشته
in this case|در این صورت
in short|خلاصه
in other words|به عبارت دیگه
in return|در عوض
in advance|از قبل
in general|به طور کلی
in person|حضوری
in secret|مخفیانه
in vain|بی_فایده
in peace|در صلح
in pain|درد دارم
in danger|در خطره
in love|عاشق
in trouble|تو دردسر
in charge|مسئول
on fire|آتیش گرفته
on sale|تخفیف خورده
on duty|سر کار
on vacation|تعطیلات
on the phone|پای تلفن
on the table|روی میز
on the floor|روی زمین
on the left|سمت چپ
on the right|سمت راست
on your left|سمت چپت
on your right|سمت راستت
on your mark|آماده
off the record|غیر رسمی
off limits|ورود ممنوع
no entry|ورود ممنوع
no smoking|سیگار کشیدن ممنوع
no parking|توقف ممنوع
no trespassing|ورود غیرمجاز ممنوع
keep out|وارد نشوید
danger|خطر
warning|هشدار
caution|احتیاط
emergency|اضطراری
fire exit|خروج اضطراری
exit|خروج
entrance|ورودی
push|هل بده
pull|بکش
open|باز
closed|بسته
free|رایگان
sale|حراج
sold out|فروخته شد
out of stock|موجود نیست
coming soon|به زودی
under construction|در دست ساخت
wet floor|زمین خیس است
staff only|فقط کارکنان
no pets|ورود حیوانات ممنوع
restroom|دستشویی
toilet|توالت
where is the toilet|دستشویی کجاست؟
where is the bathroom|دستشویی کجاست؟
where is the station|ایستگاه کجاست؟
where is the airport|فرودگاه کجاست؟
where is the hospital|بیمارستان کجاست؟
where is the nearest bank|نزدیک_ترین بانک کجاست؟
where can i buy this|از کجا می_تونم اینو بخرم؟
can i have the bill|می_تونم صورتحساب رو داشته باشم؟
can i have the menu|می_تونم منو رو داشته باشم؟
can i pay by card|می_تونم با کارت پرداخت کنم؟
can i try this on|می_تونم این رو پرو کنم؟
can you speak english|انگلیسی حرف می_زنی؟
do you speak english|انگلیسی حرف می_زنید؟
do you understand|می_فهمی؟
do you remember me|منو یادته؟
do you remember|یادته؟
do you know him|می_شناسیش؟
do you know her|می_شناسیش؟
do you know what this is|می_دونی این چیه؟
do you know where he is|می_دونی کجاست؟
do you have a minute|یه لحظه وقت داری؟
do you have any questions|سؤالی داری؟
do you have any idea|هیچ ایده_ای داری؟
do you want to come with me|می_خوای با من بیای؟
do you want some water|آب می_خوای؟
do you want to talk about it|می_خوای درباره_ش حرف بزنی؟
do you love me|دوستم داری؟
do you trust me|بهم اعتماد داری؟
do you like it|خوشت میاد؟
do you mind|ایرادی داره؟
do you mind if i sit here|ایرادی داره اینجا بشینم؟
do you need anything|چیزی لازم داری؟
do you need a ride|می_خوای برسونمت؟
did you hear that|اینو شنیدی؟
did you see that|اینو دیدی؟
did you sleep well|خوب خوابیدی؟
did you eat|غذا خوردی؟
did you miss me|دلت برام تنگ شد؟
did you do this|تو این کارو کردی؟
did anyone see you|کسی دیدت؟
did something happen|اتفاقی افتاد؟
are you okay|حالت خوبه؟
are you alright|حالت خوبه؟
are you hurt|آسیب دیدی؟
are you crazy|دیوونه شدی؟
are you sure|مطمئنی؟
are you ready|آماده_ای؟
are you hungry|گشنته؟
are you free|وقت داری؟
are you busy|سرت شلوغه؟
are you angry|عصبانی هستی؟
are you with me|با منی؟
are you coming|میای؟
are you leaving|داری می_ری؟
are you kidding me|داری شوخی می_کنی؟
are you listening|گوش می_دی؟
are you afraid|می_ترسی؟
are you scared|می_ترسی؟
are you lost|گم شدی؟
are you alone|تنهایی؟
are you married|متأهلی؟
are you serious about this|تو این مورد جدی هستی؟
are we there yet|هنوز نرسیدیم؟
are we friends|ما دوستیم؟
are we done|تموم شد؟
are they coming|دارن میان؟
is that you|خودتی؟
is that all|همینه؟
is that true|درسته؟
is that possible|ممکنه؟
is everything okay|همه_چی خوبه؟
is everything all right|همه_چی مرتبه؟
is anyone there|کسی اونجاست؟
is it true|درسته؟
is it over|تموم شد؟
is it safe|امنه؟
is it far|دوره؟
is it time|وقتشه؟
is it you|خودتی؟
is he dead|مرده؟
is she dead|مرده؟
is he alive|زنده_ست؟
is she alive|زنده_ست؟
is he okay|حالش خوبه؟
is she okay|حالش خوبه؟
is this seat taken|این صندلی پره؟
is this yours|این مال توئه؟
is this real|این واقعیه؟
is this a dream|این یه خوابه؟
is this a joke|این یه شوخیه؟
is there anything i can do|کاری هست که بتونم بکنم؟
is there a problem|مشکلی هست؟
is there another way|راه دیگه_ای هست؟
can you hear me|صدامو می_شنوی؟
can you see me|می_تونی منو ببینی؟
can you hear that|اینو می_شنوی؟
can you believe it|باورت می_شه؟
can you wait|می_تونی صبر کنی؟
can you move|می_تونی تکون بخوری؟
can you stand|می_تونی بایستی؟
can you walk|می_تونی راه بری؟
can you swim|شنا بلدی؟
can you drive|رانندگی بلدی؟
can you keep a secret|می_تونی راز نگه داری؟
can i ask you something|می_تونم یه چیزی ازت بپرسم؟
can i ask you a question|می_تونم یه سؤال بپرسم؟
can i come with you|می_تونم باهات بیام؟
can i see you tomorrow|می_تونم فردا ببینمت؟
can i borrow this|می_تونم اینو قرض بگیرم؟
can i go now|الان می_تونم برم؟
can we talk|می_تونیم حرف بزنیم؟
can we go now|می_تونیم الان بریم؟
can we start|می_تونیم شروع کنیم؟
could be worse|می_تونست بدتر باشه
could you please|می_شه لطفاً
would you like some tea|چایی می_خوای؟
would you like to dance|می_خوای برقصیم؟
would you like to come|می_خوای بیای؟
would you mind|ایرادی داره؟
would you please|لطفاً
should we go|بریم؟
should i stay|بمونم؟
should i go|برم؟
shall we|بریم؟
shall we dance|برقصیم؟
will you marry me|با من ازدواج می_کنی؟
will you be okay|حالت خوب می_شه؟
will you help me|کمکم می_کنی؟
will you stay|می_مونی؟
will it hurt|درد داره؟
will he be okay|حالش خوب می_شه؟
we are friends|ما دوستیم
we are family|ما خانواده_ایم
we are a team|ما یه تیمیم
we are not alone|ما تنها نیستیم
we are in this together|ما با هم تو این کاریم
we are almost there|تقریباً رسیدیم
we are here|رسیدیم
we are late|دیرمون شده
we are lost|گم شدیم
we are safe|در امانیم
we are screwed|گیر افتادیم
we are done here|اینجا کارمون تموم شده
we are out of time|وقت نداریم
we are running out of time|داره وقتمون تموم می_شه
we are surrounded|محاصره شدیم
we are being followed|دارن تعقیبمون می_کنن
we are under attack|مورد حمله قرار گرفتیم
we are leaving|داریم می_ریم
we are ready|آماده_ایم
we have a problem|یه مشکل داریم
we have no time|وقت نداریم
we have no choice|چاره_ای نداریم
we have to go|باید بریم
we have to run|باید فرار کنیم
we have to hurry|باید عجله کنیم
we have to stop him|باید جلوشو بگیریم
we have to fight|باید بجنگیم
we have to do something|باید یه کاری بکنیم
we have to talk|باید حرف بزنیم
we have to leave now|باید همین الان بریم
we have won|بردیم
we won|بردیم
we lost|باختیم
we made it|موفق شدیم
we did it|انجامش دادیم
we can do this|می_تونیم از پسش بربیایم
we can not lose|نمی_تونیم ببازیم
we can not stay here|نمی_تونیم اینجا بمونیم
we will win|می_بریم
we will make it|موفق می_شیم
we will find a way|یه راهی پیدا می_کنیم
we will meet again|دوباره همدیگه رو می_بینیم
we will see|می_بینیم
we should go|باید بریم
we need to talk|باید حرف بزنیم
we need to go|باید بریم
we need help|کمک می_خوایم
we need more time|وقت بیشتری می_خوایم
we need a plan|یه نقشه می_خوایم
they are coming|دارن میان
they are here|اومدن
they are gone|رفتن
they are watching us|دارن ما رو می_پان
they are lying|دارن دروغ می_گن
they are everywhere|همه جا هستن
they are right behind us|درست پشت سرمونن
they are after me|دنبالمن
they are after us|دنبال ما هستن
they will find us|پیدامون می_کنن
they know|می_دونن
they did it|اونا این کارو کردن
he is gone|رفته
he is back|برگشته
he is here|اینجاست
he is dead|مرده
he is alive|زنده_ست
he is lying|داره دروغ می_گه
he is right|حق با اونه
he is wrong|اشتباه می_کنه
he is a good man|مرد خوبیه
he is a bad guy|آدم بدیه
he is my friend|دوست منه
he is my brother|برادر منه
he is my father|پدر منه
he is not here|اینجا نیست
he is not coming|نمیاد
he is not dead|نمرده
he is just a kid|فقط یه بچه_ست
he is strong|قویه
he is weak|ضعیفه
he is too strong|خیلی قویه
he is faster than me|از من سریع_تره
he is behind you|پشت سرته
he is the one|اونه
he is the one i love|اونی که دوستش دارم
he is the enemy|دشمنه
he is mine|مال منه
he is crazy|دیوونه_ست
he is a monster|یه هیولاست
she is gone|رفته
she is back|برگشته
she is here|اینجاست
she is dead|مرده
she is alive|زنده_ست
she is lying|داره دروغ می_گه
she is right|حق با اونه
she is beautiful|زیباست
she is a good girl|دختر خوبیه
she is my friend|دوست منه
she is my sister|خواهر منه
she is my mother|مادر منه
she is my girlfriend|دوست دخترمه
she is not here|اینجا نیست
she is the one|اونه
she is mine|مال منه
she is strong|قویه
she is kind|مهربونه
she is crying|داره گریه می_کنه
she is sleeping|خوابیده
she is waiting for you|منتظرته
she loves you|دوستت داره
he loves you|دوستت داره
they love you|دوستت دارن
i love her|دوستش دارم
i love him|دوستش دارم
i love it|عاشقشم
i love this place|این جا رو دوست دارم
i like it|خوشم میاد
i like this|از این خوشم میاد
i do not like it|خوشم نمیاد
i do not like this|از این خوشم نمیاد
i do not want to|نمی_خوام
i do not want to die|نمی_خوام بمیرم
i do not want to talk about it|نمی_خوام درباره_ش حرف بزنم
i do not want to go|نمی_خوام برم
i do not want to see you|نمی_خوام ببینمت
i do not want this|اینو نمی_خوام
i do not have time|وقت ندارم
i do not have any money|پول ندارم
i do not have a choice|چاره_ای ندارم
i do not have to explain|لازم نیست توضیح بدم
i do not need your help|به کمکت نیاز ندارم
i do not need anything|چیزی لازم ندارم
i do not feel well|حالم خوب نیست
i do not feel safe|احساس امنیت نمی_کنم
i do not deserve this|لیاقت این رو ندارم
i do not deserve you|لایق تو نیستم
i do not hate you|ازت متنفر نیستم
i do not blame you|سرزنشت نمی_کنم
i do not mind|ایرادی نداره
i do not mean that|منظورم این نیست
i do not know what to do|نمی_دونم چیکار کنم
i do not know what to say|نمی_دونم چی بگم
i do not know how|نمی_دونم چطوری
i do not know why|نمی_دونم چرا
i do not know who you are|نمی_دونم تو کی هستی
i do not know anything|هیچی نمی_دونم
i do not know where he is|نمی_دونم کجاست
i do not remember anything|هیچی یادم نمیاد
i do not understand why|نمی_فهمم چرا
i do not get it|نمی_فهمم
i do not see it|نمی_بینمش
i do not think that is a good idea|فکر نمی_کنم ایده_ی خوبی باشه
i do not believe in ghosts|به روح اعتقاد ندارم
i do not believe in luck|به شانس اعتقاد ندارم
i did not know|نمی_دونستم
i did not do anything|من هیچ کاری نکردم
i did not want this|اینو نمی_خواستم
i did not see anything|هیچی ندیدم
i did not say that|من اینو نگفتم
i did not mean that|منظورم این نبود
i did not expect that|انتظارش رو نداشتم
i would never|هرگز
i would never do that|هرگز همچین کاری نمی_کنم
i would never hurt you|هرگز بهت آسیب نمی_زنم
i would die for you|برات می_میرم
i would do anything for you|هر کاری برات می_کنم
i would like some water|یه کم آب می_خوام
i would like to order|می_خوام سفارش بدم
i would like to go home|می_خوام برم خونه
i should have known|باید می_دونستم
i should go|باید برم
i should not have said that|نباید اینو می_گفتم
i must go|باید برم
i must be dreaming|حتماً دارم خواب می_بینم
i must be going crazy|حتماً دارم دیوونه می_شم
i must say|باید بگم
i might be wrong|شاید اشتباه کنم
i may be wrong|ممکنه اشتباه کنم
i need to know|باید بدونم
i need to go|باید برم
i need to talk to you|باید باهات حرف بزنم
i need some air|یه کم هوا می_خوام
i need some time|یه کم وقت می_خوام
i need some rest|یه کم استراحت می_خوام
i need a break|یه استراحت لازم دارم
i need a drink|یه نوشیدنی لازم دارم
i need to think|باید فکر کنم
i need to be alone|باید تنها باشم
i need to see him|باید ببینمش
i need to find her|باید پیداش کنم
i need answers|جواب می_خوام
i need more power|قدرت بیشتری می_خوام
i just need to|فقط باید
i just want to be with you|فقط می_خوام با تو باشم
i just want to go home|فقط می_خوام برم خونه
i just want to help|فقط می_خوام کمک کنم
i just wanted to say|فقط می_خواستم بگم
i just wanted to see you|فقط می_خواستم ببینمت
i just remembered|تازه یادم اومد
i just found out|تازه فهمیدم
i just saw him|همین الان دیدمش
i really need you|واقعاً بهت نیاز دارم
i really like you|واقعاً ازت خوشم میاد
i really do not know|واقعاً نمی_دونم
i really appreciate it|واقعاً قدردانم
i really mean it|واقعاً جدی می_گم
i truly believe|واقعاً باور دارم
i swear|قسم می_خورم
i swear to god|به خدا قسم
i promise|قول می_دم
i promise you|بهت قول می_دم
i give up|تسلیم شدم
i surrender|تسلیم می_شم
i quit|استعفا می_دم
i resign|استعفا می_دم
i refuse|قبول نمی_کنم
i accept|قبول می_کنم
i admit|اعتراف می_کنم
i confess|اعتراف می_کنم
i apologize|عذرخواهی می_کنم
i object|اعتراض دارم
i insist|اصرار دارم
i suggest|پیشنهاد می_کنم
i recommend|توصیه می_کنم
i warn you|بهت هشدار می_دم
i warned you|بهت هشدار دادم
i beg you|التماست می_کنم
i beg your pardon|ببخشید؟
i owe you one|یه چیزی بهت بدهکارم
i owe you my life|جونمو مدیونتم
i am in your debt|مدیونتم
i am yours|مال توام
i am here for you|اینجام تا کمکت کنم
i am here to help|اینجام تا کمک کنم
i am here to stay|اومدم که بمونم
i am here to win|اومدم تا ببرم
i am not here to fight|اینجا نیومدم که بجنگم
i am not your enemy|من دشمن تو نیستم
i am not a child|من بچه نیستم
i am not a monster|من هیولا نیستم
i am not weak|من ضعیف نیستم
i am not alone|من تنها نیستم
i am not kidding|شوخی نمی_کنم
i am not lying|دروغ نمی_گم
i am not going to let you|نمی_ذارم
i am not going to die|نمی_میرم
i am not letting you go|نمی_ذارم بری
i am not giving up|تسلیم نمی_شم
i am not leaving without you|بدون تو نمی_رم
i am not afraid of you|از تو نمی_ترسم
i am not afraid of death|از مرگ نمی_ترسم
i am not scared|نمی_ترسم
i am not gonna let you down|ناامیدت نمی_کنم
i am the strongest|من قوی_ترینم
i am the one who|من کسی هستم که
i am the one|منم
i am the king|من پادشاهم
i am your father|من پدرتم
i am your friend|من دوستتم
i am your brother|من برادرتم
i am your sister|من خواهرتم
i am yours forever|برای همیشه مال توام
i am a doctor|من دکترم
i am a student|من دانش_آموزم
i am a teacher|من معلمم
i am a fan|من طرفدارم
i am a human|من انسانم
i am a ghost|من روحم
i am a loser|من بازنده_ام
i am a nobody|من هیچ_کسم
i am from iran|من اهل ایرانم
i am from japan|من اهل ژاپنم
i am from america|من اهل آمریکام
i am twenty years old|بیست سالمه
i am hungry now|الان گشنمه
i am new here|اینجا تازه واردم
i am looking for|دنبال ... می_گردم
i am looking for you|دنبالت می_گردم
i am looking for a job|دنبال کار می_گردم
i am looking forward to it|بی_صبرانه منتظرشم
i am waiting|منتظرم
i am waiting for you|منتظرتم
i am working|دارم کار می_کنم
i am studying|دارم درس می_خونم
i am eating|دارم غذا می_خورم
i am sleeping|دارم می_خوابم
i am watching|دارم نگاه می_کنم
i am listening|دارم گوش می_دم
i am thinking|دارم فکر می_کنم
i am trying|دارم تلاش می_کنم
i am trying my best|دارم تمام تلاشمو می_کنم
i am trying to help|دارم سعی می_کنم کمک کنم
i am trying to sleep|دارم سعی می_کنم بخوابم
i am trying to remember|دارم سعی می_کنم یادم بیاد
i am doing my best|دارم تمام تلاشمو می_کنم
i am doing this for you|دارم اینو برای تو انجام می_دم
i am doing fine|حالم خوبه
i am doing it for you|دارم برای تو انجامش می_دم
i am telling you|دارم بهت می_گم
i am talking to you|دارم با تو حرف می_زنم
i am talking about|دارم درباره ... حرف می_زنم
i am asking you|دارم ازت می_پرسم
i am warning you|دارم بهت هشدار می_دم
i am begging you please|تو رو خدا التماست می_کنم
i am saying|دارم می_گم
i am sorry to hear that|متأسفم که اینو می_شنوم
i am sorry for your loss|برای از دست دادنت متأسفم
i am sorry about what happened|بابت اتفاقی که افتاد متأسفم
i am sorry to bother you|ببخشید مزاحمتون شدم
i am sorry to keep you waiting|ببخشید منتظر موندید
i am so sorry for what i did|بابت کاری که کردم خیلی متأسفم
i am afraid so|متأسفانه همین طوره
i am afraid not|متأسفانه نه
i am afraid i can not|متأسفانه نمی_تونم
i am afraid it is too late|می_ترسم خیلی دیر شده باشه
i am pretty sure|تقریباً مطمئنم
i am sure|مطمئنم
i am not sure|مطمئن نیستم
i am sure you will|مطمئنم که می_تونی
i am sure it is fine|مطمئنم مشکلی نیست
i am glad to hear that|خوشحالم که این رو می_شنوم
i am happy for you|برات خوشحالم
i am happy to see you|از دیدنت خوشحالم
i am happy here|اینجا خوشحالم
i am so lucky|خیلی خوش_شانسم
i am so unlucky|خیلی بدشانسم
i am so weak|خیلی ضعیفم
i am so confused|خیلی گیج شدم
i am so stupid|خیلی احمقم
i am so stressed|خیلی استرس دارم
i am so jealous|خیلی حسودیم می_شه
i am so in love with you|خیلی عاشقتم
i am so over it|دیگه ازش گذشتم
i am so done|دیگه تمومه
i am totally fine|کاملاً خوبم
i am totally lost|کاملاً گم شدم
i am completely sure|کاملاً مطمئنم
i am completely fine|کاملاً خوبم
i am absolutely fine|کاملاً خوبم
i am just fine|فقط خوبم
i am still here|هنوز اینجام
i am still alive|هنوز زنده_ام
i am still angry|هنوز عصبانی_ام
i am still waiting|هنوز منتظرم
i am still not ready|هنوز آماده نیستم
i am already here|قبلاً اینجا بودم
i am already late|الان دیرم شده
i am almost there|تقریباً رسیدم
i am almost done|تقریباً تموم شد
i am almost ready|تقریباً آماده_ام
i am also hungry|منم گشنمه
i am also sorry|منم متأسفم
i am always here for you|همیشه برات اینجام
i am always with you|همیشه با تو هستم
i am always watching|همیشه دارم نگاه می_کنم
i am always late|همیشه دیر می_رسم
i am never going back|هرگز برنمی_گردم
i am never alone|هرگز تنها نیستم
i am never wrong|هیچ_وقت اشتباه نمی_کنم
"""
}
