package app.tarjoman

/**
 * English clean-up before the offline ML Kit engine (it is weak with lowercase "i", ALL CAPS, missing punctuation and slang).
 * Slang is rewritten as plain English first, because ML Kit then translates the meaning instead of the words
 * ("tripping" -> "hallucinating", "be cool" -> "be awesome" instead of "be cold").
 */
object Pre {
    private val aux = Regex(
        "^(can|could|will|would|shall|should|may|might|am|are|is|was|were|do|does|did|have|has|had|don't|doesn't|didn't|isn't|aren't|can't|won't|" +
            "what|why|how|who|whom|whose|where|when|which)\\b", RegexOption.IGNORE_CASE
    )
    private val notQuestion = Regex("^(what|how)\\s+(a|an|the)\\b|^how\\s+(nice|beautiful|great|cool|sweet|lovely|awful|stupid)\\b", RegexOption.IGNORE_CASE)
    private val temp = Regex("\\b(water|weather|air|drink|drinks|cold|wind|breeze|temperature|cool\\s+down|cooler|fridge|ice|night|morning|summer|room)\\b", RegexOption.IGNORE_CASE)
    private val coolWord = Regex("\\bcool\\b", RegexOption.IGNORE_CASE)
    private val tripping = Regex("\\btripping\\b(?!\\s+(over|on|up|down|the|a)\\b)", RegexOption.IGNORE_CASE)

    private val idioms: List<Pair<Regex, String>> = listOf(
        Regex("\\bfreak(ing)? out\\b", RegexOption.IGNORE_CASE) to "panic",
        Regex("\\bchill out\\b", RegexOption.IGNORE_CASE) to "calm down",
        Regex("\\bhang(ing)? out\\b", RegexOption.IGNORE_CASE) to "spend time together",
        Regex("\\bgive me a break\\b", RegexOption.IGNORE_CASE) to "leave me alone",
        Regex("\\bpiece of cake\\b", RegexOption.IGNORE_CASE) to "very easy",
        Regex("\\bkidding\\b", RegexOption.IGNORE_CASE) to "joking",
        Regex("\\bdude\\b|\\bbro\\b", RegexOption.IGNORE_CASE) to "man",
        Regex("\\bgonna\\b", RegexOption.IGNORE_CASE) to "going to",
        Regex("\\bwanna\\b", RegexOption.IGNORE_CASE) to "want to",
        Regex("\\bgotta\\b", RegexOption.IGNORE_CASE) to "have to",
        Regex("\\bkinda\\b", RegexOption.IGNORE_CASE) to "kind of",
        Regex("\\bain't\\b", RegexOption.IGNORE_CASE) to "is not",
        Regex("\\by'all\\b", RegexOption.IGNORE_CASE) to "you all"
    )

    fun en(text: String): String = text.split("\n").joinToString("\n") { if (it.isBlank()) it else one(it) }

    /** Clean-up of a single sentence or clause. */
    fun line(l: String): String = if (l.isBlank()) l else one(l)

    private val diedRe = Regex("\\b(am|is|are|was|were)\\s+((?:i|you|he|she|we|they|it)\\s+)?died\\b", RegexOption.IGNORE_CASE)

    private fun one(l0: String): String {
        var l = l0.trim()
        val letters = l.count { it.isLetter() }
        // ALL CAPS (manga) -> normal sentence case
        if (letters >= 4 && l == l.uppercase() && l != l.lowercase()) l = l.lowercase()
        l = Regex("\\bi\\b").replace(l, "I")
        l = diedRe.replace(l) { m -> m.groupValues[1] + " " + m.groupValues[2] + "dead" }
        for ((re, to) in idioms) l = re.replace(l, to)
        l = tripping.replace(l, "hallucinating")
        if (!temp.containsMatchIn(l)) l = coolWord.replace(l, "awesome")
        // first letter capital
        val ix = l.indexOfFirst { it.isLetter() }
        if (ix >= 0 && l[ix].isLowerCase()) l = l.substring(0, ix) + l[ix].uppercaseChar() + l.substring(ix + 1)
        // final punctuation for full sentences only (3+ words), so labels and fragments stay untouched
        val words = l.split(Regex("\\s+")).size
        val last = l.last()
        if (words >= 3 && last.isLetterOrDigit()) {
            val q = aux.containsMatchIn(l) && !notQuestion.containsMatchIn(l)
            l += if (q) "?" else "."
        }
        return l
    }
}
