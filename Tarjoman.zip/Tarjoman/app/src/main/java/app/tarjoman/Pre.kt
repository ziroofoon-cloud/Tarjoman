package app.tarjoman

/**
 * English clean-up before the offline ML Kit engine (it is weak with lowercase "i", ALL CAPS, missing punctuation and slang).
 * Slang is rewritten as plain English first, because ML Kit then translates the meaning instead of the words
 * ("tripping" -> "hallucinating", "be cool" -> "be awesome" instead of "be cold").
 */
object Pre {
    private val aux = Regex(
        "^(can|could|will|would|shall|should|may|might|am|are|is|was|were|do|does|did|have|has|had|don't|doesn't|didn't|isn't|aren't|can't|won't|" +
            "what|why|how|who|whom|whose|where|when|which)\\b", RegexOption.IGNORE_CASE
    )
    private val notQuestion = Regex("^(what|how)\\s+(a|an|the)\\b|^how\\s+(nice|beautiful|great|cool|sweet|lovely|awful|stupid)\\b", RegexOption.IGNORE_CASE)
    private val temp = Regex("\\b(water|weather|air|drink|drinks|cold|wind|breeze|temperature|cool\\s+down|cooler|fridge|ice|night|morning|summer|room)\\b", RegexOption.IGNORE_CASE)
    private val coolWord = Regex("\\bcool\\b", RegexOption.IGNORE_CASE)
    private val tripping = Regex("\\btripping\\b(?!\\s+(over|on|up|down|the|a)\\b)", RegexOption.IGNORE_CASE)

    private val idioms: List<Pair<Regex, String>> = listOf(
        Regex("\\bfreak(ing)? out\\b", RegexOption.IGNORE_CASE) to "panic",
        Regex("\\bchill out\\b", RegexOption.IGNORE_CASE) to "calm down",
        Regex("\\bhang(ing)? out\\b", RegexOption.IGNORE_CASE) to "spend time together",
        Regex("\\bgive me a break\\b", RegexOption.IGNORE_CASE) to "leave me alone",
        Regex("\\bpiece of cake\\b", RegexOption.IGNORE_CASE) to "very easy",
        Regex("\\bkidding\\b", RegexOption.IGNORE_CASE) to "joking",
        Regex("\\bdude\\b|\\bbro\\b", RegexOption.IGNORE_CASE) to "man",
        Regex("\\bgonna\\b", RegexOption.IGNORE_CASE) to "going to",
        Regex("\\bwanna\\b", RegexOption.IGNORE_CASE) to "want to",
        Regex("\\bgotta\\b", RegexOption.IGNORE_CASE) to "have to",
        Regex("\\bkinda\\b", RegexOption.IGNORE_CASE) to "kind of",
        Regex("\\bain't\\b", RegexOption.IGNORE_CASE) to "is not",
        Regex("\\by'all\\b", RegexOption.IGNORE_CASE) to "you all",
        // chat / texting spellings
        Regex("\\blemme\\b", RegexOption.IGNORE_CASE) to "let me",
        Regex("\\bgimme\\b", RegexOption.IGNORE_CASE) to "give me",
        Regex("\\bdunno\\b", RegexOption.IGNORE_CASE) to "do not know",
        Regex("\\bcuz\\b|'cause\\b", RegexOption.IGNORE_CASE) to "because",
        Regex("\\by'?know\\b|\\bya know\\b", RegexOption.IGNORE_CASE) to "you know",
        Regex("\\bsorta\\b", RegexOption.IGNORE_CASE) to "sort of",
        Regex("\\boutta\\b", RegexOption.IGNORE_CASE) to "out of",
        Regex("\\blotta\\b", RegexOption.IGNORE_CASE) to "a lot of",
        Regex("\\btryna\\b", RegexOption.IGNORE_CASE) to "trying to",
        Regex("\\bimma\\b", RegexOption.IGNORE_CASE) to "I am going to",
        Regex("\\bpl(?:s|z)\\b", RegexOption.IGNORE_CASE) to "please",
        Regex("\\bthx\\b", RegexOption.IGNORE_CASE) to "thanks",
        Regex("(?<![\\w.'])u(?![\\w.'])", RegexOption.IGNORE_CASE) to "you",
        Regex("\\bur\\b", RegexOption.IGNORE_CASE) to "your",
        Regex("\\bbtw\\b", RegexOption.IGNORE_CASE) to "by the way",
        Regex("\\bidk\\b", RegexOption.IGNORE_CASE) to "I do not know",
        Regex("\\bomg\\b", RegexOption.IGNORE_CASE) to "oh my God",
        Regex("\\btbh\\b", RegexOption.IGNORE_CASE) to "to be honest",
        Regex("\\bimo\\b", RegexOption.IGNORE_CASE) to "in my opinion",
        Regex("\\basap\\b", RegexOption.IGNORE_CASE) to "as soon as possible",
        Regex("\\bfyi\\b", RegexOption.IGNORE_CASE) to "for your information",
        // idioms that ML Kit translates word by word
        Regex("\\bkicked the bucket\\b", RegexOption.IGNORE_CASE) to "died",
        Regex("\\bkick the bucket\\b", RegexOption.IGNORE_CASE) to "die",
        Regex("\\bbreak a leg\\b", RegexOption.IGNORE_CASE) to "good luck",
        Regex("\\bspilled the beans\\b", RegexOption.IGNORE_CASE) to "revealed the secret",
        Regex("\\bspill the beans\\b|\\blet the cat out of the bag\\b", RegexOption.IGNORE_CASE) to "reveal the secret",
        Regex("\\bunder the weather\\b", RegexOption.IGNORE_CASE) to "sick",
        Regex("\\bhit the road\\b", RegexOption.IGNORE_CASE) to "leave",
        Regex("\\bhit the (?:sack|hay)\\b", RegexOption.IGNORE_CASE) to "go to bed",
        Regex("\\bcosts? an arm and a leg\\b", RegexOption.IGNORE_CASE) to "is very expensive",
        Regex("\\bonce in a blue moon\\b", RegexOption.IGNORE_CASE) to "very rarely",
        Regex("\\bbeat(?:ing)? around the bush\\b", RegexOption.IGNORE_CASE) to "avoid the main topic",
        Regex("\\bbite the bullet\\b", RegexOption.IGNORE_CASE) to "accept the pain",
        Regex("\\bcall it a day\\b", RegexOption.IGNORE_CASE) to "stop working for today",
        Regex("\\bcut it out\\b", RegexOption.IGNORE_CASE) to "stop it",
        Regex("\\bget over it\\b", RegexOption.IGNORE_CASE) to "accept it",
        Regex("\\bno big deal\\b", RegexOption.IGNORE_CASE) to "not important",
        Regex("\\bheads up\\b", RegexOption.IGNORE_CASE) to "warning",
        Regex("\\bon the same page\\b", RegexOption.IGNORE_CASE) to "in agreement",
        Regex("\\bout of the blue\\b", RegexOption.IGNORE_CASE) to "suddenly",
        Regex("\\bat the end of the day\\b", RegexOption.IGNORE_CASE) to "in the end",
        Regex("\\bno sweat\\b", RegexOption.IGNORE_CASE) to "no problem",
        Regex("\\b(it|that|this|life|he|she) sucks\\b", RegexOption.IGNORE_CASE) to "$1 is terrible",
        Regex("\\byou suck\\b", RegexOption.IGNORE_CASE) to "you are terrible",
        Regex("\\bfigure(?:d)? it out\\b", RegexOption.IGNORE_CASE) to "find the answer",
        Regex("\\bshowed up\\b", RegexOption.IGNORE_CASE) to "arrived",
        Regex("\\bshows up\\b", RegexOption.IGNORE_CASE) to "arrives",
        Regex("\\bshow up\\b", RegexOption.IGNORE_CASE) to "arrive",
        Regex("\\bwatch out\\b|\\blook out\\b", RegexOption.IGNORE_CASE) to "be careful",
        Regex("\\bfed up\\b", RegexOption.IGNORE_CASE) to "annoyed and tired",
        Regex("\\bback off\\b", RegexOption.IGNORE_CASE) to "move away"
    )

    /** Chat spellings without the apostrophe: "dont", "im", "thats" ... */
    private val aposFix: List<Pair<Regex, String>> = listOf(
        "dont" to "don't", "doesnt" to "doesn't", "didnt" to "didn't", "cant" to "can't", "wont" to "won't", "isnt" to "isn't",
        "arent" to "aren't", "wasnt" to "wasn't", "werent" to "weren't", "havent" to "haven't", "hasnt" to "hasn't",
        "hadnt" to "hadn't", "couldnt" to "couldn't", "wouldnt" to "wouldn't", "shouldnt" to "shouldn't", "im" to "I'm",
        "ive" to "I've", "youre" to "you're", "theyre" to "they're", "thats" to "that's", "whats" to "what's"
    ).map { (a, b) -> Regex("\\b$a\\b", RegexOption.IGNORE_CASE) to b }

    private val endPunct = Regex("[.!?:;\"\u201D\u2019)\\]\u2026\u3002]$")

    /**
     * Joins lines that were broken in the middle of a sentence (text copied from a PDF or a book page): a long line that
     * does not end with punctuation and is followed by a line starting with a lower-case letter. Short lines stay
     * (lists, subtitles), and the hyphen of a word broken at the end of a line is removed.
     */
    fun unwrap(text: String): String {
        val out = ArrayList<String>()
        for (ln in text.split("\n")) {
            val cur = out.lastOrNull()
            val t = ln.trim()
            if (cur != null && t.isNotEmpty() && t[0].isLowerCase() && cur.trim().length >= 35 && !endPunct.containsMatchIn(cur.trim())) {
                val c = cur.trimEnd()
                out[out.size - 1] = if (c.endsWith("-") && c.length > 1 && c[c.length - 2].isLetter()) c.dropLast(1) + t else c + " " + t
            } else out.add(ln)
        }
        return out.joinToString("\n")
    }

    private val multiSp = Regex("[ \\t]{2,}")
    private val spBeforeP = Regex("[ \\t]+([,.;!?])")
    private val noSpAfter = Regex("([,;!?])(?=[A-Za-z])")
    private val loneI = Regex("\\bi\\b(?=[ ,.!?]|$|')")
    private val sentStart = Regex("(^|(?<=[A-Za-z0-9]{3}\\.|[!?])\\s+)([a-z])(?![A-Z])")

    /** Light clean-up of English that comes OUT of an engine: spacing, lone "i", capital after a full stop. */
    fun enOut(text: String): String = text.split("\n").joinToString("\n") { l0 ->
        if (l0.isBlank()) l0 else {
            var l = multiSp.replace(l0.trim(), " ")
            l = spBeforeP.replace(l, "$1")
            l = noSpAfter.replace(l, "$1 ")
            l = loneI.replace(l, "I")
            sentStart.replace(l) { m -> m.groupValues[1] + m.groupValues[2].uppercase() }
        }
    }

    fun en(text: String): String = text.split("\n").joinToString("\n") { if (it.isBlank()) it else one(it) }

    /** Clean-up of a single sentence or clause. */
    fun line(l: String): String = if (l.isBlank()) l else one(l)

    private val diedRe = Regex("\\b(am|is|are|was|were)\\s+((?:i|you|he|she|we|they|it)\\s+)?died\\b", RegexOption.IGNORE_CASE)

    private fun one(l0: String): String {
        var l = l0.trim()
        val letters = l.count { it.isLetter() }
        // ALL CAPS (manga) -> normal sentence case
        if (letters >= 4 && l == l.uppercase() && l != l.lowercase()) l = l.lowercase()
        l = Regex("\\bi\\b").replace(l, "I")
        for ((re, to) in aposFix) l = re.replace(l, to)
        l = diedRe.replace(l) { m -> m.groupValues[1] + " " + m.groupValues[2] + "dead" }
        for ((re, to) in idioms) l = re.replace(l, to)
        l = tripping.replace(l, "hallucinating")
        if (!temp.containsMatchIn(l)) l = coolWord.replace(l, "awesome")
        // first letter capital
        val ix = l.indexOfFirst { it.isLetter() }
        if (ix >= 0 && l[ix].isLowerCase()) l = l.substring(0, ix) + l[ix].uppercaseChar() + l.substring(ix + 1)
        // final punctuation for full sentences only (3+ words), so labels and fragments stay untouched
        val words = l.split(Regex("\\s+")).size
        val last = l.last()
        if (words >= 3 && last.isLetterOrDigit()) {
            val q = aux.containsMatchIn(l) && !notQuestion.containsMatchIn(l)
            l += if (q) "?" else "."
        }
        return l
    }
}
