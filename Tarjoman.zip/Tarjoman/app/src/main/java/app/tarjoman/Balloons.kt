package app.tarjoman

import android.graphics.Bitmap
import android.graphics.Rect

/**
 * Speech balloons and caption boxes found WITHOUT a text reader: a balloon is a clear (white) area, closed by its outline,
 * with dark letters inside. Each one can then be read on its own, with everything outside it painted white. Read alone, a
 * balloon comes out clean; read inside the whole page, the reader mixes the lines of neighbouring balloons and picks up
 * the drawing (that is where "PRESIDENT SPIRITS... I IY nr" came from).
 */
object Balloons {
    class Cand(val rect: Rect, val step: Int, val gx0: Int, val gy0: Int, val gw: Int, val gh: Int, val filled: BooleanArray, val ink: Float)

    private const val BRIGHT = 215
    private const val DARK = 150

    fun find(bmp: Bitmap): List<Cand> {
        val w = bmp.width
        val h = bmp.height
        if (w < 200 || h < 200) return emptyList()
        var step = maxOf(1, maxOf(w, h) / 1200)
        while ((w / step).toLong() * (h / step) > 1_500_000L) step++
        val gw = w / step
        val gh = h / step
        val lum = IntArray(gw * gh)
        val row = IntArray(w)
        for (gy in 0 until gh) {
            bmp.getPixels(row, 0, w, 0, gy * step, w, 1)
            for (gx in 0 until gw) {
                val c = row[gx * step]
                lum[gy * gw + gx] = (299 * ((c shr 16) and 255) + 587 * ((c shr 8) and 255) + 114 * (c and 255)) / 1000
            }
        }
        // connected clear areas (4-neighbour), with their boxes
        val lab = IntArray(gw * gh)
        val q = IntArray(gw * gh)
        val bx0 = ArrayList<Int>(); val by0 = ArrayList<Int>(); val bx1 = ArrayList<Int>(); val by1 = ArrayList<Int>(); val cnt = ArrayList<Int>()
        bx0.add(0); by0.add(0); bx1.add(0); by1.add(0); cnt.add(0)   // label 0 = none
        var next = 0
        for (i0 in 0 until gw * gh) {
            if (lab[i0] != 0 || lum[i0] < BRIGHT) continue
            next++
            var qh = 0
            var qt = 0
            q[qt++] = i0
            lab[i0] = next
            var x0 = gw; var y0 = gh; var x1 = 0; var y1 = 0; var n = 0
            while (qh < qt) {
                val i = q[qh++]
                val x = i % gw
                val y = i / gw
                n++
                if (x < x0) x0 = x
                if (x > x1) x1 = x
                if (y < y0) y0 = y
                if (y > y1) y1 = y
                if (x > 0 && lab[i - 1] == 0 && lum[i - 1] >= BRIGHT) { lab[i - 1] = next; q[qt++] = i - 1 }
                if (x < gw - 1 && lab[i + 1] == 0 && lum[i + 1] >= BRIGHT) { lab[i + 1] = next; q[qt++] = i + 1 }
                if (y > 0 && lab[i - gw] == 0 && lum[i - gw] >= BRIGHT) { lab[i - gw] = next; q[qt++] = i - gw }
                if (y < gh - 1 && lab[i + gw] == 0 && lum[i + gw] >= BRIGHT) { lab[i + gw] = next; q[qt++] = i + gw }
            }
            bx0.add(x0); by0.add(y0); bx1.add(x1); by1.add(y1); cnt.add(n)
        }
        val out = ArrayList<Cand>()
        for (id in 1..next) {
            val x0 = bx0[id]; val y0 = by0[id]; val x1 = bx1[id] + 1; val y1 = by1[id] + 1
            val cw = x1 - x0
            val ch = y1 - y0
            if (cw * step < 30 || ch * step < 20) continue
            if (cw * step > w * 0.92f || ch * step > h * 0.6f) continue
            if (cnt[id] < cw.toLong() * ch * 0.30) continue
            // what is not reachable from the box border without crossing the area is inside it: letters and the area itself
            val outside = BooleanArray(cw * ch)
            var qh = 0
            var qt = 0
            fun push(x: Int, y: Int) {
                val k = y * cw + x
                if (!outside[k] && lab[(y0 + y) * gw + x0 + x] != id) { outside[k] = true; q[qt++] = k }
            }
            for (x in 0 until cw) { push(x, 0); push(x, ch - 1) }
            for (y in 0 until ch) { push(0, y); push(cw - 1, y) }
            while (qh < qt) {
                val k = q[qh++]
                val x = k % cw
                val y = k / cw
                if (x > 0) push(x - 1, y)
                if (x < cw - 1) push(x + 1, y)
                if (y > 0) push(x, y - 1)
                if (y < ch - 1) push(x, y + 1)
            }
            val filled = BooleanArray(cw * ch)
            var fc = 0
            var ink = 0
            for (y in 0 until ch) for (x in 0 until cw) {
                val k = y * cw + x
                if (!outside[k]) {
                    filled[k] = true
                    fc++
                    val gi = (y0 + y) * gw + x0 + x
                    if (lab[gi] != id && lum[gi] < DARK) ink++
                }
            }
            if (fc == 0) continue
            val r = ink.toFloat() / fc
            if (r < 0.035f || r > 0.45f) continue
            out.add(Cand(Rect(x0 * step, y0 * step, x1 * step, y1 * step), step, x0, y0, cw, ch, filled, r))
        }
        // a white area that only surrounds other balloons (page margin around a caption box) is not itself a balloon
        val keep = ArrayList<Cand>()
        for (a in out) {
            val holdsOther = out.any { b ->
                b !== a && b.rect.left >= a.rect.left - 4 && b.rect.top >= a.rect.top - 4 && b.rect.right <= a.rect.right + 4 && b.rect.bottom <= a.rect.bottom + 4 &&
                    (b.rect.width().toLong() * b.rect.height()) * 10 < (a.rect.width().toLong() * a.rect.height()) * 9 &&
                    b.ink >= 0.10f && b.ink > a.ink * 1.5f   // the inner one is clearly more "full of letters" (a caption box in a white margin)
            }
            if (!holdsOther) keep.add(a)
        }
        return keep.sortedWith(compareBy({ it.rect.top }, { it.rect.left })).take(40)
    }

    /** The balloon cut out (3 px margin), everything outside its area painted white; returns the picture and its top-left corner in [bmp]. */
    fun crop(bmp: Bitmap, c: Cand): Triple<Bitmap, Int, Int> {
        val pad = 3
        val x0 = maxOf(0, c.rect.left - pad)
        val y0 = maxOf(0, c.rect.top - pad)
        val x1 = minOf(bmp.width, c.rect.right + pad)
        val y1 = minOf(bmp.height, c.rect.bottom + pad)
        val w = x1 - x0
        val h = y1 - y0
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, x0, y0, w, h)
        for (y in 0 until h) for (x in 0 until w) {
            val gx = (x0 + x) / c.step - c.gx0
            val gy = (y0 + y) / c.step - c.gy0
            val inside = gx in 0 until c.gw && gy in 0 until c.gh && c.filled[gy * c.gw + gx]
            if (!inside) px[y * w + x] = -1
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return Triple(out, x0, y0)
    }
}
