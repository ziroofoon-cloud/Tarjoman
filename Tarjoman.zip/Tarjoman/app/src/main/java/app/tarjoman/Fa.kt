package app.tarjoman

/** Persian text clean-up and a tiny script-based language guesser (no extra libraries). */
object Fa {
    private val qm = Regex("(?<=[\\u0600-\\u06FF])(\\s*)\\?")
    private val comma = Regex("(?<=[\\u0600-\\u06FF]),")

    /** Fix typical machine-translation leftovers: Arabic ي/ك, Arabic digits, Latin ? and , after Persian words. */
    fun fix(t: String): String {
        if (t.isEmpty()) return t
        val sb = StringBuilder(t.length)
        for (ch in t) {
            when (ch) {
                '\u064A', '\u0649' -> sb.append('\u06CC')
                '\u0643' -> sb.append('\u06A9')
                '\u0640' -> {}                                      // tatweel (kashida)
                in '\u064B'..'\u065F', '\u0670' -> {}               // Arabic vowel marks (harakat)
                '\u06C0' -> sb.append('\u0647')                     // ۀ -> ه
                in '\u0660'..'\u0669' -> sb.append('\u06F0' + (ch - '\u0660'))
                else -> sb.append(ch)
            }
        }
        var r = sb.toString()
        r = qm.replace(r) { it.groupValues[1] + "\u061F" }
        r = comma.replace(r, "\u060C")
        // Arabic ta marbuta at the end of a word is written with heh in Persian
        r = taMarbuta.replace(r, "\u0647")
        // common Arabic words that machine translation leaks into Persian
        for ((re, to) in arabicLeaks) r = re.replace(r, to)
        return r
    }

    private val taMarbuta = Regex("\u0629(?![\\u0600-\\u06FF])")
    private val arabicLeaks: List<Pair<Regex, String>> = listOf(
        "هذا" to "این", "هذه" to "این", "ذلک" to "آن", "لکن" to "ولی",
        "ماذا" to "چی", "لماذا" to "چرا", "أین" to "کجا"
    ).map { (a, b) -> Regex("(?<![\\u0600-\\u06FF])" + a + "(?![\\u0600-\\u06FF])") to b }

    /** True when a Persian answer from a small AI model is unusable: mostly Latin letters (untranslated) or empty of Persian letters. */
    fun looksBad(out: String): Boolean {
        var fa = 0; var la = 0
        for (ch in out) {
            if (ch in '\u0600'..'\u06FF' && ch.isLetter()) fa++
            else if (ch in 'A'..'Z' || ch in 'a'..'z') la++
        }
        val n = fa + la
        if (n < 4) return false
        return fa * 100 < n * 65
    }

    private fun word(p: String) = Regex("(?<![\\u0600-\\u06FF])" + p + "(?![\\u0600-\\u06FF\\u200c])")

    /** formal ending -> spoken ending, for the verbs that machine translation makes most stiff */
    private val verbForms = listOf(
        "خواهم" to "خوام", "خواهی" to "خوای", "خواهد" to "خواد", "خواهیم" to "خوایم", "خواهید" to "خواید", "خواهند" to "خوان",
        "توانم" to "تونم", "توانی" to "تونی", "تواند" to "تونه", "توانیم" to "تونیم", "توانید" to "تونید", "توانند" to "تونن",
        "دانم" to "دونم", "دانی" to "دونی", "داند" to "دونه", "دانیم" to "دونیم", "دانید" to "دونید", "دانند" to "دونن",
        "گویم" to "گم", "گویی" to "گی", "گوید" to "گه", "گوییم" to "گیم", "گویید" to "گید", "گویند" to "گن",
        "روم" to "رم", "روی" to "ری", "رود" to "ره", "رویم" to "ریم", "روید" to "رید", "روند" to "رن"
    ).map { (a, b) -> Regex("(?<![\\u0600-\\u06FF])(ن?)می[\\u200c ]?" + a + "(?![\\u0600-\\u06FF\\u200c])") to ("$1می\u200c" + b) }

    private val wordForms = listOf(
        "را" to "رو", "آن" to "اون", "او" to "اون", "آنجا" to "اونجا", "اکنون" to "الان", "بسیار" to "خیلی",
        "چگونه" to "چطور", "بله" to "آره", "زیرا" to "چون", "اما" to "ولی", "سپس" to "بعد", "مرا" to "منو"
    ).map { (a, b) -> word(a) to b }

    private val aya = Regex("(^|[\\n.!\\u061F?]\\s*)\\u0622\\u06CC\\u0627\\s+")
    private val stiff = listOf(
        "می\u200cباشد" to "هست", "می\u200cباشند" to "هستن", "می\u200cباشم" to "هستم",
        " نیز " to " هم ", "هرگز" to "هیچ\u200cوقت", "چنانچه" to "اگه"
    )

    /** Turns stiff written Persian into everyday spoken Persian (subtitles, manga, chat). Safe to apply twice. */
    fun casual(t: String): String {
        var r = t
        for ((re, to) in verbForms) r = re.replace(r, to)
        for ((re, to) in wordForms) r = re.replace(r, to)
        // spoken questions do not start with "آیا"
        r = aya.replace(r) { it.groupValues[1] }
        for ((a, b) in stiff) r = r.replace(a, b)
        return r
    }

    /** "fa" / "ja" / "en" when one script clearly dominates the letters, else null. */
    fun guess(t: String): String? {
        var ar = 0; var jp = 0; var la = 0
        for (ch in t) {
            when {
                ch in '\u0600'..'\u06FF' -> ar++
                ch in '\u3040'..'\u30FF' || ch in '\u4E00'..'\u9FFF' -> jp++
                ch in 'A'..'Z' || ch in 'a'..'z' -> la++
            }
        }
        val n = ar + jp + la
        if (n < 3) return null
        return when {
            ar * 100 >= n * 60 -> "fa"
            jp * 100 >= n * 40 -> "ja"
            la * 100 >= n * 60 -> "en"
            else -> null
        }
    }
}
