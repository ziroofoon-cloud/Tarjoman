package app.tarjoman

/** Persian text clean-up and a tiny script-based language guesser (no extra libraries). */
object Fa {
    private val qm = Regex("(?<=[\\u0620-\\u064A\\u066E-\\u06D3])(\\s*)\\?")
    private val comma = Regex("(?<=[\\u0620-\\u064A\\u066E-\\u06D3]),")

    /** Fix typical machine-translation leftovers: Arabic ي/ك, Arabic digits, Latin ? and , after Persian words. */
    fun fix(t: String): String {
        if (t.isEmpty()) return t
        val sb = StringBuilder(t.length)
        for (ch in t) {
            when (ch) {
                '\u064A', '\u0649' -> sb.append('\u06CC')
                '\u0643' -> sb.append('\u06A9')
                '\u0640' -> {}                                      // tatweel (kashida)
                in '\u064B'..'\u065F', '\u0670' -> {}               // Arabic vowel marks (harakat)
                '\u06C0' -> sb.append('\u0647')                     // ۀ -> ه
                in '\u0660'..'\u0669' -> sb.append('\u06F0' + (ch - '\u0660'))
                else -> sb.append(ch)
            }
        }
        var r = sb.toString()
        // spaces: none before Persian punctuation, half-space after می / نمی and before ها / های / ترین
        r = spBefore.replace(r, "")
        r = zwnjMi.replace(r, "$1\u200c")
        r = zwnjSuffix.replace(r, "\u200c$1")
        // Persian typography: « » for quotes, one … for three dots, ؛ after Persian words
        r = dq.replace(r) { "\u00AB" + it.groupValues[1].trim() + "\u00BB" }
        r = cdq.replace(r) { "\u00AB" + it.groupValues[1].trim() + "\u00BB" }
        r = r.replace("...", "\u2026")
        r = semi.replace(r, "\u061B")
        r = qm.replace(r) { it.groupValues[1] + "\u061F" }
        r = comma.replace(r, "\u060C")
        // Arabic ta marbuta at the end of a word is written with heh in Persian
        r = taMarbuta.replace(r, "\u0647")
        // common Arabic words that machine translation leaks into Persian
        for ((re, to) in arabicLeaks) r = re.replace(r, to)
        return r
    }

    private val spBefore = Regex("[ \\t]+(?=[\\u060C\\u061F.!,;:])")
    private val zwnjMi = Regex("(?<![\\u0620-\\u064A\\u066E-\\u06D3\\u200c])(ن?می) (?=[\\u0620-\\u064A\\u066E-\\u06D3])")
    private val zwnjSuffix = Regex("(?<=[\\u0620-\\u064A\\u066E-\\u06D3]) (ها|های|هایی|ترین)(?![\\u0620-\\u064A\\u066E-\\u06D3])")
    private val dq = Regex("\"([^\"\\n]{1,200})\"")
    private val cdq = Regex("\u201C([^\u201D\\n]{1,200})\u201D")
    private val semi = Regex("(?<=[\\u0620-\\u064A\\u066E-\\u06D3]);")
    private val taMarbuta = Regex("\u0629(?![\\u0620-\\u064A\\u066E-\\u06D3])")
    private val arabicLeaks: List<Pair<Regex, String>> = listOf(
        "هذا" to "این", "هذه" to "این", "ذلک" to "آن", "لکن" to "ولی",
        "ماذا" to "چی", "لماذا" to "چرا", "أین" to "کجا"
    ).map { (a, b) -> Regex("(?<![\\u0620-\\u064A\\u066E-\\u06D3])" + a + "(?![\\u0620-\\u064A\\u066E-\\u06D3])") to b }

    /** True when a Persian answer from a small AI model is unusable: mostly Latin letters (untranslated) or empty of Persian letters. */
    fun looksBad(out: String): Boolean {
        var fa = 0; var la = 0
        for (ch in out) {
            if (ch in '\u0600'..'\u06FF' && ch.isLetter()) fa++
            else if (ch in 'A'..'Z' || ch in 'a'..'z') la++
        }
        val n = fa + la
        if (n < 4) return false
        return fa * 100 < n * 65
    }

    private fun word(p: String) = Regex("(?<![\\u0620-\\u064A\\u066E-\\u06D3])" + p + "(?![\\u0620-\\u064A\\u066E-\\u06D3\\u200c])")

    /** formal ending -> spoken ending, for the verbs that machine translation makes most stiff */
    private val verbForms = listOf(
        "خواهم" to "خوام", "خواهی" to "خوای", "خواهد" to "خواد", "خواهیم" to "خوایم", "خواهید" to "خواید", "خواهند" to "خوان",
        "توانم" to "تونم", "توانی" to "تونی", "تواند" to "تونه", "توانیم" to "تونیم", "توانید" to "تونید", "توانند" to "تونن",
        "دانم" to "دونم", "دانی" to "دونی", "داند" to "دونه", "دانیم" to "دونیم", "دانید" to "دونید", "دانند" to "دونن",
        "گویم" to "گم", "گویی" to "گی", "گوید" to "گه", "گوییم" to "گیم", "گویید" to "گید", "گویند" to "گن",
        "روم" to "رم", "روی" to "ری", "رود" to "ره", "رویم" to "ریم", "روید" to "رید", "روند" to "رن"
    ).map { (a, b) -> Regex("(?<![\\u0620-\\u064A\\u066E-\\u06D3])(ن?)می[\\u200c ]?" + a + "(?![\\u0620-\\u064A\\u066E-\\u06D3\\u200c])") to ("$1می\u200c" + b) }

    private val wordForms = listOf(
        "را" to "رو", "آن" to "اون", "او" to "اون", "آنجا" to "اونجا", "اکنون" to "الان", "بسیار" to "خیلی",
        "چگونه" to "چطور", "بله" to "آره", "زیرا" to "چون", "اما" to "ولی", "سپس" to "بعد", "مرا" to "منو"
    ).map { (a, b) -> word(a) to b }

    private val aya = Regex("(^|[\\n.!\\u061F?]\\s*)\\u0622\\u06CC\\u0627\\s+")
    private val stiff = listOf(
        "می\u200cباشد" to "هست", "می\u200cباشند" to "هستن", "می\u200cباشم" to "هستم",
        " نیز " to " هم ", "هرگز" to "هیچ\u200cوقت", "چنانچه" to "اگه"
    )

    /** Turns stiff written Persian into everyday spoken Persian (subtitles, manga, chat). Safe to apply twice. */
    fun casual(t: String): String {
        var r = t
        for ((re, to) in verbForms) r = re.replace(r, to)
        for ((re, to) in wordForms) r = re.replace(r, to)
        // spoken questions do not start with "آیا"
        r = aya.replace(r) { it.groupValues[1] }
        for ((a, b) in stiff) r = r.replace(a, b)
        return r
    }

    private val spokenStems = listOf(
        "خوام" to "خواهم", "خوای" to "خواهی", "خواد" to "خواهد", "خوایم" to "خواهیم", "خواید" to "خواهید", "خوان" to "خواهند",
        "تونم" to "توانم", "تونی" to "توانی", "تونه" to "تواند", "تونیم" to "توانیم", "تونید" to "توانید", "تونن" to "توانند",
        "دونم" to "دانم", "دونی" to "دانی", "دونه" to "داند", "دونیم" to "دانیم", "دونید" to "دانید", "دونن" to "دانند",
        "گم" to "گویم", "گی" to "گویی", "گه" to "گوید", "گیم" to "گوییم", "گید" to "گویید", "گن" to "گویند",
        "رم" to "روم", "ری" to "روی", "ره" to "رود", "ریم" to "رویم", "رید" to "روید", "رن" to "روند",
        "شم" to "شوم", "شی" to "شوی", "شه" to "شود", "شیم" to "شویم", "شن" to "شوند",
        "دم" to "دهم", "دی" to "دهی", "ده" to "دهد", "دن" to "دهند",
        "ام" to "آیم", "ای" to "آیی", "اد" to "آید",
        "خونم" to "خوانم", "خونه" to "خواند", "کنه" to "کند", "بینه" to "بیند", "گیره" to "گیرد", "خوره" to "خورد"
    ).map { (a, b) -> Regex("(?<![\\u0620-\\u064A\\u066E-\\u06D3])(ن?)می[\\u200c ]?" + a + "(?![\\u0620-\\u064A\\u066E-\\u06D3\\u200c])") to ("$1می\u200c" + b) }

    private val spokenWords = listOf(
        "اونجا" to "آنجا", "اونا" to "آنها", "اینا" to "اینها", "اون" to "آن", "اونقدر" to "آن قدر", "اینقدر" to "این قدر",
        "اینجوری" to "این طور", "اونجوری" to "آن طور", "چیه" to "چیست", "کیه" to "کیست", "چقد" to "چقدر", "دیگه" to "دیگر",
        "منو" to "من را", "تورو" to "تو را", "اینو" to "این را", "اونو" to "آن را", "یه" to "یک", "هیچی" to "هیچ چیز",
        "بهش" to "به او", "ازش" to "از او", "باهاش" to "با او", "برام" to "برای من", "برات" to "برای تو", "واسه" to "برای",
        "واسم" to "برای من", "واست" to "برای تو",
        "خوبه" to "خوب است", "درسته" to "درست است", "غلطه" to "غلط است", "قشنگه" to "قشنگ است", "سخته" to "سخت است",
        "آسونه" to "آسان است", "گرونه" to "گران است", "ارزونه" to "ارزان است", "دیره" to "دیر است", "زوده" to "زود است"
    ).map { (a, b) -> word(a) to b }

    private val raEnd = Regex("(?<=[\\u0620-\\u064A\\u066E-\\u06D3]) رو(?=\\s*[.!\\u061F?\\u060C,]|$)")

    /** Spoken Persian -> written Persian, so that ML Kit (trained on written text) understands it. The opposite of [casual]. */
    fun formal(t: String): String {
        var r = t
        for ((re, to) in spokenStems) r = re.replace(r, to)
        for ((re, to) in spokenWords) r = re.replace(r, to)
        return raEnd.replace(r, " را")
    }

    /** "fa" / "ja" / "en" when one script clearly dominates the letters, else null. */
    fun guess(t: String): String? {
        var ar = 0; var jp = 0; var la = 0
        for (ch in t) {
            when {
                ch in '\u0600'..'\u06FF' -> ar++
                ch in '\u3040'..'\u30FF' || ch in '\u4E00'..'\u9FFF' -> jp++
                ch in 'A'..'Z' || ch in 'a'..'z' -> la++
            }
        }
        val n = ar + jp + la
        if (n < 3) return null
        return when {
            ar * 100 >= n * 60 -> "fa"
            jp * 100 >= n * 40 -> "ja"
            la * 100 >= n * 60 -> "en"
            else -> null
        }
    }
}
