package app.tarjoman

/** Persian text clean-up and a tiny script-based language guesser (no extra libraries). */
object Fa {
    private val qm = Regex("(?<=[\\u0600-\\u06FF])(\\s*)\\?")
    private val comma = Regex("(?<=[\\u0600-\\u06FF]),")

    /** Fix typical machine-translation leftovers: Arabic ي/ك, Arabic digits, Latin ? and , after Persian words. */
    fun fix(t: String): String {
        if (t.isEmpty()) return t
        val sb = StringBuilder(t.length)
        for (ch in t) {
            when (ch) {
                '\u064A', '\u0649' -> sb.append('\u06CC')
                '\u0643' -> sb.append('\u06A9')
                in '\u0660'..'\u0669' -> sb.append('\u06F0' + (ch - '\u0660'))
                else -> sb.append(ch)
            }
        }
        var r = sb.toString()
        r = qm.replace(r) { it.groupValues[1] + "\u061F" }
        r = comma.replace(r, "\u060C")
        return r
    }

    /** "fa" / "ja" / "en" when one script clearly dominates the letters, else null. */
    fun guess(t: String): String? {
        var ar = 0; var jp = 0; var la = 0
        for (ch in t) {
            when {
                ch in '\u0600'..'\u06FF' -> ar++
                ch in '\u3040'..'\u30FF' || ch in '\u4E00'..'\u9FFF' -> jp++
                ch in 'A'..'Z' || ch in 'a'..'z' -> la++
            }
        }
        val n = ar + jp + la
        if (n < 3) return null
        return when {
            ar * 100 >= n * 60 -> "fa"
            jp * 100 >= n * 40 -> "ja"
            la * 100 >= n * 60 -> "en"
            else -> null
        }
    }
}
