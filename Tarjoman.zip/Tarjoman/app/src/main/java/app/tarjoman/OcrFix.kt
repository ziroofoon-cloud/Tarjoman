package app.tarjoman

/**
 * Clean-up of English text that comes out of OCR: the typical look-alike mistakes (l / I / | / 1, O / 0), curly quotes,
 * spaces before punctuation, stray marks. Conservative on purpose: a word is only changed when the mistake is very likely.
 */
object OcrFix {
    private val tokRe = Regex("^([^A-Za-z0-9|]*)(.*?)([^A-Za-z0-9|]*)$", RegexOption.DOT_MATCHES_ALL)
    private val contraction = Regex("^[|lI1]['](m|ll|d|ve|s|re)$", RegexOption.IGNORE_CASE)
    private val noise = Regex("^[~`^_*#<>{}\\\\/=+]+$")
    private val spaceBefore = Regex("\\s+([,.!?;:])")
    private val manyDots = Regex("(\\.\\s?){3,}")

    /** Joins the lines of one block: "hyphen-" + "ated" becomes one word, other line breaks become a space. */
    fun joinLines(lines: List<String>): String {
        val sb = StringBuilder()
        for (raw in lines) {
            val ln = raw.trim()
            if (ln.isEmpty()) continue
            if (sb.isEmpty()) { sb.append(ln); continue }
            val last = sb[sb.length - 1]
            if (last == '-' && sb.length >= 2 && sb[sb.length - 2].isLetter() && ln[0].isLowerCase()) {
                sb.setLength(sb.length - 1)
                sb.append(ln)
            } else {
                sb.append(' ').append(ln)
            }
        }
        return sb.toString()
    }

    fun en(t0: String, lex: Boolean = true): String {
        var t = t0
            .replace('’', '\'').replace('‘', '\'').replace('`', '\'').replace('´', '\'')
            .replace('“', '"').replace('”', '"').replace(' ', ' ')
        val toks = t.split(Regex("\\s+")).filter { it.isNotEmpty() }
        val out = ArrayList<String>(toks.size)
        for ((i, tok) in toks.withIndex()) {
            val m = tokRe.find(tok)
            if (m == null) { out.add(tok); continue }
            val pre = m.groupValues[1]
            var core = m.groupValues[2]
            val post = m.groupValues[3]
            if (core.isEmpty()) {
                if (noise.matches(tok)) continue
                out.add(tok)
                continue
            }
            val nextAlpha = i + 1 < toks.size && toks[i + 1].firstOrNull()?.isLetter() == true
            core = when {
                core == "|" -> if (nextAlpha || (i > 0)) "I" else ""
                core == "l" -> "I"
                contraction.matches(core) -> "I" + core.substring(1)
                else -> fixWord(core).let { w -> if (lex) lexFix(w, i == 0) else w }
            }
            if (core.isEmpty() && pre.isEmpty() && post.isEmpty()) continue
            out.add(pre + core + post)
        }
        t = out.joinToString(" ")
        t = spaceBefore.replace(t, "$1")
        t = manyDots.replace(t, "...")
        return t.trim()
    }

    private val shortOk = setOf("i","a","an","am","as","at","be","by","do","go","he","if","in","is","it","me","my","no","of","oh","ok","on","or","so","to","up","us","we","ah","uh","hm","eh","ha","hi","yo","ow","ew","aw","oi","mm","um","ya","ye","id","pa","ma","pc","tv","dr","mr","ms","vs")

    /**
     * True when a reading looks like real text. Art, screentone and scribbles read as letters give tokens such as "IY", "NR"
     * (two letters that are no word) mixed with a few word-like ones. A token is good when it is a short real word, a number,
     * or has 3+ letters with a vowel; a box is kept when at least 60% of its tokens are good. Rare words and names are fine
     * (the built-in word list is small, so it is not used here).
     */
    fun plausible(t: String): Boolean {
        var good = 0
        var all = 0
        for (tok in t.split(Regex("\\s+"))) {
            val core = tok.trim { !it.isLetterOrDigit() }
            if (core.isEmpty()) continue
            all++
            val l = core.lowercase()
            when {
                core.all { it.isDigit() } -> good++
                core.length <= 2 -> if (l in shortOk) good++
                core.all { it.isLetter() || it == '\'' || it == '-' } && (l.any { it in "aeiouy" } || core.length >= 4) -> good++
            }
        }
        if (all == 0) return false
        if (all == 1) return good == 1 || t.count { it.isLetter() } >= 3
        return good * 100 >= all * 60
    }

    /**
     * Removes fragments that drawings, screentone and cut-off letters add to a real sentence: marks such as "(||!" "[" ")",
     * two-letter non-words ("IY", "nr", "wl", "er", "aN"), lone digits, and, in a mostly UPPERCASE box (comic lettering),
     * lowercase words that are not English ("mesenoo"). Real words, names and numbers like "#3" stay.
     */
    fun dropStray(t: String): String {
        val toks = t.split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (toks.size < 2) return t
        val letters = t.filter { it.isLetter() }
        val upperBox = letters.length >= 4 && letters.count { it.isUpperCase() } * 100 >= letters.length * 60
        val out = ArrayList<String>(toks.size)
        for ((i, tok) in toks.withIndex()) {
            val core = tok.trim { !it.isLetterOrDigit() }
            if (core.isEmpty()) {
                // only real sentence marks stay ("...", "?!"); brackets, bars and dashes of drawings go
                if (i == toks.size - 1 && tok.all { it == '.' || it == ',' || it == '!' || it == '?' || it == '\u2026' || it == '\'' || it == '"' }) out.add(tok)
                continue
            }
            val l = core.lowercase()
            if (core.all { it.isDigit() }) {
                if (core.length == 1 && !tok.startsWith("#") && (i == 0 || !toks[i - 1].endsWith("#"))) continue
                out.add(tok); continue
            }
            if (core.length <= 2) {
                val mixed = core.length == 2 && core[0].isLowerCase() && core[1].isUpperCase()
                if (mixed || (l !in shortOk && core.length == 2) || (core.length == 1 && l != "i" && l != "a" && !core[0].isDigit())) continue
                out.add(tok); continue
            }
            if (upperBox && core.all { it.isLowerCase() || it == '\'' } && !Lex.has(core) && !(core.length >= 4 && Translit.romajiToFa(core) != null)) continue
            out.add(tok)
        }
        return out.joinToString(" ")
    }

    /** A word of letters that is not English but becomes one with a single look-alike repair (rn -> m, cl -> d, 0 -> o ...). Names are left alone. */
    private fun lexFix(w: String, first: Boolean): String {
        if (w.length < 3 || !w.all { it.isLetterOrDigit() || it == '\'' }) return w
        if (w[0].isUpperCase() && !first && w.drop(1).any { it.isLowerCase() } && w.none { it.isDigit() }) return lookAlike(w)
        val r = Lex.repair(w)
        if (r != w) return r
        // Still not a word (a letter too many or missing, e.g. "mnafia"): one very likely fix from the wide word list. Only plain
        // lower-case words of 5+ letters; names, capitals and short words are never touched.
        if (w.length >= 5 && w.all { it in 'a'..'z' } && !Lex.hasWide(w)) {
            val f = Spell.suggest(w)
            if (f != null && f.cost <= 6) return f.to
        }
        return lookAlike(w)
    }

    /** Letters a reader mixes up: one of them in place of another. */
    private val confuse: Map<Char, String> = mapOf(
        'o' to "dcqe0a", 'd' to "oq", 'c' to "oe", 'e' to "co", 'a' to "o", 'q' to "og", 'g' to "qa",
        'l' to "it1", 'i' to "lt1j", 't' to "li", 'u' to "vn", 'v' to "uy", 'n' to "uh", 'h' to "nb", 'b' to "h", 'm' to "n",
        's' to "5", 'y' to "v", 'r' to "n", 'f' to "t", 'p' to "o"
    )

    /**
     * A word that is not in the word list, with ONE letter replaced by a look-alike that gives a known word and no other look-alike
     * does ("Schodl" -> "School", "DCCult" -> "Occult"): the reader's slip is repaired. Names are safe: a name only changes when
     * exactly one look-alike variant of it is a real word. The capitals of the original are kept.
     */
    private fun lookAlike(w: String): String {
        if (w.length < 4 || w.length > 16 || !w.all { it.isLetter() && it.code < 128 }) return w
        val low = w.lowercase()
        if (Spell.known(low)) return w
        var found: String? = null
        for (i in low.indices) {
            val alts = confuse[low[i]] ?: continue
            for (ch in alts) {
                val cand = low.substring(0, i) + ch + low.substring(i + 1)
                if (Spell.known(cand)) {
                    if (found != null && found != cand) return w     // two possible words: leave it
                    found = cand
                }
            }
        }
        val f = found ?: return w
        return if (w.all { it.isUpperCase() }) f.uppercase() else if (w[0].isUpperCase()) f.replaceFirstChar { it.uppercase() } else f
    }

    private fun fixWord(w: String): String {
        val letters = w.count { it.isLetter() }
        if (letters < 2) return w
        val upper = w.count { it.isUpperCase() }
        val lower = w.count { it.isLowerCase() }
        val chars = w.toCharArray()
        val upperWord = upper > lower
        for (i in chars.indices) {
            val c = chars[i]
            val prevL = i > 0 && chars[i - 1].isLetter()
            val nextL = i + 1 < chars.size && chars[i + 1].isLetter()
            when (c) {
                '0' -> if (prevL && nextL) chars[i] = if (upperWord) 'O' else 'o'
                '1' -> if (prevL && nextL) chars[i] = if (upperWord) 'I' else 'l'
                '5' -> if (prevL && nextL && upperWord) chars[i] = 'S'
                'l' -> if (upperWord && lower <= 1 + upper / 4) chars[i] = 'I'
                '|' -> if (prevL || nextL) chars[i] = if (upperWord) 'I' else 'l'
            }
        }
        // Capital I in the middle of a lowercase word is an "l" (wiII -> will, Iittle -> little).
        var othersLower = true
        for (c in chars) if (c != 'I' && c.isUpperCase()) { othersLower = false; break }
        if (othersLower && lower >= 2) {
            for (i in 1 until chars.size) {
                if (chars[i] == 'I' && (chars[i - 1].isLowerCase() || chars[i - 1] == 'I' || chars[i - 1] == 'l')
                    && (i + 1 >= chars.size || chars[i + 1].isLowerCase() || chars[i + 1] == 'I' || chars[i + 1] == 'l' || !chars[i + 1].isLetter())) chars[i] = 'l'
            }
        }
        return String(chars)
    }

    private val faNoiseTok = Regex("^[A-Za-z|_~^*#<>{}\\\\/=+]{1,2}$")
    private val faLetter = Regex("[\\u0600-\\u06FF]")

    /**
     * Persian OCR (Tesseract) leaves stray Latin letters, bars and dots between words, tatweel, and spaces before ، ؟ . :
     * Isolated 1-2 character Latin / symbol tokens next to Persian words are dropped.
     */
    fun fa(t0: String): String {
        val t = t0.replace("\u0640", "").replace("\u200F", "").replace("\u200E", "").replace('\u00A0', ' ')
        val toks = t.split(Regex("\\s+")).filter { it.isNotEmpty() }
        val out = ArrayList<String>(toks.size)
        for ((i, tok) in toks.withIndex()) {
            if (faNoiseTok.matches(tok)) {
                val prevFa = i > 0 && faLetter.containsMatchIn(toks[i - 1])
                val nextFa = i + 1 < toks.size && faLetter.containsMatchIn(toks[i + 1])
                if (prevFa || nextFa) continue
            }
            out.add(tok)
        }
        var r = out.joinToString(" ")
        r = Regex("\\s+([\u060C\u061B\u061F,.!:;])").replace(r, "$1")
        r = Regex("([.]{4,})").replace(r, "...")
        return r.trim()
    }
}
