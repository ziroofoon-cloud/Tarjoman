package app.tarjoman

/**
 * Clean-up of English text that comes out of OCR: the typical look-alike mistakes (l / I / | / 1, O / 0), curly quotes,
 * spaces before punctuation, stray marks. Conservative on purpose: a word is only changed when the mistake is very likely.
 */
object OcrFix {
    private val tokRe = Regex("^([^A-Za-z0-9|]*)(.*?)([^A-Za-z0-9|]*)$", RegexOption.DOT_MATCHES_ALL)
    private val contraction = Regex("^[|lI1]['](m|ll|d|ve|s|re)$", RegexOption.IGNORE_CASE)
    private val noise = Regex("^[~`^_*#<>{}\\\\/=+]+$")
    private val spaceBefore = Regex("\\s+([,.!?;:])")
    private val manyDots = Regex("(\\.\\s?){3,}")

    /** Joins the lines of one block: "hyphen-" + "ated" becomes one word, other line breaks become a space. */
    fun joinLines(lines: List<String>): String {
        val sb = StringBuilder()
        for (raw in lines) {
            val ln = raw.trim()
            if (ln.isEmpty()) continue
            if (sb.isEmpty()) { sb.append(ln); continue }
            val last = sb[sb.length - 1]
            if (last == '-' && sb.length >= 2 && sb[sb.length - 2].isLetter() && ln[0].isLowerCase()) {
                sb.setLength(sb.length - 1)
                sb.append(ln)
            } else {
                sb.append(' ').append(ln)
            }
        }
        return sb.toString()
    }

    fun en(t0: String): String {
        var t = t0
            .replace('’', '\'').replace('‘', '\'').replace('`', '\'').replace('´', '\'')
            .replace('“', '"').replace('”', '"').replace(' ', ' ')
        val toks = t.split(Regex("\\s+")).filter { it.isNotEmpty() }
        val out = ArrayList<String>(toks.size)
        for ((i, tok) in toks.withIndex()) {
            val m = tokRe.find(tok)
            if (m == null) { out.add(tok); continue }
            val pre = m.groupValues[1]
            var core = m.groupValues[2]
            val post = m.groupValues[3]
            if (core.isEmpty()) {
                if (noise.matches(tok)) continue
                out.add(tok)
                continue
            }
            val nextAlpha = i + 1 < toks.size && toks[i + 1].firstOrNull()?.isLetter() == true
            core = when {
                core == "|" -> if (nextAlpha || (i > 0)) "I" else ""
                core == "l" -> "I"
                contraction.matches(core) -> "I" + core.substring(1)
                else -> fixWord(core)
            }
            if (core.isEmpty() && pre.isEmpty() && post.isEmpty()) continue
            out.add(pre + core + post)
        }
        t = out.joinToString(" ")
        t = spaceBefore.replace(t, "$1")
        t = manyDots.replace(t, "...")
        return t.trim()
    }

    private fun fixWord(w: String): String {
        val letters = w.count { it.isLetter() }
        if (letters < 2) return w
        val upper = w.count { it.isUpperCase() }
        val lower = w.count { it.isLowerCase() }
        val chars = w.toCharArray()
        val upperWord = upper > lower
        for (i in chars.indices) {
            val c = chars[i]
            val prevL = i > 0 && chars[i - 1].isLetter()
            val nextL = i + 1 < chars.size && chars[i + 1].isLetter()
            when (c) {
                '0' -> if (prevL && nextL) chars[i] = if (upperWord) 'O' else 'o'
                '1' -> if (prevL && nextL) chars[i] = if (upperWord) 'I' else 'l'
                '5' -> if (prevL && nextL && upperWord) chars[i] = 'S'
                'l' -> if (upperWord && lower <= 1 + upper / 4) chars[i] = 'I'
                '|' -> if (prevL || nextL) chars[i] = if (upperWord) 'I' else 'l'
            }
        }
        // Capital I in the middle of a lowercase word is an "l" (wiII -> will, Iittle -> little).
        var othersLower = true
        for (c in chars) if (c != 'I' && c.isUpperCase()) { othersLower = false; break }
        if (othersLower && lower >= 2) {
            for (i in 1 until chars.size) {
                if (chars[i] == 'I' && (chars[i - 1].isLowerCase() || chars[i - 1] == 'I' || chars[i - 1] == 'l')
                    && (i + 1 >= chars.size || chars[i + 1].isLowerCase() || chars[i + 1] == 'I' || chars[i + 1] == 'l' || !chars[i + 1].isLetter())) chars[i] = 'l'
            }
        }
        return String(chars)
    }

    private val faNoiseTok = Regex("^[A-Za-z|_~^*#<>{}\\\\/=+]{1,2}$")
    private val faLetter = Regex("[\\u0600-\\u06FF]")

    /**
     * Persian OCR (Tesseract) leaves stray Latin letters, bars and dots between words, tatweel, and spaces before ، ؟ . :
     * Isolated 1-2 character Latin / symbol tokens next to Persian words are dropped.
     */
    fun fa(t0: String): String {
        val t = t0.replace("\u0640", "").replace("\u200F", "").replace("\u200E", "").replace('\u00A0', ' ')
        val toks = t.split(Regex("\\s+")).filter { it.isNotEmpty() }
        val out = ArrayList<String>(toks.size)
        for ((i, tok) in toks.withIndex()) {
            if (faNoiseTok.matches(tok)) {
                val prevFa = i > 0 && faLetter.containsMatchIn(toks[i - 1])
                val nextFa = i + 1 < toks.size && faLetter.containsMatchIn(toks[i + 1])
                if (prevFa || nextFa) continue
            }
            out.add(tok)
        }
        var r = out.joinToString(" ")
        r = Regex("\\s+([\u060C\u061B\u061F,.!:;])").replace(r, "$1")
        r = Regex("([.]{4,})").replace(r, "...")
        return r.trim()
    }
}
