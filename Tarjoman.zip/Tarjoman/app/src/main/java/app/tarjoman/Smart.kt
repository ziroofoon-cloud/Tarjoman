package app.tarjoman

import android.app.ActivityManager
import android.content.Context

/**
 * One switch for "how much effort": Fast / Balanced / Accurate / Smart. While it is not "custom", it overrides the detailed
 * settings (reader, text finder, cleaning model, picture size, engine, speed) without touching what the user saved: set it back
 * to "custom" and every old choice is there again. "Smart" picks the level for what is being translated (live screen, subtitles,
 * a picture, a manga archive, a PDF, plain text) and for the phone (memory), so no setting has to be known.
 */
object Smart {
    /** What is being translated now: text | sub | image | manga | pdf | live. Set by each tool when it starts. */
    @Volatile var task = "text"
    @Volatile var hasAi = false
    @Volatile var lowRam = false
    @Volatile var safe = false   // mirrors cfg.safe (set by Cfg)

    fun init(ctx: Context) {
        try {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            lowRam = mi.totalMem < 3_500_000_000L || am.isLowRamDevice
        } catch (_: Throwable) {}
    }

    /** The level that really applies now. */
    fun effective(level: String): String = when (level) {
        "fast", "balanced", "accurate" -> level
        "smart" -> when (task) {
            "live" -> "fast"
            "text", "sub" -> if (hasAi && !lowRam) "accurate" else "balanced"
            "pdf" -> "balanced"
            "image", "manga" -> if (lowRam) "balanced" else "accurate"
            else -> "balanced"
        }
        else -> "balanced"
    }

    /** Reliable mode: only the plain on-phone path (ML Kit / Tesseract reading, simple filling, the normal engine); nothing new or heavy. */
    fun safeValue(k: String): String? = when (k) {
        "mode" -> "normal"
        "speed" -> "fast"
        "ocrPaddle" -> "off"
        "ocrDetect" -> "0"
        "lama" -> "0"
        "lamaAll" -> "0"
        "visionOcr" -> "0"
        "visionMissing" -> "0"
        "ocrEn" -> "auto"
        "imgKind" -> "auto"
        "mzMaxPx" -> "1600"
        else -> null
    }

    /** Value that replaces setting [k] at [level], or null = the user's own value stays. */
    fun value(level: String, k: String): String? {
        val e = effective(level)
        return when (k) {
            "speed" -> if (e == "fast") "fast" else if (e == "accurate") "slow" else "fast"
            "mode" -> if (e != "fast" && hasAi && !(e == "balanced" && lowRam)) "advanced" else "normal"
            "ocrPaddle" -> if (e == "fast") "off" else "auto"
            "ocrDetect" -> if (e == "fast") "0" else "1"
            "ocrEnPre" -> if (e == "fast") "off" else if (e == "accurate") "on" else "auto"
            "ocrFaPre" -> if (e == "fast") "gray" else "auto"
            "ocrFaModel" -> if (e == "fast") "fast" else "auto"
            "paddleDet" -> if (e == "accurate") "big" else if (e == "fast") "small" else "auto"
            "paddleSide" -> if (e == "fast") "960" else if (e == "accurate") "1664" else "1280"
            "lamaAll" -> if (e == "accurate") "1" else "0"
            "mzMaxPx" -> if (e == "fast") "1200" else if (e == "accurate") "2200" else "1600"
            "visionMissing" -> if (e == "fast") "0" else null
            else -> null
        }
    }
}
