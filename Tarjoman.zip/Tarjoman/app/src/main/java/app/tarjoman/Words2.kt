package app.tarjoman

/**
 * More everyday English words (base forms; plurals and -ed / -ing / -ly are found by the stem rules of Lex.hasWide).
 * They are used to tell real sentences from reading noise and by the spell checker; they are never used to rewrite a word.
 */
object Words2 {
    val LIST: List<String> by lazy { DATA.split(' ', '\n').filter { it.isNotBlank() } }

    private const val DATA = """
mafia gang crime criminal police officer detective prison jail guard bodyguard protect protection protector shield
government president minister mayor senator congress parliament election vote voter party leader nation national
country state city capital border army navy soldier military weapon bomb missile rocket nuclear peace war conflict
permission permit allow forbid ban illegal legal law lawyer judge court trial jury sentence guilty innocent evidence
shoot film movie cinema actor actress director producer camera scene studio episode season series show stage concert
music song singer band album lyrics dance dancer artist painter painting picture photo photograph portrait gallery
famous celebrity fan star idol legend icon hero villain character story novel author writer poet poem chapter page
video channel stream streamer subscribe subscriber follow follower comment reply message post share like dislike
upload download link click tap swipe scroll screen phone mobile tablet laptop computer keyboard mouse internet online
website browser search engine email password account profile username login logout settings option button menu icon
app application software program code data file folder document text word sentence paragraph letter number digit
network server cloud storage memory battery charger cable wire signal wifi bluetooth camera lens screen speaker
robot machine engine motor vehicle car truck bus train plane airplane airport station ticket passport visa luggage
hotel resort beach island mountain valley river lake ocean sea forest desert jungle field farm village town street
road bridge tunnel building tower castle palace temple church mosque school college university classroom teacher
student professor lesson homework exam test quiz grade degree diploma subject science math history geography art
doctor nurse hospital clinic patient medicine pill drug disease illness fever cough pain wound injury surgery health
healthy sick weak strong tired sleepy hungry thirsty angry sad happy lonely nervous anxious worried scared brave
excited bored jealous proud ashamed guilty embarrassed confused surprised shocked disgusted grateful hopeful
love hate friend enemy family parent mother father brother sister cousin uncle aunt grandmother grandfather
husband wife boyfriend girlfriend partner couple wedding marriage divorce baby child kid teenager adult elder
boss worker employee manager customer client company business office factory market shop store mall restaurant
cafe bar pub club kitchen bedroom bathroom garage garden yard balcony roof floor ceiling wall window door gate
breakfast lunch dinner meal snack food drink water juice milk coffee tea beer wine bread butter cheese egg meat
chicken beef pork fish rice pasta pizza burger sandwich salad soup fruit apple banana orange grape lemon cake
chocolate candy sugar salt pepper sauce spice vegetable potato tomato onion carrot bean corn
money cash coin dollar price cost pay payment bank card credit debt loan rich poor cheap expensive worth value
salary income tax budget profit loss sale discount offer deal contract agreement rule policy plan project goal
success failure victory defeat winner loser champion player coach team match game score point goal ball
football soccer basketball baseball tennis golf boxing wrestling race racing runner swimming swimmer
history past present future ancient modern century decade year month week today tomorrow yesterday tonight
morning afternoon evening midnight noon moment minute second hour clock calendar schedule
weather sunny cloudy rainy windy stormy snowy foggy thunder lightning rainbow temperature degree warm cool
spring summer autumn winter season flower tree grass leaf plant seed animal dog cat horse cow sheep goat
pig chicken duck bird eagle owl snake spider insect bee butterfly monkey tiger lion elephant bear wolf fox
rabbit mouse rat bat shark whale dolphin
color colour white black red blue green yellow orange purple pink brown gray grey golden silver
big large huge giant small little tiny short tall long wide narrow thick thin heavy light dark bright
fast slow quick sudden early late ancient new old young fresh clean dirty empty full open closed
easy difficult hard simple complex possible impossible necessary important special different similar
real fake true false right wrong correct perfect terrible horrible awful wonderful amazing awesome
excellent fantastic brilliant beautiful ugly pretty cute lovely gorgeous handsome
polite rude kind cruel gentle fierce honest dishonest loyal selfish generous lazy clever stupid smart
foolish wise crazy insane mad weird strange normal ordinary unusual funny serious silly
remember forget imagine dream wonder realize notice recognize understand explain describe discuss argue
agree disagree refuse accept reject admit deny confess promise swear lie cheat steal rob kidnap murder
kill die dead alive survive escape rescue save protect defend attack fight punch kick slap hit
arrest capture release free freedom prison punish reward blame forgive apologize regret
travel visit explore discover invent create build destroy break fix repair clean wash cook bake fry boil
open close lock unlock push pull lift drop throw catch carry bring take give send receive deliver
borrow lend rent hire fire quit resign retire apply interview hire
smile laugh cry scream shout whisper sigh yawn blink wave nod shrug stare glare gaze
grab hold squeeze shake wipe rub scratch tickle pinch bite chew swallow spit lick
climb jump crawl slide slip trip fall faint collapse bleed breathe sneeze burp
hug kiss date marry propose engage flirt cheat
pray worship bless curse haunt ghost spirit demon angel devil monster alien zombie vampire witch wizard
magic spell curse power ability skill talent strength energy force speed
sword gun pistol rifle knife blade arrow shield armor
treasure secret mystery clue puzzle riddle answer question reason cause effect result
opinion idea thought belief faith hope fear doubt trust respect honor shame pride
instead although however therefore otherwise meanwhile besides moreover nevertheless
unexpected unlikely unfortunately fortunately probably definitely certainly obviously actually
literally basically honestly seriously absolutely totally completely entirely extremely
kinda sorta gonna wanna gotta lemme gimme dunno yeah nope yep okay bro dude buddy mate guys
"""
}
