package app.tarjoman

import android.app.Activity
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast

/** Sign-in state of huggingface.co kept by the app (the session cookie of the in-app browser). */
object Hf {
    fun signedIn(cfg: Cfg): Boolean = cfg.hfCookie.contains("token=")

    fun signOut(cfg: Cfg) {
        cfg.hfCookie = ""
        try {
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
        } catch (_: Throwable) {}
    }
}

/**
 * A small browser for huggingface.co: sign in with your own account, press "Acknowledge license" on the model page,
 * then "Done". The app keeps the session cookie and uses it for the download, so no token is needed.
 */
class HfLoginActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val next = try { java.net.URL(intent.getStringExtra("next") ?: "").path } catch (_: Throwable) { "" }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; fitsSystemWindows = true }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val back = Button(this).apply { text = L("عقب"); setOnClickListener { if (web.canGoBack()) web.goBack() } }
        val done = Button(this).apply { text = L("تمام"); setOnClickListener { saveAndClose() } }
        bar.addView(back, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(done, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        web.loadUrl(
            if (next.isNotBlank() && next != "/") "https://huggingface.co/login?next=" + java.net.URLEncoder.encode(next, "UTF-8")
            else "https://huggingface.co/login"
        )
    }

    private fun save(): Boolean {
        val cfg = Cfg(this)
        try { CookieManager.getInstance().flush() } catch (_: Throwable) {}
        cfg.hfCookie = try { CookieManager.getInstance().getCookie("https://huggingface.co") ?: "" } catch (_: Throwable) { "" }
        return Hf.signedIn(cfg)
    }

    private fun saveAndClose() {
        val ok = save()
        Toast.makeText(this, if (ok) L("ورود انجام شد ✓") else L("هنوز وارد نشده‌ای"), Toast.LENGTH_SHORT).show()
        setResult(RESULT_OK)
        finish()
    }

    override fun onPause() { save(); super.onPause() }

    @Suppress("DEPRECATION")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else saveAndClose() }

    override fun onDestroy() {
        try { web.destroy() } catch (_: Throwable) {}
        super.onDestroy()
    }
}
