package app.tarjoman

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

/** Home-screen widget with three quick buttons: type text, speak, translate a picture. */
class Widget : AppWidgetProvider() {
    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        for (id in ids) {
            val v = RemoteViews(context.packageName, R.layout.widget_tarjoman)
            fun pi(code: Int, action: String): PendingIntent {
                val i = Intent(context, MainActivity::class.java).apply {
                    this.action = action
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                }
                return PendingIntent.getActivity(context, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            }
            v.setOnClickPendingIntent(R.id.w_text, pi(1, "app.tarjoman.WIDGET_TEXT"))
            v.setOnClickPendingIntent(R.id.w_mic, pi(2, "app.tarjoman.WIDGET_MIC"))
            v.setOnClickPendingIntent(R.id.w_img, pi(3, "app.tarjoman.WIDGET_IMAGE"))
            mgr.updateAppWidget(id, v)
        }
    }
}
