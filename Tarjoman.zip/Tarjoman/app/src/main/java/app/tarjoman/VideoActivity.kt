package app.tarjoman

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * A small browser for YouTube and other sites whose video player shows subtitles (captions).
 * A script in the page reads the caption that is on screen (YouTube's player, or any <video> text track),
 * the app translates it at once with the fast engine and shows the translation under the video.
 * The page's own captions can be hidden so only the translation is seen. No sign-up is needed.
 * Twitch / Kick have no captions to read, so they cannot be translated this way.
 */
class VideoActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var cfg: Cfg
    private lateinit var tr: Tr
    private lateinit var ui: Ui
    private lateinit var root: FrameLayout
    private lateinit var main: LinearLayout
    private lateinit var fsBox: FrameLayout
    private lateinit var web: WebView
    private lateinit var urlEdit: EditText
    private lateinit var srcBtn: TextView
    private lateinit var dstBtn: TextView
    private lateinit var transBtn: TextView
    private lateinit var origBtn: TextView
    private lateinit var statusTv: TextView
    private lateinit var strip: LinearLayout
    private lateinit var origTv: TextView
    private lateinit var transTv: TextView

    private var custom: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private var savedMode: String? = null

    @Volatile private var latest = ""
    @Volatile private var changedAt = 0L
    @Volatile private var doneFor = ""
    @Volatile private var busy = false
    private var vidBottom = 0
    private var transOn = true
    private var hideOrig = true

    inner class Bridge {
        @JavascriptInterface
        fun cue(t: String) {
            latest = t
            changedAt = SystemClock.uptimeMillis()
        }

        @JavascriptInterface
        fun rect(b: Int) {
            h.post { vidBottom = b; placeStrip() }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        cfg = Cfg(this)
        C.setup(this, cfg)
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = C.BG
        window.navigationBarColor = C.BG
        ui = Ui(this)
        tr = Tr.get(this)
        // Subtitles come fast: the quick Normal engine is used while this screen is open (restored on exit).
        if (cfg.mode == "advanced") { savedMode = cfg.mode; cfg.mode = "normal" }

        root = FrameLayout(this)
        root.setBackgroundColor(C.BG)
        main = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; fitsSystemWindows = true }

        // row 1: close, address, go
        val r1 = ui.hbox()
        r1.setPadding(ui.dp(8), ui.dp(6), ui.dp(8), 0)
        r1.addView(ui.btn(L("بستن"), false) { finish() }, LinearLayout.LayoutParams(ui.dp(72), -2))
        urlEdit = ui.edit(L("لینک یا جستجو…"))
        urlEdit.setSingleLine(true)
        urlEdit.setOnEditorActionListener { _, _, _ -> go(urlEdit.text.toString()); true }
        r1.addView(urlEdit, ui.hlp(1f, 6))
        r1.addView(ui.btn(L("برو")) { go(urlEdit.text.toString()) }, LinearLayout.LayoutParams(ui.dp(64), -2).apply { marginStart = ui.dp(6) })
        main.addView(r1)

        // row 2: languages
        val r2 = ui.hbox()
        r2.setPadding(ui.dp(8), ui.dp(6), ui.dp(8), 0)
        srcBtn = ui.btn("", true) { pick(true) }
        dstBtn = ui.btn("", false) { pick(false) }
        r2.addView(srcBtn, ui.hlp(1f))
        r2.addView(ui.iconBtn("swap", 44, true) { val a = cfg.src; cfg.src = cfg.dst; cfg.dst = a; refreshLang() },
            LinearLayout.LayoutParams(ui.dp(44), ui.dp(44)).apply { marginStart = ui.dp(4); marginEnd = ui.dp(4) })
        r2.addView(dstBtn, ui.hlp(1f))
        main.addView(r2)

        // row 3: switches
        val r3 = ui.hbox()
        r3.setPadding(ui.dp(8), ui.dp(6), ui.dp(8), ui.dp(4))
        transBtn = ui.btn("", true) { transOn = !transOn; applyState() }
        origBtn = ui.btn("", false) { hideOrig = !hideOrig; applyState() }
        r3.addView(transBtn, ui.hlp(1f))
        r3.addView(origBtn, ui.hlp(1f, 6))
        r3.addView(ui.btn("YouTube", false) { web.loadUrl("https://m.youtube.com/") }, LinearLayout.LayoutParams(ui.dp(92), -2).apply { marginStart = ui.dp(6) })
        main.addView(r3)

        statusTv = ui.tv(L("زیرنویس (CC) ویدیو را روشن کن تا ترجمه شروع شود."), 11f, C.SUB)
        statusTv.setPadding(ui.dp(12), 0, ui.dp(12), ui.dp(4))
        main.addView(statusTv)

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.addJavascriptInterface(Bridge(), "TJ")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, req: WebResourceRequest): Boolean {
                val u = req.url.toString()
                return !(u.startsWith("http://") || u.startsWith("https://"))
            }

            override fun onPageFinished(v: WebView, url: String) {
                if (!urlEdit.hasFocus()) urlEdit.setText(url)
                inject()
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View, cb: CustomViewCallback) {
                if (custom != null) { cb.onCustomViewHidden(); return }
                custom = view
                customCb = cb
                fsBox.addView(view, FrameLayout.LayoutParams(-1, -1))
                fsBox.visibility = View.VISIBLE
                main.visibility = View.GONE
                window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                placeStrip()
            }

            override fun onHideCustomView() { leaveFullscreen() }
        }
        main.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(main, FrameLayout.LayoutParams(-1, -1))

        fsBox = FrameLayout(this)
        fsBox.setBackgroundColor(Color.BLACK)
        fsBox.visibility = View.GONE
        root.addView(fsBox, FrameLayout.LayoutParams(-1, -1))

        // the translation, drawn above the page and above the full-screen video
        strip = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xCC000000.toInt())
            setPadding(ui.dp(14), ui.dp(8), ui.dp(14), ui.dp(10))
            visibility = View.GONE
        }
        origTv = TextView(this).apply {
            textSize = 12f; setTextColor(0xFFBBBBBB.toInt()); gravity = Gravity.CENTER
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        }
        transTv = TextView(this).apply {
            textSize = 19f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        strip.addView(origTv)
        strip.addView(transTv, ui.lp(top = 3))
        root.addView(strip, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)

        refreshLang()
        applyState()
        val first = intent.getStringExtra("url")?.trim().orEmpty()
        if (first.isNotEmpty()) go(first) else web.loadUrl("https://m.youtube.com/")
        h.post(pump)
    }

    private fun go(raw: String) {
        val u0 = raw.trim()
        if (u0.isEmpty()) return
        val u = if (u0.startsWith("http://") || u0.startsWith("https://")) u0
        else if (u0.contains(".") && !u0.contains(" ")) "https://" + u0
        else "https://m.youtube.com/results?search_query=" + java.net.URLEncoder.encode(u0, "UTF-8")
        urlEdit.clearFocus()
        web.loadUrl(u)
    }

    private fun pick(isSrc: Boolean) {
        val items = Lang.all.map { Lang.name(it) }.toTypedArray()
        AlertDialog.Builder(this).setItems(items) { _, i ->
            val c = Lang.all[i]
            if (isSrc) { if (c == cfg.dst) cfg.dst = cfg.src; cfg.src = c }
            else { if (c == cfg.src) cfg.src = cfg.dst; cfg.dst = c }
            refreshLang()
        }.show()
    }

    private fun refreshLang() {
        srcBtn.text = Lang.name(cfg.src).substringBefore(" ·")
        dstBtn.text = Lang.name(cfg.dst).substringBefore(" ·")
        doneFor = ""   // translate the caption on screen again in the new languages
    }

    private fun applyState() {
        transBtn.text = if (transOn) L("ترجمه: روشن") else L("ترجمه: خاموش")
        origBtn.text = if (hideOrig) L("زیرنویس اصلی: پنهان") else L("زیرنویس اصلی: نمایان")
        if (!transOn) strip.visibility = View.GONE
        applyHide()
    }

    private fun applyHide() {
        val hide = hideOrig && transOn
        try { web.evaluateJavascript("window.__tjHide&&window.__tjHide(" + hide + ")", null) } catch (_: Throwable) {}
    }

    private fun inject() {
        try { web.evaluateJavascript(SCRIPT, null) } catch (_: Throwable) {}
        applyHide()
    }

    // ------------------------------------------------------------ translating the caption on screen
    private val pump = object : Runnable {
        override fun run() {
            try { step() } catch (_: Throwable) {}
            h.postDelayed(this, 150)
        }
    }

    private fun step() {
        if (!transOn) return
        val t = latest
        val now = SystemClock.uptimeMillis()
        if (t.isEmpty()) {
            if (doneFor.isNotEmpty() && now - changedAt > 700) { doneFor = ""; strip.visibility = View.GONE }
            return
        }
        if (t == doneFor || busy) return
        // YouTube's automatic captions grow word by word: wait until the text rests for a moment (or a sentence ends)
        val stable = now - changedAt >= 320 || t.last() in ".?!…。！？"
        if (!stable) return
        busy = true
        val s = cfg.src
        val d = cfg.dst
        tr.exec.execute {
            val r = try { tr.translate(t, s, d) { } } catch (e: Throwable) { Res(null, "", e.message) }
            h.post {
                busy = false
                doneFor = t
                val out = r.text
                if (out != null && out.isNotBlank()) {
                    statusTv.visibility = View.GONE
                    origTv.text = t
                    transTv.text = out
                    strip.visibility = View.VISIBLE
                    placeStrip()
                } else {
                    statusTv.visibility = View.VISIBLE
                    statusTv.text = r.err ?: L("ترجمه نشد")
                }
            }
        }
    }

    /** Under the video when the page shows it on the upper part of the screen; otherwise at the bottom (also in full screen). */
    private fun placeStrip() {
        val lp = strip.layoutParams as FrameLayout.LayoutParams
        var top = -1
        if (custom == null && vidBottom > 0) {
            val a = IntArray(2)
            val b = IntArray(2)
            web.getLocationInWindow(a)
            root.getLocationInWindow(b)
            val y = (a[1] - b[1]) + (vidBottom * resources.displayMetrics.density).toInt()
            if (y > 0 && y < root.height - ui.dp(140)) top = y
        }
        if (top >= 0) { lp.gravity = Gravity.TOP; lp.topMargin = top; lp.bottomMargin = 0 }
        else { lp.gravity = Gravity.BOTTOM; lp.topMargin = 0; lp.bottomMargin = if (custom != null) ui.dp(28) else 0 }
        strip.layoutParams = lp
    }

    private fun leaveFullscreen() {
        val v = custom ?: return
        fsBox.removeView(v)
        fsBox.visibility = View.GONE
        main.visibility = View.VISIBLE
        custom = null
        try { customCb?.onCustomViewHidden() } catch (_: Throwable) {}
        customCb = null
        window.decorView.systemUiVisibility = 0
        placeStrip()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (custom != null) leaveFullscreen()
        else if (web.canGoBack()) web.goBack()
        else finish()
    }

    override fun onPause() { try { web.onPause() } catch (_: Throwable) {}; super.onPause() }
    override fun onResume() { super.onResume(); try { web.onResume() } catch (_: Throwable) {} }

    override fun onDestroy() {
        h.removeCallbacks(pump)
        savedMode?.let { cfg.mode = it }
        try { (web.parent as? ViewGroup)?.removeView(web); web.destroy() } catch (_: Throwable) {}
        super.onDestroy()
    }

    companion object {
        /** Runs inside the page: reads the caption on screen every 0.25 s and reports where the video ends. */
        private const val SCRIPT = """
(function(){
if(window.__tjOn){return;} window.__tjOn=true;
var last=null,lastRect=-1,clicked=false,hooked=[],prevHref=location.href;
function send(t){ t=(t||'').replace(/\s+/g,' ').trim(); if(t===last)return; last=t; try{TJ.cue(t);}catch(e){} }
function dom(){
  var box=document.querySelector('.ytp-caption-window-container');
  if(!box)return null;
  var segs=box.querySelectorAll('.ytp-caption-segment'),a=[];
  for(var i=0;i<segs.length;i++){var x=(segs[i].textContent||'').trim(); if(x)a.push(x);}
  return a.join(' ');
}
window.__tjHide=function(b){
  var s=document.getElementById('__tjs');
  if(!s){s=document.createElement('style');s.id='__tjs';(document.head||document.documentElement).appendChild(s);}
  s.textContent=b?'.ytp-caption-window-container{opacity:0 !important}':'';
};
function hook(){
  var vs=document.getElementsByTagName('video');
  for(var i=0;i<vs.length;i++){
    var tt=vs[i].textTracks; if(!tt)continue;
    for(var j=0;j<tt.length;j++){
      var t=tt[j]; if(t.kind!=='subtitles'&&t.kind!=='captions')continue;
      if(hooked.indexOf(t)>=0)continue; hooked.push(t);
      if(t.mode==='disabled')t.mode='hidden';
      t.addEventListener('cuechange',function(){
        var c=this.activeCues,a=[];
        if(c){for(var k=0;k<c.length;k++){a.push((c[k].text||'').replace(/<[^>]+>/g,' '));}}
        send(a.join(' '));
      });
    }
  }
}
function rect(){
  var vs=document.getElementsByTagName('video'),best=null,ba=0;
  for(var i=0;i<vs.length;i++){var r=vs[i].getBoundingClientRect(),a=r.width*r.height; if(a>ba&&r.bottom>0){best=r;ba=a;}}
  var b=best?Math.round(best.bottom):0;
  if(Math.abs(b-lastRect)>3){lastRect=b;try{TJ.rect(b);}catch(e){}}
}
function cc(){
  if(location.href!==prevHref){prevHref=location.href;clicked=false;}
  if(clicked)return;
  var b=document.querySelector('.ytp-subtitles-button');
  if(b&&b.offsetParent!==null){clicked=true; if(b.getAttribute('aria-pressed')==='false'){b.click();}}
}
setInterval(function(){try{hook();var d=dom();if(d!==null)send(d);rect();cc();}catch(e){}},250);
})();
"""
    }
}
