package app.tarjoman

import android.content.Context
import kotlin.reflect.KProperty

/** All user settings, stored in SharedPreferences. */
class Cfg(ctx: Context) {
    private val p = ctx.applicationContext.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    private inner class Str(val k: String, val d: String, val ov: (() -> String?)? = null) {
        operator fun getValue(t: Any?, pr: KProperty<*>): String = (if (p.getInt("auto", 0) == 1) ov?.invoke() else null) ?: (p.getString(k, d) ?: d)
        operator fun setValue(t: Any?, pr: KProperty<*>, v: String) { p.edit().putString(k, v).apply() }
    }

    private inner class IntP(val k: String, val d: Int) {
        operator fun getValue(t: Any?, pr: KProperty<*>): Int = p.getInt(k, d)
        operator fun setValue(t: Any?, pr: KProperty<*>, v: Int) { p.edit().putInt(k, v).apply() }
    }

    /** Language of the app itself: "fa" | "en". Setting it also switches the live text table (see I18n.kt). */
    var uiLang: String
        get() = p.getString("uiLang", "fa") ?: "fa"
        set(v) { p.edit().putString("uiLang", v).apply(); S.en = (v == "en") }

    init {
        S.en = (uiLang == "en")
        // Old versions stored one value: "dark" or "classic". Move it to the two new settings once.
        if (!p.contains("look") && p.contains("theme")) {
            val classic = p.getString("theme", "dark") == "classic"
            p.edit().putString("look", if (classic) "classic" else "modern")
                .putString("themeMode", if (classic) "light" else "dark").apply()
        }
    }

    var histMb by IntP("histMb", 10)         // history size limit in MB; 0 = history off
    var bubMode by Str("bubMode", "lock")    // free | lock | sleep
    var liveScr by IntP("liveScr", 0)        // 1 = bubble keeps translating the screen after page turns
    var live by IntP("live", 0)              // 1 = translate while typing
    var opacity by IntP("opacity", 95)       // overlay layer opacity, 20..100
    var fontScale by IntP("fontScale", 100)  // overlay text size, 60..160
    var hybrid by IntP("hybrid", 0)          // 1 = ML Kit draft polished by the AI model (experimental)
    var preFix by IntP("preFix", 1)          // 1 = clean English (caps, I, punctuation, slang) before ML Kit
    // Translations the user corrected by hand: one "english|persian" per line (see Idm.kt)
    var userPhr by Str("userPhr", "")
    // Where the downloaded AI models live: "" = private app storage, "ext" = app folder on shared storage, "/path" = any folder
    var modelDir by Str("modelDir", "")
    var saveTree by Str("saveTree", "")      // default folder (SAF tree uri) for saved translations; empty = ask each time
    // Reading text from pictures (OCR), separately for English and Persian
    var ocrPaddle by Str("ocrPaddle", "auto")  // off | auto (extra reader / main reader where nothing else exists) | only (PaddleOCR is the reader, when its models are installed)
    var paddleDet by Str("paddleDet", "auto")  // auto | small | big (which text-finder is used when both are installed)
    var paddleSide by IntP("paddleSide", 1280) // longest side of the picture given to the text-finder (640..2048)
    var ocrEn by Str("ocrEn", "auto")        // auto (ML Kit + Tesseract when installed, best result wins) | mlkit | tess
    var ocrEnPre by Str("ocrEnPre", "auto")  // picture clean-up for English: auto | on | off
    var ocrSkipBars by IntP("ocrSkipBars", 1)   // 1 = ignore the phone status bar / bottom bar in tall screenshots
    var ocrEnFix by IntP("ocrEnFix", 1)      // 1 = repair look-alike letters with the word list
    var ocrFaModel by Str("ocrFaModel", "auto")  // auto (best if installed) | fast | best
    var ocrFont by Str("ocrFont", "")           // font of the translation drawn on pictures ("" = bold sans, system family name, or file:Name.ttf)
    var ocrFaPre by Str("ocrFaPre", "auto")      // auto (both versions, best wins) | gray | bw
    var learnAuto by IntP("learnAuto", 0)    // 1 = word meanings are fetched and saved on the phone while translating (Dict.kt)
    var explicit by IntP("explicit", 0)      // 1 = very rude spoken words for sexual / body words (Prof.kt)
    var colloq by IntP("colloq", 1)          // 1 = spoken Persian in "casual" style
    var visionMissing by IntP("visionMissing", 1) // 1 = with the cloud model on, it also looks for text the phone missed
    var visionOcr by IntP("visionOcr", 0)    // 1 = a cloud vision model (API) reads and translates pictures
    var ocrDetect by IntP("ocrDetect", 1)     // 1 = when the comic text detector is installed, it also finds text the reader overlooked
    var eraser by Str("eraser", "auto")       // which erasing model: auto (LaMa if installed, else MI-GAN) | lama | migan
    var lama by IntP("lama", 1)               // 1 = erase the old writing of a picture with the LaMa model when it is installed
    var lamaAll by IntP("lamaAll", 0)         // 1 = LaMa also on plain-coloured backgrounds (normal pictures), not only on busy ones
    var numWords by IntP("numWords", 0)      // 1 = numbers inside a translated text are written in words
    var spell by IntP("spell", 2)            // 0 off, 1 only suggest, 2 fix typos automatically (English)
    var kbAuto by IntP("kbAuto", 1)          // 1 = ask the keyboard to follow the source language
    var imgKind by Str("imgKind", "auto")      // picture type: auto / manga / manhwa / comic / screen
    var mzFmt by Str("mzFmt", "jpg")          // manga archive: output picture format (jpg / webp)
    var mzMaxPx by IntP("mzMaxPx", 2200)     // manga archive: longest side of a page while working
    var mzPause by IntP("mzPause", 0)        // manga archive: seconds to rest between pages (keeps the phone cool)
    var simple by IntP("simple", 0)          // 1 = hide all the explanatory texts
    var autoLang by IntP("autoLang", 1)      // 1 = guess source language of typed text
    var themeMode by Str("themeMode", "system")  // system | light | dark
    var learnLog by Str("learnLog", "")          // "lastDay|exercisesToday|streakDays"
    var learnLevel by Str("learnLevel", "mid")   // easy | mid | hard (English practice)
    var look by Str("look", "modern")            // modern | classic (paper)
    var layout by Str("layout", "std")           // std | compact | large | flat | icons (see Lay in Ui.kt)
    var glossary by Str("glossary", "")  // lines: source=target
    var src by Str("src", "en")
    var dst by Str("dst", "fa")
    var style by Str("style", "casual", { Auto.style })    // casual (subtitles, manga) | formal (books, articles)
    var mode by Str("mode", "normal", { Auto.mode })      // normal | advanced
    var speed by Str("speed", "fast", { Auto.speed })      // fast | slow
    var auto by IntP("auto", 0)           // 1 = engine, style and speed are picked automatically
    var onProv by Str("onProv", "")        // online source that worked last time (tried first, also after the app restarts)
    var net by Str("net", "auto")          // offline | online | auto (online when the internet works)
    var activeModel by Str("activeModel", "")
    var proxyType by Str("proxyType", "none") // none | http | socks
    var proxyHost by Str("proxyHost", "")
    var proxyPort by Str("proxyPort", "")
    var hfToken by Str("hfToken", "")
    var mirror by Str("mirror", "huggingface.co")
    var hfCookie by Str("hfCookie", "")
    var apiUrl by Str("apiUrl", "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions")
    var apiKey by Str("apiKey", "")
    var apiModel by Str("apiModel", "gemini-2.5-flash")

    fun fam(file: String): String = p.getString("fam_$file", "") ?: ""
    fun setFam(file: String, v: String) { p.edit().putString("fam_$file", v).apply() }
}
