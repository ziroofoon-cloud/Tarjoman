package app.tarjoman

import android.content.Context
import kotlin.reflect.KProperty

/** All user settings, stored in SharedPreferences. */
class Cfg(ctx: Context) {
    private val p = ctx.applicationContext.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    private inner class Str(val k: String, val d: String) {
        operator fun getValue(t: Any?, pr: KProperty<*>): String = p.getString(k, d) ?: d
        operator fun setValue(t: Any?, pr: KProperty<*>, v: String) { p.edit().putString(k, v).apply() }
    }

    private inner class IntP(val k: String, val d: Int) {
        operator fun getValue(t: Any?, pr: KProperty<*>): Int = p.getInt(k, d)
        operator fun setValue(t: Any?, pr: KProperty<*>, v: Int) { p.edit().putInt(k, v).apply() }
    }

    /** Language of the app itself: "fa" | "en". Setting it also switches the live text table (see I18n.kt). */
    var uiLang: String
        get() = p.getString("uiLang", "fa") ?: "fa"
        set(v) { p.edit().putString("uiLang", v).apply(); S.en = (v == "en") }

    init { S.en = (uiLang == "en") }

    var opacity by IntP("opacity", 95)       // overlay layer opacity, 20..100
    var fontScale by IntP("fontScale", 100)  // overlay text size, 60..160
    var hybrid by IntP("hybrid", 0)          // 1 = ML Kit draft polished by the AI model (experimental)
    var autoLang by IntP("autoLang", 1)      // 1 = guess source language of typed text
    var theme by Str("theme", "dark")        // dark | classic
    var glossary by Str("glossary", "")  // lines: source=target
    var src by Str("src", "en")
    var dst by Str("dst", "fa")
    var style by Str("style", "casual")    // casual (subtitles, manga) | formal (books, articles)
    var mode by Str("mode", "normal")      // normal | advanced
    var speed by Str("speed", "fast")      // fast | slow
    var net by Str("net", "offline")       // offline | online
    var activeModel by Str("activeModel", "")
    var proxyType by Str("proxyType", "none") // none | http | socks
    var proxyHost by Str("proxyHost", "")
    var proxyPort by Str("proxyPort", "")
    var hfToken by Str("hfToken", "")
    var mirror by Str("mirror", "huggingface.co")
    var apiUrl by Str("apiUrl", "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions")
    var apiKey by Str("apiKey", "")
    var apiModel by Str("apiModel", "gemini-2.0-flash")

    fun fam(file: String): String = p.getString("fam_$file", "") ?: ""
    fun setFam(file: String, v: String) { p.edit().putString("fam_$file", v).apply() }
}
