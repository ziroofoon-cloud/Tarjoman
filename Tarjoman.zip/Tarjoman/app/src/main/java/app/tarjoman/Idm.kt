package app.tarjoman

/**
 * English -> Persian phrase table for everyday talk, slang and idioms (offline).
 * ML Kit translates word by word and gets idioms wrong ("be cool" = "be cold"), so whole sentences and whole clauses
 * found in this table are answered directly; everything else still goes to ML Kit, one short sentence/clause at a time.
 * In the table "_" stands for the Persian half-space (ZWNJ) and "؟" marks a question.
 */
object Idm {
    class Seg(val en: String, val fa: String?, val sepAfter: String)
    class Plan(val segs: List<Seg>, val end: String)

    private val died = Regex("\\b(am|is|are|was|were|be|been)\\s+((?:i|you|he|she|we|they|it)\\s+)?died\\b")
    private val fillers = Regex("^(oh|ah|well|so|hey|okay|ok|yeah|yes|no|um|uh|hmm|look|listen)\\s+")
    private val tail = Regex("\\s+(please|man|dude|bro|buddy)$")
    private val endRe = Regex("^(.*?)([.!?\u2026]*)$", RegexOption.DOT_MATCHES_ALL)
    private val clauseRe = Regex("\\s*,\\s*(?:(?:or|and|but)\\s+)?|\\s+or\\s+|\\s+and\\s+|\\s+but\\s+", RegexOption.IGNORE_CASE)
    private val abbr = Regex("(?i)(^|\\s)(mr|mrs|ms|dr|st|vs|etc|jr|sr|no|[a-z])\\.$")
    private val splitRe = Regex("(?<=[.!?\u2026\u3002])\\s+")

    /** Lower case, expanded contractions, no punctuation: the form used to compare phrases. */
    fun norm(s: String): String {
        var t = s.lowercase().replace('\u2019', '\'').replace('\u2018', '\'')
        t = t.replace("won't", "will not").replace("can't", "can not").replace("cannot", "can not")
            .replace("let's", "let us").replace("i'm", "i am").replace("you're", "you are").replace("we're", "we are")
            .replace("they're", "they are").replace("he's", "he is").replace("she's", "she is").replace("it's", "it is")
            .replace("that's", "that is").replace("what's", "what is").replace("there's", "there is")
            .replace("who's", "who is").replace("where's", "where is").replace("how's", "how is")
            .replace("n't", " not").replace("gonna", "going to").replace("wanna", "want to").replace("gotta", "have to")
        t = t.replace(Regex("\\b(dont|doesnt|didnt|cant|wont|isnt|arent|wasnt|werent|havent|hasnt|couldnt|wouldnt|shouldnt)\\b")) { m ->
            when (val w = m.value) { "cant" -> "can not"; "wont" -> "will not"; else -> w.dropLast(2) + " not" }
        }
        t = t.replace(Regex("\\bim\\b"), "i am").replace(Regex("\\bthats\\b"), "that is").replace(Regex("\\bwhats\\b"), "what is")
        t = died.replace(t) { m -> m.groupValues[1] + " " + m.groupValues[2] + "dead" }
        t = t.replace(Regex("[^a-z0-9' ]"), " ").replace(Regex("\\s+"), " ").trim()
        return t
    }

    private val table: HashMap<String, String> by lazy {
        val m = HashMap<String, String>()
        for (line in DATA.lines()) {
            val i = line.indexOf('|')
            if (i <= 0) continue
            m[norm(line.substring(0, i))] = line.substring(i + 1).trim().replace('_', '\u200c')
        }
        m
    }

    // ---- the user's own corrections: "english|persian" per line, loaded from the settings
    @Volatile private var mine: HashMap<String, String> = HashMap()

    fun loadMine(raw: String) {
        val m = HashMap<String, String>()
        for (line in raw.lines()) {
            val i = line.indexOf('|')
            if (i <= 0) continue
            val k = norm(line.substring(0, i))
            val v = line.substring(i + 1).trim()
            if (k.isNotEmpty() && v.isNotEmpty()) m[k] = v
        }
        mine = m
    }

    fun mineCount(): Int = mine.size

    /** A translation the user has corrected before (the whole text must match, ignoring case and punctuation). */
    fun mineLookup(en: String): String? = mine[norm(en)]

    /** Exact match of a whole sentence or clause (ignores case, punctuation, a leading "oh/well/hey", a trailing "man/please"). */
    fun lookup(en: String): String? {
        var k = norm(en)
        if (k.isEmpty()) return null
        mine[k]?.let { return it }
        table[k]?.let { return it }
        for (i in 0 until 2) {
            val k2 = tail.replace(fillers.replace(k, ""), "")
            if (k2 == k || k2.isEmpty()) break
            k = k2
            mine[k]?.let { return it }
            table[k]?.let { return it }
        }
        return null
    }

    /** Splits a line into sentences (not after Mr. / Dr. / single capitals). */
    fun sentences(line: String): List<String> {
        val raw = line.trim().split(splitRe).filter { it.isNotBlank() }
        val out = ArrayList<String>()
        for (p in raw) {
            if (out.isNotEmpty() && abbr.containsMatchIn(out.last())) out[out.size - 1] = out.last() + " " + p else out.add(p)
        }
        return out
    }

    private fun sepFa(s: String): String = when (s.trim().trimStart(',').trim().lowercase()) {
        "" -> "\u060C "
        "or" -> " \u06CC\u0627 "
        "and" -> " \u0648 "
        "but" -> " \u0648\u0644\u06CC "
        else -> " "
    }

    /** A plan when the table helps with this sentence (whole sentence, or at least one clause of it); otherwise null. */
    fun plan(sentence: String): Plan? {
        val m = endRe.find(sentence.trim()) ?: return null
        val body = m.groupValues[1].trim()
        val end = m.groupValues[2]
        if (body.isEmpty()) return null
        lookup(body)?.let { return Plan(listOf(Seg(body, it, "")), end) }
        val segs = ArrayList<Seg>()
        var pos = 0
        for (c in clauseRe.findAll(body)) {
            val txt = body.substring(pos, c.range.first).trim()
            if (txt.isNotEmpty()) segs.add(Seg(txt, lookup(txt), sepFa(c.value)))
            pos = c.range.last + 1
        }
        val last = body.substring(pos).trim()
        if (last.isNotEmpty()) segs.add(Seg(last, lookup(last), ""))
        if (segs.size < 2 || segs.none { it.fa != null }) return null
        return Plan(segs, end)
    }

    /** Builds the Persian sentence; [tr] translates the clauses that are not in the table. */
    fun assemble(p: Plan, tr: (String) -> String): String {
        val sb = StringBuilder()
        var q = false
        p.segs.forEachIndexed { i, s ->
            var t = (s.fa ?: tr(s.en)).trim()
            if (t.endsWith("\u061F") || t.endsWith("?")) q = true
            t = t.trimEnd('.', '?', '\u061F', '!', '\u060C', ',', ' ')
            sb.append(t)
            if (i < p.segs.size - 1) sb.append(s.sepAfter)
        }
        var end = p.end.replace('?', '\u061F').replace('\u2026', '.')
        if (q) end = if (end.contains('!')) "\u061F!" else "\u061F"
        return sb.toString() + end
    }

    private const val DATA = """
can you be cool|می_تونی باحال باشی؟
could you be cool|می_تونی باحال باشی؟
be cool|باحال باش
stay cool|خونسرد باش
keep cool|خونسرد باش
keep your cool|خونسردیتو حفظ کن
lose your cool|کنترلتو از دست بده
that is cool|باحاله
this is cool|این باحاله
it is cool|باحاله
so cool|خیلی باحاله
very cool|خیلی باحاله
how cool|چه باحال
cool|باحال
awesome|محشره
amazing|عالیه
that is awesome|محشره
that is amazing|عالیه
that is sick|محشره
am i dead|مردم؟
am i dead or alive|مردم یا زنده_ام؟
i am dead|مردم
am i alive|زنده_ام؟
am i dreaming|دارم خواب می_بینم؟
am i tripping|دارم توهم می_زنم؟
am i crazy|دیوونه شدم؟
am i going crazy|دارم دیوونه می_شم؟
am i losing my mind|دارم عقلمو از دست می_دم؟
i am tripping|دارم توهم می_زنم
i am going crazy|دارم دیوونه می_شم
i am losing my mind|دارم عقلمو از دست می_دم
are you tripping|توهم زدی؟
you are tripping|داری توهم می_زنی
stop tripping|دست از توهم زدن بردار
are you crazy|دیوونه شدی؟
you are crazy|دیوونه_ای
are you out of your mind|عقلتو از دست دادی؟
you are out of your mind|عقلتو از دست دادی
what the hell|این دیگه چیه؟
what the hell is wrong with you|تو دیگه چه مرگته؟
what the hell is going on|اینجا چه خبره؟
what the hell are you doing|داری چه غلطی می_کنی؟
what is wrong with you|تو چت شده؟
what is wrong|چی شده؟
what is going on|چه خبره؟
what is up|چه خبر؟
what is up with you|تو چته؟
what happened|چی شد؟
what did you say|چی گفتی؟
what do you mean|منظورت چیه؟
what is that|اون چیه؟
what is this|این چیه؟
what are you doing|چیکار می_کنی؟
what do you want|چی می_خوای؟
what is your name|اسمت چیه؟
who are you|تو کی هستی؟
where are you|کجایی؟
where are you going|کجا داری می_ری؟
how are you|حالت چطوره؟
how are you doing|حالت چطوره؟
how is it going|اوضاع چطوره؟
how dare you|چطور جرئت می_کنی؟
why not|چرا که نه؟
why|چرا؟
really|واقعاً؟
seriously|جدی؟
for real|جدی؟
are you serious|جدی می_گی؟
are you kidding me|شوخی می_کنی؟
are you kidding|شوخی می_کنی؟
you are kidding|داری شوخی می_کنی
you must be kidding|حتماً شوخی می_کنی
just kidding|شوخی کردم
i am kidding|شوخی کردم
i am joking|شوخی کردم
i am just kidding|فقط شوخی کردم
no way|امکان نداره
no kidding|جدی؟
shut up|خفه شو
what the fuck|این دیگه چه کوفتیه؟
what the fuck is wrong with you|تو دیگه چه مرگته لعنتی؟
what the fuck is going on|اینجا چه خبره لعنتی؟
what the fuck are you doing|داری چه غلطی می_کنی؟
what the fuck do you want|لعنتی چی می_خوای؟
what the heck|این دیگه چیه؟
fuck you|گمشو لعنتی
fuck off|گمشو برو
fuck|لعنتی
fucking hell|لعنتی
shit|لعنتی
holy shit|وای لعنتی
oh shit|وای لعنتی
bullshit|مزخرفه
that is bullshit|این مزخرفه
asshole|عوضی
you asshole|ای عوضی
bastard|حرومزاده
you bastard|ای حرومزاده
bitch|عوضی
son of a bitch|پدرسگ
go to hell|برو به جهنم
piss off|گمشو
get lost|گمشو
are you kidding me|شوخی می_کنی؟
you idiot|ای احمق
you are an idiot|تو احمقی
shut your mouth|دهنتو ببند
be quiet|ساکت باش
get lost|گمشو
go away|برو پی کارت
leave me alone|تنهام بذار
let me go|ولم کن
let go of me|ولم کن
do not touch me|بهم دست نزن
do not move|تکون نخور
do not worry|نگران نباش
do not lie to me|بهم دروغ نگو
do not do that|این کارو نکن
stop it|بسه دیگه
stop|وایستا
enough|بسه
that is enough|دیگه بسه
calm down|آروم باش
relax|آروم باش
take it easy|آروم باش
chill out|خونسرد باش
chill|خونسرد باش
never mind|بی_خیال
forget it|بی_خیال
it does not matter|مهم نیست
no problem|مشکلی نیست
no worries|نگران نباش
my bad|تقصیر من بود
it is not my fault|تقصیر من نیست
it is not fair|این منصفانه نیست
sorry|ببخشید
i am sorry|متأسفم
excuse me|ببخشید
thank you|ممنون
thanks|مرسی
thanks a lot|خیلی ممنون
you are welcome|خواهش می_کنم
please|لطفاً
good luck|موفق باشی
good job|آفرین
well done|آفرین
nice job|دمت گرم
great job|عالی بود
congratulations|تبریک می_گم
good morning|صبح بخیر
good evening|عصر بخیر
good night|شب بخیر
goodbye|خداحافظ
bye|خداحافظ
see you later|بعداً می_بینمت
see you|می_بینمت
hello|سلام
hi|سلام
hey|هی
i am fine|خوبم
i am good|خوبم
i am okay|من خوبم
are you okay|حالت خوبه؟
are you ok|حالت خوبه؟
nice to meet you|از آشنایی باهات خوشحالم
i love you|دوستت دارم
i miss you|دلم برات تنگ شده
i hate you|ازت متنفرم
i do not know|نمی_دونم
i do not care|برام مهم نیست
i do not understand|نمی_فهمم
i do not think so|فکر نکنم
i think so|فکر کنم
i guess so|فکر کنم همین_طوره
of course|معلومه
sure|حتماً
maybe|شاید
exactly|دقیقاً
oh my god|وای خدا
oh my gosh|وای خدای من
holy crap|وای خدا
damn|لعنتی
damn it|لعنتی
oh no|وای نه
come on|بیا دیگه
hurry up|عجله کن
wait|صبر کن
wait a minute|یه دقیقه صبر کن
wait a second|یه لحظه صبر کن
hold on|یه لحظه صبر کن
hang on|یه لحظه صبر کن
hang in there|تحمل کن
look out|حواست باشه
watch out|مواظب باش
be careful|مراقب باش
let us go|بزن بریم
come here|بیا اینجا
follow me|دنبالم بیا
help me|کمکم کن
help|کمک
i need help|کمک می_خوام
i am bored|حوصله_م سر رفته
i am tired|خسته_ام
i am hungry|گشنمه
i am thirsty|تشنمه
i am scared|می_ترسم
you are right|حق با توئه
you are wrong|اشتباه می_کنی
you are fired|اخراجی
that is true|درسته
that is right|درسته
that is not true|این درست نیست
unbelievable|باورنکردنیه
i can not believe it|باورم نمی_شه
i knew it|می_دونستم
i told you|بهت گفته بودم
told you so|گفته بودم
you did it|موفق شدی
i did it|موفق شدم
i give up|تسلیم شدم
lucky you|خوش به حالت
you are so lucky|چقدر خوش_شانسی
you can do it|می_تونی از پسش بربیای
you got this|از پسش برمیای
here we go again|باز شروع شد
not again|دوباره نه
bless you|عافیت باشه
cheers|به سلامتی
happy birthday|تولدت مبارک
happy new year|سال نو مبارک
shut the fuck up|خفه شو دیگه
what is your problem|مشکلت چیه
go fuck yourself|برو بمیر
get out|برو بیرون
get out of here|برو از اینجا بیرون
get out of my way|از سر راهم برو کنار
back off|برو عقب
step back|برو عقب
you son of a bitch|ای پدرسوخته
you bitch|ای عوضی
you moron|ای ابله
you fool|ای احمق
idiot|احمق
moron|ابله
you are stupid|تو احمقی
you are insane|تو دیوونه_ای
are you insane|دیوونه شدی؟
have you lost your mind|عقلتو از دست دادی؟
i am serious|جدی می_گم
i am not kidding|شوخی نمی_کنم
dammit|لعنتی
goddamn it|لعنتی
damn you|لعنتی
oh god|وای خدا
thank god|خدا رو شکر
thank goodness|خدا رو شکر
for god's sake|تو رو خدا
for goodness sake|تو رو خدا
what a mess|چه افتضاحی
what a pain|چه دردسری
what a jerk|چه آدم عوضیه
what a shame|چه حیف
what a pity|چه حیف
what a day|چه روزی بود
what a surprise|چه سورپرایزی
what a relief|چه آرامشی
what a coincidence|چه اتفاق جالبی
how annoying|عجب دردسریه
how embarrassing|چقدر خجالت_آوره
how disgusting|چه چندش_آوره
how stupid|چه احمقانه
what happened here|اینجا چی شده؟
what is happening|چه خبره؟
what are you doing here|اینجا چیکار می_کنی؟
what did you just say|همین الان چی گفتی؟
what are you talking about|درباره چی حرف می_زنی؟
what are you looking at|به چی زل زدی؟
what was that|اون چی بود؟
who the hell are you|تو دیگه کی هستی؟
where have you been|کجا بودی؟
why me|چرا من؟
why are you here|چرا اومدی اینجا؟
why did you do that|چرا این کارو کردی؟
how could you|چطور تونستی؟
what is new|چه خبر؟
how old are you|چند سالته؟
how much is it|قیمتش چنده؟
how much|چقدر؟
how many|چندتا؟
long time no see|خیلی وقته ندیدمت
see you tomorrow|فردا می_بینمت
see you soon|به زودی می_بینمت
good afternoon|ظهر بخیر
take care|مراقب خودت باش
keep quiet|ساکت باش
do not cry|گریه نکن
do not do it|این کارو نکن
do not go|نرو
do not leave me|ترکم نکن
do not look at me|بهم نگاه نکن
do not be afraid|نترس
do not be silly|بچه_بازی درنیار
do not be ridiculous|مسخره_بازی درنیار
stop right there|همون_جا وایسا
stop crying|دیگه گریه نکن
stop talking|حرف نزن
stop lying|دروغ نگو
freeze|تکون نخور
hands up|دستا بالا
put your hands up|دستاتو ببر بالا
put it down|بذارش زمین
put the gun down|اسلحه رو بذار زمین
give it to me|بده به من
give me that|اونو بده به من
give it back|پسش بده
let me see|بذار ببینم
let me think|بذار فکر کنم
let me explain|بذار توضیح بدم
let me help you|بذار کمکت کنم
let me in|بذار بیام تو
let me out|بذار برم بیرون
trust me|بهم اعتماد کن
believe me|باور کن
listen to me|به حرفم گوش کن
look at me|به من نگاه کن
look at this|به این نگاه کن
look at that|به اون نگاه کن
come with me|با من بیا
come back|برگرد
go home|برو خونه
go back|برگرد
go ahead|بفرما
hurry|عجله کن
run away|فرار کن
run for it|فرار کن
get down|بخواب رو زمین
get up|پاشو
sit down|بشین
stand up|پاشو
wake up|بیدار شو
i am so sorry|خیلی متأسفم
forgive me|منو ببخش
thank you so much|خیلی ممنون
forget about it|بیخیالش
who cares|کی اهمیت می_ده؟
i hope so|امیدوارم
i do not want to|نمی_خوام
i do not want to die|نمی_خوام بمیرم
i want to go home|می_خوام برم خونه
i want to go|می_خوام برم
i hate this|از این متنفرم
i like you|ازت خوشم میاد
i am in love|عاشق شدم
i am not okay|حالم خوب نیست
i am here|من اینجام
i am back|برگشتم
i am coming|دارم میام
i am leaving|دارم می_رم
i am busy|سرم شلوغه
i am late|دیرم شده
i am lost|گم شدم
i am sure|مطمئنم
i am not sure|مطمئن نیستم
i am afraid|می_ترسم
i am angry|عصبانیم
i am sad|ناراحتم
i am happy|خوشحالم
i am so happy|خیلی خوشحالم
i am sleepy|خوابم میاد
i am ready|آماده_ام
i am done|تمومش کردم
i am not afraid of you|ازت نمی_ترسم
i will be right back|الان برمی_گردم
i will kill you|می_کشمت
i will kill him|می_کشمش
i will find you|پیدات می_کنم
i will do it|من انجامش می_دم
i will protect you|ازت محافظت می_کنم
i will not let you|نمی_ذارم
i will never forgive you|هیچ_وقت نمی_بخشمت
i swear|قسم می_خورم
i promise|قول می_دم
i promise you|بهت قول می_دم
that is all|همین
that is it|همین بود
that is none of your business|به تو ربطی نداره
it is none of your business|به تو ربطی نداره
mind your own business|سرت به کار خودت باشه
it is not your fault|تقصیر تو نیست
it is my fault|تقصیر منه
it is too late|خیلی دیر شده
it is too dangerous|خیلی خطرناکه
it is a trap|یه تله_ست
it is impossible|غیرممکنه
it is over|تموم شد
it is not over|تموم نشده
it is time|وقتشه
it is time to go|وقت رفتنه
it is not funny|خنده_دار نیست
it is okay|اشکالی نداره
it is fine|مشکلی نیست
it makes no sense|هیچ معنی نداره
that makes sense|منطقیه
that does not make sense|این منطقی نیست
that is crazy|دیوونگیه
that is insane|دیوونگیه
that is ridiculous|مسخره_ست
that is disgusting|چندش_آوره
that is gross|چندش_آوره
that is so cute|چقدر بامزه_ست
you are so cute|چقدر بامزه_ای
you look great|عالی به نظر می_رسی
you look beautiful|خیلی خوشگل شدی
you are beautiful|خیلی خوشگلی
you are the best|تو بهترینی
you are amazing|تو فوق_العاده_ای
you are late|دیر کردی
you are under arrest|شما بازداشتید
you are not alone|تنها نیستی
you are mine|مال منی
you are dead|مردی
you are dead meat|مرده_ای
you will pay for this|تقاصش رو پس می_دی
you will regret this|پشیمون می_شی
you will die|می_میری
you have no idea|اصلاً نمی_دونی
you have no right|حق نداری
you have a point|حق با توئه
you can not do this|نمی_تونی این کارو بکنی
you can not stop me|نمی_تونی جلومو بگیری
you can not escape|نمی_تونی فرار کنی
you can not hide|نمی_تونی قایم بشی
you asked for it|خودت خواستی
you deserve it|حقته
serves you right|حقته
nice one|دمت گرم
way to go|دمت گرم
bravo|آفرین
welcome|خوش اومدی
welcome back|خوش برگشتی
welcome home|خوش اومدی خونه
here you go|بفرما
here it is|بفرما
there you are|اینجایی
there it is|اونجاست
that is weird|عجیبه
that is strange|عجیبه
that is funny|خنده_داره
that is great|عالیه
that is terrible|افتضاحه
that is bad|بده
that is good|خوبه
that is not fair|این منصفانه نیست
that is not what i meant|منظورم این نبود
that hurts|درد داره
it hurts|درد می_کنه
i am hurt|زخمی شدم
help me please|لطفاً کمکم کن
somebody help|یکی کمک کنه
someone help me|یکی کمکم کنه
call the police|به پلیس زنگ بزن
call an ambulance|آمبولانس خبر کن
he is dead|مرده
she is dead|مرده
they are dead|مردن
he is gone|رفته
she is gone|رفته
it is gone|رفته
he is lying|داره دروغ می_گه
you are lying|داری دروغ می_گی
you lied to me|بهم دروغ گفتی
are you alright|حالت خوبه؟
are you hurt|زخمی شدی؟
are you sure|مطمئنی؟
are you ready|آماده_ای؟
are you hungry|گشنته؟
do you hear me|صدامو می_شنوی؟
can you hear me|صدامو می_شنوی؟
do you understand|می_فهمی؟
do you know me|منو می_شناسی؟
do you know who i am|می_دونی من کیم؟
do you love me|دوستم داری؟
do you like it|خوشت اومد؟
do you want to die|می_خوای بمیری؟
do you have a minute|یه دقیقه وقت داری؟
do you have any idea|اصلاً می_دونی؟
can i help you|می_تونم کمکت کنم؟
can i ask you something|می_تونم یه چیزی ازت بپرسم؟
can i come in|می_تونم بیام تو؟
may i come in|اجازه هست بیام تو؟
can we talk|می_تونیم حرف بزنیم؟
can we go|می_تونیم بریم؟
can you help me|می_تونی کمکم کنی؟
can you do me a favor|یه لطفی در حقم می_کنی؟
can you believe it|باورت می_شه؟
would you like some tea|چایی می_خوری؟
let us talk|بیا حرف بزنیم
let us do it|بیا انجامش بدیم
let us begin|بیا شروع کنیم
let us start|بیا شروع کنیم
let us see|ببینیم
let us eat|بیا غذا بخوریم
let us get started|بیا شروع کنیم
let us get out of here|بیا از اینجا بریم
let us hurry|زود باشیم
let us finish this|بیا تمومش کنیم
let us end this|بیا تمومش کنیم
i am going to kill you|می_کشمت
i am going to die|دارم می_میرم
you are driving me crazy|داری منو دیوونه می_کنی
you scared me|منو ترسوندی
you surprised me|غافلگیرم کردی
you saved me|نجاتم دادی
you saved my life|جونمو نجات دادی
i will never forget this|اینو هیچ_وقت فراموش نمی_کنم
thank you for everything|بابت همه_چی ممنون
thank you for coming|ممنون که اومدی
thank you for your help|ممنون بابت کمکت
sorry to bother you|ببخشید مزاحم شدم
sorry i am late|ببخشید دیر کردم
sorry about that|بابت اون ببخشید
oops|اوه
whoops|اوه
wow|وای
whoa|وای
ouch|آخ
ugh|اَه
yuck|اَه
phew|اوف
huh|هان
hmm|هوم
yay|هورا
hooray|هورا
yes|آره
yeah|آره
yep|آره
nope|نه
nah|نه
no|نه
okay|باشه
ok|باشه
alright|باشه
certainly|حتماً
absolutely|کاملاً
perhaps|شاید
probably|احتمالاً
definitely|قطعاً
obviously|معلومه
whatever|هرچی
anyway|به هر حال
i am not going|نمی_رم
i can not|نمی_تونم
i can not do it|نمی_تونم انجامش بدم
i can not breathe|نمی_تونم نفس بکشم
i can not move|نمی_تونم تکون بخورم
i can not see|نمی_تونم ببینم
i can do it|می_تونم انجامش بدم
i have to go|باید برم
i have to go now|الان باید برم
i have no choice|چاره_ای ندارم
i have a bad feeling about this|حس بدی نسبت به این قضیه دارم
i have a plan|یه نقشه دارم
i have an idea|یه ایده دارم
i have a question|یه سؤال دارم
i have had enough|دیگه بسمه
i need you|بهت نیاز دارم
i need to go|باید برم
i need to talk to you|باید باهات حرف بزنم
i need some air|یکم هوا لازم دارم
i need to know|باید بدونم
i want to know|می_خوام بدونم
i want to see you|می_خوام ببینمت
i want to talk to you|می_خوام باهات حرف بزنم
i want you to leave|می_خوام بری
i know|می_دونم
i know that|اینو می_دونم
i know what you did|می_دونم چیکار کردی
i see|فهمیدم
i got it|گرفتم
i get it|فهمیدم
i understand|می_فهمم
i remember|یادمه
i forgot|یادم رفت
i believe you|باورت می_کنم
i do not believe you|باورت نمی_کنم
i trust you|بهت اعتماد دارم
i do not trust you|بهت اعتماد ندارم
i am proud of you|بهت افتخار می_کنم
i am worried about you|نگرانتم
i am worried|نگرانم
i am curious|کنجکاوم
i am surprised|تعجب کردم
i am confused|گیج شدم
i am shocked|شوکه شدم
i am tired of this|از این خسته شدم
i am sick of this|حالم از این به هم می_خوره
i am fed up|کلافه شدم
i am so tired|خیلی خسته_ام
i am so scared|خیلی می_ترسم
i am not a child|بچه نیستم
i am not stupid|احمق نیستم
i am not lying|دروغ نمی_گم
i am not joking|شوخی نمی_کنم
i am not going anywhere|هیچ_جا نمی_رم
i am not going to hurt you|بهت آسیبی نمی_زنم
i am not your enemy|من دشمنت نیستم
i am your friend|من دوستتم
i am your father|من پدرتم
i am your mother|من مادرتم
i am your brother|من برادرتم
i am your sister|من خواهرتم
it is up to you|به خودت بستگی داره
it depends|بستگی داره
it makes sense|منطقیه
it does not make sense|منطقی نیست
i do not get it|نمی_فهمم
you got me|گیر انداختی منو
i have no idea|هیچ_ایده‌ای ندارم
i have no time|وقت ندارم
i do not have time|وقت ندارم
i could not care less|اصلاً برام مهم نیست
so what|که چی؟
what is the matter|چی شده؟
how come|چطور مگه؟
none of your business|به تو ربطی نداره
do not panic|نترس
do not give up|تسلیم نشو
never give up|هیچ_وقت تسلیم نشو
just a moment|فقط یه لحظه
take your time|عجله نکن
nice work|دمت گرم
it is a pleasure to meet you|از آشنایی باهاتون خوشوقتم
how have you been|چطور بودی
make yourself at home|راحت باش
pardon me|ببخشید
i beg your pardon|ببخشید، چی گفتید
my pleasure|قابلی نداشت
it is all my fault|همه‌اش تقصیر منه
it is not too late|هنوز دیر نشده
i changed my mind|نظرم عوض شد
i am on my way|دارم میام
i will be there|اونجا می_رسم
i will see you there|اونجا می_بینمت
i owe you one|یه چیزی بهت بدهکارم
i am sick of it|ازش خسته شدم
i can not take it anymore|دیگه نمی_تونم تحمل کنم
i can not wait|نمی_تونم صبر کنم
i am so proud of you|خیلی بهت افتخار می_کنم
i am dying to know|دارم از کنجکاوی می_میرم
i am dying of hunger|از گشنگی دارم می_میرم
i am starving|از گشنگی دارم می_میرم
i am freezing|دارم یخ می_زنم
i am broke|پول ندارم
i do not know what to do|نمی_دونم چیکار کنم
i do not know what to say|نمی_دونم چی بگم
i do not know where to go|نمی_دونم کجا برم
i do not know what happened|نمی_دونم چی شد
i do not know why|نمی_دونم چرا
i do not know who you are|نمی_دونم تو کی هستی
i did not mean it|منظوری نداشتم
i did not mean to hurt you|نمی_خواستم اذیتت کنم
i did not do anything|من کاری نکردم
i did not do it|من انجامش ندادم
i have never seen it before|تا حالا ندیده_بودمش
i have never been there|هیچ_وقت اونجا نرفتم
i have been waiting for you|منتظرت بودم
i have been looking for you|دنبالت می_گشتم
i have to leave|باید برم
i need your help|به کمکت نیاز دارم
i would like to go home|دلم می_خواد برم خونه
i would like to ask you something|می_خواستم یه چیزی ازت بپرسم
can i ask you a question|می_تونم یه سؤال بپرسم؟
could you help me|می_تونید کمکم کنید؟
can you see me|می_تونی منو ببینی؟
do you speak english|انگلیسی بلدی؟
do you remember me|منو یادته؟
do you remember|یادته؟
do you want to come|می_خوای بیای؟
do you want to go|می_خوای بری؟
what do you want from me|از من چی می_خوای؟
what do you think|نظرت چیه؟
what should i do|چیکار کنم؟
what can i do|چیکار می_تونم بکنم؟
what is his name|اسمش چیه؟
what is her name|اسمش چیه؟
where do you live|کجا زندگی می_کنی؟
where are you from|اهل کجایی؟
who is that|اون کیه؟
who is it|کیه؟
who did this|کی این کارو کرده؟
who told you|کی بهت گفته؟
why did you lie to me|چرا بهم دروغ گفتی؟
how did you know|از کجا می_دونستی؟
how do you know|از کجا می_دونی؟
how did you find me|چطور پیدام کردی؟
how long will it take|چقدر طول می_کشه؟
how can i help you|چطور می_تونم کمکتون کنم؟
it is not what you think|اون چیزی که فکر می_کنی نیست
it is not like that|این_جوری نیست
it is a long story|داستانش طولانیه
it is a secret|یه رازه
it is your fault|تقصیر توئه
it is about time|دیگه وقتشه
it is getting late|داره دیر می_شه
it is going to be okay|درست می_شه
everything is going to be okay|همه_چی درست می_شه
everything will be fine|همه_چی درست می_شه
everything is fine|همه_چی مرتبه
i am cold|سردمه
i am hot|گرممه
i am home|من خونه_م
i am listening|دارم گوش می_کنم
i am going home|دارم می_رم خونه
i am just joking|فقط شوخی می_کنم
i was just kidding|فقط شوخی کردم
i was wrong|اشتباه کردم
i am wrong|اشتباه می_کنم
you are so stupid|خیلی احمقی
you are so beautiful|خیلی زیبایی
you look tired|خسته به نظر می_رسی
you look good|خوب به نظر می_رسی
you did great|عالی بودی
you made me happy|خوشحالم کردی
you broke my heart|دلمو شکوندی
you are hurting me|داری اذیتم می_کنی
you are killing me|داری منو می_کشی
you are lying to me|داری بهم دروغ می_گی
you can not leave|نمی_تونی بری
you should not have done that|نباید این کارو می_کردی
you should go|باید بری
you should sleep|باید بخوابی
you must be tired|حتماً خسته_ای
you have to believe me|باید باور کنی
you have to trust me|باید بهم اعتماد کنی
be patient|صبور باش
be strong|قوی باش
be honest|صادق باش
stay here|همین_جا بمون
stay with me|پیشم بمون
stay away from me|ازم دور بمون
shut the door|درو ببند
open the door|درو باز کن
turn it off|خاموشش کن
turn it on|روشنش کن
pick it up|برش دار
let him go|ولش کن
let her go|ولش کن
leave him alone|ولش کن
leave her alone|ولش کن
that is a lie|این دروغه
that is impossible|این غیرممکنه
that was close|نزدیک بود
"""
}
