package app.tarjoman

/**
 * English -> Persian phrase table for everyday talk, slang and idioms (offline).
 * ML Kit translates word by word and gets idioms wrong ("be cool" = "be cold"), so whole sentences and whole clauses
 * found in this table are answered directly; everything else still goes to ML Kit, one short sentence/clause at a time.
 * In the table "_" stands for the Persian half-space (ZWNJ) and "؟" marks a question.
 */
object Idm {
    class Seg(val en: String, val fa: String?, val sepAfter: String)
    class Plan(val segs: List<Seg>, val end: String)

    private val died = Regex("\\b(am|is|are|was|were|be|been)\\s+((?:i|you|he|she|we|they|it)\\s+)?died\\b")
    private val fillers = Regex("^(oh|ah|well|so|hey|okay|ok|yeah|yes|no|um|uh|hmm|look|listen)\\s+")
    private val tail = Regex("\\s+(please|man|dude|bro|buddy)$")
    private val endRe = Regex("^(.*?)([.!?\u2026]*)$", RegexOption.DOT_MATCHES_ALL)
    private val clauseRe = Regex("\\s*,\\s*(?:(?:or|and|but)\\s+)?|\\s+or\\s+|\\s+and\\s+|\\s+but\\s+", RegexOption.IGNORE_CASE)
    private val abbr = Regex("(?i)(^|\\s)(mr|mrs|ms|dr|st|vs|etc|jr|sr|no|[a-z])\\.$")
    private val splitRe = Regex("(?<=[.!?\u2026\u3002])\\s+")

    /** Lower case, expanded contractions, no punctuation: the form used to compare phrases. */
    fun norm(s: String): String {
        var t = s.lowercase().replace('\u2019', '\'').replace('\u2018', '\'')
        t = t.replace("won't", "will not").replace("can't", "can not").replace("cannot", "can not")
            .replace("let's", "let us").replace("i'm", "i am").replace("you're", "you are").replace("we're", "we are")
            .replace("they're", "they are").replace("he's", "he is").replace("she's", "she is").replace("it's", "it is")
            .replace("that's", "that is").replace("what's", "what is").replace("there's", "there is")
            .replace("who's", "who is").replace("where's", "where is").replace("how's", "how is")
            .replace("n't", " not").replace("gonna", "going to").replace("wanna", "want to").replace("gotta", "have to")
        t = died.replace(t) { m -> m.groupValues[1] + " " + m.groupValues[2] + "dead" }
        t = t.replace(Regex("[^a-z0-9' ]"), " ").replace(Regex("\\s+"), " ").trim()
        return t
    }

    private val table: HashMap<String, String> by lazy {
        val m = HashMap<String, String>()
        for (line in DATA.lines()) {
            val i = line.indexOf('|')
            if (i <= 0) continue
            m[norm(line.substring(0, i))] = line.substring(i + 1).trim().replace('_', '\u200c')
        }
        m
    }

    /** Exact match of a whole sentence or clause (ignores case, punctuation, a leading "oh/well/hey", a trailing "man/please"). */
    fun lookup(en: String): String? {
        var k = norm(en)
        if (k.isEmpty()) return null
        table[k]?.let { return it }
        for (i in 0 until 2) {
            val k2 = tail.replace(fillers.replace(k, ""), "")
            if (k2 == k || k2.isEmpty()) break
            k = k2
            table[k]?.let { return it }
        }
        return null
    }

    /** Splits a line into sentences (not after Mr. / Dr. / single capitals). */
    fun sentences(line: String): List<String> {
        val raw = line.trim().split(splitRe).filter { it.isNotBlank() }
        val out = ArrayList<String>()
        for (p in raw) {
            if (out.isNotEmpty() && abbr.containsMatchIn(out.last())) out[out.size - 1] = out.last() + " " + p else out.add(p)
        }
        return out
    }

    private fun sepFa(s: String): String = when (s.trim().trimStart(',').trim().lowercase()) {
        "" -> "\u060C "
        "or" -> " \u06CC\u0627 "
        "and" -> " \u0648 "
        "but" -> " \u0648\u0644\u06CC "
        else -> " "
    }

    /** A plan when the table helps with this sentence (whole sentence, or at least one clause of it); otherwise null. */
    fun plan(sentence: String): Plan? {
        val m = endRe.find(sentence.trim()) ?: return null
        val body = m.groupValues[1].trim()
        val end = m.groupValues[2]
        if (body.isEmpty()) return null
        lookup(body)?.let { return Plan(listOf(Seg(body, it, "")), end) }
        val segs = ArrayList<Seg>()
        var pos = 0
        for (c in clauseRe.findAll(body)) {
            val txt = body.substring(pos, c.range.first).trim()
            if (txt.isNotEmpty()) segs.add(Seg(txt, lookup(txt), sepFa(c.value)))
            pos = c.range.last + 1
        }
        val last = body.substring(pos).trim()
        if (last.isNotEmpty()) segs.add(Seg(last, lookup(last), ""))
        if (segs.size < 2 || segs.none { it.fa != null }) return null
        return Plan(segs, end)
    }

    /** Builds the Persian sentence; [tr] translates the clauses that are not in the table. */
    fun assemble(p: Plan, tr: (String) -> String): String {
        val sb = StringBuilder()
        var q = false
        p.segs.forEachIndexed { i, s ->
            var t = (s.fa ?: tr(s.en)).trim()
            if (t.endsWith("\u061F") || t.endsWith("?")) q = true
            t = t.trimEnd('.', '?', '\u061F', '!', '\u060C', ',', ' ')
            sb.append(t)
            if (i < p.segs.size - 1) sb.append(s.sepAfter)
        }
        var end = p.end.replace('?', '\u061F').replace('\u2026', '.')
        if (q) end = if (end.contains('!')) "\u061F!" else "\u061F"
        return sb.toString() + end
    }

    private const val DATA = """
can you be cool|می_تونی باحال باشی؟
could you be cool|می_تونی باحال باشی؟
be cool|باحال باش
stay cool|خونسرد باش
keep cool|خونسرد باش
keep your cool|خونسردیتو حفظ کن
lose your cool|کنترلتو از دست بده
that is cool|باحاله
this is cool|این باحاله
it is cool|باحاله
so cool|خیلی باحاله
very cool|خیلی باحاله
how cool|چه باحال
cool|باحال
awesome|محشره
amazing|عالیه
that is awesome|محشره
that is amazing|عالیه
that is sick|محشره
am i dead|مردم؟
am i dead or alive|مردم یا زنده_ام؟
i am dead|مردم
am i alive|زنده_ام؟
am i dreaming|دارم خواب می_بینم؟
am i tripping|دارم توهم می_زنم؟
am i crazy|دیوونه شدم؟
am i going crazy|دارم دیوونه می_شم؟
am i losing my mind|دارم عقلمو از دست می_دم؟
i am tripping|دارم توهم می_زنم
i am going crazy|دارم دیوونه می_شم
i am losing my mind|دارم عقلمو از دست می_دم
are you tripping|توهم زدی؟
you are tripping|داری توهم می_زنی
stop tripping|دست از توهم زدن بردار
are you crazy|دیوونه شدی؟
you are crazy|دیوونه_ای
are you out of your mind|عقلتو از دست دادی؟
you are out of your mind|عقلتو از دست دادی
what the hell|این دیگه چیه؟
what the hell is wrong with you|تو دیگه چه مرگته؟
what the hell is going on|اینجا چه خبره؟
what the hell are you doing|داری چه غلطی می_کنی؟
what is wrong with you|تو چت شده؟
what is wrong|چی شده؟
what is going on|چه خبره؟
what is up|چه خبر؟
what is up with you|تو چته؟
what happened|چی شد؟
what did you say|چی گفتی؟
what do you mean|منظورت چیه؟
what is that|اون چیه؟
what is this|این چیه؟
what are you doing|چیکار می_کنی؟
what do you want|چی می_خوای؟
what is your name|اسمت چیه؟
who are you|تو کی هستی؟
where are you|کجایی؟
where are you going|کجا داری می_ری؟
how are you|حالت چطوره؟
how are you doing|حالت چطوره؟
how is it going|اوضاع چطوره؟
how dare you|چطور جرئت می_کنی؟
why not|چرا که نه؟
why|چرا؟
really|واقعاً؟
seriously|جدی؟
for real|جدی؟
are you serious|جدی می_گی؟
are you kidding me|شوخی می_کنی؟
are you kidding|شوخی می_کنی؟
you are kidding|داری شوخی می_کنی
you must be kidding|حتماً شوخی می_کنی
just kidding|شوخی کردم
i am kidding|شوخی کردم
i am joking|شوخی کردم
i am just kidding|فقط شوخی کردم
no way|امکان نداره
no kidding|جدی؟
shut up|خفه شو
shut your mouth|دهنتو ببند
be quiet|ساکت باش
get lost|گمشو
go away|برو پی کارت
leave me alone|تنهام بذار
let me go|ولم کن
let go of me|ولم کن
do not touch me|بهم دست نزن
do not move|تکون نخور
do not worry|نگران نباش
do not lie to me|بهم دروغ نگو
do not do that|این کارو نکن
stop it|بسه دیگه
stop|وایستا
enough|بسه
that is enough|دیگه بسه
calm down|آروم باش
relax|آروم باش
take it easy|آروم باش
chill out|خونسرد باش
chill|خونسرد باش
never mind|بی_خیال
forget it|بی_خیال
it does not matter|مهم نیست
no problem|مشکلی نیست
no worries|نگران نباش
my bad|تقصیر من بود
it is not my fault|تقصیر من نیست
it is not fair|این منصفانه نیست
sorry|ببخشید
i am sorry|متأسفم
excuse me|ببخشید
thank you|ممنون
thanks|مرسی
thanks a lot|خیلی ممنون
you are welcome|خواهش می_کنم
please|لطفاً
good luck|موفق باشی
good job|آفرین
well done|آفرین
nice job|دمت گرم
great job|عالی بود
congratulations|تبریک می_گم
good morning|صبح بخیر
good evening|عصر بخیر
good night|شب بخیر
goodbye|خداحافظ
bye|خداحافظ
see you later|بعداً می_بینمت
see you|می_بینمت
hello|سلام
hi|سلام
hey|هی
i am fine|خوبم
i am good|خوبم
i am okay|من خوبم
are you okay|حالت خوبه؟
are you ok|حالت خوبه؟
nice to meet you|از آشنایی باهات خوشحالم
i love you|دوستت دارم
i miss you|دلم برات تنگ شده
i hate you|ازت متنفرم
i do not know|نمی_دونم
i do not care|برام مهم نیست
i do not understand|نمی_فهمم
i do not think so|فکر نکنم
i think so|فکر کنم
i guess so|فکر کنم همین_طوره
of course|معلومه
sure|حتماً
maybe|شاید
exactly|دقیقاً
oh my god|وای خدا
oh my gosh|وای خدای من
holy crap|وای خدا
damn|لعنتی
damn it|لعنتی
oh no|وای نه
come on|بیا دیگه
hurry up|عجله کن
wait|صبر کن
wait a minute|یه دقیقه صبر کن
wait a second|یه لحظه صبر کن
hold on|یه لحظه صبر کن
hang on|یه لحظه صبر کن
hang in there|تحمل کن
look out|حواست باشه
watch out|مواظب باش
be careful|مراقب باش
let us go|بزن بریم
come here|بیا اینجا
follow me|دنبالم بیا
help me|کمکم کن
help|کمک
i need help|کمک می_خوام
i am bored|حوصله_م سر رفته
i am tired|خسته_ام
i am hungry|گشنمه
i am thirsty|تشنمه
i am scared|می_ترسم
you are right|حق با توئه
you are wrong|اشتباه می_کنی
you are fired|اخراجی
that is true|درسته
that is right|درسته
that is not true|این درست نیست
unbelievable|باورنکردنیه
i can not believe it|باورم نمی_شه
i knew it|می_دونستم
i told you|بهت گفته بودم
told you so|گفته بودم
you did it|موفق شدی
i did it|موفق شدم
i give up|تسلیم شدم
lucky you|خوش به حالت
you are so lucky|چقدر خوش_شانسی
you can do it|می_تونی از پسش بربیای
you got this|از پسش برمیای
here we go again|باز شروع شد
not again|دوباره نه
bless you|عافیت باشه
cheers|به سلامتی
happy birthday|تولدت مبارک
happy new year|سال نو مبارک
"""
}
