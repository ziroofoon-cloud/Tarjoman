package app.tarjoman

import android.content.Context
import android.graphics.Typeface
import android.net.Uri
import java.io.File

/** Fonts for the translation drawn on pictures: the phone's own families, fonts added from a file, and a few downloadable ones. */
object Fonts {
    class Info(val id: String, val label: String)

    private val cache = HashMap<String, Typeface?>()
    @Volatile var app: Context? = null

    fun dir(ctx: Context): File = File(ctx.filesDir, "fonts").apply { mkdirs() }

    /** Fonts that can be downloaded (Google Fonts files, open licence). */
    val downloads = listOf(
        Triple("Vazirmatn.ttf", "Vazirmatn", "https://raw.githubusercontent.com/google/fonts/main/ofl/vazirmatn/Vazirmatn%5Bwght%5D.ttf"),
        Triple("Lalezar.ttf", "Lalezar", "https://raw.githubusercontent.com/google/fonts/main/ofl/lalezar/Lalezar-Regular.ttf")
    )

    fun list(ctx: Context): List<Info> {
        val l = ArrayList<Info>()
        l.add(Info("", L("خودکار (کلفت)")))
        l.add(Info("sans", L("ساده (Sans)")))
        l.add(Info("condensed", L("باریک (Condensed)")))
        l.add(Info("serif", L("کتابی (Serif)")))
        l.add(Info("casual", L("دست‌نویس ساده (Casual)")))
        l.add(Info("cursive", L("خط‌نویس (Cursive)")))
        l.add(Info("mono", L("ماشین‌تحریر (Mono)")))
        dir(ctx).listFiles()?.filter { it.isFile && (it.name.endsWith(".ttf", true) || it.name.endsWith(".otf", true)) }
            ?.sortedBy { it.name }?.forEach { l.add(Info("file:" + it.name, it.name.substringBeforeLast('.'))) }
        return l
    }

    fun label(ctx: Context, id: String): String = list(ctx).firstOrNull { it.id == id }?.label ?: L("خودکار (کلفت)")

    /** The typeface for [id]; [bold] only matters for the phone's own families. Falls back to bold sans. */
    fun face(ctx0: Context?, id: String, bold: Boolean): Typeface {
        val ctx = ctx0 ?: app
        val style = if (bold) Typeface.BOLD else Typeface.NORMAL
        if (id.isEmpty()) return Typeface.create(Typeface.DEFAULT, if (bold) Typeface.BOLD else Typeface.NORMAL)
        if (id.startsWith("file:")) {
            val f = if (ctx != null) File(dir(ctx), id.removePrefix("file:")) else null
            if (f != null && f.isFile) {
                val t = synchronized(cache) { cache.getOrPut(id) { try { Typeface.createFromFile(f) } catch (_: Throwable) { null } } }
                if (t != null) return if (bold && Build_SDK_P) Typeface.create(t, 700, false) else t
            }
            return Typeface.create(Typeface.DEFAULT, style)
        }
        val fam = when (id) { "condensed" -> "sans-serif-condensed"; "serif" -> "serif"; "casual" -> "casual"; "cursive" -> "cursive"; "mono" -> "monospace"; else -> "sans-serif" }
        return Typeface.create(fam, style)
    }

    private val Build_SDK_P get() = android.os.Build.VERSION.SDK_INT >= 28

    /** Copies a font file chosen by the user; returns the saved name or null. */
    fun import(ctx: Context, uri: Uri): String? {
        var name = "font_" + System.currentTimeMillis() + ".ttf"
        ctx.contentResolver.query(uri, null, null, null, null)?.use {
            if (it.moveToFirst()) { val ix = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME); if (ix >= 0) name = it.getString(ix) }
        }
        if (!name.endsWith(".ttf", true) && !name.endsWith(".otf", true)) return null
        val dest = File(dir(ctx), name.replace('/', '_'))
        ctx.contentResolver.openInputStream(uri)?.use { ins -> dest.outputStream().use { ins.copyTo(it) } } ?: return null
        // a broken file is refused here, not later when the picture is drawn
        return try { Typeface.createFromFile(dest); synchronized(cache) { cache.remove("file:" + dest.name) }; dest.name } catch (_: Throwable) { dest.delete(); null }
    }

    fun delete(ctx: Context, id: String) {
        if (!id.startsWith("file:")) return
        try { File(dir(ctx), id.removePrefix("file:")).delete() } catch (_: Throwable) {}
        synchronized(cache) { cache.remove(id) }
    }
}
