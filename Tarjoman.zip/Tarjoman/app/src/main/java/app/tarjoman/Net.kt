package app.tarjoman

import java.io.IOException
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.URL
import java.net.URLEncoder

object Net {
    fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    fun proxyOf(c: Cfg): Proxy {
        val port = c.proxyPort.trim().toIntOrNull()
        if (c.proxyType == "none" || c.proxyHost.isBlank() || port == null) return Proxy.NO_PROXY
        val type = if (c.proxyType == "socks") Proxy.Type.SOCKS else Proxy.Type.HTTP
        return Proxy(type, InetSocketAddress.createUnresolved(c.proxyHost.trim(), port))
    }

    fun open(url: String, c: Cfg, timeout: Int = 15000): HttpURLConnection {
        val h = URL(url).openConnection(proxyOf(c)) as HttpURLConnection
        h.connectTimeout = timeout
        h.readTimeout = timeout
        h.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 12; Redmi Note 9 Pro) AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36")
        return h
    }

    fun get(url: String, c: Cfg, timeout: Int = 15000): String {
        val h = open(url, c, timeout)
        try {
            val code = h.responseCode
            val stream = if (code in 200..299) h.inputStream else h.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw IOException("HTTP $code")
            return text
        } finally {
            h.disconnect()
        }
    }

    fun postJson(url: String, body: String, headers: Map<String, String>, c: Cfg, timeout: Int = 90000): String {
        val h = open(url, c, timeout)
        try {
            h.requestMethod = "POST"
            h.doOutput = true
            h.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            for ((k, v) in headers) h.setRequestProperty(k, v)
            h.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = h.responseCode
            val stream = if (code in 200..299) h.inputStream else h.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw IOException("HTTP $code ${text.take(200)}")
            return text
        } finally {
            h.disconnect()
        }
    }
}
