package app.tarjoman

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri

/** PDF translation: each page is rendered, read with OCR (works for text PDFs and scans), then translated. */
object PdfTool {
    fun pageCount(ctx: Context, uri: Uri): Int {
        val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: throw IllegalStateException("فایل باز نشد")
        try {
            val r = PdfRenderer(pfd)
            try { return r.pageCount } finally { r.close() }
        } finally {
            pfd.close()
        }
    }

    private fun render(r: PdfRenderer, i: Int, targetW: Int): Bitmap {
        val p = r.openPage(i)
        try {
            val sc = targetW.toFloat() / p.width
            val bmp = Bitmap.createBitmap(targetW, (p.height * sc).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            return bmp
        } finally {
            p.close()
        }
    }

    /** Blocking; run on a worker thread. */
    fun translate(
        ctx: Context, uri: Uri, start: Int, s: String, d: String, tr: Tr,
        cancel: () -> Boolean, onStatus: (String) -> Unit, onPage: (Int, String) -> Unit
    ) {
        val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: throw IllegalStateException("فایل باز نشد")
        try {
            val r = PdfRenderer(pfd)
            try {
                val n = r.pageCount
                for (i in start until n) {
                    if (cancel()) break
                    onStatus("صفحه " + (i + 1) + " از " + n + ": خواندن متن…")
                    val bmp = render(r, i, 1700)
                    val blocks = Ocr.read(bmp, s)
                    bmp.recycle()
                    val sb = StringBuilder()
                    for ((k, b) in blocks.withIndex()) {
                        if (cancel()) break
                        onStatus("صفحه " + (i + 1) + " از " + n + ": ترجمه بخش " + (k + 1) + "/" + blocks.size)
                        val res = tr.translate(b.text, s, d) { }
                        if (res.text == null) throw IllegalStateException(res.err ?: "خطا")
                        sb.append(res.text).append("\n\n")
                    }
                    if (!cancel()) onPage(i, if (blocks.isEmpty()) "(متنی پیدا نشد)" else sb.toString().trim())
                }
            } finally {
                r.close()
            }
        } finally {
            pfd.close()
        }
    }
}
