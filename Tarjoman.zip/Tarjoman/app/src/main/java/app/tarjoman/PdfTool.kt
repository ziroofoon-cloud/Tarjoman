package app.tarjoman

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.text.StaticLayout
import android.text.TextPaint
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.File
import java.io.OutputStream
import android.net.Uri

/** PDF translation: each page is rendered, read with OCR (works for text PDFs and scans), then translated. */
object PdfTool {
    private var boxReady = false

    /** Opens the PDF for direct text extraction; null if that is not possible (then OCR is used). */
    private fun openText(ctx: Context, uri: Uri): Pair<PDDocument, File>? = try {
        if (!boxReady) { PDFBoxResourceLoader.init(ctx.applicationContext); boxReady = true }
        val f = File(ctx.cacheDir, "current.pdf")
        ctx.contentResolver.openInputStream(uri)?.use { ins -> f.outputStream().use { ins.copyTo(it) } }
        Pair(PDDocument.load(f, MemoryUsageSetting.setupTempFileOnly()), f)
    } catch (e: Throwable) {
        null
    }

    /** Text of one page, or null when it has too little real text (scan) so OCR must be used. */
    private fun pageText(doc: PDDocument, i: Int): String? = try {
        val st = PDFTextStripper()
        st.setStartPage(i + 1)
        st.setEndPage(i + 1)
        st.setSortByPosition(true)
        val t = st.getText(doc)
        if (t.count { it.isLetter() } >= 30) t else null
    } catch (e: Throwable) {
        null
    }

    /** Joins hard-wrapped lines into paragraphs. */
    private fun paragraphs(t: String): List<String> {
        val out = ArrayList<String>()
        val cur = StringBuilder()
        fun flush() { if (cur.isNotBlank()) out.add(cur.toString().trim()); cur.setLength(0) }
        for (raw in t.replace("\r", "").split("\n")) {
            val l = raw.trim()
            if (l.isEmpty()) { flush(); continue }
            if (cur.isNotEmpty()) {
                val last = cur.last()
                if (last == '-' && cur.length > 1) cur.setLength(cur.length - 1) else cur.append(' ')
            }
            cur.append(l)
            if (l.last() in ".!?:;\u3002\u061F\u2026\"\u201D" && l.length < 60) flush()
        }
        flush()
        return out
    }

    /** Writes the translated text as a simple A4 PDF (works for Persian / RTL too). */
    fun export(text: String, out: OutputStream) {
        val pw = 595
        val ph = 842
        val m = 40
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 13f; color = Color.BLACK }
        val sl = StaticLayout.Builder.obtain(text, 0, text.length, tp, pw - 2 * m).setLineSpacing(0f, 1.3f).build()
        val doc = PdfDocument()
        try {
            var line = 0
            var page = 1
            while (line < sl.lineCount) {
                val pg = doc.startPage(PdfDocument.PageInfo.Builder(pw, ph, page).create())
                val c = pg.canvas
                val top = sl.getLineTop(line)
                var end = line
                while (end < sl.lineCount && sl.getLineBottom(end) - top <= ph - 2 * m) end++
                if (end == line) end = line + 1
                c.save()
                c.translate(m.toFloat(), m.toFloat())
                c.clipRect(0f, 0f, (pw - 2 * m).toFloat(), (sl.getLineBottom(end - 1) - top).toFloat())
                c.translate(0f, -top.toFloat())
                sl.draw(c)
                c.restore()
                doc.finishPage(pg)
                line = end
                page++
            }
            if (sl.lineCount == 0) doc.finishPage(doc.startPage(PdfDocument.PageInfo.Builder(pw, ph, 1).create()))
            doc.writeTo(out)
        } finally {
            doc.close()
        }
    }

    fun pageCount(ctx: Context, uri: Uri): Int {
        val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: throw IllegalStateException(L("فایل باز نشد"))
        try {
            val r = PdfRenderer(pfd)
            try { return r.pageCount } finally { r.close() }
        } finally {
            pfd.close()
        }
    }

    private fun render(r: PdfRenderer, i: Int, targetW: Int): Bitmap {
        val p = r.openPage(i)
        try {
            val sc = targetW.toFloat() / p.width
            val bmp = Bitmap.createBitmap(targetW, (p.height * sc).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            return bmp
        } finally {
            p.close()
        }
    }

    /** Blocking; run on a worker thread. */
    fun translate(
        ctx: Context, uri: Uri, start: Int, s: String, d: String, tr: Tr,
        cancel: () -> Boolean, onStatus: (String) -> Unit, onPage: (Int, String, String, String) -> Unit
    ) {
        val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: throw IllegalStateException(L("فایل باز نشد"))
        try {
            val r = PdfRenderer(pfd)
            // Persian PDFs often come out in visual (reversed) order from text extraction, so those use OCR.
            val box = if (s == "fa") null else openText(ctx, uri)
            try {
                val n = r.pageCount
                for (i in start until n) {
                    if (cancel()) break
                    onStatus(L("صفحه ") + (i + 1) + L(" از ") + n + L(": خواندن متن…"))
                    val direct = if (box != null) pageText(box.first, i) else null
                    val blocks: List<String> = if (direct != null) paragraphs(direct) else {
                        val bmp = render(r, i, 1700)
                        val ob = Ocr.read(bmp, s)
                        bmp.recycle()
                        ob.map { it.text }
                    }
                    val sb = StringBuilder()
                    val ob = StringBuilder()
                    val bb = StringBuilder()
                    for ((k, b) in blocks.withIndex()) {
                        if (cancel()) break
                        onStatus(L("صفحه ") + (i + 1) + L(" از ") + n + L(": ترجمه بخش ") + (k + 1) + "/" + blocks.size)
                        val res = tr.translate(b, s, d) { }
                        if (res.text == null) throw IllegalStateException(res.err ?: L("خطا"))
                        sb.append(res.text).append("\n\n")
                        ob.append(b).append("\n\n")
                        bb.append(b).append("\n\u2192 ").append(res.text).append("\n\n")
                    }
                    if (!cancel()) {
                        val none = L("(متنی پیدا نشد)")
                        if (blocks.isEmpty()) onPage(i, none, none, none)
                        else onPage(i, sb.toString().trim(), ob.toString().trim(), bb.toString().trim())
                    }
                }
            } finally {
                try { box?.first?.close() } catch (_: Throwable) {}
                try { box?.second?.delete() } catch (_: Throwable) {}
                r.close()
            }
        } finally {
            pfd.close()
        }
    }
}
