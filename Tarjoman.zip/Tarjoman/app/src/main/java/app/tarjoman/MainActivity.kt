package app.tarjoman

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.ConcurrentHashMap

class MainActivity : Activity() {
    private lateinit var ui: Ui
    private lateinit var tr: Tr
    private lateinit var cfg: Cfg
    private val h = Handler(Looper.getMainLooper())

    private lateinit var content: FrameLayout
    private val pages = ArrayList<View>()
    private val tabViews = ArrayList<TextView>()

    // text page
    private lateinit var srcBtn: TextView
    private lateinit var dstBtn: TextView
    private lateinit var input: EditText
    private lateinit var output: TextView
    private lateinit var status: TextView
    private lateinit var goBtn: TextView

    // image page
    private lateinit var imgView: ImageView
    private lateinit var imgStatus: TextView
    private lateinit var imgText: TextView

    // models page
    private lateinit var modelsBox: LinearLayout
    private val progress = HashMap<String, TextView>()
    private val downloads = ConcurrentHashMap<String, Downloader>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ui = Ui(this)
        cfg = Cfg(this)
        tr = Tr(this)
        window.statusBarColor = C.BG
        window.navigationBarColor = C.BG

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(C.BG)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val title = ui.tv("ترجمان", 24f, C.TXT, true).apply {
            typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
            setPadding(ui.dp(18), ui.dp(36), ui.dp(18), ui.dp(4))
        }
        root.addView(title)
        root.addView(ui.tv("مترجم آفلاین با هوش مصنوعی", 12f, C.SUB).apply { setPadding(ui.dp(18), 0, ui.dp(18), ui.dp(6)) })

        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))

        pages.add(buildTextPage())
        pages.add(buildImagePage())
        pages.add(buildModelsPage())
        pages.add(buildSettingsPage())
        pages.forEach { content.addView(it, FrameLayout.LayoutParams(MATCH, MATCH)) }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(C.CARD)
        }
        listOf("متن", "عکس", "مدل‌ها", "تنظیمات").forEachIndexed { i, n ->
            val t = ui.tv(n, 14f, C.SUB, true).apply {
                gravity = Gravity.CENTER
                setPadding(0, ui.dp(14), 0, ui.dp(14))
                setOnClickListener { show(i) }
            }
            tabViews.add(t)
            bar.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        root.addView(bar)
        setContentView(root)
        show(0)
    }

    private fun show(i: Int) {
        pages.forEachIndexed { k, v -> v.visibility = if (k == i) View.VISIBLE else View.GONE }
        tabViews.forEachIndexed { k, t -> t.setTextColor(if (k == i) C.ACC else C.SUB) }
        if (i == 2) refreshModels()
    }

    private fun toast(m: String) { h.post { Toast.makeText(this, m, Toast.LENGTH_LONG).show() } }

    // ------------------------------------------------------------------ TEXT PAGE
    private fun refreshLang() {
        srcBtn.text = Lang.name(cfg.src)
        dstBtn.text = Lang.name(cfg.dst)
    }

    private fun pickLang(isSrc: Boolean) {
        AlertDialog.Builder(this)
            .setItems(Lang.all.map { Lang.name(it) }.toTypedArray()) { _, i ->
                val c = Lang.all[i]
                if (isSrc) {
                    if (c == cfg.dst) cfg.dst = cfg.src
                    cfg.src = c
                } else {
                    if (c == cfg.src) cfg.src = cfg.dst
                    cfg.dst = c
                }
                refreshLang()
            }.show()
    }

    private fun modeCard(): View {
        val c = ui.card()
        fun row(label: String, opts: List<String>, sel: Int, on: (Int) -> Unit) {
            c.addView(ui.tv(label, 12f, C.SUB), ui.lp(top = 6))
            c.addView(ui.seg(opts, sel, on), ui.lp(top = 3))
        }
        row("موتور ترجمه", listOf("Normal (سبک)", "Advanced (AI)"), if (cfg.mode == "advanced") 1 else 0) { cfg.mode = if (it == 1) "advanced" else "normal" }
        row("سرعت / دقت", listOf("سریع", "کند و دقیق"), if (cfg.speed == "slow") 1 else 0) { cfg.speed = if (it == 1) "slow" else "fast" }
        row("اتصال", listOf("آفلاین", "آنلاین"), if (cfg.net == "online") 1 else 0) { cfg.net = if (it == 1) "online" else "offline" }
        return c
    }

    private fun buildTextPage(): View {
        val sv = ScrollView(this)
        val col = ui.vbox()
        sv.addView(col)

        val row = ui.hbox()
        srcBtn = ui.btn("", false) { pickLang(true) }
        dstBtn = ui.btn("", false) { pickLang(false) }
        val swap = ui.btn("⇄") {
            val a = cfg.src; cfg.src = cfg.dst; cfg.dst = a; refreshLang()
        }
        row.addView(srcBtn, ui.hlp())
        row.addView(swap, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = ui.dp(8) })
        row.addView(dstBtn, ui.hlp(1f, 8))
        col.addView(row)
        refreshLang()

        col.addView(modeCard(), ui.lp(top = 12))

        input = ui.edit("متن را بنویس یا بچسبان…", 5)
        col.addView(input, ui.lp(top = 12))

        val r2 = ui.hbox()
        r2.addView(ui.btn("چسباندن", false) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() ?: ""
            input.setText(t)
        }, ui.hlp())
        r2.addView(ui.btn("پاک کردن", false) { input.setText(""); output.text = ""; status.text = "" }, ui.hlp(1f, 8))
        goBtn = ui.btn("ترجمه") { doTranslate() }
        r2.addView(goBtn, ui.hlp(1.3f, 8))
        col.addView(r2, ui.lp(top = 8))

        status = ui.tv("", 12f, C.SUB)
        col.addView(status, ui.lp(top = 10))

        val oc = ui.card()
        output = ui.tv("", 17f, C.TXT).apply {
            setTextIsSelectable(true)
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            setLineSpacing(0f, 1.15f)
        }
        oc.addView(output)
        oc.addView(ui.btn("کپی ترجمه", false) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("tr", output.text))
            toast("کپی شد")
        }, ui.lp(top = 10))
        col.addView(oc, ui.lp(top = 6))
        return sv
    }

    private fun doTranslate() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        goBtn.isEnabled = false
        status.text = "در حال ترجمه…"
        output.text = ""
        val s = cfg.src
        val d = cfg.dst
        tr.exec.execute {
            val r = tr.translate(text, s, d) { p -> h.post { status.text = p } }
            h.post {
                goBtn.isEnabled = true
                if (r.text != null) { output.text = r.text; status.text = r.info } else { status.text = "خطا: " + r.err }
            }
        }
    }

    // ------------------------------------------------------------------ IMAGE PAGE
    private fun buildImagePage(): View {
        val sv = ScrollView(this)
        val col = ui.vbox()
        sv.addView(col)
        col.addView(ui.tv("عکس (مانگا، اسکرین‌شات، متن روی تصویر) را انتخاب کن. متن خوانده، ترجمه و روی خود عکس نوشته می‌شود. زبان مبدأ را از تب «متن» انتخاب کن (انگلیسی یا ژاپنی).", 12f, C.SUB))
        col.addView(ui.btn("انتخاب عکس از گالری") {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "image/*" }
            startActivityForResult(i, 1)
        }, ui.lp(top = 10))
        imgStatus = ui.tv("", 12f, C.SUB)
        col.addView(imgStatus, ui.lp(top = 8))
        imgView = ImageView(this).apply { adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER }
        col.addView(imgView, ui.lp(top = 8))
        val oc = ui.card()
        imgText = ui.tv("", 15f, C.TXT).apply { setTextIsSelectable(true); textDirection = View.TEXT_DIRECTION_FIRST_STRONG }
        oc.addView(imgText)
        col.addView(oc, ui.lp(top = 10))
        return sv
    }

    private fun decode(uri: Uri): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var sample = 1
        while (o.outWidth / sample > 2200 || o.outHeight / sample > 2200) sample *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = sample }
        return contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
    }

    private fun runImage(uri: Uri) {
        val s = cfg.src
        val d = cfg.dst
        if (s == "fa") { imgStatus.text = "خواندن متن فارسی از عکس هنوز اضافه نشده (فاز بعد). مبدأ را روی انگلیسی یا ژاپنی بگذار."; return }
        imgStatus.text = "در حال خواندن عکس…"
        imgText.text = ""
        tr.exec.execute {
            try {
                val bmp = decode(uri) ?: throw IllegalStateException("عکس باز نشد")
                val rec = if (s == "ja") TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
                else TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                val vt = Tasks.await(rec.process(InputImage.fromBitmap(bmp, 0)))
                val blocks = vt.textBlocks.filter { it.boundingBox != null && it.text.isNotBlank() }
                if (blocks.isEmpty()) { h.post { imgStatus.text = "متنی در عکس پیدا نشد." }; return@execute }
                val out = bmp.copy(Bitmap.Config.ARGB_8888, true)
                val canvas = Canvas(out)
                val all = StringBuilder()
                blocks.forEachIndexed { i, b ->
                    h.post { imgStatus.text = "ترجمه بلوک " + (i + 1) + " از " + blocks.size + "…" }
                    val raw = if (s == "ja") b.text.replace("\n", "") else b.text.replace("\n", " ")
                    val r = tr.translate(raw, s, d) { }
                    val t = r.text ?: raw
                    drawBlock(canvas, bmp, b.boundingBox!!, t)
                    all.append(t).append("\n\n")
                }
                h.post { imgView.setImageBitmap(out); imgText.text = all.toString().trim(); imgStatus.text = "تمام شد (" + blocks.size + " بلوک)" }
            } catch (e: Throwable) {
                h.post { imgStatus.text = "خطا: " + (e.cause?.message ?: e.message) }
            }
        }
    }

    private fun drawBlock(c: Canvas, bmp: Bitmap, r: Rect, text: String) {
        val rr = Rect(r)
        rr.inset(-4, -4)
        if (!rr.intersect(0, 0, bmp.width, bmp.height)) return
        val col = sample(bmp, rr)
        c.drawRect(rr, Paint().apply { color = col; style = Paint.Style.FILL })
        val lum = 0.299 * Color.red(col) + 0.587 * Color.green(col) + 0.114 * Color.blue(col)
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = if (lum > 140) Color.BLACK else Color.WHITE }
        val w = maxOf(rr.width(), 24)
        var size = minOf(rr.height().toFloat(), 64f)
        var sl: StaticLayout
        while (true) {
            tp.textSize = size
            sl = StaticLayout.Builder.obtain(text, 0, text.length, tp, w).setAlignment(Layout.Alignment.ALIGN_CENTER).build()
            if (sl.height <= rr.height() || size <= 9f) break
            size -= 2f
        }
        c.save()
        c.translate(rr.left.toFloat(), rr.top + (rr.height() - sl.height) / 2f)
        sl.draw(c)
        c.restore()
    }

    private fun sample(b: Bitmap, r: Rect): Int {
        val xs = intArrayOf(r.left + 1, (r.left + r.right) / 2, r.right - 2)
        val ys = intArrayOf(r.top + 1, (r.top + r.bottom) / 2, r.bottom - 2)
        var rs = 0; var gs = 0; var bs = 0; var n = 0
        for (x in xs) for (y in ys) {
            val px = b.getPixel(x.coerceIn(0, b.width - 1), y.coerceIn(0, b.height - 1))
            rs += Color.red(px); gs += Color.green(px); bs += Color.blue(px); n++
        }
        return Color.rgb(rs / n, gs / n, bs / n)
    }

    // ------------------------------------------------------------------ MODELS PAGE
    private fun buildModelsPage(): View {
        val sv = ScrollView(this)
        modelsBox = ui.vbox()
        sv.addView(modelsBox)
        return sv
    }

    private fun refreshModels() {
        modelsBox.removeAllViews()
        progress.clear()

        val k = ui.card()
        k.addView(ui.tv("Normal · ML Kit (آفلاین)", 16f, C.TXT, true))
        k.addView(ui.tv("بسته‌های زبانی گوگل (حدود ۳۰ مگ برای هر زبان). یک‌بار با اینترنت دانلود کن، بعد آفلاین کار می‌کند.", 12f, C.SUB), ui.lp(top = 4))
        val kr = ui.hbox()
        kr.addView(ui.btn("انگلیسی ↔ فارسی") { packDl("fa") }, ui.hlp())
        kr.addView(ui.btn("ژاپنی", false) { packDl("ja") }, ui.hlp(1f, 8))
        k.addView(kr, ui.lp(top = 8))
        modelsBox.addView(k)

        modelsBox.addView(ui.tv("Advanced · مدل‌های AI روی گوشی", 16f, C.TXT, true), ui.lp(top = 18))
        modelsBox.addView(ui.tv("هرچه مدل بزرگ‌تر، ترجمه بهتر ولی کندتر. برای مدل‌های Gemma باید در تنظیمات توکن Hugging Face بگذاری. اگر Hugging Face فیلتر است، در تنظیمات آینه یا پروکسی بگذار.", 12f, C.SUB), ui.lp(top = 2))

        for (m in Models.catalog) {
            modelsBox.addView(
                modelCard(m.id, m.title + "  ·  " + m.tier, "≈ " + m.mb + " MB", m.note, Models.file(this, m), m.url),
                ui.lp(top = 10)
            )
        }

        val manual = Models.manualFiles(this)
        if (manual.isNotEmpty()) {
            modelsBox.addView(ui.tv("مدل‌های دستی", 14f, C.TXT, true), ui.lp(top = 18))
            for (f in manual) modelsBox.addView(modelCard("m:" + f.name, f.name, "", "", f, null), ui.lp(top = 8))
        }

        val add = ui.card()
        add.addView(ui.tv("افزودن مدل دستی", 16f, C.TXT, true))
        add.addView(ui.tv("فایل .task / .bin سازگار با MediaPipe (مثلاً از litert-community در Hugging Face).", 12f, C.SUB), ui.lp(top = 4))
        val ar = ui.hbox()
        ar.addView(ui.btn("از فایل گوشی") {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
            startActivityForResult(i, 2)
        }, ui.hlp())
        ar.addView(ui.btn("از لینک", false) { addByUrl() }, ui.hlp(1f, 8))
        add.addView(ar, ui.lp(top = 8))
        modelsBox.addView(add, ui.lp(top = 18))
    }

    private fun packDl(other: String) {
        toast("در حال دانلود بسته زبان…")
        tr.exec.execute {
            try {
                MlKit.ensure("en", other)
                toast("بسته زبان آماده شد")
            } catch (e: Throwable) {
                toast("خطا: " + (e.cause?.message ?: e.message))
            }
        }
    }

    private fun modelCard(id: String, title: String, size: String, note: String, f: File, url: String?): View {
        val c = ui.card()
        c.addView(ui.tv(title, 15f, C.TXT, true))
        if (size.isNotEmpty()) c.addView(ui.tv(size, 12f, C.SUB))
        if (note.isNotEmpty()) c.addView(ui.tv(note, 12f, C.SUB), ui.lp(top = 4))
        val installed = Models.isModelFile(f)
        val dl = downloads[id]
        val st = ui.tv(
            if (dl != null) "در حال دانلود…" else if (installed) "✓ نصب شده (" + (f.length() / 1048576) + " MB)" else "نصب نشده",
            12f, if (installed) C.OK else C.SUB
        )
        progress[id] = st
        c.addView(st, ui.lp(top = 6))
        val r = ui.hbox()
        if (dl != null) {
            r.addView(ui.btn("لغو") { dl.cancelled = true }, ui.hlp())
        } else if (installed) {
            val active = tr.activeFile()?.name == f.name
            r.addView(ui.btn(if (active) "✓ فعال" else "فعال‌سازی", !active) { cfg.activeModel = f.name; refreshModels() }, ui.hlp())
            r.addView(ui.btn("حذف", false) { f.delete(); if (cfg.activeModel == f.name) cfg.activeModel = ""; refreshModels() }, ui.hlp(1f, 8))
        } else if (url != null) {
            r.addView(ui.btn("دانلود") { startDl(id, url, f) }, ui.hlp())
        }
        c.addView(r, ui.lp(top = 8))
        return c
    }

    private fun startDl(id: String, url: String, dest: File) {
        if (downloads.containsKey(id)) return
        val dl = Downloader(cfg)
        downloads[id] = dl
        Thread {
            var last = 0L
            try {
                dl.download(url, dest) { a, b ->
                    val n = System.currentTimeMillis()
                    if (n - last > 500) {
                        last = n
                        h.post { progress[id]?.text = "دانلود: " + (a / 1048576) + " / " + (if (b > 0) (b / 1048576).toString() else "?") + " MB" }
                    }
                }
                toast("دانلود کامل شد")
            } catch (e: Throwable) {
                toast("خطا: " + e.message)
            }
            h.post { downloads.remove(id); refreshModels() }
        }.start()
        refreshModels()
    }

    private fun addByUrl() {
        val e = ui.edit("https://…/model.task")
        AlertDialog.Builder(this).setTitle("لینک مستقیم فایل مدل").setView(e)
            .setPositiveButton("دانلود") { _, _ ->
                val u = e.text.toString().trim()
                val name = u.substringBefore("?").substringAfterLast('/')
                if (u.isNotEmpty() && name.isNotEmpty()) {
                    if (name.endsWith(".litertlm")) { toast("فرمت .litertlm هنوز پشتیبانی نمی‌شود"); return@setPositiveButton }
                    askFamily(name)
                    startDl("m:$name", u, File(Models.dir(this), name))
                }
            }.setNegativeButton("بستن", null).show()
    }

    private fun askFamily(name: String) {
        AlertDialog.Builder(this).setTitle("نوع قالب چت این مدل؟")
            .setItems(arrayOf("Gemma", "Qwen / ChatML", "خام (Raw)")) { _, i ->
                cfg.setFam(name, arrayOf("gemma", "qwen", "raw")[i])
            }.show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        if (requestCode == 1) runImage(uri)
        if (requestCode == 2) importModel(uri)
    }

    private fun importModel(uri: Uri) {
        var name = "model_" + System.currentTimeMillis() + ".task"
        contentResolver.query(uri, null, null, null, null)?.use {
            if (it.moveToFirst()) {
                val ix = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (ix >= 0) name = it.getString(ix)
            }
        }
        if (name.endsWith(".litertlm")) { toast("فرمت .litertlm هنوز پشتیبانی نمی‌شود"); return }
        val fname = name
        toast("در حال کپی مدل… صبر کن")
        Thread {
            try {
                val dest = File(Models.dir(this), fname)
                contentResolver.openInputStream(uri)?.use { ins -> FileOutputStream(dest).use { out -> ins.copyTo(out, 256 * 1024) } }
                h.post { askFamily(fname); refreshModels() }
                toast("مدل اضافه شد")
            } catch (e: Throwable) {
                toast("خطا: " + e.message)
            }
        }.start()
    }

    // ------------------------------------------------------------------ SETTINGS PAGE
    private fun buildSettingsPage(): View {
        val sv = ScrollView(this)
        val col = ui.vbox()
        sv.addView(col)

        val net = ui.card()
        net.addView(ui.tv("شبکه (پروکسی/فیلترشکن)", 16f, C.TXT, true))
        net.addView(ui.tv("اگر فیلترشکن سیستمی روشن است همین کافی است؛ اگر فقط پروکسی داری اینجا بگذار. برای دانلود مدل و ترجمه آنلاین استفاده می‌شود.", 12f, C.SUB), ui.lp(top = 4))
        val types = listOf("none", "http", "socks")
        net.addView(ui.seg(listOf("بدون پروکسی", "HTTP", "SOCKS5"), types.indexOf(cfg.proxyType).coerceAtLeast(0)) { cfg.proxyType = types[it] }, ui.lp(top = 8))
        val ph = ui.edit("آدرس (مثلاً 127.0.0.1)").apply { setText(cfg.proxyHost) }
        val pp = ui.edit("پورت (مثلاً 10808)").apply { setText(cfg.proxyPort) }
        net.addView(ph, ui.lp(top = 8))
        net.addView(pp, ui.lp(top = 8))
        col.addView(net)

        val hf = ui.card()
        hf.addView(ui.tv("دانلود مدل (Hugging Face)", 16f, C.TXT, true))
        hf.addView(ui.tv("توکن فقط برای مدل‌های Gemma لازم است (از huggingface.co/settings/tokens، نوع Read، و لایسنس مدل را در سایت قبول کن). آینه برای زمانی است که huggingface.co فیلتر است.", 12f, C.SUB), ui.lp(top = 4))
        val tok = ui.edit("HF token (hf_…)", 1, true).apply { setText(cfg.hfToken) }
        val mir = ui.edit("آینه، پیش‌فرض huggingface.co").apply { setText(cfg.mirror) }
        hf.addView(tok, ui.lp(top = 8))
        hf.addView(mir, ui.lp(top = 8))
        col.addView(hf, ui.lp(top = 12))

        val api = ui.card()
        api.addView(ui.tv("آنلاین پیشرفته (اختیاری)", 16f, C.TXT, true))
        api.addView(ui.tv("اگر کلید API سازگار با OpenAI بگذاری (مثلاً Gemini رایگان)، در حالت آنلاین + Advanced با هوش مصنوعی ابری ترجمه می‌شود. خالی بماند، از ترجمه گوگل استفاده می‌شود.", 12f, C.SUB), ui.lp(top = 4))
        val au = ui.edit("آدرس API").apply { setText(cfg.apiUrl) }
        val ak = ui.edit("API key", 1, true).apply { setText(cfg.apiKey) }
        val am = ui.edit("نام مدل").apply { setText(cfg.apiModel) }
        api.addView(au, ui.lp(top = 8))
        api.addView(ak, ui.lp(top = 8))
        api.addView(am, ui.lp(top = 8))
        col.addView(api, ui.lp(top = 12))

        col.addView(ui.btn("ذخیره تنظیمات") {
            cfg.proxyHost = ph.text.toString().trim()
            cfg.proxyPort = pp.text.toString().trim()
            cfg.hfToken = tok.text.toString().trim()
            cfg.mirror = mir.text.toString().trim().ifEmpty { "huggingface.co" }
            cfg.apiUrl = au.text.toString().trim()
            cfg.apiKey = ak.text.toString().trim()
            cfg.apiModel = am.text.toString().trim()
            toast("ذخیره شد")
        }, ui.lp(top = 14))

        col.addView(ui.tv("نسخه ۰.۱ (فاز اول). فاز بعد: حباب شناور و ترجمه تمام‌صفحه، ترجمه PDF، خواندن متن فارسی از عکس.", 12f, C.SUB), ui.lp(top = 16))
        return sv
    }
}
