package app.tarjoman

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.InputType
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.ConcurrentHashMap

class MainActivity : Activity() {
    private lateinit var ui: Ui
    private lateinit var tr: Tr
    private lateinit var cfg: Cfg
    private val h = Handler(Looper.getMainLooper())

    private lateinit var content: FrameLayout
    private val pages = ArrayList<View>()
    private val tabViews = ArrayList<View>()
    private val tabIcons = ArrayList<IconView>()
    private var curTab = 0
    private var settingsScroll: ScrollView? = null
    private var dark = true
    private val tabLabels = ArrayList<TextView>()

    // text page
    private lateinit var srcBtn: TextView
    private lateinit var dstBtn: TextView
    private lateinit var input: EditText
    private lateinit var output: TextView
    private lateinit var status: TextView
    private lateinit var goBtn: TextView
    private lateinit var modeHolder: FrameLayout

    // image page
    private lateinit var imgView: ImageView
    private var imgBlocks: List<OBlock> = emptyList()
    private var imgClean: Bitmap? = null   // the picture with its old writing erased (LaMa), null = not erased
    private lateinit var imgStatus: TextView
    private lateinit var imgText: TextView
    private lateinit var imgSegHolder: FrameLayout
    private lateinit var imgTextCard: View
    private lateinit var imgActions: View
    private var imgOut: Bitmap? = null        // picture with the translation drawn on it
    private var imgOrig: Bitmap? = null       // the picture as chosen
    private var imgOrigText = ""
    private var imgTransText = ""
    private var imgMode = 0                   // 0 on the picture | 1 translated text | 2 original text
    @Volatile private var imgJob = 0
    private var imgUri: Uri? = null
    private lateinit var imgSrcBtn: TextView
    private lateinit var imgDstBtn: TextView
    private var txtJob = 0
    private var txtRunning = false

    // history page
    private lateinit var histBox: LinearLayout
    private lateinit var learnBox: LinearLayout
    private lateinit var learnStats: TextView
    private val learnQueue = ArrayList<Vocab.Card>()
    private var learnMode = 0
    private var learnDone = 0
    private var learnRight = 0
    private var tts: android.speech.tts.TextToSpeech? = null
    private var ttsOk = false
    private lateinit var histInfo: TextView
    private lateinit var histSearch: EditText
    private val histSel = HashSet<Long>()
    private val histShown = ArrayList<HEntry>()
    private var histCount = 0
    private var histBytes = 0L
    @Volatile private var histJob = 0
    private val histRun = Runnable { refreshHistory() }

    // pdf page
    private lateinit var pdfInfo: TextView
    private lateinit var pdfStatus: TextView
    private lateinit var pdfOut: TextView
    private lateinit var pdfFrom: EditText
    private var pdfUri: Uri? = null
    private var pdfPages = 0
    private val pdfSb = StringBuilder()       // translated
    private val pdfOrigSb = StringBuilder()   // extracted original
    private val pdfBiSb = StringBuilder()     // original + translation, paragraph by paragraph
    private var pdfMode = 0                   // 0 translated | 1 original | 2 both
    @Volatile private var pdfCancel = false
    @Volatile private var pdfRunning = false

    // subtitle page
    private lateinit var srtInfo: TextView
    private lateinit var srtStatus: TextView
    private lateinit var srtOut: TextView
    private lateinit var srtStartBtn: TextView
    private var srtLangS = "en"
    private var srtLangD = "fa"
    private var srtSavedAt = 0L
    private var pdfDone = 0                   // next page (0-based) to translate; kept for "continue later"
    private var pdfName = "PDF"
    private var pdfLangS = "en"
    private var pdfLangD = "fa"
    private var pdfSavedAt = 0L
    private var imgLangS = "en"
    private var imgLangD = "fa"
    private lateinit var imgContBtn: TextView
    private var srtCues: List<Cue> = emptyList()
    private val srtTexts = ArrayList<String?>()
    @Volatile private var srtCancel = false
    @Volatile private var srtRunning = false

    // bubble page
    private lateinit var bubbleStatus: TextView
    private lateinit var bubbleToggle: TextView

    /** One button: "Turn on" when the bubble is off, "Turn off" when it is on. */
    private fun updateBubbleUi() {
        val on = BubbleService.running
        bubbleStatus.text = if (on) L("حباب روشن است") else L("حباب خاموش است")
        bubbleStatus.setTextColor(if (on) C.OK else C.SUB)
        bubbleToggle.text = if (on) L("خاموش کردن حباب") else L("روشن کردن حباب")
    }

    // models page
    private lateinit var modelsBox: LinearLayout
    private val progress = HashMap<String, TextView>()

    private fun statusBarH(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else ui.dp(24)
    }

    /** Writes the stack trace of a crash to files/crash.txt, so the cause can be read and sent (Settings -> last error). */
    private fun installCrashLog() {
        val app = applicationContext
        val old = Thread.getDefaultUncaughtExceptionHandler()
        if (old is CrashLog) return
        Thread.setDefaultUncaughtExceptionHandler(CrashLog(app, old))
    }

    private class CrashLog(val ctx: Context, val next: Thread.UncaughtExceptionHandler?) : Thread.UncaughtExceptionHandler {
        override fun uncaughtException(t: Thread, e: Throwable) {
            try {
                val sw = java.io.StringWriter()
                e.printStackTrace(java.io.PrintWriter(sw))
                val v = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName } catch (_: Throwable) { "?" }
                java.io.File(ctx.filesDir, "crash.txt").writeText(
                    "Tarjoman " + v + " · Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ") · " + Build.MANUFACTURER + " " + Build.MODEL +
                        "\nthread: " + t.name + "\n\n" + sw.toString().take(6000)
                )
            } catch (_: Throwable) {}
            next?.uncaughtException(t, e)
        }
    }

    /** Settings card with the last crash report (only when there is one). */
    private fun crashCard(): View? {
        val f = File(filesDir, "crash.txt")
        if (!f.isFile) return null
        val txt = try { f.readText() } catch (_: Throwable) { return null }
        val c = ui.card()
        c.addView(ui.tv(L("آخرین خطای برنامه"), 16f, C.TXT, true))
        c.addView(ui.tv(L("برنامه دفعهٔ قبل ناگهان بسته شده. این گزارش را کپی کن و بفرست تا دلیلش پیدا شود."), 12f, C.SUB), ui.lp(top = 4))
        c.addView(ui.tv(txt.take(1200), 10f, C.SUB).apply { setTextIsSelectable(true); textDirection = View.TEXT_DIRECTION_LTR }, ui.lp(top = 6))
        val r = ui.hbox()
        r.addView(ui.btn(L("کپی گزارش"), false) {
            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("crash", txt)); toast(L("کپی شد"))
        }, ui.hlp())
        r.addView(ui.btn(L("پاک کردن گزارش"), false) { f.delete(); toast(L("حذف شد")) }, ui.hlp(1f, 8))
        c.addView(r, ui.lp(top = 8))
        return c
    }

    private var crashNote: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        installCrashLog()
        crashNote = try { Models.settleCrash(this) } catch (_: Throwable) { null }
        cfg = Cfg(this)
        dark = C.setup(this, cfg)
        // Dialogs follow the same light/dark choice.
        setTheme(if (dark) android.R.style.Theme_DeviceDefault_NoActionBar else android.R.style.Theme_DeviceDefault_Light_NoActionBar)
        super.onCreate(savedInstanceState)
        Lay.set(cfg.layout)
        Ui.hideHelp = cfg.simple == 1
        ui = Ui(this, true)
        tr = Tr.get(this)
        window.statusBarColor = C.BG
        window.navigationBarColor = C.BAR
        window.decorView.systemUiVisibility =
            if (dark) 0 else (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(C.BG)
            layoutDirection = S.dir
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(20), ui.dp(6), ui.dp(20), ui.dp(8))   // title close to the status bar
        }
        head.addView(ui.tv(L("ترجمان"), if (C.classic) 28f else 24f, C.TXT, true))
        root.addView(head)
        if (C.classic) {
            // thin rule under the title, like a book page
            root.addView(View(this).apply { setBackgroundColor(C.LINE) },
                LinearLayout.LayoutParams(MATCH, ui.dp(1)).apply { marginStart = ui.dp(20); marginEnd = ui.dp(20) })
        }

        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))

        pages.add(buildTextPage())
        pages.add(buildImagePage())
        pages.add(buildPdfPage())
        pages.add(buildSrtPage())
        pages.add(buildBubblePage())
        pages.add(buildModelsPage())
        pages.add(buildSettingsPage())
        pages.add(buildHistoryPage())   // page 7: opened from the Text tab and from Settings (no tab of its own)
        pages.add(buildLearnPage())     // page 8: language learning, opened from the Text tab
        pages.forEach { content.addView(it, FrameLayout.LayoutParams(MATCH, MATCH)) }

        // Bottom bar: drawn icons (no emoji), label, and a soft pill behind the selected tab.
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(C.BAR)
            setPadding(ui.dp(4), ui.dp(6), ui.dp(4), ui.dp(8))
        }
        val kinds = listOf("text", "image", "pdf", "sub", "bubble", "model", "settings")
        listOf(L("متن"), L("عکس"), "PDF", L("زیرنویس"), L("حباب"), L("مدل‌ها"), L("تنظیمات")).forEachIndexed { i, n ->
            val ic = IconView(this, kinds[i], C.SUB)
            val lb = ui.tv(n, 10.5f, C.SUB, true).apply { gravity = Gravity.CENTER; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END; setAutoSizeTextTypeUniformWithConfiguration(8, 11, 1, android.util.TypedValue.COMPLEX_UNIT_SP); visibility = if (Lay.tabLabels) View.VISIBLE else View.GONE }
            val t = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(0, ui.dp(7), 0, ui.dp(6))
                setOnClickListener { show(i) }
                addView(ic, LinearLayout.LayoutParams(ui.dp(24), ui.dp(24)))
                addView(lb, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = ui.dp(2) })
            }
            tabViews.add(t)
            tabIcons.add(ic)
            tabLabels.add(lb)
            bar.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = ui.dp(2); marginEnd = ui.dp(2) })
        }
        val line = View(this).apply { setBackgroundColor(C.LINE) }
        root.addView(line, LinearLayout.LayoutParams(MATCH, ui.dp(1)))
        root.addView(bar)
        setContentView(root)

        // After a theme / language change the activity is rebuilt: come back to the same tab and scroll position.
        restoreState()
        show(savedInstanceState?.getInt("tab", 0) ?: 0)
        val sy = savedInstanceState?.getInt("setY", 0) ?: 0
        if (sy > 0) settingsScroll?.post { settingsScroll?.scrollTo(0, sy) }
        if (savedInstanceState == null) handleIntent(intent)
        // Warm up the offline engine in the background, so the first translation does not wait for the model to load.
        if (savedInstanceState == null && cfg.mode == "normal") {
            val ws = cfg.src
            val wd = cfg.dst
            tr.exec.execute {
                try {
                    if (ws != wd && MlKit.isDownloaded(ws) && MlKit.isDownloaded(wd)) {
                        MlKit.ensure(ws, wd)
                        MlKit.one("hi", ws, wd)
                    }
                } catch (_: Throwable) {
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        // Downloads run in a service: when the screen comes back, show their real state again.
        Dl.listener = { id, fin -> h.post { if (fin) { if (curTab == 5) refreshModels() } else updateProgress(id) } }
        if (curTab == 5) refreshModels()
        crashNote?.let { n ->
            crashNote = null
            val nm = n.substringAfter(":")
            toast(if (n.startsWith("bad:")) L("مدل «") + nm + L("» دو بار برنامه را بست و کنار گذاشته شد. حذفش کن و دوباره بگیر.") else L("برنامه هنگام استفاده از مدل «") + nm + L("» بسته شده بود؛ حافظهٔ موقت مدل پاک شد و یک بار دیگر تلاش می‌شود."))
        }
    }

    override fun onStop() {
        saveSrtNow()
        savePdfNow()
        Dl.listener = null
        super.onStop()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("tab", curTab)
        outState.putInt("setY", settingsScroll?.scrollY ?: 0)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    /** Text shared from another app (Share menu) or selected text ("Tarjoman" in the selection menu). */
    private fun handleIntent(i: Intent?) {
        val t: String? = when (i?.action) {
            Intent.ACTION_SEND -> i?.getStringExtra(Intent.EXTRA_TEXT)
            Intent.ACTION_PROCESS_TEXT -> i?.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString()
            else -> null
        }
        when (i?.action) {
            "app.tarjoman.WIDGET_TEXT" -> { show(0); input.requestFocus() }
            "app.tarjoman.WIDGET_MIC" -> { show(0); listenMic() }
            "app.tarjoman.WIDGET_IMAGE" -> show(1)
        }
        if (!t.isNullOrBlank()) {
            show(0)
            input.setText(t)
            doTranslate()   // also guesses the source language when that option is on
        }
    }

    private fun show(i: Int) {
        curTab = i
        pages.forEachIndexed { k, v -> v.visibility = if (k == i) View.VISIBLE else View.GONE }
        tabViews.forEachIndexed { k, t ->
            val on = k == i
            t.background = if (on) ui.rect((C.ACC and 0x00FFFFFF) or 0x26000000, C.R_BTN) else null
            tabIcons[k].setTint(if (on) C.ACC else C.SUB)
            tabLabels[k].setTextColor(if (on) C.ACC else C.SUB)
        }
        if (i == 0) { refreshLang(); modeHolder.removeAllViews(); modeHolder.addView(modeCard()) }
        if (i == 4) updateBubbleUi()
        if (i == 5) {
            if (!modelsBuilt) {
                // show the tab at once, build the long list one frame later
                modelsBox.removeAllViews()
                modelsBox.addView(ui.tv(L("در حال بارگذاری…"), 13f, C.SUB), ui.lp(top = 20))
                h.post { refreshModels() }
            } else checkPacks()
        }
        if (i == 7) refreshHistory()
        if (i == 8) refreshLearn()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (curTab == 7 || curTab == 8) show(0) else super.onBackPressed()
    }

    private fun toast(m: String) { h.post { Toast.makeText(this, m, Toast.LENGTH_LONG).show() } }

    // ------------------------------------------------------------------ TEXT PAGE
    /** Asks the keyboard to use the source language when the text box is used (and again when the language changes). */
    private fun applyKeyboard() {
        if (!::input.isInitialized) return
        try {
            input.imeHintLocales = if (cfg.kbAuto == 1) android.os.LocaleList(java.util.Locale(cfg.src)) else null
            if (input.hasFocus()) (getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).restartInput(input)
        } catch (_: Throwable) {}
    }

    private fun refreshLang() {
        srcBtn.text = Lang.name(cfg.src).substringBefore(" ·")
        dstBtn.text = Lang.name(cfg.dst).substringBefore(" ·")
        // ask the keyboard to switch to the source language (works when that language is enabled in the keyboard)
        applyKeyboard()
        if (::imgSrcBtn.isInitialized) {
            imgSrcBtn.text = srcBtn.text
            imgDstBtn.text = dstBtn.text
        }
    }

    private fun pickLang(isSrc: Boolean) {
        AlertDialog.Builder(this)
            .setItems(Lang.all.map { Lang.name(it) }.toTypedArray()) { _, i ->
                val c = Lang.all[i]
                if (isSrc) {
                    if (c == cfg.dst) cfg.dst = cfg.src
                    cfg.src = c
                } else {
                    if (c == cfg.src) cfg.src = cfg.dst
                    cfg.dst = c
                }
                refreshLang()
            }.show()
    }

    private fun modeCard(): View {
        val c = ui.card()
        fun row(label: String, opts: List<String>, sel: Int, on: (Int) -> Unit) {
            c.addView(ui.tv(label, 12f, C.SUB), ui.lp(top = 6))
            c.addView(ui.seg(opts, sel, on), ui.lp(top = 3))
        }
        c.addView(ui.tv(L("حالت مطمئن"), 14f, C.ACC, true), ui.lp(top = 2))
        c.addView(ui.seg(listOf(L("خاموش"), L("روشن")), cfg.safe) { cfg.safe = it }, ui.lp(top = 4))
        c.addView(ui.tv(L("اگر جایی مشکل یا خطا دیدی، این را روشن کن: فقط روش ساده و آزموده (خواندن با ML Kit و Tesseract، پاک‌کردن ساده، موتور Normal، بدون PaddleOCR، پیداکنندهٔ متن، LaMa و هوش مصنوعی ابری، و بدون برش صفحه‌های بلند) استفاده می‌شود. روی سطح تلاش و تنظیمات دیگر اولویت دارد و تنظیمات ذخیره‌شده‌ات پاک نمی‌شود."), 11f, C.SUB), ui.lp(top = 3))
        c.addView(ui.tv(L("سطح تلاش (سرعت یا دقت)"), 14f, C.ACC, true), ui.lp(top = 12))
        val pl = listOf("custom", "fast", "balanced", "accurate", "smart")
        c.addView(ui.seg(listOf(L("دستی"), L("سریع"), L("متوسط"), L("دقیق"), L("هوشمند")), pl.indexOf(cfg.perf).coerceAtLeast(0)) { cfg.perf = pl[it] }, ui.lp(top = 4))
        c.addView(ui.tv(L("هوشمند: خودش براساس چیزی که ترجمه می‌کنی (متن، زیرنویس، عکس، مانگا، PDF، صفحهٔ زنده) و حافظهٔ گوشی بهترین ترکیب را انتخاب می‌کند؛ لازم نیست هیچ تنظیمی را بشناسی. سریع: کمترین مصرف و سریع‌ترین. متوسط: تعادل. دقیق: بهترین کیفیت، کندتر و با مصرف بیشتر (مدل‌های نصب‌شده را استفاده می‌کند). دستی: همان تنظیمات جزئی خودت؛ با انتخاب هر سطح دیگر، تنظیمات ذخیره‌شده‌ات پاک نمی‌شود و با برگشتن به «دستی» برمی‌گردند."), 11f, C.SUB), ui.lp(top = 4))
        row(L("حالت خودکار (همه‌چیز را خودش انتخاب کند)"), listOf(L("خاموش"), L("روشن")), cfg.auto) { cfg.auto = it; Auto.decide(cfg, "", false) }
        c.addView(ui.tv(L("روشن باشد، برای هر متن خودش موتور (Normal / AI)، سبک (محاوره‌ای / رسمی) و سرعت را انتخاب می‌کند: متن کوتاه و صمیمی = محاوره‌ای، متن بلند و رسمی = رسمی، حباب زنده = سریع. انتخاب‌های خودت ذخیره می‌مانند و با خاموش‌کردن برمی‌گردند. (اتصال آنلاین/آفلاین جدا تنظیم می‌شود.)"), 11f, C.SUB), ui.lp(top = 2))
        row(L("موتور ترجمه"), listOf(L("Normal (سبک)"), "Advanced (AI)"), if (cfg.mode == "advanced") 1 else 0) { cfg.mode = if (it == 1) "advanced" else "normal"; if (it == 0) tr.cancelAi() }
        row(L("سبک ترجمه"), listOf(L("محاوره‌ای"), L("رسمی")), if (cfg.style == "formal") 1 else 0) { cfg.style = if (it == 1) "formal" else "casual" }
        c.addView(ui.tv(L("محاوره‌ای: برای زیرنویس، مانگا و گفتگو. رسمی: برای کتاب و مقاله."), 11f, C.SUB), ui.lp(top = 3))
        row(L("سرعت / دقت"), listOf(L("سریع"), L("کند و دقیق")), if (cfg.speed == "slow") 1 else 0) { cfg.speed = if (it == 1) "slow" else "fast" }
        row(L("اتصال"), listOf(L("آفلاین"), L("آنلاین"), L("خودکار")), when (cfg.net) { "online" -> 1; "auto" -> 2; else -> 0 }) { cfg.net = when (it) { 1 -> "online"; 2 -> "auto"; else -> "offline" } }
        row(L("ترکیب ML Kit + AI (آزمایشی، برای فارسی بهتر در Advanced)"), listOf(L("خاموش"), L("روشن")), cfg.hybrid) { cfg.hybrid = it }
        return c
    }

    private fun buildTextPage(): View {
        val sv = ScrollView(this)
        val col = ui.vbox()
        sv.addView(col)

        // Labels on top, then [from] [swap] [to] on one line, all vertically centred with each other.
        val lblRow = ui.hbox()
        lblRow.addView(ui.tv(L("از (زبان مبدأ)"), 11f, C.SUB, true).apply { setPadding(ui.dp(4), 0, ui.dp(4), 0) }, ui.hlp())
        lblRow.addView(View(this), LinearLayout.LayoutParams(ui.dp(52), 1))
        lblRow.addView(ui.tv(L("به (زبان مقصد)"), 11f, C.SUB, true).apply { setPadding(ui.dp(4), 0, ui.dp(4), 0) }, ui.hlp())
        col.addView(lblRow)

        val row = ui.hbox()
        srcBtn = ui.btn("", true) { pickLang(true) }
        dstBtn = ui.btn("", false) { pickLang(false) }
        val swap = ui.iconBtn("swap", 44, true) {
            val a = cfg.src; cfg.src = cfg.dst; cfg.dst = a; refreshLang()
        }
        row.addView(srcBtn, ui.hlp())
        row.addView(swap, LinearLayout.LayoutParams(ui.dp(44), ui.dp(44)).apply { marginStart = ui.dp(4); marginEnd = ui.dp(4) })
        row.addView(dstBtn, ui.hlp())
        col.addView(row, ui.lp(top = 4))
        refreshLang()

        modeHolder = FrameLayout(this)
        modeHolder.addView(modeCard())

        input = ui.edit(L("متن را بنویس یا بچسبان…"), 5)
        applyKeyboard()
        input.setOnFocusChangeListener { _, f -> if (f) applyKeyboard() }
        input.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun afterTextChanged(e: android.text.Editable?) {
                // the meanings under the result belong to the text that was translated: when the text is cleared or changed they go
                if (::meaningsTv.isInitialized && (e?.toString()?.trim() ?: "") != meaningsFor) { meaningsJob++; meaningsTv.visibility = View.GONE }
                // the text was deleted: the translation, its other meanings and the status go away at once (also stops a running one)
                if (e.isNullOrBlank() && ::output.isInitialized && ::status.isInitialized) {
                    if (txtRunning) stopTranslate()
                    txtJob++; meaningsFor = ""; output.text = ""; status.text = ""
                }
                if (cfg.live != 1) return
                h.removeCallbacks(liveRun)
                if (e.isNullOrBlank()) { output.text = ""; status.text = ""; return }
                h.postDelayed(liveRun, if (cfg.mode == "advanced") 1600L else 700L)
            }
        })
        col.addView(input, ui.lp(top = 10))

        val r2 = ui.hbox()
        r2.addView(ui.tile("paste", L("چسباندن")) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() ?: ""
            input.setText(t)
        }, ui.hlp())
        r2.addView(ui.tile("mic", L("میکروفون")) { listenMic() }, ui.hlp(1f, 6))
        r2.addView(ui.tile("pen", L("دست‌خط")) {
            HandInk.show(this, ui, cfg.src) { t -> input.setText(t); input.setSelection(input.text.length); doTranslate() }
        }, ui.hlp(1f, 6))
        r2.addView(ui.tile("speaker", L("تلفظ")) { val t = input.text.toString().trim(); if (t.isNotEmpty()) speak(t, cfg.src) }, ui.hlp(1f, 6))
        r2.addView(ui.tile("clear", L("پاک")) { input.setText(""); output.text = ""; status.text = "" }, ui.hlp(1f, 6))
        goBtn = ui.btn(L("ترجمه")) { if (txtRunning) stopTranslate() else doTranslate() }
        r2.addView(goBtn, LinearLayout.LayoutParams(0, MATCH, 1.5f).apply { marginStart = ui.dp(6) })
        col.addView(r2, ui.lp(top = 8))

        status = ui.tv("", 12f, C.SUB)
        col.addView(status, ui.lp(top = 10))

        val oc = ui.card()
        output = ui.tv("", 17f, C.TXT).apply {
            setTextIsSelectable(true)
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            setLineSpacing(0f, 1.15f)
        }
        oc.addView(output)
        meaningsTv = ui.tv("", 13f, C.SUB).apply { visibility = View.GONE; setTextIsSelectable(true) }
        oc.addView(meaningsTv, ui.lp(top = 6))
        val orow = ui.hbox()
        orow.addView(ui.tile("copy", L("کپی")) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("tr", output.text))
            toast(L("کپی شد"))
        }, ui.hlp())
        orow.addView(ui.tile("speaker", L("تلفظ")) { val t = output.text.toString().trim(); if (t.isNotEmpty()) speak(t, cfg.dst) }, ui.hlp(1f, 6))
        orow.addView(ui.tile("retry", L("دوباره")) {
            if (txtRunning) stopTranslate()
            doTranslate(true)
        }, ui.hlp(1f, 6))
        orow.addView(ui.tile("share", L("اشتراک")) { shareTextOut(output.text.toString()) }, ui.hlp(1f, 6))
        oc.addView(orow, ui.lp(top = 10))
        val xrow = ui.hbox()
        xrow.addView(ui.tile("bookmark", L("واژگان من")) { saveToVocab() }, ui.hlp())
        xrow.addView(ui.tile("list", L("معانی دیگر")) { showSenses() }, ui.hlp(1f, 6))
        if (cfg.simple != 1) {
            xrow.addView(ui.tile("plus", L("ترجمهٔ دلخواه")) { addOwnMeaning() }, ui.hlp(1f, 6))
            xrow.addView(ui.tile("pen", L("اصلاح ترجمه")) { correctTranslation() }, ui.hlp(1f, 6))
        }
        oc.addView(xrow, ui.lp(top = 8))
        col.addView(oc, ui.lp(top = 6))
        // Mode / speed / connection are set once and rarely: they sit under the result so the text box and the result are always on top.
        if (cfg.simple != 1) col.addView(modeHolder, ui.lp(top = 12))
        val hr = ui.hbox()
        hr.addView(ui.tile("history", L("تاریخچه ترجمه")) { show(7) }, ui.hlp())
        hr.addView(ui.tile("cap", L("آموزش زبان")) { show(8) }, ui.hlp(1f, 8))
        col.addView(hr, ui.lp(top = 10))
        return sv
    }

    /** "Translate while typing": runs shortly after the last key; waits if a translation is still running. */
    private val liveRun = object : Runnable {
        override fun run() {
            if (cfg.live != 1 || input.text.isNullOrBlank()) return
            if (txtRunning) { h.postDelayed(this, 400); return }
            doTranslate()
        }
    }

    /** Small line under the result: the other meanings the user saved for this text. */
    private lateinit var meaningsTv: TextView

    private var meaningsJob = 0
    private var meaningsFor = ""
    @Volatile private var bulkRunning = false

    /** Under the result: the important meanings of a word by part of speech (saved ones also work offline). */
    private fun updateMeanings(out: String? = null) {
        val src = input.text.toString().trim()
        val s = cfg.src; val d = cfg.dst
        val job = ++meaningsJob
        meaningsFor = src
        if (src.isEmpty()) { meaningsTv.visibility = View.GONE; return }
        // short forms inside the text (HD, LOL, Hz …) and what they stand for
        val abbr = if (Abbr.whole(src) != null || NumWords.isNumber(src)) "" else Abbr.inText(src).joinToString("\n") { Abbr.line(it.first, it.second, d) }
        fun put(t: String) {
            val all = (t + (if (abbr.isNotEmpty()) (if (t.isNotEmpty()) "\n" else "") + abbr else "")).trim()
            if (all.isEmpty()) meaningsTv.visibility = View.GONE else { meaningsTv.text = all; meaningsTv.visibility = View.VISIBLE }
        }
        if (!Dict.isWord(src)) {
            val all = if (s == "en" && d == "fa") Idm.mineAll(src) else emptyList()
            put(if (all.size > 1) L("معانی ذخیره‌شده: ") + all.joinToString("  •  ") else "")
            return
        }
        Thread {
            val r = try { Dict.lookup(this, cfg, src, s, d, out ?: output.text.toString(), cfg.learnAuto == 1) } catch (_: Throwable) { null }
            val ph = if (s == "en" && cfg.net != "offline" && !src.contains(' ') && Net.isOnline(this)) try { Spell.ipa(src) } catch (_: Throwable) { null } else null
            runOnUiThread {
                if (job != meaningsJob) return@runOnUiThread
                val own = if (s == "en" && d == "fa") Idm.mineAll(src) else emptyList()
                val groups = if (r == null) emptyList() else Dict.firstPage(r)
                val sb = StringBuilder()
                if (ph != null) sb.append(L("تلفظ: ")).append(ph).append('\n')
                if (own.size > 1) sb.append(L("معانی ذخیره‌شده: ")).append(own.joinToString("  •  ")).append('\n')
                for ((p, ws) in groups) sb.append(if (p.isEmpty()) "" else "$p: ").append(ws.joinToString("  •  ")).append('\n')
                put(sb.toString().trim())
            }
        }.start()
    }

    /** One picture for a bug report: the original with every found block boxed and numbered, and under it what was read and what it became. */
    private fun diagReport(): Bitmap? {
        val src = imgOrig ?: return null
        val w = src.width
        val pad = 16
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; textSize = maxOf(22f, w / 38f) }
        val sb = StringBuilder()
        sb.append("v").append(try { packageManager.getPackageInfo(packageName, 0).versionName } catch (_: Throwable) { "?" }).append("  ").append(src.width).append("x").append(src.height).append("  ").append(Ocr.diag).append("\n\n")
        imgBlocks.forEachIndexed { i, b -> sb.append(i + 1).append(")  ").append(b.text.replace("\n", " ")).append("\n      ->  ").append(b.out.replace("\n", " ")).append("\n\n") }
        val lay = StaticLayout.Builder.obtain(sb.toString(), 0, sb.length, tp, w - 2 * pad).setAlignment(Layout.Alignment.ALIGN_NORMAL).build()
        val res = Bitmap.createBitmap(w, src.height + lay.height + 2 * pad, Bitmap.Config.ARGB_8888)
        val c = Canvas(res)
        c.drawColor(Color.WHITE)
        c.drawBitmap(src, 0f, 0f, null)
        val bp = Paint().apply { style = Paint.Style.STROKE; strokeWidth = maxOf(3f, w / 300f); color = Color.RED }
        val np = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.RED; textSize = maxOf(24f, w / 34f); isFakeBoldText = true }
        imgBlocks.forEachIndexed { i, b -> c.drawRect(b.rect, bp); c.drawText((i + 1).toString(), b.rect.left.toFloat() + 4f, b.rect.top.toFloat() + np.textSize, np) }
        c.save(); c.translate(pad.toFloat(), (src.height + pad).toFloat()); lay.draw(c); c.restore()
        return res
    }

    /** Speech to text with the phone's own recognizer (language = the source language), then translates. */
    private fun listenMic() {
        val tag = when (cfg.src) { "fa" -> "fa-IR"; "ja" -> "ja-JP"; "en" -> "en-US"; "ko" -> "ko-KR"; "zh" -> "zh-CN"; "ar" -> "ar-SA"; "es" -> "es-ES"; else -> cfg.src }
        val i = Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, tag)
            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, tag)
            putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, Lang.name(cfg.src).substringBefore(" ·"))
        }
        try { startActivityForResult(i, 50) }
        catch (_: Throwable) { toast(L("تشخیص گفتار در این گوشی در دسترس نیست (برنامهٔ Google یا موتور گفتار لازم است).")) }
    }

    /** The user adds a meaning of his own to the list of translations of the text. */
    private fun addOwnMeaning() {
        val src = input.text.toString().trim()
        val cur = output.text.toString().trim()
        if (src.isEmpty() || cur.isEmpty()) { toast(L("اول یک متن را ترجمه کن.")); return }
        val s = cfg.src; val d = cfg.dst
        val e = ui.edit(L("ترجمه یا معنی…"), 2)
        val box = ui.vbox()
        box.setPadding(ui.dp(20), ui.dp(8), ui.dp(20), 0)
        box.addView(ui.tv(src.take(80), 13f, C.TXT, true))
        box.addView(e, ui.lp(top = 8))
        AlertDialog.Builder(this).setTitle(L("افزودن ترجمهٔ دلخواه")).setView(box)
            .setPositiveButton(L("ذخیره")) { _, _ ->
                val w = e.text.toString().replace("\n", " ").trim()
                if (w.isEmpty()) return@setPositiveButton
                if (s == "en" && d == "fa") {
                    saveMeanings(src, ((Idm.mineAll(src).ifEmpty { listOf(cur) }) + w).distinct())
                    toast(L("ذخیره شد"))
                } else Thread {
                    val r = try { Dict.lookup(this, cfg, src, s, d, cur, false, false, false) } catch (_: Throwable) { null }
                    val ents = (r?.entries ?: emptyList()) + Dict.Entry("alt", listOf(w))
                    try { Dict.save(this, src, s, d, Dict.Result(ents, ((r?.important ?: emptyList()) + w).distinct())) } catch (_: Throwable) {}
                    runOnUiThread { updateMeanings(); toast(L("ذخیره شد")) }
                }.start()
            }
            .setNegativeButton(L("بستن"), null).show()
    }

    /** Saves [values] (the first is the main one) as the correct translations of [src] and shows the main one. */
    private fun saveMeanings(src: String, values: List<String>) {
        cfg.userPhr = Idm.setMine(cfg.userPhr, src, values)
        Idm.loadMine(cfg.userPhr)
        if (values.isNotEmpty()) output.text = values[0]
        updateMeanings()
    }

    /** The user fixes a wrong translation. Several correct meanings can be saved (one per line, the first is the main one);
     *  the app uses them every time this English text comes again, in every mode. */
    private fun correctTranslation() {
        val src = input.text.toString().trim()
        val cur = output.text.toString().trim()
        if (src.isEmpty() || cur.isEmpty()) { toast(L("اول یک متن را ترجمه کن.")); return }
        if (cfg.src != "en" || cfg.dst != "fa") { toast(L("اصلاح فقط برای انگلیسی به فارسی است.")); return }
        val e = ui.edit("", 6)
        val had = Idm.mineAll(src)
        e.setText((if (had.isNotEmpty()) had else listOf(cur)).joinToString("\n"))
        val box = ui.vbox()
        box.setPadding(ui.dp(20), ui.dp(8), ui.dp(20), 0)
        box.addView(ui.tv(L("هر خط یک معنی یا ترجمهٔ درست. خط اول، ترجمهٔ اصلی است که نمایش داده می‌شود؛ بقیه به‌عنوان معنی‌های دیگر ذخیره می‌مانند. خط را پاک کنی از حافظه حذف می‌شود."), 12f, C.SUB))
        box.addView(e, ui.lp(top = 8))
        AlertDialog.Builder(this).setTitle(L("ترجمهٔ درست چیست؟")).setView(box)
            .setPositiveButton(L("ذخیره")) { _, _ ->
                val vals = e.text.toString().split("\n").map { it.trim() }.filter { it.isNotEmpty() }
                saveMeanings(src, vals)
                toast(if (vals.isEmpty()) L("حذف شد") else L("ذخیره شد؛ دفعهٔ بعد همین ترجمه می‌آید."))
            }
            .setNegativeButton(L("بستن"), null).show()
    }

    /** Settings: every saved text with its meanings; tap one to edit or delete it. */
    private fun showMineList(after: () -> Unit) {
        val list = Idm.mineEntries()
        if (list.isEmpty()) { toast(L("چیزی ذخیره نشده.")); return }
        val lines = list.map { it.en.take(60) + "  ←  " + it.values.joinToString(" • ") }.toTypedArray()
        AlertDialog.Builder(this).setTitle(L("ترجمه‌های اصلاح‌شدهٔ من"))
            .setItems(lines) { _, i ->
                val m = list[i]
                val e = ui.edit("", 6)
                e.setText(m.values.joinToString("\n"))
                val box = ui.vbox()
                box.setPadding(ui.dp(20), ui.dp(8), ui.dp(20), 0)
                box.addView(ui.tv(m.en, 13f, C.TXT, true))
                box.addView(e, ui.lp(top = 8))
                AlertDialog.Builder(this).setView(box)
                    .setPositiveButton(L("ذخیره")) { _, _ ->
                        cfg.userPhr = Idm.setMine(cfg.userPhr, m.en, e.text.toString().split("\n"))
                        Idm.loadMine(cfg.userPhr); after()
                    }
                    .setNeutralButton(L("حذف")) { _, _ ->
                        cfg.userPhr = Idm.setMine(cfg.userPhr, m.en, emptyList())
                        Idm.loadMine(cfg.userPhr); after()
                    }
                    .setNegativeButton(L("بستن"), null).show()
            }.setNegativeButton(L("بستن"), null).show()
    }

    /** Other wordings of a sentence without the internet: the spoken and the written Persian form, and the plain engine answer. */
    private fun offlineAlts(src: String, s: String, d: String, cur: String): Dict.Result? {
        val c = cur.trim()
        val alts = LinkedHashSet<String>()
        if (d == "fa" && c.isNotEmpty()) { alts.add(Fa.casual(c)); alts.add(Fa.formal(c)) }
        try { tr.translate(src, s, d, "", true) { }.text?.let { alts.add(it.trim()) } } catch (_: Throwable) {}
        alts.remove(c)
        val all = (listOf(c) + alts).filter { it.isNotBlank() }.distinct()
        return if (all.size < 2) null else Dict.Result(listOf(Dict.Entry("alt", all)), emptyList())
    }

    /** "More translations": every meaning by part of speech (Noun / Verb / Adjective …). Tick the important ones (they also show on
     *  the first page); then choose the main one or leave it automatic (the first). For English to Persian they become the saved translations. */
    private fun showSenses(net: Boolean = false) {
        val src = input.text.toString().trim()
        if (src.isEmpty()) { toast(L("اول یک متن را ترجمه کن.")); return }
        if (src.length > 300) { toast(L("برای متن کوتاه (کلمه یا جمله)")); return }
        val s = cfg.src; val d = cfg.dst
        val curOut = output.text.toString()
        Thread {
            // First the built-in dictionary and what was saved (instant, no internet); the internet only on the button, or when those know nothing
            var r0 = try { Dict.lookup(this, cfg, src, s, d, curOut, false, net, net) } catch (_: Throwable) { null }
            var fromNet = net
            if (!net && (r0 == null || r0.entries.isEmpty()) && Dict.isWord(src)) {
                runOnUiThread { toast(L("در حال گرفتن معانی از اینترنت…")) }
                r0 = try { Dict.lookup(this, cfg, src, s, d, curOut, false, true, true) } catch (_: Throwable) { null }
                fromNet = true
            }
            // A sentence with no internet: other wordings made on the phone (spoken / written, plain engine)
            val r = if ((r0 == null || r0.entries.isEmpty()) && !Dict.isWord(src)) offlineAlts(src, s, d, curOut) else r0
            runOnUiThread {
                if (r == null || r.entries.isEmpty()) { toast(L("معنی دیگری پیدا نشد (اینترنت لازم است).")); return@runOnUiThread }
                val items = ArrayList<String>()
                val lines = ArrayList<String>()
                for (e in r.entries) for (w in e.words) { items.add(w); lines.add(Dict.label(e.pos) + "  ·  " + w) }
                val had = if (s == "en" && d == "fa") Idm.mineAll(src) else r.important
                val checked = BooleanArray(items.size) { items[it] in had }
                fun finish(picked: List<String>) {
                    try { Dict.save(this, src, s, d, Dict.Result(r.entries, picked)) } catch (_: Throwable) {}
                    if (s == "en" && d == "fa") {
                        if (picked.isEmpty() && had.isNotEmpty()) { saveMeanings(src, emptyList()); toast(L("حذف شد")) }
                        else if (picked.isNotEmpty()) { saveMeanings(src, (picked + had.filter { it !in items }).distinct()); toast(L("ذخیره شد؛ دفعهٔ بعد همین ترجمه می‌آید.")) }
                    } else if (picked.isNotEmpty()) { output.text = picked[0]; toast(L("ذخیره شد")) }
                    updateMeanings()
                }
                AlertDialog.Builder(this).setTitle(L("معنی‌های مهم را علامت بزن"))
                    .setMultiChoiceItems(lines.toTypedArray(), checked) { _, i, on -> checked[i] = on }
                    .setPositiveButton(L("ذخیره")) { _, _ ->
                        val picked = items.filterIndexed { i, _ -> checked[i] }
                        if (picked.size < 2) finish(picked)
                        else {
                            val opts = (listOf(L("خودکار (اولین)")) + picked).toTypedArray()
                            AlertDialog.Builder(this).setTitle(L("معنی اصلی کدام است؟"))
                                .setSingleChoiceItems(opts, 0) { dlg, which ->
                                    dlg.dismiss()
                                    finish(if (which == 0) picked else listOf(picked[which - 1]) + picked.filterIndexed { i, _ -> i != which - 1 })
                                }.setNegativeButton(L("بستن"), null).show()
                        }
                    }
                    .apply { if (!fromNet && Dict.isWord(src)) setNeutralButton(L("معانی بیشتر از اینترنت")) { _, _ -> toast(L("در حال گرفتن معانی از اینترنت…")); showSenses(true) } }
                    .setNegativeButton(L("بستن"), null).show()
            }
        }.start()
    }

    /** Stop button (the Translate button turns into Stop while a translation runs). */
    private fun stopTranslate() {
        txtJob++
        txtRunning = false
        tr.cancelAi()
        goBtn.text = L("ترجمه")
        status.text = L("متوقف شد.")
    }

    private fun doTranslate(fresh: Boolean = false, online: Boolean = false) {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        if (txtRunning) tr.cancelAi()   // a newer request replaces the one still running
        val job = ++txtJob
        txtRunning = true
        goBtn.text = L("توقف")
        status.text = L("در حال ترجمه…")
        output.text = ""
        if (cfg.autoLang == 1) {
            val g = Fa.guess(text)
            if (g != null && g != cfg.src) {
                if (g == cfg.dst) cfg.dst = cfg.src
                cfg.src = g
                refreshLang()
            }
        }
        val s = cfg.src
        val d = cfg.dst
        // A typed number is written in words; a lone short form (HD, LOL …) is explained. No engine needed.
        run {
            val nw = NumWords.words(text, if (d == "fa" || d == "ja") d else "en")
            val ab = if (nw == null) Abbr.whole(text) else null
            val res = nw ?: ab?.let { Abbr.line(it.first, it.second, d) }
            if (res != null) {
                txtRunning = false
                goBtn.text = L("ترجمه")
                output.text = if (nw != null) nw else res
                status.text = if (nw != null) L("عدد به حروف") else L("مخفف")
                meaningsFor = text
                if (nw != null) {
                    val others = listOf("en", "fa", "ja").filter { it != (if (d == "fa" || d == "ja") d else "en") }
                    meaningsTv.text = others.joinToString("\n") { Lang.name(it).substringBefore(" ·") + ": " + NumWords.words(text, it) }
                    meaningsTv.visibility = View.VISIBLE
                } else meaningsTv.visibility = View.GONE
                saveHist("text", s, d, text, output.text.toString())
                return
            }
        }
        // One letter: which letter of the alphabet it is
        run {
            val lt = Spell.letter(text, if (d == "fa" || d == "ja") d else "en")
            if (lt != null && s == "en") {
                txtRunning = false
                goBtn.text = L("ترجمه")
                output.text = lt
                status.text = L("حرف الفبا")
                meaningsFor = text
                meaningsTv.visibility = View.GONE
                saveHist("text", s, d, text, lt)
                return
            }
        }
        // English typos: "helo" -> "hello" (the typed text stays in the box; the corrected one is translated)
        var sendText = text
        var spellNote = ""
        if (s == "en" && cfg.spell != 0) {
            val sp = try { Spell.fix(text, if (cfg.spell == 2) 4 else -1) } catch (_: Throwable) { null }
            if (sp != null) {
                if (cfg.spell == 2 && sp.changes.isNotEmpty()) { sendText = sp.text; spellNote = sp.changes.joinToString("، ") { it.from + " → " + it.to } }
                else if (sp.changes.isNotEmpty() || sp.suggestedOnly.isNotEmpty()) spellNote = L("منظورت این بود؟ ") + (sp.changes + sp.suggestedOnly).joinToString("، ") { it.from + " → " + it.to }
            }
        }
        val spellDone = sendText != text
        // Shows what is happening and how many seconds have passed (the AI can take a while on a phone).
        val t0 = System.currentTimeMillis()
        var lastProg = L("در حال ترجمه…")
        val tick = object : Runnable {
            override fun run() {
                if (txtJob == job && txtRunning) {
                    status.text = lastProg + " · " + (System.currentTimeMillis() - t0) / 1000 + "s"
                    h.postDelayed(this, 1000)
                }
            }
        }
        h.postDelayed(tick, 1000)
        tr.exec.execute {
            val r = tr.translate(if (s == "en" && tr.cfg.preFix == 1) Pre.unwrap(sendText) else sendText, s, d, "", fresh, online) { p -> h.post { if (txtJob == job) { lastProg = p; status.text = p } } }
            h.post {
                if (txtJob != job) return@post
                txtRunning = false
                goBtn.text = L("ترجمه")
                if (r.text != null) { output.text = if (cfg.numWords == 1 && (d == "fa" || d == "en" || d == "ja")) NumWords.inText(r.text, d) else r.text; status.text = r.info + (if (spellNote.isNotEmpty()) "  ·  " + (if (spellDone) L("اصلاح املا: ") else "") + spellNote else ""); saveHist("text", s, d, text, r.text); updateMeanings(r.text) } else { status.text = L("خطا: ") + r.err }
            }
        }
    }

    // ------------------------------------------------------------------ LANGUAGE LEARNING
    override fun onDestroy() {
        try { tts?.shutdown() } catch (_: Throwable) {}
        super.onDestroy()
    }

    /** Reads a word aloud with the phone's own speech engine (no download in the app). */
    private var ttsState = 0                      // 0 not started, 1 starting, 2 ready
    private var ttsPending: Pair<String, String>? = null
    private var ttsRetried = false

    private fun speak(text: String, lang: String) {
        when (ttsState) {
            2 -> speakNow(text, lang)
            1 -> { ttsPending = text to lang; toast(L("موتور تلفظ در حال آماده شدن است…")) }
            else -> {
                // The engine starts asynchronously: the first press only starts it and the word is read as soon as it is ready
                // (before, a second press during the start-up showed an error, and a failed start stayed broken until the app was reopened).
                ttsState = 1
                ttsPending = text to lang
                try { tts?.shutdown() } catch (_: Throwable) {}
                tts = null
                try {
                    tts = android.speech.tts.TextToSpeech(this) { st ->
                        h.post {
                            val p = ttsPending
                            ttsPending = null
                            if (st == android.speech.tts.TextToSpeech.SUCCESS) {
                                ttsOk = true
                                ttsState = 2
                                if (p != null) speakNow(p.first, p.second)
                            } else {
                                ttsOk = false
                                ttsState = 0
                                try { tts?.shutdown() } catch (_: Throwable) {}
                                tts = null
                                toast(L("موتور تلفظ (TTS) گوشی در دسترس نیست."))
                            }
                        }
                    }
                } catch (_: Throwable) {
                    ttsState = 0
                    toast(L("موتور تلفظ (TTS) گوشی در دسترس نیست."))
                }
            }
        }
    }

    private fun speakNow(text: String, lang: String) {
        val t = tts ?: run { ttsState = 0; return }
        val r = try { t.setLanguage(java.util.Locale.forLanguageTag(lang)) } catch (_: Throwable) { android.speech.tts.TextToSpeech.ERROR }
        if (r == android.speech.tts.TextToSpeech.LANG_MISSING_DATA || r == android.speech.tts.TextToSpeech.LANG_NOT_SUPPORTED) {
            toast(L("این زبان در موتور تلفظ گوشی نصب نیست (تنظیمات گوشی ← تبدیل متن به گفتار)."))
            return
        }
        val res = try { t.speak(text, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "tarjoman") } catch (_: Throwable) { android.speech.tts.TextToSpeech.ERROR }
        if (res != android.speech.tts.TextToSpeech.SUCCESS) {
            // the engine died in the background: start it again once and read the word
            ttsState = 0
            if (!ttsRetried) { ttsRetried = true; speak(text, lang) } else { ttsRetried = false; toast(L("موتور تلفظ (TTS) گوشی در دسترس نیست.")) }
        } else ttsRetried = false
    }

    private fun saveToVocab() {
        val a = input.text.toString().trim()
        var b = output.text.toString().trim()
        if (a.isEmpty() || b.isEmpty()) { toast(L("اول یک متن را ترجمه کن.")); return }
        if (a.length > 120) { toast(L("برای آموزش، کلمه یا جملهٔ کوتاه ذخیره کن.")); return }
        if (cfg.src == "en" && cfg.dst == "fa") { val all = Idm.mineAll(a); if (all.size > 1) b = all.joinToString(" • ") }
        val s = cfg.src; val d = cfg.dst
        Thread {
            val added = Vocab.add(this, s, d, a, b)
            toast(if (added) L("به واژگان اضافه شد.") else L("این مورد قبلاً در واژگان است."))
        }.start()
    }

    private fun buildLearnPage(): View {
        val sv = ScrollView(this)
        learnSv = sv
        val col = ui.vbox()
        sv.addView(col)
        val top = ui.hbox()
        top.addView(ui.tv(L("آموزش زبان"), 18f, C.TXT, true), ui.hlp())
        top.addView(ui.btn(L("بازگشت"), false) { show(0) }, LinearLayout.LayoutParams(WRAP, WRAP))
        col.addView(top)
        col.addView(buildPracticeCard(), ui.lp(top = 10))
        col.addView(ui.tv(L("واژگان من"), 16f, C.TXT, true), ui.lp(top = 16))
        col.addView(ui.tv(L("کلمه و جمله‌هایی که خودت برای یادگیری ذخیره می‌کنی (دکمهٔ «ذخیره برای یادگیری» زیر ترجمه) اینجا جمع می‌شوند. با کارت‌های مرور و آزمون چهارگزینه‌ای یاد می‌گیری؛ کارتی که بلدی دیرتر و کارتی که اشتباه می‌کنی زودتر دوباره می‌آید."), 12f, C.SUB), ui.lp(top = 4))
        val sc = ui.card()
        learnStats = ui.tv("", 14f, C.TXT, true)
        sc.addView(learnStats)
        col.addView(sc, ui.lp(top = 10))
        val r1 = ui.hbox()
        r1.addView(ui.btn(L("مرور کارت‌ها")) { learnStart(0) }, ui.hlp())
        r1.addView(ui.btn(L("آزمون چهارگزینه‌ای")) { learnStart(1) }, ui.hlp(1f, 8))
        col.addView(r1, ui.lp(top = 10))
        val r2 = ui.hbox()
        r2.addView(ui.btn(L("افزودن دستی"), false) { learnAdd() }, ui.hlp())
        r2.addView(ui.btn(L("از تاریخچه"), false) { learnFromHistory() }, ui.hlp(1f, 8))
        col.addView(r2, ui.lp(top = 8))
        col.addView(ui.btn(L("فهرست واژه‌ها"), false) { learnList() }, ui.lp(top = 8))
        learnBox = ui.vbox()
        col.addView(learnBox, ui.lp(top = 12))
        return sv
    }

    private fun setLearnStats() {
        Thread {
            val n = Vocab.count(this)
            val due = Vocab.due(this).size
            val ok = Vocab.learned(this)
            h.post {
                learnStats.text = L("واژه‌ها: ") + n + "  ·  " + L("برای مرور: ") + due + "  ·  " + L("یادگرفته‌شده: ") + ok
                if (learnQueue.isEmpty() && learnBox.childCount == 0)
                    learnBox.addView(ui.tv(if (n == 0) L("هنوز واژه‌ای ذخیره نشده. یک کلمه را در تب «متن» ترجمه کن و «ذخیره در واژگان» را بزن.") else L("برای شروع «مرور کارت‌ها» یا «آزمون» را بزن."), 13f, C.SUB))
            }
        }.start()
    }

    private fun refreshLearn() { setLearnStats() }

    private fun learnStart(mode: Int) {
        Thread {
            val all = Vocab.all(this)
            val q = if (mode == 0) Vocab.due(this).take(20) else all.shuffled().take(10)
            h.post {
                if (all.isEmpty()) { toast(L("اول چند واژه ذخیره کن.")); return@post }
                if (mode == 1 && all.size < 4) { toast(L("برای آزمون حداقل ۴ واژه لازم است.")); return@post }
                learnMode = mode
                learnDone = 0
                learnRight = 0
                learnQueue.clear()
                learnQueue.addAll(q)
                if (q.isEmpty()) {
                    learnBox.removeAllViews()
                    learnBox.addView(ui.tv(L("امروز چیزی برای مرور نیست. بعداً برگرد یا آزمون بزن."), 14f, C.OK))
                } else learnNext()
            }
        }.start()
    }

    private fun learnNext() {
        learnBox.removeAllViews()
        setLearnStats()
        if (learnQueue.isEmpty()) {
            val c = ui.card()
            c.addView(ui.tv(L("تمام شد."), 16f, C.OK, true))
            c.addView(ui.tv(L("کارت‌های مرورشده: ") + learnDone + (if (learnMode == 1) "  ·  " + L("درست: ") + learnRight else ""), 13f, C.TXT), ui.lp(top = 4))
            learnBox.addView(c)
            return
        }
        val c = learnQueue[0]
        if (learnMode == 0) learnFlash(c) else learnQuiz(c)
    }

    private fun learnFinishCard(c: Vocab.Card, g: Int) {
        Thread { Vocab.grade(this, c, g) }.start()
        learnQueue.removeAt(0)
        learnDone++
        if (g == 0) learnQueue.add(c)       // a missed card comes back in this round
        learnNext()
    }

    private fun frontText(c: Vocab.Card): TextView =
        ui.tv(c.a, 22f, C.TXT, true).apply { textDirection = View.TEXT_DIRECTION_FIRST_STRONG; gravity = Gravity.CENTER; setTextIsSelectable(true) }

    private fun learnFlash(c: Vocab.Card) {
        val card = ui.card()
        card.addView(ui.tv(L("کارت ") + (learnDone + 1) + " / " + (learnDone + learnQueue.size), 11f, C.SUB))
        card.addView(frontText(c), ui.lp(top = 14))
        card.addView(ui.btn(L("تلفظ"), false) { speak(c.a, c.s) }, ui.lp(top = 12))
        val ans = ui.vbox()
        card.addView(ans, ui.lp(top = 12))
        ans.addView(ui.btn(L("نمایش جواب")) {
            ans.removeAllViews()
            ans.addView(ui.tv(c.b, 20f, C.ACC, true).apply { textDirection = View.TEXT_DIRECTION_FIRST_STRONG; gravity = Gravity.CENTER; setTextIsSelectable(true) })
            val g = ui.hbox()
            g.addView(ui.btn(L("دوباره"), false) { learnFinishCard(c, 0) }, ui.hlp())
            g.addView(ui.btn(L("سخت"), false) { learnFinishCard(c, 1) }, ui.hlp(1f, 6))
            g.addView(ui.btn(L("آسان")) { learnFinishCard(c, 2) }, ui.hlp(1f, 6))
            ans.addView(g, ui.lp(top = 12))
        })
        learnBox.addView(card)
    }

    private fun learnQuiz(c: Vocab.Card) {
        val others = Vocab.all(this).filter { it.id != c.id && it.b != c.b }.shuffled().take(3).map { it.b }
        val options = (others + c.b).distinct().shuffled()
        val card = ui.card()
        card.addView(ui.tv(L("سؤال ") + (learnDone + 1) + " / " + (learnDone + learnQueue.size), 11f, C.SUB))
        card.addView(frontText(c), ui.lp(top = 14))
        card.addView(ui.btn(L("تلفظ"), false) { speak(c.a, c.s) }, ui.lp(top = 10))
        card.addView(ui.tv(L("معنی درست کدام است؟"), 12f, C.SUB), ui.lp(top = 12))
        val btns = ArrayList<TextView>()
        var answered = false
        val next = ui.btn(L("بعدی")) {}
        next.visibility = View.GONE
        for (o in options) {
            val b = ui.btn(o, false) {}
            b.setOnClickListener {
                if (answered) return@setOnClickListener
                answered = true
                val right = o == c.b
                if (right) learnRight++
                for (x in btns) if (x.text.toString() == c.b) x.text = x.text.toString() + "   (" + L("درست") + ")"
                if (!right) b.text = o + "   (" + L("نادرست") + ")"
                Thread { Vocab.grade(this, c, if (right) 2 else 0) }.start()
                next.visibility = View.VISIBLE
                next.setOnClickListener {
                    learnQueue.removeAt(0)
                    learnDone++
                    learnNext()
                }
            }
            btns.add(b)
            card.addView(b, ui.lp(top = 8))
        }
        card.addView(next, ui.lp(top = 12))
        learnBox.addView(card)
    }

    private fun learnAdd() {
        val a = ui.edit(L("کلمه یا جمله (زبان مبدأ)"), 2)
        val b = ui.edit(L("معنی"), 2)
        val box = ui.vbox()
        box.setPadding(ui.dp(20), ui.dp(8), ui.dp(20), 0)
        box.addView(a)
        box.addView(b, ui.lp(top = 8))
        val s = cfg.src; val d = cfg.dst
        AlertDialog.Builder(this).setTitle(L("افزودن به واژگان")).setView(box)
            .setPositiveButton(L("ذخیره")) { _, _ ->
                val x = a.text.toString(); val y = b.text.toString()
                Thread {
                    val ok = Vocab.add(this, s, d, x, y)
                    toast(if (ok) L("به واژگان اضافه شد.") else L("این مورد قبلاً در واژگان است."))
                    h.post { refreshLearn() }
                }.start()
            }.setNegativeButton(L("بستن"), null).show()
    }

    /** Short texts from the translation history become cards (words and short phrases only). */
    private fun learnFromHistory() {
        toast(L("در حال خواندن تاریخچه…"))
        Thread {
            var n = 0
            for (e in Hist.list(this, "", 400)) {
                if (e.kind != "text" || e.src.length > 60 || e.src.isBlank() || e.out.isBlank()) continue
                if (Vocab.add(this, e.s, e.d, e.src, e.out)) n++
            }
            toast(L("اضافه شد: ") + n)
            h.post { refreshLearn() }
        }.start()
    }

    private fun learnList() {
        Thread {
            val all = Vocab.all(this).sortedByDescending { it.id }
            h.post {
                if (all.isEmpty()) { toast(L("هنوز واژه‌ای ذخیره نشده.")); return@post }
                val lines = all.map { it.a.take(40) + "  ←  " + it.b.take(40) }.toTypedArray()
                AlertDialog.Builder(this).setTitle(L("فهرست واژه‌ها") + " (" + all.size + ")")
                    .setItems(lines) { _, i ->
                        val c = all[i]
                        AlertDialog.Builder(this).setTitle(c.a).setMessage(c.b + "\n\n" + L("جعبه: ") + c.box + "  ·  " + L("مرور: ") + c.seen)
                            .setPositiveButton(L("تلفظ")) { _, _ -> speak(c.a, c.s) }
                            .setNeutralButton(L("حذف")) { _, _ -> Thread { Vocab.remove(this, c.id); h.post { refreshLearn() } }.start() }
                            .setNegativeButton(L("بستن"), null).show()
                    }
                    .setNeutralButton(L("حذف همه")) { _, _ ->
                        confirmDelete(L("همهٔ واژگان پاک شود؟")) { Thread { Vocab.clear(this); h.post { learnBox.removeAllViews(); refreshLearn() } }.start() }
                    }
                    .setNegativeButton(L("بستن"), null).show()
            }
        }.start()
    }

    // ------------------------------------------------------------------ ENGLISH PRACTICE (built-in phrases, no download)
    private lateinit var learnSv: ScrollView
    private lateinit var practiceInfoTv: TextView
    private var exList: List<Pair<String, String>> = emptyList()
    private var exPool: List<Pair<String, String>> = emptyList()
    private var exKind = 0
    private var exIdx = 0
    private var exRight = 0

    private fun dayNum(back: Int = 0): Int {
        val c = java.util.Calendar.getInstance()
        c.add(java.util.Calendar.DAY_OF_YEAR, -back)
        return c.get(java.util.Calendar.YEAR) * 10000 + (c.get(java.util.Calendar.MONTH) + 1) * 100 + c.get(java.util.Calendar.DAY_OF_MONTH)
    }

    /** learnLog = "lastDay|exercisesToday|streakDays" */
    private fun logPractice(count: Int) {
        val p = cfg.learnLog.split("|")
        var day = p.getOrNull(0)?.toIntOrNull() ?: 0
        var n = p.getOrNull(1)?.toIntOrNull() ?: 0
        var streak = p.getOrNull(2)?.toIntOrNull() ?: 0
        val today = dayNum()
        if (day != today) { streak = if (day == dayNum(1)) streak + 1 else 1; day = today; n = 0 }
        n += count
        cfg.learnLog = "$day|$n|$streak"
        showPracticeInfo()
    }

    private fun showPracticeInfo() {
        val p = cfg.learnLog.split("|")
        val day = p.getOrNull(0)?.toIntOrNull() ?: 0
        val n = if (day == dayNum()) (p.getOrNull(1)?.toIntOrNull() ?: 0) else 0
        val streak = if (day == dayNum() || day == dayNum(1)) (p.getOrNull(2)?.toIntOrNull() ?: 0) else 0
        practiceInfoTv.text = L("امروز: ") + n + L(" تمرین") + "  ·  " + L("روزهای پشت‌سرهم: ") + streak
    }

    private fun practicePool(forOrder: Boolean): List<Pair<String, String>> {
        val all = Idm.practice()
        val lvl = cfg.learnLevel
        fun words(s: String) = s.trim().split(' ').size
        val f = all.filter {
            val w = words(it.first)
            (if (forOrder) w >= 3 else true) && when (lvl) { "easy" -> w <= 3; "hard" -> w >= 6; else -> w in 4..5 }
        }
        return if (f.size >= 12) f else all.filter { !forOrder || words(it.first) >= 3 }
    }

    private fun exStart(kind: Int) {
        val pool = practicePool(kind == 2)
        if (pool.size < 4) { toast(L("عبارت کافی برای تمرین نیست.")); return }
        exPool = Idm.practice()
        exList = pool.shuffled().take(10)
        exKind = kind
        exIdx = 0
        exRight = 0
        learnQueue.clear()
        learnSv.post { learnSv.smoothScrollTo(0, learnBox.top) }
        exNext()
    }

    private fun exNext() {
        learnBox.removeAllViews()
        if (exIdx >= exList.size) {
            logPractice(exList.size)
            val c = ui.card()
            c.addView(ui.tv(L("تمام شد."), 16f, C.OK, true))
            c.addView(ui.tv(L("درست: ") + exRight + " / " + exList.size, 14f, C.TXT, true), ui.lp(top = 4))
            val r = ui.hbox()
            r.addView(ui.btn(L("یک دور دیگر")) { exStart(exKind) }, ui.hlp())
            r.addView(ui.btn(L("بستن"), false) { learnBox.removeAllViews() }, ui.hlp(1f, 8))
            c.addView(r, ui.lp(top = 10))
            learnBox.addView(c)
            return
        }
        val q = exList[exIdx]
        if (exKind == 2) exOrder(q) else exChoice(q)
    }

    private fun enText(t: String, size: Float, bold: Boolean = true): TextView =
        ui.tv(t, size, C.TXT, bold).apply { textDirection = View.TEXT_DIRECTION_LTR; gravity = Gravity.CENTER; setTextIsSelectable(true) }

    /** kind 0: English -> pick the Persian meaning; 1: Persian -> pick the English; 3: listen -> pick the written English. */
    private fun exChoice(q: Pair<String, String>) {
        val toFa = exKind == 0
        val correct = if (toFa) q.second else q.first
        val wrong = exPool.filter { it.first != q.first && it.second != q.second }.shuffled().take(3).map { if (toFa) it.second else it.first }
        val options = (wrong + correct).distinct().shuffled()
        val card = ui.card()
        card.addView(ui.tv(L("سؤال ") + (exIdx + 1) + " / " + exList.size, 11f, C.SUB))
        when (exKind) {
            0 -> {
                card.addView(enText(q.first, 22f), ui.lp(top = 14))
                card.addView(ui.btn(L("تلفظ"), false) { speak(q.first, "en") }, ui.lp(top = 10))
                card.addView(ui.tv(L("معنی درست کدام است؟"), 12f, C.SUB), ui.lp(top = 12))
            }
            1 -> {
                card.addView(ui.tv(q.second, 22f, C.TXT, true).apply { gravity = Gravity.CENTER }, ui.lp(top = 14))
                card.addView(ui.tv(L("معادل انگلیسی درست کدام است؟"), 12f, C.SUB), ui.lp(top = 12))
            }
            else -> {
                card.addView(ui.tv(L("گوش بده و جملهٔ درست را انتخاب کن"), 13f, C.TXT, true).apply { gravity = Gravity.CENTER }, ui.lp(top = 14))
                card.addView(ui.btn(L("پخش دوباره")) { speak(q.first, "en") }, ui.lp(top = 10))
                h.postDelayed({ if (exIdx < exList.size && exList[exIdx] === q && exKind == 3) speak(q.first, "en") }, 400)
            }
        }
        val btns = ArrayList<TextView>()
        var answered = false
        val next = ui.btn(L("بعدی")) {}
        next.visibility = View.GONE
        for (o in options) {
            val b = ui.btn(o, false) {}
            if (!toFa) b.textDirection = View.TEXT_DIRECTION_LTR
            b.setOnClickListener {
                if (answered) return@setOnClickListener
                answered = true
                val right = o == correct
                if (right) exRight++
                for (x in btns) if (x.text.toString() == correct) x.text = x.text.toString() + "   (" + L("درست") + ")"
                if (!right) b.text = o + "   (" + L("نادرست") + ")"
                if (exKind == 1) speak(q.first, "en")
                next.visibility = View.VISIBLE
                next.setOnClickListener { exIdx++; exNext() }
            }
            btns.add(b)
            card.addView(b, ui.lp(top = 8))
        }
        card.addView(next, ui.lp(top = 12))
        learnBox.addView(card)
    }

    /** Build the English sentence from its words (shown in a mixed order) for the Persian meaning. */
    private fun exOrder(q: Pair<String, String>) {
        val words = q.first.trim().split(' ')
        val card = ui.card()
        card.addView(ui.tv(L("سؤال ") + (exIdx + 1) + " / " + exList.size, 11f, C.SUB))
        card.addView(ui.tv(q.second, 20f, C.TXT, true).apply { gravity = Gravity.CENTER }, ui.lp(top = 12))
        card.addView(ui.tv(L("جملهٔ انگلیسی را با زدن کلمه‌ها به ترتیب بساز:"), 12f, C.SUB), ui.lp(top = 8))
        val chosen = ArrayList<String>()
        val answerTv = ui.tv("", 18f, C.ACC, true).apply { textDirection = View.TEXT_DIRECTION_LTR; gravity = Gravity.CENTER; minHeight = ui.dp(40) }
        card.addView(answerTv, ui.lp(top = 8))
        val chips = ArrayList<TextView>()
        val result = ui.tv("", 14f, C.TXT, true).apply { gravity = Gravity.CENTER }
        val next = ui.btn(L("بعدی")) {}
        next.visibility = View.GONE
        var done = false
        val order = words.indices.shuffled()
        var row = ui.hbox()
        order.forEachIndexed { n, wi ->
            if (n % 3 == 0) { row = ui.hbox(); card.addView(row, ui.lp(top = 6)) }
            val chip = ui.btn(words[wi], false) {}
            chip.textDirection = View.TEXT_DIRECTION_LTR
            chip.setOnClickListener {
                if (done) return@setOnClickListener
                chosen.add(words[wi])
                answerTv.text = chosen.joinToString(" ")
                chip.visibility = View.INVISIBLE
            }
            chips.add(chip)
            row.addView(chip, ui.hlp(1f, if (n % 3 == 0) 0 else 6))
        }
        val ctl = ui.hbox()
        ctl.addView(ui.btn(L("پاک کردن"), false) {
            if (done) return@btn
            chosen.clear(); answerTv.text = ""
            for (c in chips) c.visibility = View.VISIBLE
        }, ui.hlp())
        ctl.addView(ui.btn(L("بررسی")) {
            if (done || chosen.isEmpty()) return@btn
            done = true
            val ok = Idm.norm(chosen.joinToString(" ")) == Idm.norm(q.first)
            if (ok) exRight++
            result.setTextColor(if (ok) C.OK else C.BAD)
            result.text = if (ok) L("درست") else L("نادرست") + ":  " + q.first
            result.textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            speak(q.first, "en")
            next.visibility = View.VISIBLE
            next.setOnClickListener { exIdx++; exNext() }
        }, ui.hlp(1f, 8))
        card.addView(ctl, ui.lp(top = 12))
        card.addView(result, ui.lp(top = 10))
        card.addView(next, ui.lp(top = 10))
        learnBox.addView(card)
    }

    /** The "English practice" card at the top of the learning page. */
    private fun buildPracticeCard(): View {
        val pc = ui.card()
        pc.addView(ui.tv(L("تمرین انگلیسی"), 16f, C.TXT, true))
        pc.addView(ui.tv(L("بدون دانلود و بدون اینترنت؛ با عبارت‌های روزمرهٔ آماده. هر روز چند دقیقه کافی است."), 12f, C.SUB), ui.lp(top = 4))
        practiceInfoTv = ui.tv("", 12f, C.ACC, true)
        pc.addView(practiceInfoTv, ui.lp(top = 8))
        showPracticeInfo()
        val pool = Idm.practice()
        if (pool.isNotEmpty()) {
            val today = pool[((dayNum() % 100000) * 37 + 11) % pool.size]
            pc.addView(ui.tv(L("عبارت امروز"), 12f, C.SUB), ui.lp(top = 12))
            pc.addView(enText(today.first, 20f), ui.lp(top = 4))
            pc.addView(ui.tv(today.second, 15f, C.SUB).apply { gravity = Gravity.CENTER }, ui.lp(top = 2))
            val pr = ui.hbox()
            pr.addView(ui.btn(L("تلفظ"), false) { speak(today.first, "en") }, ui.hlp())
            pr.addView(ui.btn(L("افزودن به واژگان"), false) {
                Thread { toast(if (Vocab.add(this, "en", "fa", today.first, today.second)) L("به واژگان اضافه شد.") else L("این مورد قبلاً در واژگان است.")) }.start()
            }, ui.hlp(1f, 8))
            pc.addView(pr, ui.lp(top = 8))
        }
        pc.addView(ui.tv(L("سطح"), 12f, C.SUB), ui.lp(top = 12))
        val lv = listOf("easy", "mid", "hard")
        pc.addView(ui.seg(listOf(L("آسان (۲–۳ کلمه)"), L("متوسط (۴–۵)"), L("سخت (۶+)")), lv.indexOf(cfg.learnLevel).coerceAtLeast(1)) { cfg.learnLevel = lv[it] }, ui.lp(top = 3))
        val a = ui.hbox()
        a.addView(ui.btn(L("انگلیسی ← معنی")) { exStart(0) }, ui.hlp())
        a.addView(ui.btn(L("فارسی ← انگلیسی")) { exStart(1) }, ui.hlp(1f, 8))
        pc.addView(a, ui.lp(top = 10))
        val b = ui.hbox()
        b.addView(ui.btn(L("ترتیب کلمات")) { exStart(2) }, ui.hlp())
        b.addView(ui.btn(L("شنیداری")) { exStart(3) }, ui.hlp(1f, 8))
        pc.addView(b, ui.lp(top = 8))
        return pc
    }

    // ------------------------------------------------------------------ IMAGE PAGE
    private fun buildImagePage(): View {
        val sv = ScrollView(this)
        val col = ui.vbox()
        sv.addView(col)
        col.addView(ui.tv(L("عکس (مانگا، اسکرین‌شات، متن روی تصویر) را انتخاب کن. متن خوانده، ترجمه و روی خود عکس نوشته می‌شود؛ می‌توانی بین «روی عکس»، «ترجمه» و «متن اصلی» جابه‌جا شوی. زبان مبدأ را از تب «متن» انتخاب کن (انگلیسی، ژاپنی یا فارسی)."), 12f, C.SUB))
        val lrow = ui.hbox()
        imgSrcBtn = ui.btn("", true) { pickLang(true) }
        imgDstBtn = ui.btn("", false) { pickLang(false) }
        val isw = ui.iconBtn("swap", 44, true) { val a = cfg.src; cfg.src = cfg.dst; cfg.dst = a; refreshLang() }
        lrow.addView(imgSrcBtn, ui.hlp())
        lrow.addView(isw, LinearLayout.LayoutParams(ui.dp(44), ui.dp(44)).apply { marginStart = ui.dp(4); marginEnd = ui.dp(4) })
        lrow.addView(imgDstBtn, ui.hlp())
        col.addView(lrow, ui.lp(top = 10))
        refreshLang()
        val pickRow = ui.hbox()
        pickRow.addView(ui.tile("image", L("گالری"), false) {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "image/*" }
            startActivityForResult(i, 1)
        }, ui.hlp())
        pickRow.addView(ui.tile("camera", L("دوربین"), false) { takePhoto() }, ui.hlp(1f, 8))
        pickRow.addView(ui.tile("eye", L("ترجمهٔ زنده"), false) {
            startActivityForResult(Intent(this, LiveCamActivity::class.java), 21)
        }, ui.hlp(1f, 8))
        col.addView(pickRow, ui.lp(top = 10))
        imgStatus = ui.tv("", 12f, C.SUB)
        col.addView(imgStatus, ui.lp(top = 8))
        imgSegHolder = FrameLayout(this)
        imgSegHolder.visibility = View.GONE
        col.addView(imgSegHolder, ui.lp(top = 8))
        imgView = ImageView(this).apply { adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER; visibility = View.GONE }
        imgView.setOnClickListener { openViewer() }
        col.addView(imgView, ui.lp(top = 8))
        col.addView(ui.tv(L("روی عکس بزن تا تمام‌صفحه باز شود (بزرگ‌نمایی با دو انگشت؛ روی هر نوشته بزنی متن اصلی و ترجمه‌اش را می‌بینی و کپی می‌کنی)."), 11f, C.SUB).also { imgHint = it; it.visibility = View.GONE }, ui.lp(top = 4))

        val oc = ui.card()
        imgText = ui.tv("", 15f, C.TXT).apply { setTextIsSelectable(true); textDirection = View.TEXT_DIRECTION_FIRST_STRONG; setLineSpacing(0f, 1.15f) }
        oc.addView(imgText)
        oc.addView(ui.btn(L("کپی"), false) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("img", imgText.text))
            toast(L("کپی شد"))
        }, ui.lp(top = 10))
        oc.visibility = View.GONE
        imgTextCard = oc
        col.addView(oc, ui.lp(top = 10))

        val act = ui.vbox()
        val act1 = ui.hbox()
        act1.addView(ui.tile("save", L("ذخیره")) {
            if (imgOut == null) toast(L("اول یک عکس ترجمه کن"))
            else startSave("translated.png", "image/png", 8)
        }, ui.hlp())
        act1.addView(ui.tile("share", L("اشتراک")) { shareImageOut() }, ui.hlp(1f, 6))
        act1.addView(ui.tile("retry", L("ترجمه دوباره")) {
            val u = imgUri
            if (u == null) toast(L("اول یک عکس انتخاب کن")) else runImage(u, true)
        }, ui.hlp(1f, 6))
        // Hold to see the original picture (to compare with the translation); let go and the translation is back.
        val orgBtn = ui.tile("eye", L("اصلی")) {}
        orgBtn.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    val o = imgOrig
                    if (o != null && imgOut != null) { imgView.visibility = View.VISIBLE; imgView.setImageBitmap(o); v.isPressed = true }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { applyImgMode(); v.isPressed = false }
            }
            true
        }
        act1.addView(orgBtn, ui.hlp(1f, 6))
        act1.addView(ui.tile("close", L("لغو")) { clearImage() }, ui.hlp(1f, 6))
        act.addView(act1)
        act.addView(ui.btn(L("ارسال عکس اصلی به برنامهٔ دیگر (مثلاً Google Translate)"), false) {
            val u = imgUri
            if (u == null) toast(L("اول یک عکس انتخاب کن"))
            else try {
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                    type = "image/*"; putExtra(Intent.EXTRA_STREAM, u); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }, L("ارسال عکس")))
            } catch (_: Throwable) { toast(L("ارسال ممکن نشد")) }
        }, ui.lp(top = 8))
        act.addView(ui.btn(L("ذخیرهٔ گزارش تشخیص (برای رفع مشکل)"), false) {
            if (imgOut == null || imgBlocks.isEmpty()) toast(L("اول یک عکس ترجمه کن"))
            else startSave("tarjoman_report.png", "image/png", 42)
        }, ui.lp(top = 8))
        imgContBtn = ui.btn(L("ادامه ترجمه")) { continueImage() }.also { it.visibility = View.GONE }
        act.addView(imgContBtn, ui.lp(top = 8))
        // Text size of the translation on the picture: redraws the picture, no new translation.
        act.addView(ui.slider(L("اندازهٔ متن ترجمه"), 60, 160, cfg.fontScale) { v ->
            cfg.fontScale = v
            h.removeCallbacks(redrawRun)
            h.postDelayed(redrawRun, 250)
        }, ui.lp(top = 8))
        act.visibility = View.GONE
        imgActions = act
        col.addView(act, ui.lp(top = 10))
        return sv
    }

    private lateinit var imgHint: TextView

    private val redrawRun = Runnable { redrawImage() }

    /** Draws the translations on the picture again (after the text size changed). */
    private fun redrawImage() {
        val orig = imgClean ?: imgOrig ?: return
        if (imgBlocks.isEmpty() || imgOut == null) return
        try {
            val sc = cfg.fontScale / 100f
            val out = orig.copy(Bitmap.Config.ARGB_8888, true)
            val canvas = Canvas(out)
            for (b in imgBlocks) Ocr.draw(canvas, b, sc)
            imgOut = out
            applyImgMode()
        } catch (_: Throwable) {
            toast(L("حافظه کم است؛ اندازهٔ متن عوض نشد."))
        }
    }

    private fun pickGalleryImage() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "image/*" }
        startActivityForResult(i, 1)
    }
    private var camUri: Uri? = null
    private var customEdit: EditText? = null
    private var storagePathTv: TextView? = null

    /** Takes a picture with the phone's camera app (no camera permission needed) and translates it like a gallery picture. */
    private fun takePhoto() {
        // The app declares the camera permission (live camera), so the system camera app also needs it granted first.
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), 31)
            return
        }
        if (Build.VERSION.SDK_INT < 29 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 12)
            toast(L("اجازهٔ دسترسی به حافظه را بده و دوباره امتحان کن."))
            return
        }
        val v = android.content.ContentValues().apply {
            put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, "tarjoman_" + System.currentTimeMillis() + ".jpg")
            put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) put(android.provider.MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Tarjoman")
        }
        val u = try { contentResolver.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) } catch (_: Throwable) { null }
        if (u == null) { toast(L("ساخت فایل عکس ممکن نشد.")); return }
        camUri = u
        val i = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE)
            .putExtra(android.provider.MediaStore.EXTRA_OUTPUT, u)
            .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try { startActivityForResult(i, 20) } catch (_: Throwable) {
            camUri = null
            try { contentResolver.delete(u, null, null) } catch (_: Throwable) {}
            toast(L("برنامهٔ دوربین پیدا نشد."))
        }
    }

    /** Full-screen viewer for the translated picture: zoom, move, tap a text to read / copy it, hold the button to compare with the original. */
    private fun openViewer() {
        val out = imgOut ?: return
        val orig = imgOrig ?: return
        val dlg = android.app.Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val root = FrameLayout(this)
        root.setBackgroundColor(android.graphics.Color.BLACK)
        val zv = ZoomView(this)
        zv.setBitmap(out)
        zv.onTap = { x, y ->
            val xi = x.toInt()
            val yi = y.toInt()
            val b = imgBlocks.firstOrNull { it.rect.contains(xi, yi) }
            if (b != null) {
                val msg = L("اصل:") + "\n" + b.text + "\n\n" + L("ترجمه:") + "\n" + b.out
                AlertDialog.Builder(this).setMessage(msg)
                    .setPositiveButton(L("ظاهر ترجمه (اندازه و رنگ)")) { _, _ -> styleBlock(b) { imgOut?.let { zv.setBitmap(it, true) } } }
                    .setNeutralButton(L("ویرایش و ترجمه دوباره")) { _, _ ->
                        editBlock(b) { imgOut?.let { zv.setBitmap(it, true) } }
                    }
                    .setNegativeButton(L("کپی ترجمه")) { _, _ ->
                        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("tr", b.out)); toast(L("کپی شد"))
                    }.show()
            }
        }
        root.addView(zv, FrameLayout.LayoutParams(-1, -1))
        val bar = ui.hbox()
        bar.setPadding(ui.dp(12), ui.dp(32), ui.dp(12), ui.dp(8))
        bar.addView(ui.btn(L("بستن"), false) { dlg.dismiss() }, ui.hlp())
        val cmp = ui.btn(L("نگه دار: عکس اصلی"), false) {}
        cmp.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { zv.setBitmap(orig, true); v.isPressed = true }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { zv.setBitmap(imgOut ?: out, true); v.isPressed = false }
            }
            true
        }
        bar.addView(cmp, ui.hlp(1.4f, 8))
        bar.addView(ui.btn(L("عکس دیگر"), false) { dlg.dismiss(); pickGalleryImage() }, ui.hlp(1f, 8))
        root.addView(bar, FrameLayout.LayoutParams(-1, -2).apply { gravity = android.view.Gravity.TOP })
        dlg.setContentView(root)
        dlg.show()
    }

    /** Manual look of one translated text on the picture: size, text colour, background colour, bold. Changes show at once. */
    private fun styleBlock(b: OBlock, onDone: () -> Unit) {
        val box = ui.vbox()
        box.setPadding(ui.dp(16), ui.dp(8), ui.dp(16), ui.dp(8))
        var all = false
        fun targets(): List<OBlock> = if (all) imgBlocks else listOf(b)
        fun refresh() { for (t in targets()) { t.sl = null }; redrawImage(); onDone() }
        box.addView(ui.seg(listOf(L("فقط این نوشته"), L("همهٔ نوشته‌ها")), 0) { all = it == 1 }, ui.lp())
        box.addView(ui.slider(L("اندازهٔ همین متن"), 50, 250, (b.sizeMul * 100).toInt()) { v -> for (t in targets()) t.sizeMul = v / 100f; refresh() }, ui.lp(top = 8))
        val cols = listOf<Int?>(null, Color.BLACK, Color.WHITE, Color.parseColor("#C62828"), Color.parseColor("#1565C0"), Color.parseColor("#F9A825"))
        val names = listOf(L("خودکار"), L("مشکی"), L("سفید"), L("قرمز"), L("آبی"), L("زرد"))
        box.addView(ui.tv(L("رنگ متن"), 12f, C.SUB), ui.lp(top = 8))
        box.addView(ui.seg(names, cols.indexOf(b.fgOv).coerceAtLeast(0)) { i -> for (t in targets()) t.fgOv = cols[i]; refresh() }, ui.lp(top = 3))
        val bgs = listOf<Int?>(null, Color.WHITE, Color.BLACK, Color.parseColor("#FFF8E1"), Color.parseColor("#E0E0E0"), Color.parseColor("#FFFF99"))
        val bgn = listOf(L("خودکار"), L("سفید"), L("مشکی"), L("کرم"), L("خاکستری"), L("زرد"))
        box.addView(ui.tv(L("رنگ زمینه"), 12f, C.SUB), ui.lp(top = 8))
        box.addView(ui.seg(bgn, bgs.indexOf(b.bgOv).coerceAtLeast(0)) { i -> for (t in targets()) t.bgOv = bgs[i]; refresh() }, ui.lp(top = 3))
        val fb = ui.btn(L("فونت: ") + Fonts.label(this, b.fontOv ?: cfg.ocrFont), false) {}
        fb.setOnClickListener { fontChoose(b.fontOv ?: cfg.ocrFont) { id -> for (t in targets()) t.fontOv = id; fb.text = L("فونت: ") + Fonts.label(this, id); refresh() } }
        box.addView(fb, ui.lp(top = 8))
        box.addView(ui.tv(L("حروف"), 12f, C.SUB), ui.lp(top = 8))
        box.addView(ui.seg(listOf(L("کلفت"), L("معمولی")), if (b.bold) 0 else 1) { i -> for (t in targets()) t.bold = i == 0; refresh() }, ui.lp(top = 3))
        val sv = ScrollView(this)
        sv.addView(box)
        AlertDialog.Builder(this).setTitle(L("ظاهر ترجمه")).setView(sv).setPositiveButton(L("تمام"), null).show()
    }

    /** The reader made a mistake in one text? Fix the original text here and only that block is translated again. */
    private fun editBlock(b: OBlock, onDone: () -> Unit) {
        val et = ui.edit("", 4)
        et.setText(b.text)
        AlertDialog.Builder(this).setTitle(L("ویرایش متن خوانده‌شده")).setView(et)
            .setPositiveButton(L("ترجمه")) { _, _ ->
                val t = et.text.toString().trim()
                if (t.isNotEmpty()) {
                    val s = cfg.src
                    val d = cfg.dst
                    toast(L("در حال ترجمه…"))
                    tr.exec.execute {
                        val r = tr.translate(t, s, d, "", true) { }
                        h.post {
                            val out = r.text
                            if (out != null && out.isNotBlank()) {
                                b.text = t
                                b.out = Translit.names(out)
                                b.sl = null
                                b.usedScale = -1f
                                imgOrigText = imgBlocks.joinToString("\n\n") { it.text }
                                imgTransText = imgBlocks.joinToString("\n\n") { it.out }
                                redrawImage()
                                saveImgJson()
                                onDone()
                            } else toast(r.err ?: L("خطا"))
                        }
                    }
                }
            }
            .setNegativeButton(L("لغو"), null).show()
    }

    private fun saveImgJson() {
        val bmp = imgOrig ?: return
        val blocks = imgBlocks
        if (blocks.isEmpty()) return
        val s = imgLangS
        val d = imgLangD
        Resume.async { Resume.saveImage(this, bmp, blocks, s, d, false) }
    }

    private fun rebuildImgOut() {
        val orig = imgClean ?: imgOrig ?: return
        try {
            val out = orig.copy(Bitmap.Config.ARGB_8888, true)
            val canvas = Canvas(out)
            val sc = cfg.fontScale / 100f
            for (b in imgBlocks) Ocr.draw(canvas, b, sc)
            imgOut = out
        } catch (_: Throwable) {}
    }

    /** A picture whose text was read but not (fully) translated before the app was closed: translate only what is missing. */
    private fun continueImage() {
        val blocks = imgBlocks
        val idx = blocks.indices.filter { blocks[it].out.isEmpty() }
        if (idx.isEmpty()) { imgContBtn.visibility = View.GONE; return }
        val s = imgLangS
        val d = imgLangD
        val job = ++imgJob
        imgContBtn.visibility = View.GONE
        imgStatus.text = L("ترجمه…") + " (" + idx.size + L(" بلوک)")
        tr.exec.execute {
            try {
                val (outs, firstErr) = tr.translateMany(idx.map { blocks[it].text }, s, d, false) { p ->
                    h.post { if (imgJob == job) imgStatus.text = p }
                }
                if (imgJob != job) return@execute
                idx.forEachIndexed { k, i -> blocks[i].out = Translit.names(outs[k]) }
                h.post {
                    if (imgJob == job) {
                        rebuildImgOut()
                        imgOrigText = blocks.joinToString("\n\n") { it.text }
                        imgTransText = blocks.joinToString("\n\n") { it.out }
                        saveImgJson()
                        imgStatus.text = L("تمام شد (") + blocks.size + L(" بلوک)") + (if (firstErr != null) " · " + L("خطا: ") + firstErr else "") + (if (Ocr.diag.isNotEmpty()) "\n" + Ocr.diag else "")
                        setImgMode(0)
                    }
                }
            } catch (e: Throwable) {
                h.post { if (imgJob == job) { imgStatus.text = L("خطا: ") + (e.cause?.message ?: e.message); imgContBtn.visibility = View.VISIBLE } }
            }
        }
    }

    private fun setImgMode(m: Int) {
        imgMode = m
        imgSegHolder.removeAllViews()
        imgSegHolder.addView(ui.seg(listOf(L("روی عکس"), L("ترجمه"), L("متن اصلی")), m) { setImgMode(it) })
        applyImgMode()
    }

    private fun applyImgMode() {
        val has = imgOrig != null
        val done = imgOut != null
        imgSegHolder.visibility = if (done) View.VISIBLE else View.GONE
        imgActions.visibility = if (has) View.VISIBLE else View.GONE
        val showPic = has && (!done || imgMode == 0)
        imgView.visibility = if (showPic) View.VISIBLE else View.GONE
        if (showPic) imgView.setImageBitmap(if (done && imgMode == 0) imgOut else imgOrig)
        imgTextCard.visibility = if (done && imgMode != 0) View.VISIBLE else View.GONE
        imgHint.visibility = if (done && imgMode == 0) View.VISIBLE else View.GONE
        imgText.text = if (imgMode == 1) imgTransText else imgOrigText
    }

    /** Back to the empty page: forgets the picture, its text and any translation in progress. */
    private fun clearImage() {
        imgJob++
        Resume.async { Resume.clearImage(this) }
        imgContBtn.visibility = View.GONE
        imgUri = null
        imgOrig = null
        imgOut = null
        imgBlocks = emptyList()
        imgOrigText = ""
        imgTransText = ""
        imgStatus.text = ""
        imgView.setImageDrawable(null)
        imgMode = 0
        applyImgMode()
    }

    private fun decode(uri: Uri): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var sample = 1
        while (o.outWidth / sample > 2200 || o.outHeight / sample > 2200) sample *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) } ?: return null
        // Camera photos are often stored sideways with an orientation tag; turn them upright so the text can be read.
        val rot = try {
            contentResolver.openInputStream(uri)?.use { ins ->
                when (android.media.ExifInterface(ins).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
            } ?: 0f
        } catch (_: Throwable) { 0f }
        if (rot == 0f) return bmp
        val m = android.graphics.Matrix().apply { postRotate(rot) }
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }

    private fun runImage(uri: Uri, fresh: Boolean = false) {
        val s0 = cfg.src
        val d0 = cfg.dst
        val job = ++imgJob
        imgUri = uri
        imgStatus.text = L("در حال خواندن عکس…") + " (" + Lang.name(s0).substringBefore(" ·") + " → " + Lang.name(d0).substringBefore(" ·") + ")"
        imgOut = null
        imgClean = null
        imgOrigText = ""
        imgTransText = ""
        imgContBtn.visibility = View.GONE
        Resume.async { Resume.clearImage(this) }   // an older saved picture must not come back
        tr.exec.execute {
            try {
                val bmp = decode(uri) ?: throw IllegalStateException(L("عکس باز نشد"))
                // Show the chosen picture right away, before the text is read.
                h.post { if (imgJob == job) { imgOrig = bmp; setImgMode(0) } }
                Smart.task = "image"
                val ar = Ocr.readAuto(bmp, s0)
                val blocks = ar.blocks.toMutableList()
                if (imgJob != job) return@execute
                // Cloud model on: it can still find text on a picture where the phone read nothing, so do not stop yet.
                if (blocks.isEmpty() && !(Vision.usable(cfg, this) && cfg.visionMissing == 1)) { h.post { if (imgJob == job) imgStatus.text = L("متنی در عکس پیدا نشد.") }; return@execute }
                // If the text was found in another language than the chosen one, translate from that language.
                val s = ar.lang
                val d = if (s == d0) (if (s == "fa") "en" else "fa") else d0
                if (s != s0) h.post { if (imgJob == job) imgStatus.text = L("زبان متن تشخیص داده شد: ") + Lang.name(s).substringBefore(" ·") }
                // Save the picture and the text that was read now: if the app is closed during translation, it can continue.
                try { Resume.saveImage(this, bmp, blocks, s, d, true) } catch (_: Throwable) {}
                val all = StringBuilder()
                val orig = StringBuilder()
                val sc = cfg.fontScale / 100f
                h.post { if (imgJob == job) imgStatus.text = L("ترجمه…") + " (" + blocks.size + L(" بلوک)") }
                val vis = if (Vision.usable(cfg, this)) { try { Vision.translateBlocks(tr, cfg, bmp, blocks, s, d, fresh) { p -> h.post { if (imgJob == job) imgStatus.text = p } } } catch (_: Throwable) { null } } else null
                val (outs0, firstErr) = if (blocks.isEmpty()) Pair(emptyList<String>(), null) else (vis ?: tr.translateMany(blocks.map { it.text }, s, d, fresh) { p ->
                    h.post { if (imgJob == job) imgStatus.text = p }
                })
                // Text the phone missed (found and translated by the cloud model from the whole page).
                var outs: List<String> = outs0
                if (Vision.usable(cfg, this) && cfg.visionMissing == 1) {
                    val extra = Vision.findMissing(cfg, bmp, blocks, s, d) { p -> h.post { if (imgJob == job) imgStatus.text = p } }
                    if (extra.isNotEmpty()) {
                        blocks.addAll(extra.map { it.first })
                        outs = outs0 + extra.map { it.second }
                    }
                }
                if (blocks.isEmpty()) { h.post { if (imgJob == job) imgStatus.text = L("متنی در عکس پیدا نشد.") }; return@execute }
                if (imgJob != job) return@execute
                for (i in blocks.indices) blocks[i].out = Translit.names(outs[i])
                // Erase the old writing with the LaMa model (if installed): only on busy backgrounds, plain bubbles are filled directly.
                var base = bmp
                if (cfg.lama == 1 && Inpaint.ready()) {
                    h.post { if (imgJob == job) imgStatus.text = L("پاک‌کردن متن اصلی…") }
                    try {
                        base = Inpaint.clean(bmp, blocks, 30, { imgJob != job }, cfg.lamaAll == 1 || (cfg.lamaAll == 2 && blocks.size <= 8)) { n, t ->
                            h.post { if (imgJob == job) imgStatus.text = L("پاک‌کردن متن اصلی…") + " " + n + "/" + t }
                        }
                    } catch (_: Throwable) {
                        base = bmp
                        for (b in blocks) b.noFill = false
                    }
                }
                if (imgJob != job) return@execute
                val cleaned = if (base !== bmp) base else null
                val out = base.copy(Bitmap.Config.ARGB_8888, true)
                val canvas = Canvas(out)
                blocks.forEachIndexed { i, b ->
                    val t = outs[i]
                    Ocr.draw(canvas, b, sc)
                    all.append(t).append("\n\n")
                    orig.append(b.text).append("\n\n")
                }
                try { Resume.saveImage(this, bmp, blocks, s, d, false) } catch (_: Throwable) {}
                h.post {
                    if (imgJob == job) {
                        imgLangS = s
                        imgLangD = d
                        imgOut = out
                        imgClean = cleaned
                        imgBlocks = blocks
                        imgTransText = all.toString().trim()
                        imgOrigText = orig.toString().trim()
                        saveHist("image", s, d, imgOrigText, imgTransText)
                        imgStatus.text = L("تمام شد (") + blocks.size + L(" بلوک)") + (if (firstErr != null) " · " + L("خطا: ") + firstErr else "")
                        setImgMode(0)
                    }
                }
            } catch (e: Throwable) {
                h.post { if (imgJob == job) imgStatus.text = L("خطا: ") + (e.cause?.message ?: e.message) }
            }
        }
    }

    // ------------------------------------------------------------------ PDF PAGE
    private fun buildPdfPage(): View {
        val sv = ScrollView(this)
        val col = ui.vbox()
        sv.addView(col)
        col.addView(ui.tv(L("یک PDF (کتاب، مقاله، اسکن) انتخاب کن؛ صفحه‌به‌صفحه خوانده و ترجمه می‌شود (PDF متنی مستقیم، اسکن و فارسی با OCR). زبان و موتور ترجمه را از تب «متن» انتخاب کن (مبدأ انگلیسی یا ژاپنی). برای کتاب‌های بلند بهتر است Normal یا حالت سریع را بگذاری."), 12f, C.SUB))
        col.addView(ui.btn(L("انتخاب فایل PDF")) {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf" }
            startActivityForResult(i, 4)
        }, ui.lp(top = 10))
        pdfInfo = ui.tv("", 13f, C.TXT)
        col.addView(pdfInfo, ui.lp(top = 8))
        col.addView(ui.btn(L("لغو انتخاب فایل"), false) { clearPdfSelection() }, ui.lp(top = 6))
        pdfFrom = ui.edit(L("از صفحهٔ… (پیش‌فرض ۱)"))
        pdfFrom.inputType = InputType.TYPE_CLASS_NUMBER
        col.addView(pdfFrom, ui.lp(top = 8))
        val r = ui.hbox()
        r.addView(ui.btn(L("شروع ترجمه")) { startPdf() }, ui.hlp())
        r.addView(ui.btn(L("توقف"), false) { pdfCancel = true; tr.cancelAi() }, ui.hlp(1f, 8))
        col.addView(r, ui.lp(top = 8))
        col.addView(ui.btn(L("ترجمه دوباره (از همین صفحه)"), false) { startPdf(true) }, ui.lp(top = 8))
        pdfStatus = ui.tv("", 12f, C.SUB)
        col.addView(pdfStatus, ui.lp(top = 8))
        col.addView(ui.seg(listOf(L("ترجمه"), L("متن اصلی"), L("هر دو")), pdfMode) { pdfMode = it; showPdf() }, ui.lp(top = 8))
        val oc = ui.card()
        pdfOut = ui.tv("", 15f, C.TXT).apply {
            setTextIsSelectable(true)
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            setLineSpacing(0f, 1.15f)
        }
        oc.addView(pdfOut)
        val br = ui.hbox()
        br.addView(ui.tile("copy", L("کپی همه")) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("pdf", pdfCur().toString()))
            toast(L("کپی شد"))
        }, ui.hlp())
        br.addView(ui.tile("text", L("ذخیره txt")) {
            startSave("translation.txt", "text/plain", 5)
        }, ui.hlp(1f, 6))
        br.addView(ui.tile("pdf", L("ذخیره PDF")) {
            if (pdfCur().isEmpty()) toast(L("هنوز چیزی ترجمه نشده"))
            else startSave("translation.pdf", "application/pdf", 9)
        }, ui.hlp(1f, 6))
        br.addView(ui.tile("share", L("اشتراک")) {
            val t = pdfCur().toString()
            if (t.isBlank()) toast(L("هنوز چیزی ترجمه نشده"))
            else Thread { shareFileOut("translation.pdf", "application/pdf") { PdfTool.export(t, it) } }.start()
        }, ui.hlp(1f, 6))
        oc.addView(br, ui.lp(top = 10))
        col.addView(oc, ui.lp(top = 8))

        // Manga archive (ZIP / CBZ)
        val mz = ui.card()
        mz.addView(ui.tv(L("مانگا: فایل ZIP / CBZ"), 16f, C.TXT, true))
        mz.addView(ui.tv(L("یک فایل ZIP یا CBZ از صفحه‌های مانگا انتخاب کن. صفحه‌به‌صفحه ترجمه می‌شود (با زبان‌هایی که در صفحهٔ اصلی گذاشته‌ای) و یک CBZ تازه با صفحه‌های ترجمه‌شده ساخته می‌شود. صفحه‌ای که متن ندارد یا خطا بدهد همان‌طور که هست می‌ماند. هر صفحه چند ثانیه طول می‌کشد؛ با «توقف» تا همان‌جا قابل ذخیره است."), 12f, C.SUB), ui.lp(top = 4))
        mz.addView(ui.btn(L("انتخاب ZIP / CBZ")) {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
            startActivityForResult(i, 40)
        }, ui.lp(top = 8))
        mzInfo = ui.tv("", 12f, C.TXT)
        mz.addView(mzInfo, ui.lp(top = 6))
        mz.addView(ui.tv(L("کاهش فشار روی گوشی"), 12f, C.SUB), ui.lp(top = 10))
        val mpx = listOf(1200, 1600, 2200)
        mz.addView(ui.seg(listOf(L("سبک (۱۲۰۰)"), L("متوسط (۱۶۰۰)"), L("کامل (۲۲۰۰)")), mpx.indexOf(cfg.mzMaxPx).let { if (it < 0) 2 else it }) { cfg.mzMaxPx = mpx[it] }, ui.lp(top = 3))
        mz.addView(ui.tv(L("فرمت عکس خروجی"), 12f, C.SUB), ui.lp(top = 8))
        val mfm = listOf("jpg", "webp")
        mz.addView(ui.seg(listOf(L("JPG (سازگار)"), L("WEBP (کم‌حجم‌تر)")), mfm.indexOf(cfg.mzFmt).coerceAtLeast(0)) { cfg.mzFmt = mfm[it] }, ui.lp(top = 3))
        val mps = listOf(0, 2, 5)
        mz.addView(ui.tv(L("استراحت بین صفحه‌ها"), 12f, C.SUB), ui.lp(top = 8))
        mz.addView(ui.seg(listOf(L("بدون استراحت"), L("۲ ثانیه"), L("۵ ثانیه")), mps.indexOf(cfg.mzPause).let { if (it < 0) 0 else it }) { cfg.mzPause = mps[it] }, ui.lp(top = 3))
        mz.addView(ui.btn(L("پیش‌نمایش (فقط اولین صفحه)"), false) { previewManga() }, ui.lp(top = 10))
        val mr = ui.hbox()
        mr.addView(ui.btn(L("شروع ترجمهٔ مانگا")) { startMangaZip() }, ui.hlp())
        mr.addView(ui.btn(L("توقف"), false) { mzStop = true; tr.cancelAi() }, ui.hlp(1f, 8))
        mz.addView(mr, ui.lp(top = 8))
        val mzAct = ui.hbox()
        mzAct.addView(ui.tile("save", L("ذخیرهٔ CBZ")) {
            if (!mzOut.isFile || mzOut.length() == 0L) toast(L("هنوز چیزی ترجمه نشده"))
            else startSave("manga_translated.cbz", "application/zip", 41)
        }, ui.hlp())
        mzAct.addView(ui.tile("share", L("اشتراک")) {
            if (!mzOut.isFile || mzOut.length() == 0L) toast(L("هنوز چیزی ترجمه نشده"))
            else Thread { shareFileOut("manga_translated.cbz", "application/vnd.comicbook+zip") { o -> mzOut.inputStream().use { it.copyTo(o, 256 * 1024) } } }.start()
        }, ui.hlp(1f, 8))
        mz.addView(mzAct, ui.lp(top = 8))
        col.addView(mz, ui.lp(top = 12))
        return sv
    }

    private lateinit var mzInfo: TextView
    private var mzUri: Uri? = null
    @Volatile private var mzStop = false
    @Volatile private var mzRunning = false
    private val mzOut: File get() = File(cacheDir, "manga_translated.cbz")

    private fun onMangaPicked(uri: Uri) {
        mzUri = uri
        var name = "manga.cbz"
        contentResolver.query(uri, null, null, null, null)?.use { if (it.moveToFirst()) { val ix = it.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (ix >= 0) name = it.getString(ix) } }
        mzInfo.text = L("انتخاب‌شده: ") + name
    }

    /** Translates only the first page that has text and shows it, to check the languages and the look before the whole archive. */
    private fun previewManga() {
        val u = mzUri
        if (u == null) { toast(L("اول یک فایل ZIP / CBZ انتخاب کن.")); return }
        if (mzRunning) { toast(L("در حال ترجمه است.")); return }
        mzRunning = true
        val app = applicationContext
        mzInfo.text = L("شروع…")
        Thread {
            var bytes: ByteArray? = null
            var fatal: String? = null
            try { bytes = MangaZip.preview(app, tr, cfg, u) { p -> h.post { mzInfo.text = p } } }
            catch (e: Throwable) { fatal = e.message ?: e.javaClass.simpleName }
            finally { mzRunning = false }
            h.post {
                val b = bytes
                if (b == null) { mzInfo.text = L("متنی پیدا نشد") + (if (fatal != null) " · " + fatal else ""); return@post }
                mzInfo.text = L("پیش‌نمایش آماده شد.")
                val bm = BitmapFactory.decodeByteArray(b, 0, b.size)
                val iv = ImageView(this).apply { setImageBitmap(bm); adjustViewBounds = true }
                val sv = ScrollView(this).apply { addView(iv) }
                AlertDialog.Builder(this).setView(sv).setPositiveButton(L("بستن"), null).show()
            }
        }.start()
    }

    private fun startMangaZip() {
        val u = mzUri
        if (u == null) { toast(L("اول یک فایل ZIP / CBZ انتخاب کن.")); return }
        if (mzRunning) { toast(L("در حال ترجمه است.")); return }
        mzRunning = true
        mzStop = false
        val app = applicationContext
        Dl.keepBegin(app)
        mzInfo.text = L("شروع…")
        Thread {
            try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND) } catch (_: Throwable) {}
            var res: MangaZip.Result? = null
            var fatal: String? = null
            try {
                res = MangaZip.run(app, tr, cfg, u, mzOut, { mzStop }) { p -> h.post { mzInfo.text = p } }
            } catch (e: Throwable) {
                fatal = e.message ?: e.javaClass.simpleName
            } finally {
                Dl.keepEnd(app)
                mzRunning = false
            }
            h.post {
                val r = res
                mzInfo.text = if (r == null) L("خطا: ") + fatal
                else L("تمام شد: ") + r.translated + " / " + r.pages + L(" صفحه ترجمه شد.") + (if (r.err != null) "  " + L("خطا: ") + r.err else "") + "  " + L("حالا «ذخیرهٔ CBZ ترجمه‌شده» را بزن.")
            }
        }.start()
    }

    private fun pdfCur(): StringBuilder = when (pdfMode) { 1 -> pdfOrigSb; 2 -> pdfBiSb; else -> pdfSb }

    private fun showPdf() {
        val all = pdfCur().toString()
        pdfOut.text = if (all.length > 15000) "…\n" + all.substring(all.length - 15000) else all
    }

    /** Forgets the chosen PDF (and stops a running translation) so another file can be chosen. */
    private fun clearPdfSelection() {
        pdfCancel = true
        tr.cancelAi()
        pdfUri = null
        pdfPages = 0
        pdfDone = 0
        Resume.async { Resume.clearPdf(this) }
        pdfInfo.text = ""
        pdfStatus.text = ""
        pdfOut.text = ""
        pdfFrom.setText("")
        clearPdfText()
    }

    private fun clearSrtSelection() {
        srtCancel = true
        tr.cancelAi()
        srtCues = emptyList()
        srtTexts.clear()
        srtInfo.text = ""
        srtStatus.text = ""
        srtOut.text = ""
        Resume.async { Resume.clearSrt(this) }
        refreshSrtBtn()
    }

    private fun clearPdfText() { pdfSb.setLength(0); pdfOrigSb.setLength(0); pdfBiSb.setLength(0) }

    private fun onPdfPicked(uri: Uri) {
        var name = "PDF"
        contentResolver.query(uri, null, null, null, null)?.use {
            if (it.moveToFirst()) {
                val ix = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (ix >= 0) name = it.getString(ix)
            }
        }
        try {
            pdfPages = PdfTool.pageCount(this, uri)
            pdfUri = uri
            // keep the right to read this file after the app is closed, so the translation can be continued later
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Throwable) {}
            pdfName = name
            pdfDone = 0
            pdfLangS = cfg.src
            pdfLangD = cfg.dst
            pdfInfo.text = name + " · " + pdfPages + L(" صفحه")
            clearPdfText()
            pdfOut.text = ""
            pdfStatus.text = ""
        } catch (e: Throwable) {
            pdfUri = null
            pdfInfo.text = L("این PDF باز نشد (شاید رمزدار یا خراب است): ") + (e.message ?: "")
        }
    }

    private fun savePdfNow() {
        val u = pdfUri?.toString() ?: return
        if (pdfSb.isEmpty() && pdfDone == 0) return
        val a = pdfSb.toString()
        val b = pdfOrigSb.toString()
        val c = pdfBiSb.toString()
        val name = pdfName
        val pages = pdfPages
        val next = pdfDone
        val s = pdfLangS
        val d = pdfLangD
        Resume.async { Resume.savePdf(this, u, name, pages, next, a, b, c, s, d) }
    }

    private fun savePdfSoon() {
        val n = android.os.SystemClock.uptimeMillis()
        if (n - pdfSavedAt > 2500) { pdfSavedAt = n; savePdfNow() }
    }

    /** Brings back the unfinished subtitle file, PDF and picture from the last time the app was used. */
    private fun restoreState() {
        Resume.loadSrt(this)?.let { st ->
            srtCues = st.cues
            srtTexts.clear()
            srtTexts.addAll(st.texts)
            srtLangS = st.s
            srtLangD = st.d
            srtInfo.text = srtCues.size.toString() + L(" خط زیرنویس")
            srtStatus.text = if (srtTexts.size >= srtCues.size) L("ترجمهٔ دفعهٔ قبل کامل بود؛ می‌توانی ذخیره کنی.")
            else if (srtTexts.isEmpty()) ""
            else L("ترجمهٔ نیمه‌کاره از دفعهٔ قبل: ") + srtTexts.size + " / " + srtCues.size + L(" — «ادامه ترجمه» را بزن.")
            val last = srtTexts.indexOfLast { it != null }
            if (last >= 0 && last < srtCues.size) srtOut.text = SrtTool.plain(srtCues[last].text) + "\n→ " + srtTexts[last]
            refreshSrtBtn()
        }
        Resume.loadPdf(this)?.let { st ->
            pdfPages = st.pages
            pdfName = st.name
            pdfDone = st.next
            pdfLangS = st.s
            pdfLangD = st.d
            pdfSb.append(st.tr)
            pdfOrigSb.append(st.orig)
            pdfBiSb.append(st.bi)
            pdfInfo.text = st.name + " · " + st.pages + L(" صفحه")
            val u = Uri.parse(st.uri)
            val ok = try { contentResolver.openInputStream(u)?.close(); true } catch (_: Throwable) { false }
            if (ok) {
                pdfUri = u
                pdfStatus.text = if (st.next >= st.pages) L("ترجمهٔ دفعهٔ قبل کامل بود.")
                else L("از دفعهٔ قبل تا صفحهٔ ") + st.next + L(" ترجمه شده؛ «ترجمه» را بزن تا از صفحهٔ بعد ادامه یابد.")
                pdfFrom.setText(if (st.next in 1 until st.pages) (st.next + 1).toString() else "")
            } else {
                pdfStatus.text = L("فایل PDF دیگر در دسترس نیست؛ متن ترجمه‌شده نگه داشته شد. برای ادامه، همان PDF را دوباره انتخاب کن.")
            }
            showPdf()
        }
        Resume.loadImage(this)?.let { st ->
            imgOrig = st.bmp
            imgBlocks = st.blocks
            imgLangS = st.s
            imgLangD = st.d
            imgUri = Uri.fromFile(Resume.imageFile(this))
            imgOrigText = st.blocks.joinToString("\n\n") { it.text }
            imgTransText = st.blocks.joinToString("\n\n") { it.out }
            if (st.blocks.all { it.out.isNotEmpty() }) {
                rebuildImgOut()
                imgStatus.text = L("عکس و ترجمهٔ دفعهٔ قبل برگشت.")
            } else {
                imgStatus.text = L("متن عکس خوانده شده بود ولی ترجمه‌اش تمام نشد؛ «ادامه ترجمه» را بزن.")
                imgContBtn.visibility = View.VISIBLE
            }
            setImgMode(0)
        }
    }

    private fun startPdf(fresh: Boolean = false) {
        val uri = pdfUri
        if (uri == null) { toast(L("اول یک PDF انتخاب کن")); return }
        if (pdfRunning) { toast(L("ترجمه در حال انجام است")); return }
        val from = (pdfFrom.text.toString().trim().toIntOrNull() ?: 1).coerceIn(1, maxOf(pdfPages, 1)) - 1
        // continuing a half-done book keeps the languages it was started with
        val continuing = from > 0 && !fresh && pdfSb.isNotEmpty()
        val s = if (continuing) pdfLangS else cfg.src
        val d = if (continuing) pdfLangD else cfg.dst
        pdfLangS = s
        pdfLangD = d
        if (from == 0 || fresh) { clearPdfText(); pdfOut.text = ""; pdfDone = 0 }
        pdfRunning = true
        pdfCancel = false
        Thread {
            try {
                PdfTool.translate(this, uri, from, s, d, tr, fresh, { pdfCancel }, { m -> h.post { pdfStatus.text = m } }) { i, t, o, bi ->
                    h.post {
                        val head = L("— صفحه ") + (i + 1) + " —\n"
                        pdfSb.append(head).append(t).append("\n\n")
                        pdfOrigSb.append(head).append(o).append("\n\n")
                        pdfBiSb.append(head).append(bi).append("\n\n")
                        pdfDone = i + 1
                        showPdf()
                        savePdfSoon()
                    }
                }
                h.post {
                    pdfStatus.text = if (pdfCancel) L("متوقف شد. (برای ادامه، شمارهٔ صفحهٔ بعدی را بنویس)") else L("تمام شد.")
                    if (!pdfCancel && pdfDone >= pdfPages) pdfFrom.setText("") else if (pdfDone in 1 until pdfPages) pdfFrom.setText((pdfDone + 1).toString())
                    savePdfNow()
                }
            } catch (e: Throwable) {
                h.post { pdfStatus.text = L("خطا: ") + (e.cause?.message ?: e.message); savePdfNow() }
            }
            pdfRunning = false
        }.start()
    }

    // ------------------------------------------------------------------ SUBTITLE PAGE
    private fun buildSrtPage(): View {
        val sv = ScrollView(this)
        val col = ui.vbox()
        sv.addView(col)
        col.addView(ui.tv(L("فایل زیرنویس (.srt یا .vtt یوتیوب) را انتخاب کن؛ جمله‌به‌جمله و با در نظر گرفتن دو خط قبلی ترجمه می‌شود (برای موتور AI)، زمان‌بندی دست‌نخورده می‌ماند و فایل جدید را ذخیره می‌کنی. زبان و موتور را از تب «متن» انتخاب کن. اسامی خاص را در تنظیمات ← واژه‌نامه بنویس."), 12f, C.SUB))
        col.addView(ui.btn(L("انتخاب فایل زیرنویس")) {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
            startActivityForResult(i, 6)
        }, ui.lp(top = 10))
        val ytIn = ui.edit(L("یا لینک ویدیوی یوتیوب را بچسبان…"))
        col.addView(ytIn, ui.lp(top = 8))
        col.addView(ui.btn(L("دریافت زیرنویس از لینک"), false) { fetchYt(ytIn.text.toString()) }, ui.lp(top = 8))
        val vc = ui.card()
        vc.addView(ui.tv(L("مرورگر ویدیو با ترجمهٔ زنده"), 15f, C.TXT, true))
        vc.addView(ui.tv(L("یوتیوب (و سایت‌هایی که ویدیویشان زیرنویس دارد) را داخل برنامه باز می‌کند و زیرنویسی را که روی ویدیو می‌آید همان لحظه ترجمه می‌کند و زیر ویدیو می‌گذارد. زیرنویس (CC) ویدیو را روشن کن. ثبت‌نام لازم نیست. Twitch و Kick زیرنویس ندارند و پشتیبانی نمی‌شوند."), 12f, C.SUB), ui.lp(top = 4))
        vc.addView(ui.btn(L("باز کردن مرورگر ویدیو")) {
            startActivity(Intent(this, VideoActivity::class.java).putExtra("url", ytIn.text.toString()))
        }, ui.lp(top = 8))
        col.addView(vc, ui.lp(top = 12))
        srtInfo = ui.tv("", 13f, C.TXT)
        col.addView(srtInfo, ui.lp(top = 8))
        col.addView(ui.btn(L("لغو انتخاب فایل"), false) { clearSrtSelection() }, ui.lp(top = 6))
        val r = ui.hbox()
        srtStartBtn = ui.btn(L("شروع ترجمه")) { startSrt(resume = srtTexts.size in 1 until srtCues.size) }
        r.addView(srtStartBtn, ui.hlp())
        r.addView(ui.btn(L("توقف"), false) { srtCancel = true; tr.cancelAi() }, ui.hlp(1f, 8))
        col.addView(r, ui.lp(top = 8))
        col.addView(ui.btn(L("ترجمه دوباره"), false) { startSrt(true) }, ui.lp(top = 8))
        srtStatus = ui.tv("", 12f, C.SUB)
        col.addView(srtStatus, ui.lp(top = 8))
        val oc = ui.card()
        srtOut = ui.tv("", 14f, C.TXT).apply { setTextIsSelectable(true); textDirection = View.TEXT_DIRECTION_FIRST_STRONG }
        oc.addView(srtOut)
        val srtAct = ui.hbox()
        srtAct.addView(ui.tile("save", L("ذخیره .srt")) {
            startSave("translated.srt", "application/x-subrip", 7)
        }, ui.hlp())
        srtAct.addView(ui.tile("share", L("اشتراک")) {
            val txt = "\uFEFF" + SrtTool.build(srtCues, srtTexts)
            shareFileOut("translated.srt", "application/x-subrip") { it.write(txt.toByteArray(Charsets.UTF_8)) }
        }, ui.hlp(1f, 8))
        oc.addView(srtAct, ui.lp(top = 10))
        col.addView(oc, ui.lp(top = 8))
        return sv
    }

    private fun fetchYt(link: String) {
        val id = Yt.id(link.trim())
        if (id == null) { toast(L("لینک یوتیوب معتبر نیست")); return }
        srtInfo.text = L("در حال دریافت زیرنویس…")
        val src = cfg.src
        Thread {
            try {
                val cues = SrtTool.parse(Yt.fetch(id, src, cfg))
                h.post {
                    srtCues = cues
                    srtTexts.clear()
                    srtOut.text = ""
                    srtLangS = cfg.src
                    srtLangD = cfg.dst
                    srtInfo.text = if (cues.isEmpty()) L("زیرنویس معتبری پیدا نشد (فایل .srt یا .vtt لازم است).") else cues.size.toString() + L(" خط زیرنویس")
                    saveSrtNow()
                    refreshSrtBtn()
                }
            } catch (e: Throwable) {
                h.post { srtInfo.text = L("خطا: ") + (e.message ?: "") }
            }
        }.start()
    }

    private fun onSrtPicked(uri: Uri) {
        try {
            val raw = SrtTool.decode(contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: ByteArray(0), cfg.src)
            Smart.task = "sub"
            srtCues = SrtTool.parse(raw)
            srtTexts.clear()
            srtOut.text = ""
            srtLangS = cfg.src
            srtLangD = cfg.dst
            srtInfo.text = if (srtCues.isEmpty()) L("زیرنویس معتبری پیدا نشد (فایل .srt یا .vtt لازم است).") else srtCues.size.toString() + L(" خط زیرنویس")
            saveSrtNow()
            refreshSrtBtn()
        } catch (e: Throwable) {
            srtInfo.text = L("خطا: ") + e.message
        }
    }

    private fun saveSrtNow() {
        val cues = srtCues
        if (cues.isEmpty()) return
        val texts = ArrayList<String?>(srtTexts)
        val s = srtLangS
        val d = srtLangD
        Resume.async { Resume.saveSrt(this, cues, texts, s, d) }
    }

    private fun saveSrtSoon() {
        val n = android.os.SystemClock.uptimeMillis()
        if (n - srtSavedAt > 2500) { srtSavedAt = n; saveSrtNow() }
    }

    /** "Start" becomes "Continue (12 / 300)" when part of the file is already translated. */
    private fun refreshSrtBtn() {
        val n = srtCues.size
        val k = srtTexts.size
        srtStartBtn.text = if (k in 1 until n && !srtRunning) L("ادامه ترجمه") + " (" + k + " / " + n + ")" else L("شروع ترجمه")
    }

    private fun startSrt(fresh: Boolean = false, resume: Boolean = false) {
        val cues = srtCues
        if (cues.isEmpty()) { toast(L("اول یک فایل .srt انتخاب کن")); return }
        if (srtRunning) { toast(L("ترجمه در حال انجام است")); return }
        val s = if (resume) srtLangS else cfg.src
        val d = if (resume) srtLangD else cfg.dst
        srtLangS = s
        srtLangD = d
        srtRunning = true
        srtCancel = false
        if (!resume) srtTexts.clear()
        val startAt = if (resume) minOf(srtTexts.size, cues.size) else 0
        Thread {
            try {
                var i = startAt
                while (i < cues.size && cfg.mode == "normal" && !srtCancel) {
                    val end = minOf(i + 20, cues.size)
                    val plains = (i until end).map { SrtTool.plain(cues[it].text) }
                    val r = if (plains.all { it.isEmpty() }) null else tr.translate(plains.joinToString("\n"), s, d, "", fresh) { }
                    val lines = r?.text?.split("\n")
                    if (r != null && r.text == null) throw IllegalStateException(r.err ?: L("خطا"))
                    if (r != null && (lines == null || lines.size != plains.size)) break   // line count changed: fall back to line-by-line
                    val batch = plains.indices.map { k -> if (plains[k].isEmpty()) null else lines!![k].trim() }
                    val upto = end
                    h.post {
                        srtTexts.addAll(batch)
                        srtStatus.text = upto.toString() + " / " + cues.size
                        saveSrtSoon()
                        val lastIx = batch.indexOfLast { it != null }
                        if (lastIx >= 0) srtOut.text = plains[lastIx] + "\n→ " + batch[lastIx]
                    }
                    i = end
                }
                while (i < cues.size) {
                    val c = cues[i]
                    if (srtCancel) break
                    val plain = SrtTool.plain(c.text)
                    var out: String? = null
                    if (plain.isNotEmpty()) {
                        val ctx = (maxOf(0, i - 2) until i).map { SrtTool.plain(cues[it].text) }.filter { it.isNotEmpty() }.joinToString("\n")
                        val r = tr.translate(plain, s, d, ctx, fresh) { }
                        out = r.text ?: throw IllegalStateException(r.err ?: L("خطا"))
                    }
                    val k = i + 1
                    i++
                    val shown = out
                    h.post {
                        srtTexts.add(shown)
                        srtStatus.text = k.toString() + " / " + cues.size
                        saveSrtSoon()
                        if (shown != null) srtOut.text = plain + "\n→ " + shown
                    }
                }
                h.post {
                    srtStatus.text = if (srtCancel) L("متوقف شد؛ خطوط ترجمه‌نشده در فایل به‌صورت اصلی می‌مانند. هر وقت خواستی «ادامه ترجمه» را بزن.") else L("تمام شد. حالا ذخیره کن.")
                    srtRunning = false
                    saveSrtNow()
                    refreshSrtBtn()
                }
            } catch (e: Throwable) {
                h.post { srtStatus.text = L("خطا: ") + (e.cause?.message ?: e.message); srtRunning = false; saveSrtNow(); refreshSrtBtn() }
            }
            srtRunning = false
        }.start()
    }

    // ------------------------------------------------------------------ BUBBLE PAGE
    private fun buildBubblePage(): View {
        val sv = ScrollView(this)
        val col = ui.vbox()
        sv.addView(col)
        col.addView(ui.tv(L("حباب شناور · ترجمهٔ تمام‌صفحه"), 16f, C.TXT, true))
        col.addView(ui.tv(L("حباب را روشن کن و برو سراغ هر برنامه‌ای (مرورگر، مانگا، ویدیو…). با یک لمس روی حباب ترجمه شروع می‌شود (و اگر «ترجمه زنده» روشن باشد، با ورق زدن صفحه خودکار دوباره ترجمه می‌شود)؛ با لمس دوباره متوقف می‌شود. یک لایهٔ شفاف روی کل صفحه می‌آید و ترجمه دقیقاً روی نوشتهٔ اصلی چاپ می‌شود. لمس طولانی روی حباب = تنظیمات (زبان، موتور، سرعت، آفلاین/آنلاین، شفافیت، اندازهٔ متن)."), 12f, C.SUB), ui.lp(top = 4))
        bubbleStatus = ui.tv("", 13f, C.TXT, true)
        col.addView(bubbleStatus, ui.lp(top = 10))
        bubbleToggle = ui.btn("") {
            if (BubbleService.running) {
                stopService(Intent(this, BubbleService::class.java))
                BubbleService.running = false
                updateBubbleUi()
            } else startBubble()
        }
        col.addView(bubbleToggle, ui.lp(top = 8))
        updateBubbleUi()
        val c = ui.card()
        c.addView(ui.tv(L("ترجمه زنده (ورق زدن)"), 12f, C.SUB))
        c.addView(ui.seg(listOf(L("خاموش"), L("روشن")), cfg.liveScr) { cfg.liveScr = it }, ui.lp(top = 3))
        c.addView(ui.tv(L("روشن باشد، با یک لمس حباب ترجمه روی صفحه می‌ماند و هر بار صفحه عوض شد (ورق زدن مانگا، اسکرول) و ثابت ماند، خودش دوباره ترجمه می‌کند؛ با دوبار لمس حباب متوقف می‌شود. هر چند ثانیه صفحه را بررسی می‌کند، پس مصرف باتری و پردازنده بیشتر است. با حالت Normal و سریع بهتر جواب می‌دهد."), 11f, C.SUB), ui.lp(top = 4))
        c.addView(ui.tv(L("حالت حباب"), 12f, C.SUB), ui.lp(top = 10))
        val bm = listOf("free", "lock", "sleep")
        c.addView(ui.seg(listOf(L("آزاد"), L("قفل"), L("خواب")), bm.indexOf(cfg.bubMode).coerceAtLeast(0)) { cfg.bubMode = bm[it] }, ui.lp(top = 3))
        c.addView(ui.tv(L("آزاد: هرجا رها کنی می‌ماند. قفل: خودکار به لبهٔ چپ یا راست می‌چسبد. خواب: کمی بیرون از لبه و کمرنگ. هر حالتی که باشد، حباب را به بیرون لبه بکشی فوراً به خواب می‌رود و هیچ‌وقت کامل از صفحه خارج نمی‌شود."), 11f, C.SUB), ui.lp(top = 4))
        c.addView(ui.slider(L("شفافیت لایه"), 20, 100, cfg.opacity) { v -> cfg.opacity = v }, ui.lp(top = 10))
        c.addView(ui.slider(L("اندازهٔ متن ترجمه"), 60, 160, cfg.fontScale) { v -> cfg.fontScale = v }, ui.lp(top = 8))
        col.addView(c, ui.lp(top = 12))
        col.addView(ui.tv(L("نکتهٔ شیائومی/MIUI: اگر حباب ظاهر نشد، در تنظیمات برنامه ← «سایر مجوزها» گزینه‌های «نمایش روی سایر برنامه‌ها» و «نمایش پنجره‌های بازشو هنگام اجرا در پس‌زمینه» را روشن کن، و بهینه‌سازی باتری ترجمان را روی «بدون محدودیت» بگذار."), 12f, C.SUB), ui.lp(top = 12))
        // Xiaomi / Redmi (MIUI, HyperOS) stop apps in the background: one tap to the right settings pages.
        val xr = ui.hbox()
        xr.addView(ui.btn(L("تنظیمات برنامه و باتری"), false) { openAppSettings() }, ui.hlp())
        xr.addView(ui.btn(L("شروع خودکار شیائومی"), false) { openMiuiAutostart() }, ui.hlp(1f, 8))
        col.addView(xr, ui.lp(top = 8))
        return sv
    }

    private fun openAppSettings() {
        try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) } catch (_: Throwable) {}
    }

    private fun openMiuiAutostart() {
        val tries = listOf(
            Intent().setClassName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"),
            Intent("miui.intent.action.OP_AUTO_START").addCategory(Intent.CATEGORY_DEFAULT)
        )
        for (i in tries) { try { startActivity(i); return } catch (_: Throwable) {} }
        toast(L("این صفحه در گوشی تو پیدا نشد؛ از تنظیمات گوشی ← برنامه‌ها ← ترجمان ← «شروع خودکار» را روشن کن."))
        openAppSettings()
    }

    private fun startBubble() {
        if (!Settings.canDrawOverlays(this)) {
            toast(L("مجوز «نمایش روی سایر برنامه‌ها» را برای ترجمان روشن کن، بعد برگرد و دوباره بزن"))
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName)))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
            return
        }
        askProjection()
    }

    private fun askProjection() {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), 3)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10) askProjection()
        if (requestCode == 31) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) takePhoto() else toast(L("اجازهٔ دوربین داده نشد."))
        }
    }

    // ------------------------------------------------------------------ MODELS PAGE
    private fun buildModelsPage(): View {
        val sv = ScrollView(this)
        modelsBox = ui.vbox()
        sv.addView(modelsBox)
        return sv
    }

    private val bars = HashMap<String, android.widget.ProgressBar>()
    private val pct = HashMap<String, Int>()          // download progress in 1/1000
    private val packBusy = HashSet<String>()
    private val packOk = HashMap<String, Boolean>()

    private var modelsBuilt = false
    private var orphanDone = false

    private fun refreshModels() {
        renderModels()
        checkPacks()
    }

    private fun checkPacks() {
        Thread {
            var changed = false
            for (c in listOf("fa", "ja", "ko", "zh", "ar", "es")) {
                val ok: Boolean? = try { MlKit.isDownloaded(c) } catch (_: Throwable) { null }
                if (ok != null && packOk[c] != ok) { changed = true; h.post { packOk[c] = ok } }
            }
            // rebuild only when something changed (before: the whole list was built twice on every open)
            if (changed) h.post { if (curTab == 5) renderModels() }
        }.start()
    }

    private fun mkBar(id: String, indeterminate: Boolean): android.widget.ProgressBar {
        val b = android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        b.max = 1000
        b.isIndeterminate = indeterminate
        b.progressTintList = android.content.res.ColorStateList.valueOf(C.ACC)
        b.progressBackgroundTintList = android.content.res.ColorStateList.valueOf(C.CARD2)
        b.indeterminateTintList = android.content.res.ColorStateList.valueOf(C.ACC)
        if (!indeterminate) b.progress = pct[id] ?: 0
        bars[id] = b
        return b
    }

    private fun impChip(required: Boolean): TextView =
        if (required) ui.chip(L("ضروری"), C.BAD) else ui.chip(L("اختیاری"), C.SUB)

    private fun dots(n: Int): String = "\u25CF".repeat(n) + "\u25CB".repeat(5 - n)

    private fun titleRow(title: String, vararg chips: TextView): LinearLayout {
        val hr = ui.hbox()
        hr.addView(ui.tv(title, 15f, C.TXT, true), ui.hlp())
        for (ch in chips) hr.addView(ch, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = ui.dp(6) })
        return hr
    }

    /** Card of one Persian OCR model (the fast one and the optional more accurate one share this code). */
    private fun ocrCard(id: String, name: String, title: String, note: String, f: File?, ok: Boolean, url: String, rec: Boolean = false): View {
        val ocr = ui.card()
        if (rec) ocr.addView(titleRow(title, ui.chip(L("پیشنهاد می‌شود"), C.ACC), impChip(false))) else ocr.addView(titleRow(title, impChip(false)))
        ocr.addView(ui.tv(note, 12f, C.SUB), ui.lp(top = 4))
        val dl = Dl.jobs[id]
        val st = ui.tv(if (dl != null) L("در حال دانلود…") else if (ok) L("نصب شده") + (if (f != null) " (" + fmt(f.length()) + ")" else "") else if (Dl.partBytes(f ?: File("x")) > 0) L("دانلود ناقص ماند: ") + fmt(Dl.partBytes(f ?: File("x"))) + L(" ذخیره شده؛ «ادامه دانلود» از همین‌جا ادامه می‌دهد") else L("نصب نشده"), 12f, if (ok) C.OK else C.SUB)
        progress[id] = st
        ocr.addView(st, ui.lp(top = 6))
        if (dl != null) ocr.addView(mkBar(id, dl.total <= 0), ui.lp(MATCH, ui.dp(6), 8))
        if (f != null) {
            val part = Dl.partBytes(f)
            if (dl != null) {
                val rr = ui.hbox()
                rr.addView(ui.btn(L("توقف")) { Dl.cancel(id) }, ui.hlp())
                rr.addView(ui.btn(L("لغو"), false) { Dl.abort(id) }, ui.hlp(1f, 8))
                ocr.addView(rr, ui.lp(top = 8))
            } else if (ok) {
                ocr.addView(ui.btn(L("حذف"), false) { confirmDelete(name) { f.delete(); refreshModels() } }, ui.lp(top = 8))
            } else {
                ocr.addView(ui.btn(if (part > 0) L("ادامه دانلود") else L("دانلود")) {
                    f.parentFile?.mkdirs()
                    startDl(id, name, url, f)
                }, ui.lp(top = 8))
                if (part > 0) ocr.addView(ui.btn(L("حذف بخش نیمه‌دانلودشده"), false) { confirmDelete(name) { Dl.deletePart(f); refreshModels() } }, ui.lp(top = 6))
            }
        }
        return ocr
    }

    /** companion download: the small dictionary of a PaddleOCR reader is fetched together with the model */
    private val companions = HashMap<String, Pair<String, File>>()

    private fun paddleCard(key: String, folder: String, title: String, note: String, rec: Boolean) {
        val base = "https://huggingface.co/monkt/paddleocr-onnx/resolve/main/languages/$folder/"
        val df = Paddle.dictFile(key) ?: return
        companions["paddle-$key"] = Pair(base + "dict.txt", df)
        modelsBox.addView(ocrCard("paddle-$key", "rec_$key.onnx", title, note, Paddle.recFile(key), Paddle.recReady(key), base + "rec.onnx", rec), ui.lp(top = 10))
    }

    private fun packCard(code: String, title: String, note: String, required: Boolean): View {
        val c = ui.card()
        c.addView(titleRow(title, impChip(required)))
        c.addView(ui.tv(note, 12f, C.SUB), ui.lp(top = 4))
        val busy = packBusy.contains(code)
        val ok = packOk[code]
        val st = ui.tv(
            if (busy) L("در حال دانلود بسته… (برای بسته‌های گوگل درصد نمایش داده نمی‌شود)") else if (ok == true) L("نصب شده") else if (ok == false) L("نصب نشده") else "…",
            12f, if (ok == true && !busy) C.OK else C.SUB
        )
        c.addView(st, ui.lp(top = 6))
        if (busy) c.addView(mkBar("pack-$code", true), ui.lp(MATCH, ui.dp(6), 8))
        else if (ok != true) c.addView(ui.btn(L("دانلود")) { packDl(code) }, ui.lp(top = 8))
        else c.addView(ui.btn(L("حذف"), false) { confirmDelete(title) { packDelete(code) } }, ui.lp(top = 8))
        if (busy) c.addView(ui.btn(L("توقف")) { Dl.packStop = true; toast(L("بعد از اتمام مرحلهٔ فعلی متوقف می‌شود")) }, ui.lp(top = 8))
        return c
    }

    private fun sectionHead(title: String, sub: String) {
        modelsBox.addView(ui.tv(title, 16f, C.TXT, true), ui.lp(top = 20))
        if (sub.isNotEmpty()) modelsBox.addView(ui.tv(sub, 12f, C.SUB), ui.lp(top = 2))
    }

    private fun renderModels() {
        modelsBox.removeAllViews()
        progress.clear()
        bars.clear()

        val intro = ui.card()
        intro.addView(ui.tv(L("از کجا شروع کنم؟"), 16f, C.TXT, true))
        intro.addView(ui.tv(L("فقط مورد «ضروری» برای کار کردن ترجمهٔ معمولی (Normal) لازم است. بقیه اختیاری‌اند؛ هر کدام را فقط اگر آن قابلیت را می‌خواهی دانلود کن."), 12f, C.SUB), ui.lp(top = 4))
        intro.addView(ui.tv(L("محل ذخیرهٔ مدل‌ها (از تنظیمات می‌شود عوضش کرد):"), 11f, C.SUB), ui.lp(top = 8))
        intro.addView(ui.tv(Models.dir(this).absolutePath, 11f, C.TXT).apply { setTextIsSelectable(true); textDirection = View.TEXT_DIRECTION_LTR }, ui.lp(top = 2))
        intro.addView(ui.btn(L("لینک مستقیم دانلود همهٔ مدل‌ها"), false) { showAllLinks() }, ui.lp(top = 10))
        intro.addView(ui.btn(L("توقف همهٔ دانلودها"), false) {
            Dl.cancelAll(); Dl.packStop = true; Dl.resetKeep()
            try { stopService(Intent(this, DlService::class.java)) } catch (_: Throwable) {}
            toast(L("همهٔ دانلودها متوقف شد"))
            h.postDelayed({ refreshModels() }, 800)
        }, ui.lp(top = 8))
        modelsBox.addView(intro)
        modelsBox.addView(storageSummary(), ui.lp(top = 10))

        sectionHead(L("ضروری برای شروع"), "")
        modelsBox.addView(packCard("fa", L("انگلیسی ↔ فارسی"), L("بستهٔ زبانی گوگل (حدود ۳۰ مگابایت). یک‌بار با اینترنت دانلود کن، بعد آفلاین کار می‌کند. بدون آن ترجمهٔ آفلاین Normal کار نمی‌کند."), true), ui.lp(top = 8))

        sectionHead(L("اختیاری"), L("هر کدام فقط در صورت نیاز."))
        modelsBox.addView(packCard("ja", L("ژاپنی"), L("فقط اگر از یا به ژاپنی ترجمه می‌کنی (حدود ۳۰ مگابایت)."), false), ui.lp(top = 8))
        modelsBox.addView(packCard("ko", L("کره‌ای"), L("فقط اگر از یا به کره‌ای ترجمه می‌کنی (حدود ۳۰ مگابایت). خواندن متن عکس کره‌ای با ML Kit."), false), ui.lp(top = 8))
        modelsBox.addView(packCard("zh", L("چینی"), L("فقط اگر از یا به چینی ترجمه می‌کنی (حدود ۳۰ مگابایت). خواندن متن عکس چینی با ML Kit."), false), ui.lp(top = 8))
        modelsBox.addView(packCard("ar", L("عربی"), L("فقط اگر از یا به عربی ترجمه می‌کنی (حدود ۳۰ مگابایت). خواندن متن عکس عربی هنوز پشتیبانی نمی‌شود."), false), ui.lp(top = 8))
        modelsBox.addView(packCard("es", L("اسپانیایی"), L("فقط اگر از یا به اسپانیایی ترجمه می‌کنی (حدود ۳۰ مگابایت). عکس اسپانیایی با خواننده‌ٔ لاتین خوانده می‌شود."), false), ui.lp(top = 8))

        modelsBox.addView(ocrCard("ocr-en", L("OCR انگلیسی"), L("OCR انگلیسی · Tesseract (آفلاین)"),
            L("اختیاری و حدود ۴ مگابایت. خواندن عکس انگلیسی به‌طور پیش‌فرض با ML Kit انجام می‌شود؛ با نصب این مدل، هر دو می‌خوانند و بهترین نتیجه انتخاب می‌شود (حروف و علامت‌های اشتباه کمتر). پیشنهاد می‌شود."),
            Ocr.enFile(), Ocr.enReady(), "https://github.com/tesseract-ocr/tessdata_fast/raw/main/eng.traineddata", true), ui.lp(top = 10))
        modelsBox.addView(ocrCard("ocr-en-best", L("OCR انگلیسی دقیق‌تر"), L("OCR انگلیسی دقیق‌تر · tessdata_best"),
            L("اختیاری، بزرگ‌تر (چند مگابایت) و دقیق‌تر از نسخهٔ معمولی. اگر نصب باشد به‌جای نسخهٔ سریع استفاده می‌شود؛ کمی کندتر است."),
            Ocr.enBestFile(), Ocr.enBestReady(), "https://github.com/tesseract-ocr/tessdata_best/raw/main/eng.traineddata"), ui.lp(top = 10))
        modelsBox.addView(ocrCard("ocr-fa", L("OCR فارسی"), L("OCR فارسی · Tesseract (آفلاین)"),
            L("فقط برای خواندن متن فارسی از عکس، صفحه (حباب) و PDF لازم است؛ حدود ۱ تا ۲ مگابایت از GitHub. اگر متن مبدأت انگلیسی یا ژاپنی است، لازم نیست. دقت روی متن تمیز خوب و روی متن کوچک یا خط‌دار متوسط است."),
            Ocr.faFile(), Ocr.faReady(), "https://github.com/tesseract-ocr/tessdata_fast/raw/main/fas.traineddata", true), ui.lp(top = 10))
        modelsBox.addView(ocrCard("ocr-fa-best", L("OCR فارسی دقیق‌تر"), L("OCR فارسی دقیق‌تر · tessdata_best"),
            L("نسخهٔ دقیق‌تر و بزرگ‌تر همان OCR فارسی (چند مگابایت، حجم دقیقش را GitHub تعیین می‌کند). اگر نصبش کنی، به‌جای نسخهٔ سریع استفاده می‌شود: خواندن فارسی از عکس دقیق‌تر ولی کمی کندتر است. با اینترنت ضعیف بهتر است اول نسخهٔ معمولی را داشته باشی."),
            Ocr.faBestFile(), Ocr.faBestReady(), "https://github.com/tesseract-ocr/tessdata_best/raw/main/fas.traineddata"), ui.lp(top = 10))
        modelsBox.addView(ocrCard("lama", "lama_fp32.onnx", L("پاک‌کردن متن عکس · LaMa (آفلاین)"),
            L("اختیاری و بزرگ (حدود ۲۰۸ مگابایت). متن اصلی را از روی عکس پاک می‌کند و پس‌زمینه را بازسازی می‌کند تا ترجمه روی تصویر تمیز بنشیند (مثل K3). برای مانگا و عکس‌های با پس‌زمینهٔ طرح‌دار یا رنگی. روی حباب‌های ساده لازم نیست و رد می‌شود؛ هر متنِ روی پس‌زمینهٔ شلوغ چند ثانیه طول می‌کشد و تا حدود یک گیگابایت رم می‌خواهد (۴۵ ثانیه بعد از استفاده آزاد می‌شود). در تنظیمات می‌توانی خاموشش کنی. مدل: Carve/LaMa-ONNX، مجوز Apache-2.0."),
            Inpaint.file(), Inpaint.lamaReady(), "https://huggingface.co/Carve/LaMa-ONNX/resolve/main/lama_fp32.onnx", false), ui.lp(top = 10))
        modelsBox.addView(ocrCard("cdet", "comic_detector.onnx", L("پیدا کردن جای متن در مانگا و کمیک (سبک)"),
            L("اختیاری و کوچک (حدود ۱۱ مگابایت، لایسنس Apache-2.0). فقط می‌گوید «متن کجاست» (حباب‌ها و نوشته‌های آزاد)؛ چیزی نمی‌خواند. هر جایی را که خواندن معمولی از دست داده باشد جدا می‌خواند و اضافه می‌کند، پس خط و کادر جاافتاده کمتر می‌شود. برای مانگا، کمیک و وب‌تون پیشنهاد می‌شود."),
            Detector.file(), Detector.ready(), "https://huggingface.co/Sundowner123/comic-text-and-bubble-detector/resolve/main/detector.onnx", true), ui.lp(top = 10))
        modelsBox.addView(ocrCard("migan", "migan_pipeline_v2.onnx", L("پاک‌کردن متن عکس · MI-GAN (سبک)"),
            L("اختیاری و کوچک (حدود ۲۸ مگابایت، لایسنس MIT). همان کار LaMa را با حجم و حافظهٔ خیلی کمتر انجام می‌دهد؛ برای گوشی ساخته شده. روی عکس‌هایی با پس‌زمینهٔ طرح‌دار متن اصلی را پاک می‌کند. اگر هر دو نصب باشند، در تنظیمات انتخاب می‌کنی کدام استفاده شود (خودکار: LaMa). اگر حافظه یا سرعت گوشی کم است، همین را بگیر."),
            Inpaint.miganFile(), Inpaint.miganReady(), "https://huggingface.co/andraniksargsyan/migan/resolve/main/migan_pipeline_v2.onnx", true), ui.lp(top = 10))

        sectionHead(L("OCR چندزبانه · PaddleOCR (آفلاین)"), L("یک خواننده و یک «پیداکنندهٔ خط متن» که کاملاً روی گوشی کار می‌کنند. اول یکی از پیداکننده‌ها، بعد خواننده‌های زبان‌هایی که لازم داری."))
        modelsBox.addView(ocrCard("paddle-det-s", "det_v3.onnx", L("پیداکنندهٔ خط متن · سبک (۲٫۳ مگابایت)"),
            L("خیلی کوچک و سریع. جای هر خط متن را پیدا می‌کند (هر اندازه و جهت). برای کار با خواننده‌های PaddleOCR لازم است؛ یکی از دو پیداکننده کافی است."),
            Paddle.detFile(false), Paddle.detFile(false)?.let { it.isFile && it.length() > 1_000_000L } ?: false, "https://huggingface.co/monkt/paddleocr-onnx/resolve/main/detection/v3/det.onnx", true), ui.lp(top = 10))
        modelsBox.addView(ocrCard("paddle-det-b", "det_v5.onnx", L("پیداکنندهٔ خط متن · دقیق (۸۴ مگابایت)"),
            L("نسخهٔ دقیق‌تر و سنگین‌تر (PP-OCRv5): متن کوچک، کج یا روی طرح شلوغ را بهتر پیدا می‌کند؛ کندتر و رم بیشتر. اگر هر دو نصب باشند، در تنظیمات انتخاب می‌کنی."),
            Paddle.detFile(true), Paddle.detFile(true)?.let { it.isFile && it.length() > 50_000_000L } ?: false, "https://huggingface.co/monkt/paddleocr-onnx/resolve/main/detection/v5/det.onnx"), ui.lp(top = 10))
        paddleCard("en", "english", L("خواننده · انگلیسی (۷٫۵ مگابایت)"), L("انگلیسی و لاتین ساده؛ سبک و سریع. برای مانگا و عکس انگلیسی."), true)
        paddleCard("latin", "latin", L("خواننده · لاتین / اسپانیایی (۷٫۵ مگابایت)"), L("اسپانیایی، فرانسوی، آلمانی، ایتالیایی و بقیهٔ زبان‌های لاتین با حروف اضافه (ñ é ü …)."), false)
        paddleCard("ko", "korean", L("خواننده · کره‌ای (۱۳ مگابایت)"), L("هانگول و انگلیسی. برای مانهوا و عکس کره‌ای."), false)
        paddleCard("zh", "chinese", L("خواننده · چینی و ژاپنی (۸۱ مگابایت)"), L("چینی ساده و سنتی، ژاپنی و انگلیسی. سنگین‌ترین ولی کامل‌ترین؛ برای مانهوا/مانگای چینی و ژاپنی. متن عمودی ژاپنی را ML Kit بهتر می‌خواند."), false)
        paddleCard("ar", "arabic", L("خواننده · عربی و فارسی (۸٫۶ مگابایت)"), L("حروف عربی و فارسی (پ چ ژ گ هم). سبک؛ خواندن آفلاین عربی فقط با این ممکن است."), false)

        sectionHead(L("Advanced · مدل‌های AI روی گوشی"), L("اختیاری. مرتب‌شده از بهترین کیفیت به ضعیف‌ترین. هرچه مدل بزرگ‌تر، ترجمه بهتر ولی کندتر. برای مدل‌های Gemma باید در تنظیمات توکن Hugging Face بگذاری. اگر Hugging Face فیلتر است، در تنظیمات آینه یا پروکسی بگذار."))

        val lv = ui.card()
        lv.addView(ui.tv(L("کدام مدل را بگیرم؟"), 15f, C.TXT, true))
        lv.addView(ui.tv(L("سبک: Qwen 2.5 · 0.5B (بدون توکن)\nمتوسط: Gemma 3 · 1B (int4)  ⭐ بهترین پیشنهاد\nسنگین: Gemma 3 · 1B (q8)\nفوق‌سنگین (فقط نسخهٔ LiteRT-LM): Gemma 4 · E2B"), 12f, C.TXT), ui.lp(top = 6))
        lv.addView(ui.tv(L("صادقانه: هیچ‌کدام از این مدل‌های کوچک در فارسی به ترجمهٔ معمولی (ML Kit / گوگل آنلاین) نمی‌رسند. فایدهٔ AI بیشتر در محاوره، اصطلاح، فحش و جمله‌های بی‌قاعده است؛ برای متن عادی «Normal» بهتر است."), 12f, C.SUB), ui.lp(top = 6))
        modelsBox.addView(lv, ui.lp(top = 10))

        // models this build cannot run (.litertlm without LiteRT-LM) go to the end, with a warning on the card
        val list = Models.ranked.sortedBy { if (it.file.endsWith(".litertlm") && !LmBridge.available) 1 else 0 }
        list.forEachIndexed { i, m ->
            modelsBox.addView(
                modelCard(m.id, m.title + "  ·  " + m.tier, "≈ " + m.mb + " MB", m.note, Models.file(this, m), m.url, i + 1, m),
                ui.lp(top = 10)
            )
        }

        if (!orphanDone) { orphanDone = true; Thread { try { Models.cleanOrphanCaches(this) } catch (_: Throwable) {} }.start() }
        val tl = ui.card()
        tl.addView(titleRow(L("ابزارهای لازم برای اجرای بعضی مدل‌ها"), impChip(false)))
        tl.addView(ui.tv(L("• توکن Hugging Face: برای مدل‌های Gemma (قفل). در huggingface.co ثبت‌نام کن، لایسنس مدل را قبول کن و توکن Read بساز؛ بعد در «تنظیمات» بگذارش.\n• موتور LiteRT-LM: برای مدل‌های .litertlm (Gemma 4، Gemma 3n، Qwen 3). فقط در APK دوم ساخت GitHub (Tarjoman-apk-litertlm) هست؛ مدل را در نسخهٔ عادی می‌شود دانلود کرد ولی اجرا نمی‌شود.\n• MediaPipe: موتور مدل‌های .task؛ داخل همین برنامه است و چیزی لازم نیست."), 12f, C.SUB), ui.lp(top = 4))
        val tr2 = ui.hbox()
        tr2.addView(ui.btn(L("ساخت توکن Hugging Face"), false) { openUrl("https://huggingface.co/settings/tokens") }, ui.hlp())
        tr2.addView(ui.btn(L("تنظیمات (توکن)"), false) { show(6) }, ui.hlp(1f, 8))
        tl.addView(tr2, ui.lp(top = 8))
        modelsBox.addView(tl, ui.lp(top = 14))

        val manual = Models.manualFiles(this)
        if (manual.isNotEmpty()) {
            modelsBox.addView(ui.tv(L("مدل‌های دستی"), 14f, C.TXT, true), ui.lp(top = 18))
            for (f in manual) modelsBox.addView(modelCard("m:" + f.name, f.name, "", "", f, null, 0, null), ui.lp(top = 8))
        }

        val add = ui.card()
        add.addView(titleRow(L("افزودن مدل دستی"), impChip(false)))
        add.addView(ui.tv(L("فایل .task / .bin سازگار با MediaPipe (مثلاً از litert-community در Hugging Face)."), 12f, C.SUB), ui.lp(top = 4))
        val ar = ui.hbox()
        ar.addView(ui.btn(L("از فایل گوشی")) {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
            startActivityForResult(i, 2)
        }, ui.hlp())
        ar.addView(ui.btn(L("از لینک"), false) { addByUrl() }, ui.hlp(1f, 8))
        add.addView(ar, ui.lp(top = 8))
        modelsBox.addView(add, ui.lp(top = 18))
        modelsBuilt = true
    }


    private fun packDelete(code: String) {
        tr.exec.execute {
            try { MlKit.delete(code); toast(L("حذف شد")) } catch (e: Throwable) { toast(L("خطا: ") + (e.cause?.message ?: e.message)) }
            h.post { packOk[code] = false; refreshModels() }
        }
    }

    /** Google's language pack: no percentage is available, but it keeps retrying and the service keeps it alive in the background. */
    private fun packDl(code: String) {
        if (!packBusy.add(code)) return
        Dl.packStop = false
        val app = applicationContext
        Dl.packRunning++
        Dl.keepBegin(app)
        renderModels()
        tr.exec.execute {
            var okDone = false
            try {
                var tries = 0
                while (!okDone && !Dl.packStop && tries < 6) {
                    tries++
                    try {
                        MlKit.ensure("en", code, { Dl.packStop }, 600)
                        okDone = true
                    } catch (e: Throwable) {
                        if (tries >= 6 || Dl.packStop) { if (!Dl.packStop) Dl.toast(app, L("خطا: ") + (e.cause?.message ?: e.message)); break }
                        var w = 0
                        while (w < 5 && !Dl.packStop) { try { Thread.sleep(1000) } catch (_: InterruptedException) {}; w++ }
                        while (!Dl.packStop && !Net.isOnline(app)) { try { Thread.sleep(2000) } catch (_: InterruptedException) {} }
                    }
                }
                if (okDone) Dl.toast(app, L("بسته زبان آماده شد"))
            } finally {
                Dl.packRunning = maxOf(0, Dl.packRunning - 1)
                Dl.keepEnd(app)
                h.post { packBusy.remove(code); packOk[code] = okDone; refreshModels() }
            }
        }
    }

    private fun modelCard(id: String, title: String, size: String, note: String, f: File, url: String?, rank: Int, m: Mdl?): View {
        val c = ui.card()
        val chips = ArrayList<TextView>()
        val needsLm = m != null && m.file.endsWith(".litertlm") && !LmBridge.available
        if (m != null) for (b in Models.badges(m.id)) chips.add(ui.chip(b, if (b.startsWith("⭐") || b.startsWith(L("پیشنهاد"))) C.ACC else if (b == L("بهترین کیفیت")) C.OK else C.SUB))
        chips.add(impChip(false))
        c.addView(titleRow(title, *chips.toTypedArray()))
        if (size.isNotEmpty()) c.addView(ui.tv(size, 12f, C.SUB))
        if (m != null) {
            c.addView(ui.tv(
                "#" + rank + "   " + L("کیفیت") + " " + dots(Models.quality(m.id)) + "    " + L("سرعت") + " " + dots(Models.speed(m.id)),
                12f, C.ACC, true
            ), ui.lp(top = 4))
        }
        if (m != null) {
            val parts = ArrayList<String>()
            parts.add(if (m.file.endsWith(".litertlm")) L("موتور: LiteRT-LM") else L("موتور: MediaPipe"))
            if (m.gated) parts.add(L("نیاز: توکن Hugging Face + قبول لایسنس")) else parts.add(L("بدون توکن"))
            c.addView(ui.tv((if (needsLm) "✗ " + L("روی این نسخه اجرا نمی‌شود") else "✓ " + L("روی این نسخه اجرا می‌شود")) + "  ·  " + parts.joinToString("  ·  "), 12f, if (needsLm) C.BAD else C.OK), ui.lp(top = 4))
        }
        if (note.isNotEmpty()) c.addView(ui.tv(note, 12f, C.SUB), ui.lp(top = 4))
        val installed = Models.isModelFile(f)
        val gatedHere = m != null && m.gated && !installed
        if (needsLm) c.addView(ui.tv(L("این نسخه از برنامه با LiteRT-LM ساخته نشده؛ این مدل را می‌توانی دانلود کنی ولی تا نسخهٔ LiteRT-LM نسازی اجرا نمی‌شود."), 12f, C.ACC), ui.lp(top = 4))
        if (installed && Models.knownBad(f.name)) c.addView(ui.tv(L("این فایل با موتور LiteRT-LM این نسخه سازگار نیست و خطا می‌دهد؛ حذفش کن و مدل رسمی «Qwen 3 - 0.6B (LiteRT-LM)» را بگیر."), 12f, 0xFFE53935.toInt(), true), ui.lp(top = 4))
        else if (installed && Models.isBad(this, f)) c.addView(ui.tv(L("این مدل دو بار پشت‌سرهم باعث بسته‌شدن برنامه شد و کنار گذاشته شده. فایل احتمالاً ناقص یا خراب است؛ حذفش کن و دوباره دانلود کن."), 12f, 0xFFE53935.toInt(), true), ui.lp(top = 4))
        if (gatedHere) c.addView(ui.tv(L("این مدل قفل است. برای دانلود: ۱) در huggingface.co ثبت‌نام کن ۲) در «صفحهٔ مدل» دکمهٔ Acknowledge license را بزن ۳) در huggingface.co/settings/tokens روی Create new token بزن، نوع Read را انتخاب کن و توکن را در «توکن» بگذار. مدل‌های Qwen و SmolLM بدون توکن دانلود می‌شوند."), 12f, C.ACC), ui.lp(top = 4))
        val dl = Dl.jobs[id]
        val part = File(f.path + ".part")
        val partBytes = if (part.exists()) part.length() else 0L
        val partPct = if (partBytes > 0) (if (m != null && m.mb > 0) (partBytes * 100 / (m.mb * 1048576L)).toInt().coerceIn(1, 99) else 1) else 0
        val st = ui.tv(
            if (dl != null) L("در حال دانلود…")
            else if (installed) L("نصب شده (") + fmt(f.length()) + ")"
            else if (partPct > 0) L("دانلود ناقص ماند: ") + fmt(partBytes) + (if (m != null) " (" + L("حدود ") + partPct + "%)" else "") + L(" ذخیره شده؛ «ادامه دانلود» از همین‌جا ادامه می‌دهد")
            else L("نصب نشده"),
            12f, if (installed) C.OK else C.SUB
        )
        progress[id] = st
        c.addView(st, ui.lp(top = 6))
        if (dl != null) c.addView(mkBar(id, dl.total <= 0), ui.lp(MATCH, ui.dp(6), 8))
        val r = ui.hbox()
        if (dl != null) {
            r.addView(ui.btn(L("توقف")) { Dl.cancel(id) }, ui.hlp())
            r.addView(ui.btn(L("لغو"), false) { Dl.abort(id) }, ui.hlp(1f, 8))
        } else if (installed) {
            val active = tr.activeFile()?.name == f.name
            r.addView(ui.btn(if (active) L("فعال") else L("فعال‌سازی"), !active) { cfg.activeModel = f.name; refreshModels() }, ui.hlp())
            r.addView(ui.btn(L("حذف"), false) { confirmDelete(title) { f.delete(); Models.deleteCaches(f); Dl.deletePart(f); if (cfg.activeModel == f.name) cfg.activeModel = ""; refreshModels() } }, ui.hlp(1f, 8))
        } else if (url != null) {
            r.addView(ui.btn(if (partPct > 0) L("ادامه دانلود") else L("دانلود")) {
                if (gatedHere && cfg.hfToken.isBlank() && !Hf.signedIn(cfg)) askAccess(id, title, url, f) else startDl(id, title, url, f)
            }, ui.hlp())
            if (partBytes > 0) r.addView(ui.btn(L("حذف بخش نیمه‌دانلودشده"), false) { confirmDelete(title) { Dl.deletePart(f); refreshModels() } }, ui.hlp(1f, 8))
        }
        c.addView(r, ui.lp(top = 8))
        if (url != null) {
            val rl = ui.hbox()
            rl.addView(ui.btn(L("کپی لینک مستقیم"), false) { copyText(url) }, ui.hlp())
            rl.addView(ui.btn(L("باز کردن در مرورگر"), false) { openUrl(url) }, ui.hlp(1f, 8))
            c.addView(rl, ui.lp(top = 6))
        }
        if (gatedHere && dl == null && url != null) {
            val rs = ui.hbox()
            rs.addView(ui.btn(if (Hf.signedIn(cfg)) L("وارد شده‌ای ✓ (دوباره ورود)") else L("ورود با حساب Hugging Face"), !Hf.signedIn(cfg)) { openHfLogin(url.substringBefore("/resolve/")) }, ui.hlp())
            c.addView(rs, ui.lp(top = 6))
            val r2 = ui.hbox()
            r2.addView(ui.btn(L("صفحهٔ مدل (قبول لایسنس)"), false) { openUrl(url.substringBefore("/resolve/")) }, ui.hlp())
            r2.addView(ui.btn(L("توکن"), false) { askToken { startDl(id, title, url, f) } }, ui.hlp(1f, 8))
            c.addView(r2, ui.lp(top = 6))
        }
        return c
    }

    private fun copyText(t: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("link", t))
        toast(L("کپی شد"))
    }

    /** Direct download links of every model the app suggests, plus where to put the files by hand. */
    private fun allLinks(): String {
        val sb = StringBuilder()
        sb.append(L("پوشهٔ مدل‌ها در گوشی:")).append("\n").append(Models.dir(this).absolutePath).append("\n")
        sb.append(L("(مدل را دستی دانلود کردی؟ فایل را در همین پوشه بگذار تا برنامه ببیندش.)")).append("\n\n")
        sb.append("== ").append(L("مدل‌های AI (Hugging Face)")).append(" ==\n\n")
        for (m in Models.ranked) {
            sb.append(m.title).append("  ·  ≈ ").append(m.mb).append(" MB")
            if (m.gated) sb.append("  [").append(L("نیاز به حساب و قبول لایسنس")).append("]")
            sb.append("\n").append(m.url).append("\n\n")
        }
        sb.append("== OCR (Tesseract) ==\n\n")
        sb.append("eng (fast)\nhttps://github.com/tesseract-ocr/tessdata_fast/raw/main/eng.traineddata\n\n")
        sb.append("eng (best)\nhttps://github.com/tesseract-ocr/tessdata_best/raw/main/eng.traineddata\n\n")
        sb.append("fas (fast)\nhttps://github.com/tesseract-ocr/tessdata_fast/raw/main/fas.traineddata\n\n")
        sb.append("fas (best)\nhttps://github.com/tesseract-ocr/tessdata_best/raw/main/fas.traineddata\n\n")
        sb.append("LaMa (text eraser, 208 MB)\nhttps://huggingface.co/Carve/LaMa-ONNX/resolve/main/lama_fp32.onnx\n\n")
        sb.append("Comic text detector (where is the text, 11 MB)\nhttps://huggingface.co/Sundowner123/comic-text-and-bubble-detector/resolve/main/detector.onnx\n\n")
        sb.append("MI-GAN (text eraser, small, 28 MB)\nhttps://huggingface.co/andraniksargsyan/migan/resolve/main/migan_pipeline_v2.onnx\n")
        return sb.toString()
    }

    private fun showAllLinks() {
        val txt = allLinks()
        val tv = ui.tv(txt, 12f, C.TXT).apply { setTextIsSelectable(true); textDirection = View.TEXT_DIRECTION_LTR; setPadding(ui.dp(16), ui.dp(8), ui.dp(16), ui.dp(8)) }
        val sv = ScrollView(this)
        sv.addView(tv)
        AlertDialog.Builder(this).setTitle(L("لینک مستقیم دانلود")).setView(sv)
            .setPositiveButton(L("کپی همه")) { _, _ -> copyText(txt) }
            .setNeutralButton(L("اشتراک‌گذاری")) { _, _ ->
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, txt) }, null))
            }
            .setNegativeButton(L("بستن"), null)
            .show()
    }

    /** content://...externalstorage tree (what the folder picker returns) -> the real path of that folder. */
    private fun treeToPath(u: Uri): String? {
        val id = try { android.provider.DocumentsContract.getTreeDocumentId(u) } catch (_: Throwable) { return null }
        val i = id.indexOf(':')
        if (i < 0) return null
        val vol = id.substring(0, i)
        val rel = id.substring(i + 1)
        val base = if (vol == "primary") android.os.Environment.getExternalStorageDirectory().absolutePath else "/storage/" + vol
        return if (rel.isEmpty()) base else base + "/" + rel
    }

    private fun openUrl(u: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (_: Throwable) { toast(u) }
    }

    private var hfOpened = false

    override fun onResume() {
        super.onResume()
        if (hfOpened) { hfOpened = false; try { refreshModels() } catch (_: Throwable) {} }
    }

    private fun openHfLogin(page: String?) {
        hfOpened = true
        startActivity(Intent(this, HfLoginActivity::class.java).putExtra("next", page ?: ""))
    }

    /** Locked model without a token or a sign-in: offers the sign-in (no token needed) or the token. */
    private fun askAccess(id: String, title: String, url: String, f: File) {
        AlertDialog.Builder(this).setTitle(L("ورود به Hugging Face"))
            .setMessage(L("این مدل قفل است. وارد حساب Hugging Face شو (همان حسابی که ساخته‌ای)، در صفحهٔ مدل دکمهٔ Acknowledge license را بزن و بعد «تمام» را بزن؛ دانلود بدون توکن انجام می‌شود."))
            .setPositiveButton(L("ورود با حساب Hugging Face")) { _, _ -> openHfLogin(url.substringBefore("/resolve/")) }
            .setNeutralButton(L("استفاده از توکن")) { _, _ -> askToken { startDl(id, title, url, f) } }
            .setNegativeButton(L("بستن"), null).show()
    }

    /** Asks for the Hugging Face token (needed for Gemma models) and starts the download when it is saved. */
    private fun askToken(then: () -> Unit) {
        val e = ui.edit("HF token (hf_…)", 1, false).apply { setText(cfg.hfToken) }
        AlertDialog.Builder(this).setTitle(L("توکن Hugging Face"))
            .setMessage(L("توکن نوع Read را از huggingface.co/settings/tokens بساز و اینجا بچسبان. لایسنس همین مدل را هم باید در صفحهٔ مدل قبول کرده باشی."))
            .setView(e)
            .setPositiveButton(L("ذخیره و دانلود")) { _, _ ->
                cfg.hfToken = e.text.toString().trim()
                if (cfg.hfToken.isNotBlank()) then()
            }
            .setNeutralButton(L("ساخت توکن")) { _, _ -> openUrl("https://huggingface.co/settings/tokens") }
            .setNegativeButton(L("بستن"), null).show()
    }

    /** The download itself runs in a service (see Dl.kt): it goes on when the app is closed and retries by itself. */
    private fun startDl(id: String, title: String, url: String, dest: File) {
        if (Dl.jobs.containsKey(id)) return
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)   // only for the progress notification
        pct.remove(id)
        Dl.start(this, id, title, url, dest)
        companions[id]?.let { (u, f) -> if (!f.isFile || f.length() < 50L) { f.parentFile?.mkdirs(); if (!Dl.jobs.containsKey("$id-dict")) Dl.start(this, "$id-dict", title + " (dict)", u, f) } }
        renderModels()
    }

    private fun fmt(b: Long): String =
        if (b >= 1073741824L) String.format(java.util.Locale.US, "%.2f GB", b / 1073741824.0)
        else if (b >= 100L * 1048576) String.format(java.util.Locale.US, "%.0f MB", b / 1048576.0)
        else String.format(java.util.Locale.US, "%.1f MB", b / 1048576.0)

    private fun etaText(sec: Long): String =
        if (sec >= 3600) (sec / 3600).toString() + L(" ساعت و ") + ((sec % 3600) / 60) + L(" دقیقه")
        else if (sec >= 60) (sec / 60).toString() + L(" دقیقه")
        else sec.toString() + L(" ثانیه")

    /** Card on top of the Models tab: how much space the downloaded models take, and how much is free. */
    private fun storageSummary(): View {
        val c = ui.card()
        val dir = Models.dir(this)
        var ai = 0L
        for (f in dir.listFiles() ?: emptyArray()) if (f.isFile) ai += f.length()
        val lama = (Inpaint.file()?.let { if (it.isFile) it.length() else 0L } ?: 0L) + (Inpaint.miganFile()?.let { if (it.isFile) it.length() else 0L } ?: 0L)
        var ocr = 0L
        fun walk(f: File) { if (f.isFile) ocr += f.length() else for (x in f.listFiles() ?: emptyArray()) walk(x) }
        Ocr.base?.let { if (it.exists()) walk(it) }
        c.addView(ui.tv(L("فضای مصرف‌شده"), 14f, C.TXT, true))
        c.addView(ui.tv(L("مدل‌های AI") + ": " + fmt(ai) + "   ·   LaMa: " + fmt(lama) + "   ·   OCR: " + fmt(ocr), 12f, C.SUB), ui.lp(top = 4))
        c.addView(ui.tv(L("مجموع") + ": " + fmt(ai + lama + ocr) + "   ·   " + L("فضای خالی") + ": " + fmt(dir.usableSpace), 12f, C.ACC, true), ui.lp(top = 4))
        return c
    }

    /** Live update of one progress bar and its text while a download runs. */
    private fun updateProgress(id: String) {
        val j = Dl.jobs[id] ?: return
        val p = if (j.total > 0) (j.have * 1000 / j.total).toInt().coerceIn(0, 1000) else -1
        if (p >= 0) {
            pct[id] = p
            bars[id]?.let { bar -> bar.isIndeterminate = false; bar.progress = p }
        }
        val sp = if (j.speed > 0) "  ·  " + String.format(java.util.Locale.US, "%.1f", j.speed / 1048576.0) + " MB/s" else ""
        val eta = if (j.speed > 0 && j.total > j.have) "  ·  " + L("مانده: ") + etaText((j.total - j.have) / j.speed) else ""
        progress[id]?.text = if (j.note.isNotEmpty()) j.note else
            L("دانلود: ") + (if (p >= 0) (p / 10).toString() + "% · " else "") + fmt(j.have) + " / " + (if (j.total > 0) fmt(j.total) else "?") + sp + eta
    }

    private var fontPreview: TextView? = null

    private fun fontChoose(cur: String, onPick: (String) -> Unit) {
        val l = Fonts.list(this)
        AlertDialog.Builder(this).setTitle(L("انتخاب فونت"))
            .setSingleChoiceItems(l.map { it.label }.toTypedArray(), l.indexOfFirst { it.id == cur }.coerceAtLeast(0)) { d, i -> d.dismiss(); onPick(l[i].id) }
            .setNegativeButton(L("بستن"), null).show()
    }

    /** Settings card: the font of the translation on pictures / the bubble layer; fonts can be added from a file or downloaded. */
    private fun fontCard(): View {
        val c = ui.card()
        c.addView(ui.tv(L("فونت ترجمه روی عکس و حباب"), 16f, C.TXT, true))
        c.addView(ui.tv(L("فونت متن ترجمه‌ای که روی عکس، مانگا و لایهٔ حباب نوشته می‌شود. می‌توانی فونت فارسی خودت (.ttf یا .otf) را اضافه کنی یا چند فونت آماده را دانلود کنی. برای هر نوشته جداگانه هم می‌شود فونت گذاشت (روی نوشته در نمایش تمام‌صفحه بزن ← ظاهر ترجمه). فونت روی خواندن (OCR) اثر ندارد؛ خواندن با تنظیمات بالا است."), 11f, C.SUB), ui.lp(top = 4))
        val pv = ui.tv(L("این یک نمونهٔ ترجمه است ۱۲۳"), 20f, C.TXT, true).apply { gravity = android.view.Gravity.CENTER; textDirection = View.TEXT_DIRECTION_RTL }
        fontPreview = pv
        fun show() { pv.typeface = Fonts.face(this, cfg.ocrFont, true) }
        show()
        c.addView(pv, ui.lp(top = 8))
        val name = ui.tv(L("فونت فعلی: ") + Fonts.label(this, cfg.ocrFont), 12f, C.SUB)
        c.addView(name, ui.lp(top = 4))
        val row = ui.hbox()
        row.addView(ui.btn(L("انتخاب فونت"), true) { fontChoose(cfg.ocrFont) { id -> cfg.ocrFont = id; show(); name.text = L("فونت فعلی: ") + Fonts.label(this, id) } }, ui.hlp())
        row.addView(ui.btn(L("افزودن از گوشی"), false) {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }, 33)
        }, ui.hlp(1f, 8))
        c.addView(row, ui.lp(top = 8))
        c.addView(ui.btn(L("دانلود فونت‌های آماده (اینترنت)"), false) {
            val l = Fonts.downloads
            AlertDialog.Builder(this).setTitle(L("دانلود فونت"))
                .setItems(l.map { it.second }.toTypedArray()) { _, i ->
                    val (file, nm, url) = l[i]
                    toast(L("در حال دانلود…"))
                    Thread {
                        val err = try { Net.fetchFile(url, cfg, File(Fonts.dir(this), file)); null } catch (e: Throwable) { e.message ?: e.javaClass.simpleName }
                        runOnUiThread {
                            if (err == null) { cfg.ocrFont = "file:$file"; show(); name.text = L("فونت فعلی: ") + nm; toast(L("دانلود شد و انتخاب شد.")) }
                            else toast(L("دانلود نشد (") + err + L(")؛ فونت را از گوشی اضافه کن."))
                        }
                    }.start()
                }.setNegativeButton(L("بستن"), null).show()
        }, ui.lp(top = 8))
        c.addView(ui.btn(L("حذف یک فونت اضافه‌شده"), false) {
            val l = Fonts.list(this).filter { it.id.startsWith("file:") }
            if (l.isEmpty()) { toast(L("فونتی اضافه نشده.")); return@btn }
            AlertDialog.Builder(this).setTitle(L("کدام فونت حذف شود؟"))
                .setItems(l.map { it.label }.toTypedArray()) { _, i ->
                    Fonts.delete(this, l[i].id)
                    if (cfg.ocrFont == l[i].id) cfg.ocrFont = ""
                    show(); name.text = L("فونت فعلی: ") + Fonts.label(this, cfg.ocrFont)
                }.setNegativeButton(L("بستن"), null).show()
        }, ui.lp(top = 8))
        return c
    }

    private var saveDirTv: TextView? = null
    private fun saveDirLabel(): String {
        val t = cfg.saveTree
        if (t.isEmpty()) return L("هر بار می‌پرسد (صفحهٔ «ذخیره به‌عنوان»)")
        return try { treeToPath(Uri.parse(t)) ?: Uri.parse(t).lastPathSegment ?: t } catch (_: Throwable) { t }
    }

    /** Settings card: default folder for saved translations (picture, PDF, text, subtitles). */
    private fun saveDirCard(): View {
        val c = ui.card()
        c.addView(ui.tv(L("پوشهٔ ذخیرهٔ فایل‌های ترجمه‌شده"), 16f, C.TXT, true))
        c.addView(ui.tv(L("اگر یک پوشه انتخاب کنی، عکس، PDF، txt و srt ترجمه‌شده مستقیم همان‌جا (با نام و ساعت) ذخیره می‌شوند و هر بار پوشه نمی‌پرسد. هر وقت خواستی عوضش کن یا به حالت «هر بار بپرس» برگردان."), 11f, C.SUB), ui.lp(top = 4))
        val tv = ui.tv(saveDirLabel(), 12f, C.TXT).apply { setTextIsSelectable(true); textDirection = View.TEXT_DIRECTION_LTR }
        saveDirTv = tv
        c.addView(tv, ui.lp(top = 8))
        val row = ui.hbox()
        row.addView(ui.btn(L("انتخاب / تغییر پوشه"), true) {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), 32)
        }, ui.hlp())
        row.addView(ui.btn(L("هر بار بپرس"), false) { cfg.saveTree = ""; tv.text = saveDirLabel() }, ui.hlp(1f, 8))
        c.addView(row, ui.lp(top = 8))
        return c
    }

    /** Settings card: where the downloaded models are stored, with a move button. */
    private fun storageCard(): View {
        val c = ui.card()
        c.addView(ui.tv(L("پوشهٔ ذخیرهٔ مدل‌ها"), 16f, C.TXT, true))
        val pathTv = ui.tv("", 12f, C.SUB).apply { setTextIsSelectable(true); textDirection = View.TEXT_DIRECTION_LTR }
        storagePathTv = pathTv
        fun showPath() { pathTv.text = Models.dir(this).absolutePath }
        showPath()
        c.addView(pathTv, ui.lp(top = 6))
        val opts = listOf("", "ext", "custom")
        val cur = when { cfg.modelDir == "" -> 0; cfg.modelDir == "ext" -> 1; else -> 2 }
        customEdit = null
        val customRow = ui.vbox()
        customRow.addView(ui.btn(L("انتخاب پوشه از گوشی…")) {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), 30)
        }, ui.lp())
        customRow.visibility = if (cur == 2) View.VISIBLE else View.GONE
        c.addView(ui.seg(listOf(L("خصوصی (پیش‌فرض)"), L("پوشهٔ برنامه"), L("مسیر دلخواه")), cur) { i ->
            customRow.visibility = if (i == 2) View.VISIBLE else View.GONE
            if (i == 0) { switchModelDir(""); showPath() }
            if (i == 1) { switchModelDir("ext"); showPath() }
        }, ui.lp(top = 8))
        c.addView(customRow, ui.lp(top = 6))
        c.addView(ui.tv(L("خصوصی: امن‌ترین و بدون مجوز، ولی از بیرون برنامه دیده نمی‌شود (برای کپی کردن مدل‌ها مناسب نیست). پوشهٔ برنامه: Android/data/app.tarjoman/files/models (در اندروید ۱۱ به بعد بیشتر مدیر فایل‌ها اجازهٔ دیدنش را نمی‌دهند). مسیر دلخواه: هر پوشه‌ای که انتخاب کنی، مثلاً /storage/emulated/0/Tarjoman/models که در مدیر فایل راحت دیده می‌شود؛ برای اندروید ۱۱ به بعد مجوز «دسترسی به همهٔ فایل‌ها» لازم است. با عوض کردن پوشه، همهٔ مدل‌های دانلودشده (مدل‌های AI، LaMa، داده‌های OCR و نیمه‌کاره‌ها) به پوشهٔ جدید جابه‌جا می‌شوند، نه کپی. اگر پوشهٔ جدید روی همین حافظه باشد آنی است؛ اگر روی حافظهٔ دیگری باشد هر فایل کپی و بلافاصله پاک می‌شود، پس فقط یک فایل (بزرگ‌ترینش) لحظه‌ای دوبار جا می‌گیرد. بسته‌های زبانی ML Kit و مدل نوشتن با دست را خود گوگل مدیریت می‌کند و جابه‌جا نمی‌شوند."), 11f, C.SUB), ui.lp(top = 8))
        return c
    }

    /** On Android 11+ a folder outside the app needs the "all files access" permission. */
    private fun needAllFiles(): Boolean {
        if (Build.VERSION.SDK_INT >= 30 && !android.os.Environment.isExternalStorageManager()) {
            toast(L("مجوز «دسترسی به همهٔ فایل‌ها» را برای ترجمان روشن کن و دوباره امتحان کن."))
            try {
                startActivity(Intent(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
            } catch (_: Throwable) {
                try { startActivity(Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) } catch (_: Throwable) {}
            }
            return true
        }
        if (Build.VERSION.SDK_INT in 23..29 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 12)
            toast(L("اجازهٔ دسترسی به حافظه را بده و دوباره امتحان کن."))
            return true
        }
        return false
    }

    /** Sets the new models folder and moves everything from the old one (models and half-finished downloads). */
    private fun switchModelDir(v: String) {
        if (Dl.jobs.isNotEmpty()) { toast(L("اول دانلودهای در حال انجام را متوقف کن.")); return }
        if (v == "ext" && getExternalFilesDir("models") == null) { toast(L("حافظهٔ خارجی در دسترس نیست.")); return }
        val from = Models.dir(this)
        val to = Models.dirFor(this, v)
        if (from.absolutePath == to.absolutePath) { cfg.modelDir = v; return }
        try { to.mkdirs(); if (!to.isDirectory || !to.canWrite()) throw IllegalStateException(L("روی این مسیر نمی‌شود نوشت.")) } catch (e: Throwable) { toast(e.message ?: "?"); return }
        val oldV = cfg.modelDir
        cfg.modelDir = v
        Inpaint.release()
        Ocr.base = Models.auxDir(this, "ocr")
        Inpaint.base = Models.auxDir(this, "inpaint")
        Detector.release()
        Detector.base = Models.auxDir(this, "detect")
        toast(L("در حال انتقال مدل‌ها…"))
        tr.exec.execute {
            var moved = 0
            var failed = 0
            for (f in from.listFiles() ?: emptyArray()) {
                if (!f.isFile) continue
                val n = f.name
                if (!(n.endsWith(".task") || n.endsWith(".litertlm") || n.endsWith(".part") || n.endsWith(".meta") || n.endsWith(".bin") || n.endsWith(".tflite"))) continue
                if (Models.moveFile(f, File(to, n))) moved++ else failed++
            }
            for (name in listOf("inpaint", "ocr", "detect")) {
                val r = Models.moveTree(Models.auxDirFor(this, oldV, name), Models.auxDirFor(this, v, name))
                moved += r.first
                failed += r.second
            }
            h.post {
                toast(L("منتقل شد: ") + moved + (if (failed > 0) L("، ناموفق: ") + failed else ""))
                if (curTab == 5) refreshModels()
            }
        }
    }

    /** Asks once before anything downloaded is deleted. */
    private fun confirmDelete(what: String, ok: () -> Unit) {
        AlertDialog.Builder(this).setTitle(L("حذف شود؟")).setMessage(what)
            .setPositiveButton(L("حذف")) { _, _ -> ok() }
            .setNegativeButton(L("بستن"), null).show()
    }

    private fun addByUrl() {
        val e = ui.edit("https://…/model.task")
        AlertDialog.Builder(this).setTitle(L("لینک مستقیم فایل مدل")).setView(e)
            .setPositiveButton(L("دانلود")) { _, _ ->
                val u = e.text.toString().trim()
                val name = u.substringBefore("?").substringAfterLast('/')
                if (u.isNotEmpty() && name.isNotEmpty()) {
                    if (name.endsWith(".litertlm") && !LmBridge.available) { toast(L("فرمت .litertlm فقط در نسخهٔ LiteRT-LM پشتیبانی می‌شود")); return@setPositiveButton }
                    askFamily(name)
                    startDl("m:$name", name, u, File(Models.dir(this), name))
                }
            }.setNegativeButton(L("بستن"), null).show()
    }

    private fun askFamily(name: String) {
        AlertDialog.Builder(this).setTitle(L("نوع قالب چت این مدل؟"))
            .setItems(arrayOf("Gemma", "Qwen / ChatML", L("خام (Raw)"))) { _, i ->
                cfg.setFam(name, arrayOf("gemma", "qwen", "raw")[i])
            }.show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 50) {
            val t = if (resultCode == RESULT_OK) data?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() else null
            if (!t.isNullOrBlank()) { input.setText(t); input.setSelection(input.text.length); doTranslate() }
            return
        }
        if (requestCode == 3) {
            if (resultCode == RESULT_OK && data != null) {
                val i = Intent(this, BubbleService::class.java).putExtra("code", resultCode).putExtra("data", data)
                startForegroundService(i)
                h.postDelayed({ updateBubbleUi() }, 800)
                toast(L("حباب روشن شد؛ به برنامهٔ دلخواه برو"))
            } else toast(L("اجازهٔ ضبط صفحه داده نشد"))
            return
        }
        if (requestCode == 20) {
            val u = camUri
            camUri = null
            if (u != null) {
                if (resultCode == RESULT_OK) runImage(u)
                else try { contentResolver.delete(u, null, null) } catch (_: Throwable) {}   // cancelled: do not leave an empty picture behind
            }
            return
        }
        if (requestCode == 21) {
            // picture taken in the live camera screen: read and translate it like a gallery picture
            val path = data?.getStringExtra("path")
            if (resultCode == RESULT_OK && path != null) { show(1); runImage(Uri.fromFile(File(path))) }
            return
        }
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        if (requestCode == 33) {
            val n = try { Fonts.import(this, uri) } catch (_: Throwable) { null }
            if (n == null) toast(L("فایل فونت معتبر نیست (.ttf یا .otf)."))
            else { cfg.ocrFont = "file:$n"; fontPreview?.typeface = Fonts.face(this, cfg.ocrFont, true); toast(L("فونت اضافه و انتخاب شد.")) }
            return
        }
        if (requestCode == 32) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (_: Throwable) {}
            cfg.saveTree = uri.toString()
            saveDirTv?.text = saveDirLabel()
            toast(L("پوشهٔ پیش‌فرض ذخیره شد."))
            return
        }
        if (requestCode == 30) {
            val p = treeToPath(uri)
            if (p == null) { toast(L("این پوشه پشتیبانی نمی‌شود؛ پوشه‌ای از حافظهٔ داخلی یا کارت حافظه انتخاب کن.")); return }
            customEdit?.setText(p)
            if (needAllFiles()) return
            switchModelDir(p)
            storagePathTv?.text = Models.dir(this).absolutePath
            return
        }
        if (requestCode == 1) runImage(uri)
        if (requestCode == 2) importModel(uri)
        if (requestCode == 4) onPdfPicked(uri)
        if (requestCode == 40) onMangaPicked(uri)
        if (requestCode == 6) onSrtPicked(uri)
        if (requestCode == 5 || requestCode == 7 || requestCode == 8 || requestCode == 9 || requestCode == 41 || requestCode == 42) doSave(requestCode, uri)
    }

    /** Writes the result for save request [code] (5 txt, 7 srt, 8 picture, 9 pdf) to [uri]. */
    private fun doSave(code: Int, uri: Uri) {
        val requestCode = code
        if (requestCode == 42) {
            try {
                val bm = diagReport()
                if (bm != null) contentResolver.openOutputStream(uri)?.use { bm.compress(Bitmap.CompressFormat.PNG, 100, it) }
                toast(L("ذخیره شد"))
            } catch (e: Throwable) { toast(L("خطا: ") + e.message) }
        }
        if (requestCode == 41) {
            Thread {
                try {
                    mzOut.inputStream().use { ins -> contentResolver.openOutputStream(uri)?.use { o -> ins.copyTo(o, 256 * 1024) } }
                    toast(L("ذخیره شد"))
                } catch (e: Throwable) { toast(L("خطا: ") + e.message) }
            }.start()
        }
        if (requestCode == 7) {
            try {
                val txt = "\uFEFF" + SrtTool.build(srtCues, srtTexts)
                contentResolver.openOutputStream(uri)?.use { it.write(txt.toByteArray(Charsets.UTF_8)) }
                toast(L("ذخیره شد"))
            } catch (e: Throwable) { toast(L("خطا: ") + e.message) }
        }
        if (requestCode == 9) {
            try {
                contentResolver.openOutputStream(uri)?.use { PdfTool.export(pdfCur().toString(), it) }
                toast(L("PDF ذخیره شد"))
            } catch (e: Throwable) { toast(L("خطا: ") + e.message) }
        }
        if (requestCode == 8) {
            try {
                val bm = imgOut
                if (bm != null) contentResolver.openOutputStream(uri)?.use { bm.compress(Bitmap.CompressFormat.PNG, 100, it) }
                toast(L("ذخیره شد"))
            } catch (e: Throwable) { toast(L("خطا: ") + e.message) }
        }
        if (requestCode == 5) {
            try {
                contentResolver.openOutputStream(uri)?.use { it.write(pdfCur().toString().toByteArray(Charsets.UTF_8)) }
                toast(L("ذخیره شد"))
            } catch (e: Throwable) { toast(L("خطا: ") + e.message) }
        }
    }

    // ---- Share sheet: any translated result can be sent to another app
    private fun shareFileOut(name: String, mime: String, write: (java.io.OutputStream) -> Unit) {
        try {
            val dir = File(cacheDir, "share")
            dir.mkdirs()
            dir.listFiles()?.forEach { if (System.currentTimeMillis() - it.lastModified() > 3_600_000L) it.delete() }
            val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
            File(dir, safe).outputStream().use { write(it) }
            val u = Uri.parse("content://app.tarjoman.share/" + Uri.encode(safe))
            val i = Intent(Intent.ACTION_SEND).apply {
                type = mime
                putExtra(Intent.EXTRA_STREAM, u)
                clipData = ClipData.newRawUri("", u)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(i, L("اشتراک‌گذاری")))
        } catch (e: Throwable) { toast(L("اشتراک‌گذاری ممکن نشد") + ": " + (e.message ?: "")) }
    }

    private fun shareTextOut(t: String) {
        if (t.isBlank()) { toast(L("هنوز چیزی ترجمه نشده")); return }
        try {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, t) }, L("اشتراک‌گذاری")))
        } catch (_: Throwable) { toast(L("اشتراک‌گذاری ممکن نشد")) }
    }

    private fun shareImageOut() {
        val bm = imgOut
        if (bm == null) { toast(L("اول یک عکس ترجمه کن")); return }
        Thread {
            shareFileOut("translated_" + System.currentTimeMillis() + ".png", "image/png") { bm.compress(Bitmap.CompressFormat.PNG, 100, it) }
        }.start()
    }

    /** Where saved files go: the default folder when one is chosen (no question each time), otherwise the system "save as" screen. */
    private fun startSave(name: String, mime: String, code: Int) {
        val tree = cfg.saveTree
        if (tree.isNotEmpty()) {
            try {
                val t = Uri.parse(tree)
                val docId = android.provider.DocumentsContract.getTreeDocumentId(t)
                val parent = android.provider.DocumentsContract.buildDocumentUriUsingTree(t, docId)
                var nm = name
                val dot = name.lastIndexOf('.')
                val stem = if (dot > 0) name.substring(0, dot) else name
                val ext = if (dot > 0) name.substring(dot) else ""
                nm = stem + "_" + java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date()) + ext
                val u = android.provider.DocumentsContract.createDocument(contentResolver, parent, mime, nm)
                if (u != null) { doSave(code, u); return }
            } catch (_: Throwable) {
            }
            toast(L("پوشهٔ پیش‌فرض در دسترس نیست؛ پوشه را دوباره انتخاب کن."))
        }
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = mime; putExtra(Intent.EXTRA_TITLE, name) }, code)
    }

    private fun importModel(uri: Uri) {
        var name = "model_" + System.currentTimeMillis() + ".task"
        contentResolver.query(uri, null, null, null, null)?.use {
            if (it.moveToFirst()) {
                val ix = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (ix >= 0) name = it.getString(ix)
            }
        }
        if (name.endsWith(".litertlm") && !LmBridge.available) { toast(L("فرمت .litertlm فقط در نسخهٔ LiteRT-LM پشتیبانی می‌شود")); return }
        val fname = name
        toast(L("در حال کپی مدل… صبر کن (فایل بزرگ است؛ برنامه را نبند)"))
        Thread {
            try {
                val dest = File(Models.dir(this), fname)
                val tmp = File(dest.path + ".part")   // copied under a temporary name so a half copy is never taken for a model
                var total = 0L
                contentResolver.query(uri, null, null, null, null)?.use { q -> if (q.moveToFirst()) { val ix = q.getColumnIndex(OpenableColumns.SIZE); if (ix >= 0) total = q.getLong(ix) } }
                var last = System.currentTimeMillis()
                contentResolver.openInputStream(uri)?.use { ins ->
                    FileOutputStream(tmp).use { out ->
                        val buf = ByteArray(1024 * 1024)
                        var done = 0L
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            val now = System.currentTimeMillis()
                            if (now - last > 3000) { last = now; toast(L("در حال کپی مدل… ") + (done / 1048576) + (if (total > 0) " / " + (total / 1048576) else "") + " MB") }
                        }
                    }
                }
                Models.deleteCaches(dest)
                dest.delete()
                if (!tmp.renameTo(dest)) throw java.io.IOException("rename")
                h.post { askFamily(fname); refreshModels() }
                toast(L("مدل اضافه شد"))
            } catch (e: Throwable) {
                toast(L("خطا: ") + e.message)
            }
        }.start()
    }

    // ------------------------------------------------------------------ SETTINGS PAGE
    // ------------------------------------------------------------------ HISTORY PAGE
    /** Saves a finished translation in the background (the size limit is applied there). */
    private fun saveHist(kind: String, s: String, d: String, a: String, b: String) {
        val mb = cfg.histMb
        if (mb <= 0) return
        Thread { Hist.add(this, mb, kind, s, d, a, b) }.start()
    }

    private fun buildHistoryPage(): View {
        val sv = ScrollView(this)
        val col = ui.vbox()
        sv.addView(col)
        val top = ui.hbox()
        top.addView(ui.tv(L("تاریخچه ترجمه"), 18f, C.TXT, true), ui.hlp())
        top.addView(ui.btn(L("بازگشت"), false) { show(0) }, LinearLayout.LayoutParams(WRAP, WRAP))
        col.addView(top)
        histSearch = ui.edit(L("جستجو در تاریخچه…"))
        histSearch.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun afterTextChanged(e: android.text.Editable?) { h.removeCallbacks(histRun); h.postDelayed(histRun, 300) }
        })
        col.addView(histSearch, ui.lp(top = 10))
        histInfo = ui.tv("", 12f, C.SUB)
        col.addView(histInfo, ui.lp(top = 8))
        val r1 = ui.hbox()
        r1.addView(ui.btn(L("انتخاب همه"), false) { histSel.addAll(histShown.map { it.id }); renderHistory() }, ui.hlp())
        r1.addView(ui.btn(L("لغو انتخاب"), false) { histSel.clear(); renderHistory() }, ui.hlp(1f, 8))
        col.addView(r1, ui.lp(top = 8))
        val r2 = ui.hbox()
        r2.addView(ui.btn(L("حذف انتخاب‌شده"), false) {
            if (histSel.isEmpty()) { toast(L("اول چند مورد را انتخاب کن")); return@btn }
            val ids = HashSet(histSel)
            confirmDelete(L("موارد انتخاب‌شده پاک شوند؟") + " (" + ids.size + ")") {
                Thread { Hist.delete(this, ids); h.post { histSel.removeAll(ids); refreshHistory() } }.start()
            }
        }, ui.hlp())
        r2.addView(ui.btn(L("حذف همه")) {
            confirmDelete(L("همهٔ تاریخچهٔ ترجمه پاک شود؟")) {
                Thread { Hist.clear(this); h.post { histSel.clear(); refreshHistory() } }.start()
            }
        }, ui.hlp(1f, 8))
        col.addView(r2, ui.lp(top = 8))
        histBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(histBox, ui.lp(top = 10))
        return sv
    }

    private fun refreshHistory() {
        val q = histSearch.text.toString()
        val job = ++histJob
        Thread {
            val list = Hist.list(this, q, 150)
            val n = Hist.count(this)
            val sz = Hist.size(this)
            h.post {
                if (job == histJob) {
                    histShown.clear(); histShown.addAll(list)
                    histCount = n; histBytes = sz
                    renderHistory()
                }
            }
        }.start()
    }

    private fun renderHistory() {
        val cap = cfg.histMb
        histInfo.text = L("تعداد: ") + histCount + " · " + String.format(java.util.Locale.US, "%.2f MB", histBytes / 1048576.0) +
            (if (cap > 0) " / $cap MB" else " · " + L("ذخیره‌سازی خاموش است"))
        histBox.removeAllViews()
        if (histShown.isEmpty()) {
            histBox.addView(ui.tv(L("تاریخچه خالی است."), 13f, C.SUB))
            return
        }
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US)
        for (e in histShown) {
            val c = ui.card()
            val head = ui.hbox()
            head.addView(android.widget.CheckBox(this).apply {
                isChecked = e.id in histSel
                setOnCheckedChangeListener { _, on -> if (on) histSel.add(e.id) else histSel.remove(e.id) }
            }, LinearLayout.LayoutParams(WRAP, WRAP))
            val kind = if (e.kind == "image") L("عکس") + " · " else ""
            head.addView(ui.tv(kind + Lang.name(e.s).substringBefore(" ·") + " → " + Lang.name(e.d).substringBefore(" ·") + " · " + fmt.format(java.util.Date(e.id)), 11f, C.SUB, true), ui.hlp())
            c.addView(head)
            val a = ui.tv(e.src, 14f, C.TXT).apply {
                maxLines = 3; ellipsize = android.text.TextUtils.TruncateAt.END
                textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            }
            val b = ui.tv(e.out, 15f, C.ACC, true).apply {
                maxLines = 4; ellipsize = android.text.TextUtils.TruncateAt.END
                textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            }
            val toggle = View.OnClickListener {
                val open = a.maxLines == Int.MAX_VALUE
                a.maxLines = if (open) 3 else Int.MAX_VALUE
                b.maxLines = if (open) 4 else Int.MAX_VALUE
            }
            a.setOnClickListener(toggle); b.setOnClickListener(toggle)
            c.addView(a, ui.lp(top = 4))
            c.addView(b, ui.lp(top = 6))
            val br = ui.hbox()
            br.addView(ui.btn(L("استفاده"), false) {
                cfg.src = e.s; cfg.dst = e.d
                refreshLang()
                input.setText(e.src)
                output.text = e.out
                status.text = L("از تاریخچه")
                show(0)
            }, ui.hlp())
            br.addView(ui.btn(L("کپی"), false) {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("tr", e.out))
                toast(L("کپی شد"))
            }, ui.hlp(1f, 6))
            br.addView(ui.btn(L("حذف"), false) {
                Thread { Hist.delete(this, setOf(e.id)); h.post { histSel.remove(e.id); refreshHistory() } }.start()
            }, ui.hlp(1f, 6))
            c.addView(br, ui.lp(top = 8))
            histBox.addView(c, ui.lp(top = 8))
        }
    }

    private fun buildSettingsPage(): View {
        val sv = ScrollView(this)
        settingsScroll = sv
        val col = ui.vbox()
        sv.addView(col)

        val lang = ui.card()
        lang.addView(ui.tv(L("زبان برنامه"), 16f, C.TXT, true))
        lang.addView(ui.tv(L("زبان منوها و نوشته‌های خود برنامه (غیر از ترجمه). حباب شناور بعد از خاموش و روشن شدن زبان جدید را می‌گیرد."), 12f, C.SUB), ui.lp(top = 4))
        lang.addView(ui.seg(listOf(L("فارسی"), "English"), if (cfg.uiLang == "en") 1 else 0) {
            cfg.uiLang = if (it == 1) "en" else "fa"
            recreate()
        }, ui.lp(top = 8))
        col.addView(lang)

        val look = ui.card()
        look.addView(ui.tv(L("ظاهر برنامه"), 16f, C.TXT, true))
        look.addView(ui.tv(L("حالت رنگ"), 12f, C.SUB), ui.lp(top = 10))
        val tm = listOf("system", "light", "dark")
        look.addView(ui.seg(listOf(L("تم سیستم"), L("تم روشن"), L("تم تیره")), tm.indexOf(cfg.themeMode).coerceAtLeast(0)) {
            cfg.themeMode = tm[it]
            recreate()
        }, ui.lp(top = 3))
        look.addView(ui.tv(L("سبک ظاهر"), 12f, C.SUB), ui.lp(top = 10))
        look.addView(ui.seg(listOf(L("مدرن"), L("کلاسیک (کاغذی)")), if (cfg.look == "classic") 1 else 0) {
            cfg.look = if (it == 1) "classic" else "modern"
            recreate()
        }, ui.lp(top = 3))
        look.addView(ui.tv(L("«تم سیستم» از حالت روشن/تیرهٔ خود گوشی پیروی می‌کند. سبک کلاسیک ظاهر کاغذی با حروف سریف دارد و در هر دو حالت روشن (کاغذ) و تیره (کاغذ شب) کار می‌کند."), 11f, C.SUB), ui.lp(top = 6))
        col.addView(look, ui.lp(top = 12))

        val lay = ui.card()
        lay.addView(ui.tv(L("چیدمان برنامه"), 16f, C.TXT, true))
        lay.addView(ui.tv(L("حالت ساده (بدون توضیحات)"), 12f, C.SUB), ui.lp(top = 8))
        lay.addView(ui.seg(listOf(L("خاموش"), L("روشن")), cfg.simple) { cfg.simple = it; recreate() }, ui.lp(top = 3))
        lay.addView(ui.tv(L("روشن باشد، همهٔ توضیح‌های طولانی زیر گزینه‌ها پنهان می‌شوند و برنامه خیلی ساده‌تر دیده می‌شود. با هر انتخاب برنامه یک‌بار دوباره باز می‌شود."), 11f, C.SUB), ui.lp(top = 4))
        val lk = listOf("std", "compact", "large", "flat", "icons")
        lay.addView(ui.seg(listOf(L("استاندارد"), L("فشرده"), L("درشت")), lk.indexOf(cfg.layout).let { if (it in 0..2) it else -1 }) {
            cfg.layout = lk[it]; recreate()
        }, ui.lp(top = 10))
        lay.addView(ui.seg(listOf(L("مسطح"), L("فقط آیکون")), lk.indexOf(cfg.layout).let { if (it >= 3) it - 3 else -1 }) {
            cfg.layout = lk[3 + it]; recreate()
        }, ui.lp(top = 6))
        lay.addView(ui.tv(L("استاندارد (پیش‌فرض): اندازهٔ معمول. فشرده: نوشته و فاصله‌ها کوچک‌تر، چیزهای بیشتر در یک صفحه. درشت: نوشته و دکمه‌ها بزرگ‌تر، لمس راحت‌تر. مسطح: کارت‌ها بدون حاشیه و ساده‌تر. فقط آیکون: نوار پایین بدون نوشته و جادارتر. با هر انتخاب برنامه یک‌بار دوباره باز می‌شود."), 11f, C.SUB), ui.lp(top = 8))
        col.addView(lay, ui.lp(top = 12))

        val hs = ui.card()
        hs.addView(ui.tv(L("تاریخچه ترجمه"), 16f, C.TXT, true))
        hs.addView(ui.tv(L("متن‌ها و عکس‌هایی که ترجمه می‌کنی ذخیره می‌شوند تا بعداً دوباره ببینی. فقط روی خود گوشی می‌ماند. وقتی به سقف حجم برسد، قدیمی‌ترین‌ها خودکار پاک می‌شوند."), 12f, C.SUB), ui.lp(top = 4))
        hs.addView(ui.tv(L("حداکثر حجم تاریخچه (مگابایت)"), 12f, C.SUB), ui.lp(top = 10))
        val hv = listOf(0, 5, 10, 25, 50, 100)
        val hsize = ui.tv("", 12f, C.SUB)
        fun showUsed() { Thread { val b = Hist.size(this); h.post { hsize.text = L("حجم فعلی: ") + String.format(java.util.Locale.US, "%.2f MB", b / 1048576.0) } }.start() }
        hs.addView(ui.seg(listOf(L("خاموش"), "5", "10", "25", "50", "100"), hv.indexOf(cfg.histMb).let { if (it < 0) 2 else it }) {
            cfg.histMb = hv[it]
            if (it > 0) Thread { Hist.trim(this, hv[it]); showUsed() }.start()
        }, ui.lp(top = 3))
        hs.addView(hsize, ui.lp(top = 6))
        showUsed()
        val hr = ui.hbox()
        hr.addView(ui.btn(L("باز کردن تاریخچه"), false) { show(7) }, ui.hlp())
        hr.addView(ui.btn(L("پاک کردن همه"), false) {
            confirmDelete(L("همهٔ تاریخچهٔ ترجمه پاک شود؟")) { Thread { Hist.clear(this); showUsed() }.start() }
        }, ui.hlp(1f, 8))
        hs.addView(hr, ui.lp(top = 8))
        col.addView(hs, ui.lp(top = 12))

        val pref = ui.card()
        pref.addView(ui.tv(L("تشخیص خودکار زبان متن"), 16f, C.TXT, true))
        pref.addView(ui.tv(L("وقتی در تب «متن» ترجمه می‌زنی، اگر نوشته فارسی/انگلیسی/ژاپنی بود و با زبان مبدأ فرق داشت، خودش جابه‌جا می‌شود."), 12f, C.SUB), ui.lp(top = 4))
        pref.addView(ui.seg(listOf(L("خاموش"), L("روشن")), cfg.autoLang) { cfg.autoLang = it }, ui.lp(top = 8))
        pref.addView(ui.tv(L("انتخاب خودکار زبان کیبورد"), 12f, C.SUB), ui.lp(top = 12))
        pref.addView(ui.seg(listOf(L("خاموش"), L("روشن")), cfg.kbAuto) { cfg.kbAuto = it; applyKeyboard() }, ui.lp(top = 3))
        pref.addView(ui.tv(L("روشن باشد، هنگام نوشتن در کادر متن، کیبورد گوشی به زبان مبدأ می‌رود (اگر آن زبان در کیبورد فعال باشد)."), 11f, C.SUB), ui.lp(top = 4))
        pref.addView(ui.tv(L("اصلاح غلط‌های املایی انگلیسی"), 12f, C.SUB), ui.lp(top = 12))
        pref.addView(ui.seg(listOf(L("خاموش"), L("فقط پیشنهاد"), L("خودکار")), cfg.spell) { cfg.spell = it }, ui.lp(top = 3))
        pref.addView(ui.tv(L("مثلاً «helo» را «hello» می‌فهمد و همان را ترجمه می‌کند. «خودکار» غلط‌های روشن را خودش درست می‌کند و بقیه را فقط پیشنهاد می‌دهد؛ «فقط پیشنهاد» هیچ‌چیز را عوض نمی‌کند. واژگان آفلاین محدود است، پس واژهٔ نادر ممکن است ناشناخته بماند."), 11f, C.SUB), ui.lp(top = 4))
        col.addView(pref, ui.lp(top = 12))

        val imp = ui.card()
        imp.addView(ui.tv(L("بهبود ترجمه"), 16f, C.TXT, true))
        imp.addView(ui.tv(L("اصلاح انگلیسی قبل از ترجمهٔ آفلاین"), 12f, C.SUB), ui.lp(top = 8))
        imp.addView(ui.seg(listOf(L("خاموش"), L("روشن")), cfg.preFix) { cfg.preFix = it }, ui.lp(top = 3))
        imp.addView(ui.tv(L("حروف بزرگ مانگا را عادی می‌کند، i را I می‌کند، نقطه و علامت سؤال می‌گذارد و اصطلاحات عامیانه (مثل tripping یا cool) را به انگلیسی ساده تبدیل می‌کند تا ML Kit معنی را ترجمه کند، نه کلمه‌به‌کلمه."), 11f, C.SUB), ui.lp(top = 4))
        imp.addView(ui.tv(L("فارسی محاوره‌ای خودکار"), 12f, C.SUB), ui.lp(top = 10))
        imp.addView(ui.seg(listOf(L("خاموش"), L("روشن")), cfg.colloq) { cfg.colloq = it }, ui.lp(top = 3))
        imp.addView(ui.tv(L("وقتی «سبک ترجمه» محاوره‌ای است، فارسی رسمی را گفتاری می‌کند (مثلاً «می‌توانید» می‌شود «می‌تونید»، «را» می‌شود «رو»). برای ترجمهٔ همهٔ موتورها اعمال می‌شود."), 11f, C.SUB), ui.lp(top = 4))
        imp.addView(ui.tv(L("اعداد داخل جمله به حروف"), 12f, C.SUB), ui.lp(top = 10))
        imp.addView(ui.seg(listOf(L("خاموش"), L("روشن")), cfg.numWords) { cfg.numWords = it }, ui.lp(top = 3))
        imp.addView(ui.tv(L("روشن باشد، عددهای صحیح داخل ترجمهٔ متن (مثلاً «۳ سیب») به حروف نوشته می‌شوند («سه سیب»). ساعت، تاریخ و عددهای اعشاری یا جداشده با ویرگول دست‌نخورده می‌مانند."), 11f, C.SUB), ui.lp(top = 4))
        imp.addView(ui.tv(L("یادگیری خودکار معانی"), 12f, C.SUB), ui.lp(top = 10))
        imp.addView(ui.seg(listOf(L("خاموش"), L("روشن")), cfg.learnAuto) { cfg.learnAuto = it }, ui.lp(top = 3))
        imp.addView(ui.tv(L("روشن باشد، وقتی کلمه‌ای ترجمه می‌شود، برنامه معنی‌هایش را از اینترنت می‌گیرد و روی گوشی نگه می‌دارد (بعداً آفلاین هم نشان داده می‌شود). اگر مترجم کلمه را ترجمه نکند و همان را برگرداند، بهترین معنی جایش می‌نشیند؛ اگر ترجمه‌ای داد که در معانی دیگر نبود، به آن‌ها اضافه می‌شود."), 11f, C.SUB), ui.lp(top = 4))
        imp.addView(ui.tv(L("دانلود لغات بیشتر"), 12f, C.SUB), ui.lp(top = 10))
        val bulkTv = ui.tv("", 12f, C.SUB)
        fun bulkRefresh() { bulkTv.text = L("واژه‌های آماده: ") + Dict.bulkDone(this) + " / " + Words.MORE.size }
        bulkRefresh()
        imp.addView(bulkTv, ui.lp(top = 3))
        imp.addView(ui.tv(L("معنی‌های حدود ۱۴۰۰ واژهٔ پرکاربرد دیگر (اسم، فعل، صفت، فحش، کلمات رسمی و محاوره‌ای) را از اینترنت می‌گیرد و روی گوشی نگه می‌دارد تا بعداً بدون اینترنت و سریع نشان داده شوند. چند دقیقه تا نیم‌ساعت طول می‌کشد و می‌توانی هر وقت خواستی متوقفش کنی؛ دفعهٔ بعد از همان‌جا ادامه می‌دهد."), 11f, C.SUB), ui.lp(top = 3))
        val bulkBtn = ui.btn(L("شروع دانلود لغات"), false) { }
        bulkBtn.setOnClickListener {
            if (bulkRunning) { Dl.packStop = true; bulkBtn.text = L("در حال توقف…"); return@setOnClickListener }
            if (!Net.isOnline(this)) { toast(L("اینترنت لازم است.")); return@setOnClickListener }
            bulkRunning = true
            Dl.packStop = false
            bulkBtn.text = L("توقف")
            val app = applicationContext
            Dl.keepBegin(app)
            Thread {
                var added = 0
                try {
                    added = Dict.bulk(app, cfg, { Dl.packStop }) { done, total -> if (done % 5 == 0) h.post { bulkTv.text = L("در حال گرفتن: ") + done + " / " + total } }
                } catch (_: Throwable) {
                } finally {
                    Dl.keepEnd(app)
                    bulkRunning = false
                    h.post { bulkBtn.text = L("شروع دانلود لغات"); bulkRefresh(); toast(L("اضافه شد: ") + added) }
                }
            }.start()
        }
        imp.addView(bulkBtn, ui.lp(top = 6))
        imp.addView(ui.tv(L("کلمات و جمله‌های خیلی رکیک"), 12f, C.SUB), ui.lp(top = 10))
        imp.addView(ui.seg(listOf(L("خاموش"), L("روشن")), cfg.explicit) { cfg.explicit = it }, ui.lp(top = 3))
        imp.addView(ui.tv(L("واژه‌های جنسی و بدنی همیشه ترجمه می‌شوند و سانسور نمی‌شوند. خاموش: معادل‌های عادی و معمولی. روشن: معادل‌های گفتاری و خیلی رکیک. فحش‌ها و توهین‌های معمولی در هر دو حالت ترجمه می‌شوند."), 11f, C.SUB), ui.lp(top = 4))
        col.addView(imp, ui.lp(top = 12))

        val ocrC = ui.card()
        ocrC.addView(ui.tv(L("خواندن متن از عکس (OCR)"), 16f, C.TXT, true))
        ocrC.addView(ui.tv(L("برای هر زبان جدا تنظیم می‌شود، چون ابزار خواندن انگلیسی و فارسی یکی نیست. روی عکس‌های ترجمه، صفحه (حباب) و PDF اثر دارد."), 12f, C.SUB), ui.lp(top = 4))
        ocrC.addView(ui.tv(L("انگلیسی"), 14f, C.ACC, true), ui.lp(top = 12))
        ocrC.addView(ui.tv(L("ابزار خواندن"), 12f, C.SUB), ui.lp(top = 6))
        val enEng = listOf("auto", "mlkit", "tess")
        ocrC.addView(ui.seg(listOf(L("خودکار"), "ML Kit", "Tesseract"), enEng.indexOf(cfg.ocrEn).coerceAtLeast(0)) { cfg.ocrEn = enEng[it] }, ui.lp(top = 3))
        ocrC.addView(ui.tv(L("خودکار: ML Kit همیشه خوانده می‌شود و اگر مدل Tesseract انگلیسی را در تب «مدل‌ها» نصب کرده باشی، هر دو می‌خوانند و نتیجه‌ای که کلمات واقعی بیشتری دارد انتخاب می‌شود (دقیق‌تر ولی کمی کندتر). ML Kit: سریع و بدون مدل اضافه. Tesseract: فقط وقتی مدلش نصب است."), 11f, C.SUB), ui.lp(top = 4))
        ocrC.addView(ui.tv(L("نوع عکس"), 12f, C.SUB), ui.lp(top = 10))
        val ikl = listOf("auto", "manga", "manhwa", "comic", "screen")
        ocrC.addView(ui.seg(listOf(L("خودکار"), L("مانگا"), L("مانهوا/وبتون"), L("کمیک"), L("اسکرین‌شات")), ikl.indexOf(cfg.imgKind).coerceAtLeast(0)) { cfg.imgKind = ikl[it] }, ui.lp(top = 3))
        ocrC.addView(ui.tv(L("مانگا: ترتیب خواندن از راست به چپ. مانهوا و کمیک: چپ به راست. هر سه نوار بالا و پایین را حذف نمی‌کنند و پیداکنندهٔ متن را فعال نگه می‌دارند. اسکرین‌شات: نوار بالا و پایین حذف می‌شود و پیداکننده خاموش است (سریع‌تر). ترتیب درست به ترجمهٔ پیوستهٔ داستان کمک می‌کند."), 11f, C.SUB), ui.lp(top = 4))
        ocrC.addView(ui.tv(L("PaddleOCR (وقتی مدلش نصب است)"), 12f, C.SUB), ui.lp(top = 10))
        val pdm = listOf("off", "auto", "only")
        ocrC.addView(ui.seg(listOf(L("خاموش"), L("خودکار"), L("فقط این")), pdm.indexOf(cfg.ocrPaddle).coerceAtLeast(0)) { cfg.ocrPaddle = pdm[it] }, ui.lp(top = 3))
        ocrC.addView(ui.tv(L("خودکار: برای انگلیسی خواننده‌ای کمکی است که با ML Kit مقایسه می‌شود؛ برای عربی تنها خواننده؛ برای بقیه فقط وقتی ML Kit چیزی پیدا نکند. «فقط این»: همهٔ زبان‌هایی که مدلشان نصب است با PaddleOCR خوانده می‌شوند (دقیق‌تر روی بعضی عکس‌ها، کندتر)."), 11f, C.SUB), ui.lp(top = 4))
        ocrC.addView(ui.tv(L("پیداکنندهٔ خط متن (اگر هر دو نصب باشند)"), 12f, C.SUB), ui.lp(top = 8))
        val pdd = listOf("auto", "small", "big")
        ocrC.addView(ui.seg(listOf(L("خودکار"), L("سبک"), L("دقیق")), pdd.indexOf(cfg.paddleDet).coerceAtLeast(0)) { cfg.paddleDet = pdd[it] }, ui.lp(top = 3))
        ocrC.addView(ui.tv(L("اندازهٔ عکس برای پیداکننده (بزرگ‌تر = دقیق‌تر و کندتر)"), 12f, C.SUB), ui.lp(top = 8))
        val pds = listOf(960, 1280, 1664)
        ocrC.addView(ui.seg(listOf("960", "1280", "1664"), pds.indexOf(cfg.paddleSide).let { if (it < 0) 1 else it }) { cfg.paddleSide = pds[it] }, ui.lp(top = 3))
        ocrC.addView(ui.tv(L("بهتر کردن عکس قبل از خواندن (بزرگ‌کردن و کنتراست)"), 12f, C.SUB), ui.lp(top = 10))
        val enPre = listOf("auto", "on", "off")
        ocrC.addView(ui.seg(listOf(L("خودکار"), L("همیشه"), L("خاموش")), enPre.indexOf(cfg.ocrEnPre).coerceAtLeast(0)) { cfg.ocrEnPre = enPre[it] }, ui.lp(top = 3))
        ocrC.addView(ui.tv(L("خودکار: فقط وقتی خواندن اول مشکوک یا عکس کوچک است. «همیشه» برای متن ریز و کم‌رنگ؛ «خاموش» اگر عکست خودش تمیز و بزرگ است و سرعت می‌خواهی."), 11f, C.SUB), ui.lp(top = 4))
        ocrC.addView(ui.tv(L("اصلاح حروف شبیه هم با فهرست کلمات (مثلاً rn به جای m)"), 12f, C.SUB), ui.lp(top = 10))
        ocrC.addView(ui.seg(listOf(L("خاموش"), L("روشن")), cfg.ocrEnFix) { cfg.ocrEnFix = it }, ui.lp(top = 3))
        ocrC.addView(ui.tv(L("نوار بالا و پایین گوشی در اسکرین‌شات (ساعت، دکمه‌های پایین مثل Home)"), 12f, C.SUB), ui.lp(top = 10))
        ocrC.addView(ui.seg(listOf(L("بخوان"), L("نادیده بگیر")), cfg.ocrSkipBars) { cfg.ocrSkipBars = it }, ui.lp(top = 3))
        ocrC.addView(ui.tv(L("فارسی"), 14f, C.ACC, true), ui.lp(top = 16))
        ocrC.addView(ui.tv(L("مدل خواندن"), 12f, C.SUB), ui.lp(top = 6))
        val faMod = listOf("auto", "fast", "best")
        ocrC.addView(ui.seg(listOf(L("خودکار"), L("سریع"), L("دقیق")), faMod.indexOf(cfg.ocrFaModel).coerceAtLeast(0)) { cfg.ocrFaModel = faMod[it] }, ui.lp(top = 3))
        ocrC.addView(ui.tv(L("خودکار: اگر مدل «دقیق‌تر» نصب باشد همان را می‌گیرد. اگر مدل انتخابی نصب نباشد، مدل نصب‌شدهٔ دیگر استفاده می‌شود."), 11f, C.SUB), ui.lp(top = 4))
        ocrC.addView(ui.tv(L("آماده‌سازی عکس"), 12f, C.SUB), ui.lp(top = 10))
        val faPre = listOf("auto", "gray", "bw")
        ocrC.addView(ui.seg(listOf(L("خودکار"), L("خاکستری"), L("سیاه و سفید")), faPre.indexOf(cfg.ocrFaPre).coerceAtLeast(0)) { cfg.ocrFaPre = faPre[it] }, ui.lp(top = 3))
        ocrC.addView(ui.tv(L("خودکار: هر عکس به دو شکل خوانده می‌شود و نتیجهٔ مطمئن‌تر می‌ماند (کندتر). خاکستری: برای متن تیره روی زمینهٔ روشن. سیاه و سفید: برای مانگا و متن سفید روی زمینهٔ تیره؛ سریع‌تر."), 11f, C.SUB), ui.lp(top = 4))
        ocrC.addView(ui.tv(L("پاک‌کردن متن اصلی با LaMa"), 14f, C.ACC, true), ui.lp(top = 16))
        ocrC.addView(ui.seg(listOf(L("خاموش"), L("روشن")), cfg.lama) { cfg.lama = it }, ui.lp(top = 6))
        ocrC.addView(ui.tv(L("روشن: اگر مدل LaMa را از تب «مدل‌ها» نصب کرده باشی، متن اصلی روی پس‌زمینه‌های طرح‌دار پاک و بازسازی می‌شود و ترجمه با حاشیهٔ روشن/تیره روی تصویر می‌نشیند. خاموش: همان پُرکردن ساده با رنگ پس‌زمینه. حباب‌های تک‌رنگ در هر دو حالت سریع پر می‌شوند."), 11f, C.SUB), ui.lp(top = 4))
        ocrC.addView(ui.tv(L("پیدا کردن جای متن با مدل (اگر نصب باشد)"), 12f, C.SUB), ui.lp(top = 10))
        ocrC.addView(ui.seg(listOf(L("خاموش"), L("روشن")), cfg.ocrDetect) { cfg.ocrDetect = it }, ui.lp(top = 3))
        ocrC.addView(ui.tv(L("مدل «پیدا کردن جای متن» را از تب مدل‌ها بگیر. روشن: جاهایی از صفحه که متن دارد ولی خواندن معمولی ندیده، جدا خوانده و اضافه می‌شود."), 11f, C.SUB), ui.lp(top = 4))
        ocrC.addView(ui.tv(L("مدل پاک‌کننده"), 12f, C.SUB), ui.lp(top = 10))
        val erK = listOf("auto", "lama", "migan")
        ocrC.addView(ui.seg(listOf(L("خودکار"), "LaMa", "MI-GAN"), erK.indexOf(cfg.eraser).coerceAtLeast(0)) { cfg.eraser = erK[it]; Inpaint.release() }, ui.lp(top = 3))
        ocrC.addView(ui.tv(L("خودکار: LaMa اگر نصب باشد، وگرنه MI-GAN. MI-GAN خیلی سبک‌تر و سریع‌تر است (۲۸ مگابایت در برابر ۲۰۸)؛ LaMa روی طرح‌های پیچیده معمولاً کمی تمیزتر است. اگر مدل انتخابی نصب نباشد، مدل نصب‌شدهٔ دیگر استفاده می‌شود."), 11f, C.SUB), ui.lp(top = 4))
        ocrC.addView(ui.tv(L("پاک‌کردن روی همهٔ عکس‌ها"), 12f, C.SUB), ui.lp(top = 10))
        val lamaOrder = listOf(0, 2, 1)   // stored values: 0 = fast, 2 = auto, 1 = always (1 keeps the meaning it had in 0.91.2)
        ocrC.addView(ui.seg(listOf(L("سریع"), L("خودکار"), L("همیشه")), lamaOrder.indexOf(cfg.lamaAll).coerceAtLeast(0)) { cfg.lamaAll = lamaOrder[it] }, ui.lp(top = 3))
        ocrC.addView(ui.tv(L("سریع: حباب‌ها و زمینه‌های تک‌رنگ با پُرکردن ساده و فقط پس‌زمینه‌های طرح‌دار با LaMa. خودکار: اگر عکس متن کمی دارد (تا ۸ متن) LaMa روی همهٔ متن‌ها اجرا می‌شود، چون زمان زیادی نمی‌برد؛ اگر متن‌ها زیادند (مثل صفحهٔ مانگا) مثل «سریع» عمل می‌کند. همیشه: LaMa روی همهٔ متن‌ها اجرا می‌شود؛ پاک‌شدن طبیعی‌تر ولی کندتر (چند ثانیه برای هر متن) و رم بیشتر. بیشینه ۳۰ متن در هر عکس. فقط وقتی «پاک‌کردن متن اصلی با LaMa» روشن و مدل نصب باشد اثر دارد."), 11f, C.SUB), ui.lp(top = 4))
        col.addView(ocrC, ui.lp(top = 12))
        col.addView(fontCard(), ui.lp(top = 12))

        col.addView(saveDirCard(), ui.lp(top = 12))
        col.addView(storageCard(), ui.lp(top = 12))
        crashCard()?.let { col.addView(it, ui.lp(top = 12)) }
        val mineC = ui.card()
        mineC.addView(ui.tv(L("ترجمه‌های اصلاح‌شدهٔ من"), 16f, C.TXT, true))
        val mineTv = ui.tv("", 12f, C.SUB)
        fun showMine() { mineTv.text = L("تعداد: ") + Idm.mineCount() + L(" · با دکمهٔ «اصلاح ترجمه» در صفحهٔ متن اضافه می‌شود.") }
        showMine()
        mineC.addView(mineTv, ui.lp(top = 4))
        mineC.addView(ui.btn(L("مشاهده و ویرایش"), false) { showMineList { showMine() } }, ui.lp(top = 8))
        mineC.addView(ui.btn(L("پاک کردن همه"), false) {
            confirmDelete(L("ترجمه‌های اصلاح‌شدهٔ من")) { cfg.userPhr = ""; Idm.loadMine(""); showMine() }
        }, ui.lp(top = 8))
        col.addView(mineC, ui.lp(top = 12))

        val live = ui.card()
        live.addView(ui.tv(L("ترجمه خودکار هنگام نوشتن"), 16f, C.TXT, true))
        live.addView(ui.tv(L("روشن باشد، بعد از چند لحظه که تایپ را رها کنی خودش ترجمه می‌کند و نیازی به دکمهٔ ترجمه نیست. با موتور AI کندتر است و برای Normal بهتر جواب می‌دهد."), 12f, C.SUB), ui.lp(top = 4))
        live.addView(ui.seg(listOf(L("خاموش"), L("روشن")), cfg.live) { cfg.live = it }, ui.lp(top = 8))
        col.addView(live, ui.lp(top = 12))

        val net = ui.card()
        net.addView(ui.tv(L("شبکه (پروکسی/فیلترشکن)"), 16f, C.TXT, true))
        net.addView(ui.tv(L("اگر فیلترشکن سیستمی روشن است همین کافی است؛ اگر فقط پروکسی داری اینجا بگذار. برای دانلود مدل و ترجمه آنلاین استفاده می‌شود."), 12f, C.SUB), ui.lp(top = 4))
        val types = listOf("none", "http", "socks")
        net.addView(ui.seg(listOf(L("بدون پروکسی"), "HTTP", "SOCKS5"), types.indexOf(cfg.proxyType).coerceAtLeast(0)) { cfg.proxyType = types[it] }, ui.lp(top = 8))
        val ph = ui.edit(L("آدرس (مثلاً 127.0.0.1)")).apply { setText(cfg.proxyHost) }
        val pp = ui.edit(L("پورت (مثلاً 10808)")).apply { setText(cfg.proxyPort) }
        net.addView(ph, ui.lp(top = 8))
        net.addView(pp, ui.lp(top = 8))
        col.addView(net, ui.lp(top = 12))

        val hf = ui.card()
        hf.addView(ui.tv(L("دانلود مدل (Hugging Face)"), 16f, C.TXT, true))
        hf.addView(ui.tv(L("توکن فقط برای مدل‌های Gemma لازم است (از huggingface.co/settings/tokens، نوع Read، و لایسنس مدل را در سایت قبول کن). آینه برای زمانی است که huggingface.co فیلتر است."), 12f, C.SUB), ui.lp(top = 4))
        hf.addView(ui.btn(if (Hf.signedIn(cfg)) L("وارد شده‌ای ✓ (دوباره ورود)") else L("ورود با حساب Hugging Face"), !Hf.signedIn(cfg)) { openHfLogin(null) }, ui.lp(top = 8))
        hf.addView(ui.tv(L("ورود با حساب فقط با نام کاربری و رمز کار می‌کند؛ ورود با Google/GitHub داخل برنامه ممکن است مسدود باشد."), 12f, C.SUB), ui.lp(top = 4))
        if (Hf.signedIn(cfg)) hf.addView(ui.btn(L("خروج از حساب"), false) { Hf.signOut(cfg); toast(L("خروج انجام شد")) }, ui.lp(top = 8))
        val tok = ui.edit("HF token (hf_…)", 1, true).apply { setText(cfg.hfToken) }
        val mir = ui.edit(L("آینه، پیش‌فرض huggingface.co")).apply { setText(cfg.mirror) }
        hf.addView(tok, ui.lp(top = 8))
        hf.addView(mir, ui.lp(top = 8))
        col.addView(hf, ui.lp(top = 12))

        val api = ui.card()
        api.addView(ui.tv(L("آنلاین پیشرفته (اختیاری)"), 16f, C.TXT, true))
        api.addView(ui.tv(L("اگر کلید API سازگار با OpenAI بگذاری (مثلاً Gemini رایگان)، در حالت آنلاین + Advanced با هوش مصنوعی ابری ترجمه می‌شود. خالی بماند، از ترجمه گوگل استفاده می‌شود."), 12f, C.SUB), ui.lp(top = 4))
        val au = ui.edit(L("آدرس API")).apply { setText(cfg.apiUrl) }
        val ak = ui.edit("API key", 1, true).apply { setText(cfg.apiKey) }
        val am = ui.edit(L("نام مدل")).apply { setText(cfg.apiModel) }
        // ready-made cloud services: one tap fills the address and a good model; the note says where the key comes from
        val provNote = ui.tv("", 12f, C.SUB)
        val provs = listOf(
            arrayOf("Google Gemini (" + L("رایگان، بهترین برای عکس") + ")", "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions", "gemini-2.5-flash", L("کلید رایگان: aistudio.google.com/apikey ← Create API key. هم متن و هم عکس را می‌خواند؛ بهترین انتخاب برای مانگا. سهمیهٔ رایگان محدود است.")),
            arrayOf("Groq (" + L("رایگان، خیلی سریع، فقط متن") + ")", "https://api.groq.com/openai/v1/chat/completions", "llama-3.3-70b-versatile", L("کلید رایگان: console.groq.com/keys. بسیار سریع ولی برای عکس مناسب نیست؛ فقط برای ترجمهٔ متن.")),
            arrayOf("OpenRouter (" + L("چند مدل، بعضی رایگان") + ")", "https://openrouter.ai/api/v1/chat/completions", "google/gemini-2.5-flash", L("کلید: openrouter.ai/keys. مدل‌های زیادی دارد؛ نام مدل را می‌توانی عوض کنی (مدل‌های با پسوند :free رایگان‌اند).")),
            arrayOf("Mistral (" + L("سطح رایگان") + ")", "https://api.mistral.ai/v1/chat/completions", "mistral-small-latest", L("کلید: console.mistral.ai ← API keys (برای سطح رایگان باید حساب را فعال کنی).")),
            arrayOf("DeepSeek (" + L("ارزان، فقط متن") + ")", "https://api.deepseek.com/chat/completions", "deepseek-chat", L("کلید: platform.deepseek.com ← API keys. پولی ولی بسیار ارزان؛ ترجمهٔ متن خوب.")),
            arrayOf("OpenAI (" + L("پولی") + ")", "https://api.openai.com/v1/chat/completions", "gpt-4o-mini", L("کلید: platform.openai.com/api-keys. پولی؛ متن و عکس.")))
        api.addView(ui.btn(L("انتخاب سرویس‌دهندهٔ آماده"), false) {
            AlertDialog.Builder(this).setTitle(L("سرویس‌دهندهٔ ابری")).setItems(provs.map { it[0] }.toTypedArray()) { _, i ->
                au.setText(provs[i][1]); am.setText(provs[i][2]); provNote.text = provs[i][3]
            }.setNegativeButton(L("بستن"), null).show()
        }, ui.lp(top = 8))
        api.addView(provNote, ui.lp(top = 4))
        api.addView(au, ui.lp(top = 8))
        api.addView(ak, ui.lp(top = 8))
        api.addView(am, ui.lp(top = 8))
        api.addView(ui.tv(L("خواندن و ترجمهٔ عکس / حباب با هوش مصنوعی ابری"), 14f, C.TXT, true), ui.lp(top = 14))
        api.addView(ui.tv(L("با کلید API (مثلاً Gemini رایگان) مدل بینایی هر کادر متن را دقیق می‌خواند و با کل صفحه به‌عنوان زمینه ترجمه می‌کند؛ خیلی بهتر از خواندن گوشی. عکس به سرویس‌دهنده فرستاده می‌شود و اینترنت لازم است. اگر نشد یا خاموش بود، همان روش معمولی کار می‌کند."), 12f, C.SUB), ui.lp(top = 4))
        api.addView(ui.seg(listOf(L("خاموش"), L("روشن")), cfg.visionOcr) { cfg.visionOcr = it }, ui.lp(top = 6))
        api.addView(ui.tv(L("پیدا کردن متن جاافتاده (مدل کل صفحه را یک بار دیگر می‌بیند و متنی را که گوشی نخوانده پیدا و ترجمه می‌کند؛ یک درخواست اضافه برای هر عکس)"), 12f, C.SUB), ui.lp(top = 10))
        api.addView(ui.seg(listOf(L("خاموش"), L("روشن")), cfg.visionMissing) { cfg.visionMissing = it }, ui.lp(top = 3))
        api.addView(ui.btn(L("تست اتصال API"), false) {
            cfg.apiUrl = au.text.toString().trim(); cfg.apiKey = ak.text.toString().trim(); cfg.apiModel = am.text.toString().trim()
            toast(L("در حال تست…"))
            Thread { val r = Vision.test(cfg); h.post { AlertDialog.Builder(this).setTitle(L("نتیجهٔ تست API")).setMessage(r).setPositiveButton(L("بستن"), null).show() } }.start()
        }, ui.lp(top = 8))
        col.addView(api, ui.lp(top = 12))

        val gl = ui.card()
        gl.addView(ui.tv(L("واژه‌نامه (اسامی و اصطلاحات)"), 16f, C.TXT, true))
        gl.addView(ui.tv(L("هر خط یک مورد، به شکل  اصلی=ترجمه  مثلاً  Naruto=ناروتو . فقط روی موتور AI و API اثر دارد."), 12f, C.SUB), ui.lp(top = 4))
        val gle = ui.edit(L("Naruto=ناروتو"), 4).apply { setText(cfg.glossary) }
        gl.addView(gle, ui.lp(top = 8))
        col.addView(gl, ui.lp(top = 12))

        col.addView(ui.btn(L("ذخیره تنظیمات")) {
            cfg.glossary = gle.text.toString().trim()
            cfg.proxyHost = ph.text.toString().trim()
            cfg.proxyPort = pp.text.toString().trim()
            cfg.hfToken = tok.text.toString().trim()
            cfg.mirror = mir.text.toString().trim().ifEmpty { "huggingface.co" }
            cfg.apiUrl = au.text.toString().trim()
            cfg.apiKey = ak.text.toString().trim()
            cfg.apiModel = am.text.toString().trim()
            toast(L("ذخیره شد"))
        }, ui.lp(top = 14))

        col.addView(ui.tv(L("نسخه ۰.۱۶: ترجمه زنده با ورق زدن. نسخه ۰.۱۵: نوشتن «از/به» بالای زبان‌ها. نسخه ۰.۱۴: یک دکمه برای روشن/خاموش کردن حباب، لایهٔ ترجمه بدون جلوگیری از لمس، تنظیمات حباب فقط با لمس طولانی. نسخه ۰.۱۳: ترجمه خودکار هنگام نوشتن، حالت‌های حباب (آزاد/قفل/خواب)، نوار پایین جدید، مدل کوچک‌تر. نسخه ۰.۱۲: گزینهٔ «سبک ترجمه» (محاوره‌ای/رسمی) برای موتور AI. نسخه ۰.۱۱: زبان برنامه (فارسی/انگلیسی) در تنظیمات، اسم انگلیسی زیر آیکون، مدل سنگین‌تر Gemma 3n در فهرست مدل‌ها. نسخه ۰.۱۰: پشتیبانی اختیاری از مدل‌های .litertlm. نسخه ۰.۹: تم کلاسیک/مدرن و آیکون جدید. نسخه ۰.۸: PDFهای متنی بدون OCR. نسخه ۰.۷: خروجی PDF و حباب‌های عمودی مانگا. نسخه ۰.۶: تشخیص خودکار زبان، حافظهٔ ترجمه، اصلاح نگارش فارسی، حالت ترکیبی، .vtt یوتیوب."), 12f, C.SUB), ui.lp(top = 16))
        return sv
    }
}
