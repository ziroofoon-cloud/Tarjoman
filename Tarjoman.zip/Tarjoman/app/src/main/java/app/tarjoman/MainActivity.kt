package app.tarjoman

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.InputType
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.ConcurrentHashMap

class MainActivity : Activity() {
    private lateinit var ui: Ui
    private lateinit var tr: Tr
    private lateinit var cfg: Cfg
    private val h = Handler(Looper.getMainLooper())

    private lateinit var content: FrameLayout
    private val pages = ArrayList<View>()
    private val tabViews = ArrayList<View>()
    private val tabIcons = ArrayList<IconView>()
    private var curTab = 0
    private var settingsScroll: ScrollView? = null
    private var dark = true
    private val tabLabels = ArrayList<TextView>()

    // text page
    private lateinit var srcBtn: TextView
    private lateinit var dstBtn: TextView
    private lateinit var input: EditText
    private lateinit var output: TextView
    private lateinit var status: TextView
    private lateinit var goBtn: TextView
    private lateinit var modeHolder: FrameLayout

    // image page
    private lateinit var imgView: ImageView
    private var imgBlocks: List<OBlock> = emptyList()
    private lateinit var imgStatus: TextView
    private lateinit var imgText: TextView
    private lateinit var imgSegHolder: FrameLayout
    private lateinit var imgTextCard: View
    private lateinit var imgActions: View
    private var imgOut: Bitmap? = null        // picture with the translation drawn on it
    private var imgOrig: Bitmap? = null       // the picture as chosen
    private var imgOrigText = ""
    private var imgTransText = ""
    private var imgMode = 0                   // 0 on the picture | 1 translated text | 2 original text
    @Volatile private var imgJob = 0
    private var imgUri: Uri? = null
    private lateinit var imgSrcBtn: TextView
    private lateinit var imgDstBtn: TextView
    private var txtJob = 0
    private var txtRunning = false

    // history page
    private lateinit var histBox: LinearLayout
    private lateinit var histInfo: TextView
    private lateinit var histSearch: EditText
    private val histSel = HashSet<Long>()
    private val histShown = ArrayList<HEntry>()
    private var histCount = 0
    private var histBytes = 0L
    @Volatile private var histJob = 0
    private val histRun = Runnable { refreshHistory() }

    // pdf page
    private lateinit var pdfInfo: TextView
    private lateinit var pdfStatus: TextView
    private lateinit var pdfOut: TextView
    private lateinit var pdfFrom: EditText
    private var pdfUri: Uri? = null
    private var pdfPages = 0
    private val pdfSb = StringBuilder()       // translated
    private val pdfOrigSb = StringBuilder()   // extracted original
    private val pdfBiSb = StringBuilder()     // original + translation, paragraph by paragraph
    private var pdfMode = 0                   // 0 translated | 1 original | 2 both
    @Volatile private var pdfCancel = false
    @Volatile private var pdfRunning = false

    // subtitle page
    private lateinit var srtInfo: TextView
    private lateinit var srtStatus: TextView
    private lateinit var srtOut: TextView
    private var srtCues: List<Cue> = emptyList()
    private val srtTexts = ArrayList<String?>()
    @Volatile private var srtCancel = false
    @Volatile private var srtRunning = false

    // bubble page
    private lateinit var bubbleStatus: TextView
    private lateinit var bubbleToggle: TextView

    /** One button: "Turn on" when the bubble is off, "Turn off" when it is on. */
    private fun updateBubbleUi() {
        val on = BubbleService.running
        bubbleStatus.text = if (on) L("حباب روشن است") else L("حباب خاموش است")
        bubbleStatus.setTextColor(if (on) C.OK else C.SUB)
        bubbleToggle.text = if (on) L("خاموش کردن حباب") else L("روشن کردن حباب")
    }

    // models page
    private lateinit var modelsBox: LinearLayout
    private val progress = HashMap<String, TextView>()

    private fun statusBarH(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else ui.dp(24)
    }

    /** Writes the stack trace of a crash to files/crash.txt, so the cause can be read and sent (Settings -> last error). */
    private fun installCrashLog() {
        val app = applicationContext
        val old = Thread.getDefaultUncaughtExceptionHandler()
        if (old is CrashLog) return
        Thread.setDefaultUncaughtExceptionHandler(CrashLog(app, old))
    }

    private class CrashLog(val ctx: Context, val next: Thread.UncaughtExceptionHandler?) : Thread.UncaughtExceptionHandler {
        override fun uncaughtException(t: Thread, e: Throwable) {
            try {
                val sw = java.io.StringWriter()
                e.printStackTrace(java.io.PrintWriter(sw))
                val v = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName } catch (_: Throwable) { "?" }
                java.io.File(ctx.filesDir, "crash.txt").writeText(
                    "Tarjoman " + v + " · Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ") · " + Build.MANUFACTURER + " " + Build.MODEL +
                        "\nthread: " + t.name + "\n\n" + sw.toString().take(6000)
                )
            } catch (_: Throwable) {}
            next?.uncaughtException(t, e)
        }
    }

    /** Settings card with the last crash report (only when there is one). */
    private fun crashCard(): View? {
        val f = File(filesDir, "crash.txt")
        if (!f.isFile) return null
        val txt = try { f.readText() } catch (_: Throwable) { return null }
        val c = ui.card()
        c.addView(ui.tv(L("آخرین خطای برنامه"), 16f, C.TXT, true))
        c.addView(ui.tv(L("برنامه دفعهٔ قبل ناگهان بسته شده. این گزارش را کپی کن و بفرست تا دلیلش پیدا شود."), 12f, C.SUB), ui.lp(top = 4))
        c.addView(ui.tv(txt.take(1200), 10f, C.SUB).apply { setTextIsSelectable(true); textDirection = View.TEXT_DIRECTION_LTR }, ui.lp(top = 6))
        val r = ui.hbox()
        r.addView(ui.btn(L("کپی گزارش"), false) {
            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("crash", txt)); toast(L("کپی شد"))
        }, ui.hlp())
        r.addView(ui.btn(L("پاک کردن گزارش"), false) { f.delete(); toast(L("حذف شد")) }, ui.hlp(1f, 8))
        c.addView(r, ui.lp(top = 8))
        return c
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        installCrashLog()
        cfg = Cfg(this)
        dark = C.setup(this, cfg)
        // Dialogs follow the same light/dark choice.
        setTheme(if (dark) android.R.style.Theme_DeviceDefault_NoActionBar else android.R.style.Theme_DeviceDefault_Light_NoActionBar)
        super.onCreate(savedInstanceState)
        ui = Ui(this)
        tr = Tr.get(this)
        window.statusBarColor = C.BG
        window.navigationBarColor = C.BAR
        window.decorView.systemUiVisibility =
            if (dark) 0 else (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(C.BG)
            layoutDirection = S.dir
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(20), statusBarH() + ui.dp(10), ui.dp(20), ui.dp(10))
        }
        head.addView(ui.tv(L("ترجمان"), if (C.classic) 28f else 24f, C.TXT, true))
        head.addView(ui.tv(L("مترجم آفلاین با هوش مصنوعی"), 12f, C.SUB), ui.lp(top = 2))
        root.addView(head)
        if (C.classic) {
            // thin rule under the title, like a book page
            root.addView(View(this).apply { setBackgroundColor(C.LINE) },
                LinearLayout.LayoutParams(MATCH, ui.dp(1)).apply { marginStart = ui.dp(20); marginEnd = ui.dp(20) })
        }

        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))

        pages.add(buildTextPage())
        pages.add(buildImagePage())
        pages.add(buildPdfPage())
        pages.add(buildSrtPage())
        pages.add(buildBubblePage())
        pages.add(buildModelsPage())
        pages.add(buildSettingsPage())
        pages.add(buildHistoryPage())   // page 7: opened from the Text tab and from Settings (no tab of its own)
        pages.forEach { content.addView(it, FrameLayout.LayoutParams(MATCH, MATCH)) }

        // Bottom bar: drawn icons (no emoji), label, and a soft pill behind the selected tab.
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(C.BAR)
            setPadding(ui.dp(4), ui.dp(6), ui.dp(4), ui.dp(8))
        }
        val kinds = listOf("text", "image", "pdf", "sub", "bubble", "model", "settings")
        listOf(L("متن"), L("عکس"), "PDF", L("زیرنویس"), L("حباب"), L("مدل‌ها"), L("تنظیمات")).forEachIndexed { i, n ->
            val ic = IconView(this, kinds[i], C.SUB)
            val lb = ui.tv(n, 10.5f, C.SUB, true).apply { gravity = Gravity.CENTER; setSingleLine(true) }
            val t = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(0, ui.dp(7), 0, ui.dp(6))
                setOnClickListener { show(i) }
                addView(ic, LinearLayout.LayoutParams(ui.dp(24), ui.dp(24)))
                addView(lb, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = ui.dp(2) })
            }
            tabViews.add(t)
            tabIcons.add(ic)
            tabLabels.add(lb)
            bar.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = ui.dp(2); marginEnd = ui.dp(2) })
        }
        val line = View(this).apply { setBackgroundColor(C.LINE) }
        root.addView(line, LinearLayout.LayoutParams(MATCH, ui.dp(1)))
        root.addView(bar)
        setContentView(root)

        // After a theme / language change the activity is rebuilt: come back to the same tab and scroll position.
        show(savedInstanceState?.getInt("tab", 0) ?: 0)
        val sy = savedInstanceState?.getInt("setY", 0) ?: 0
        if (sy > 0) settingsScroll?.post { settingsScroll?.scrollTo(0, sy) }
        if (savedInstanceState == null) handleIntent(intent)
        // Warm up the offline engine in the background, so the first translation does not wait for the model to load.
        if (savedInstanceState == null && cfg.mode == "normal") {
            val ws = cfg.src
            val wd = cfg.dst
            tr.exec.execute {
                try {
                    if (ws != wd && MlKit.isDownloaded(ws) && MlKit.isDownloaded(wd)) {
                        MlKit.ensure(ws, wd)
                        MlKit.one("hi", ws, wd)
                    }
                } catch (_: Throwable) {
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        // Downloads run in a service: when the screen comes back, show their real state again.
        Dl.listener = { id, fin -> h.post { if (fin) { if (curTab == 5) refreshModels() } else updateProgress(id) } }
        if (curTab == 5) refreshModels()
    }

    override fun onStop() {
        Dl.listener = null
        super.onStop()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("tab", curTab)
        outState.putInt("setY", settingsScroll?.scrollY ?: 0)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    /** Text shared from another app (Share menu) or selected text ("Tarjoman" in the selection menu). */
    private fun handleIntent(i: Intent?) {
        val t: String? = when (i?.action) {
            Intent.ACTION_SEND -> i?.getStringExtra(Intent.EXTRA_TEXT)
            Intent.ACTION_PROCESS_TEXT -> i?.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString()
            else -> null
        }
        if (!t.isNullOrBlank()) {
            show(0)
            input.setText(t)
            doTranslate()   // also guesses the source language when that option is on
        }
    }

    private fun show(i: Int) {
        curTab = i
        pages.forEachIndexed { k, v -> v.visibility = if (k == i) View.VISIBLE else View.GONE }
        tabViews.forEachIndexed { k, t ->
            val on = k == i
            t.background = if (on) ui.rect((C.ACC and 0x00FFFFFF) or 0x26000000, C.R_BTN) else null
            tabIcons[k].setTint(if (on) C.ACC else C.SUB)
            tabLabels[k].setTextColor(if (on) C.ACC else C.SUB)
        }
        if (i == 0) { refreshLang(); modeHolder.removeAllViews(); modeHolder.addView(modeCard()) }
        if (i == 4) updateBubbleUi()
        if (i == 5) refreshModels()
        if (i == 7) refreshHistory()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (curTab == 7) show(0) else super.onBackPressed()
    }

    private fun toast(m: String) { h.post { Toast.makeText(this, m, Toast.LENGTH_LONG).show() } }

    // ------------------------------------------------------------------ TEXT PAGE
    private fun refreshLang() {
        srcBtn.text = Lang.name(cfg.src).substringBefore(" ·")
        dstBtn.text = Lang.name(cfg.dst).substringBefore(" ·")
        if (::imgSrcBtn.isInitialized) {
            imgSrcBtn.text = srcBtn.text
            imgDstBtn.text = dstBtn.text
        }
    }

    private fun pickLang(isSrc: Boolean) {
        AlertDialog.Builder(this)
            .setItems(Lang.all.map { Lang.name(it) }.toTypedArray()) { _, i ->
                val c = Lang.all[i]
                if (isSrc) {
                    if (c == cfg.dst) cfg.dst = cfg.src
                    cfg.src = c
                } else {
                    if (c == cfg.src) cfg.src = cfg.dst
                    cfg.dst = c
                }
                refreshLang()
            }.show()
    }

    private fun modeCard(): View {
        val c = ui.card()
        fun row(label: String, opts: List<String>, sel: Int, on: (Int) -> Unit) {
            c.addView(ui.tv(label, 12f, C.SUB), ui.lp(top = 6))
            c.addView(ui.seg(opts, sel, on), ui.lp(top = 3))
        }
        row(L("موتور ترجمه"), listOf(L("Normal (سبک)"), "Advanced (AI)"), if (cfg.mode == "advanced") 1 else 0) { cfg.mode = if (it == 1) "advanced" else "normal"; if (it == 0) tr.cancelAi() }
        row(L("سبک ترجمه"), listOf(L("محاوره‌ای (زیرنویس/مانگا)"), L("رسمی (کتاب/مقاله)")), if (cfg.style == "formal") 1 else 0) { cfg.style = if (it == 1) "formal" else "casual" }
        row(L("سرعت / دقت"), listOf(L("سریع"), L("کند و دقیق")), if (cfg.speed == "slow") 1 else 0) { cfg.speed = if (it == 1) "slow" else "fast" }
        row(L("اتصال"), listOf(L("آفلاین"), L("آنلاین"), L("خودکار")), when (cfg.net) { "online" -> 1; "auto" -> 2; else -> 0 }) { cfg.net = when (it) { 1 -> "online"; 2 -> "auto"; else -> "offline" } }
        row(L("ترکیب ML Kit + AI (آزمایشی، برای فارسی بهتر در Advanced)"), listOf(L("خاموش"), L("روشن")), cfg.hybrid) { cfg.hybrid = it }
        return c
    }

    private fun buildTextPage(): View {
        val sv = ScrollView(this)
        val col = ui.vbox()
        sv.addView(col)

        // Labels on top, then [from] [swap] [to] on one line, all vertically centred with each other.
        val lblRow = ui.hbox()
        lblRow.addView(ui.tv(L("از (زبان مبدأ)"), 11f, C.SUB, true).apply { setPadding(ui.dp(4), 0, ui.dp(4), 0) }, ui.hlp())
        lblRow.addView(View(this), LinearLayout.LayoutParams(ui.dp(52), 1))
        lblRow.addView(ui.tv(L("به (زبان مقصد)"), 11f, C.SUB, true).apply { setPadding(ui.dp(4), 0, ui.dp(4), 0) }, ui.hlp())
        col.addView(lblRow)

        val row = ui.hbox()
        srcBtn = ui.btn("", false) { pickLang(true) }
        dstBtn = ui.btn("", false) { pickLang(false) }
        val swap = ui.iconBtn("swap", 44, true) {
            val a = cfg.src; cfg.src = cfg.dst; cfg.dst = a; refreshLang()
        }
        row.addView(srcBtn, ui.hlp())
        row.addView(swap, LinearLayout.LayoutParams(ui.dp(44), ui.dp(44)).apply { marginStart = ui.dp(4); marginEnd = ui.dp(4) })
        row.addView(dstBtn, ui.hlp())
        col.addView(row, ui.lp(top = 4))
        refreshLang()

        modeHolder = FrameLayout(this)
        modeHolder.addView(modeCard())

        input = ui.edit(L("متن را بنویس یا بچسبان…"), 5)
        input.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun afterTextChanged(e: android.text.Editable?) {
                if (cfg.live != 1) return
                h.removeCallbacks(liveRun)
                if (e.isNullOrBlank()) { output.text = ""; status.text = ""; return }
                h.postDelayed(liveRun, if (cfg.mode == "advanced") 1600L else 700L)
            }
        })
        col.addView(input, ui.lp(top = 10))

        val r2 = ui.hbox()
        r2.addView(ui.btn(L("چسباندن"), false) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() ?: ""
            input.setText(t)
        }, ui.hlp())
        r2.addView(ui.btn(L("پاک کردن"), false) { input.setText(""); output.text = ""; status.text = "" }, ui.hlp(1f, 8))
        goBtn = ui.btn(L("ترجمه")) { if (txtRunning) stopTranslate() else doTranslate() }
        r2.addView(goBtn, ui.hlp(1.3f, 8))
        col.addView(r2, ui.lp(top = 8))

        status = ui.tv("", 12f, C.SUB)
        col.addView(status, ui.lp(top = 10))

        val oc = ui.card()
        output = ui.tv("", 17f, C.TXT).apply {
            setTextIsSelectable(true)
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            setLineSpacing(0f, 1.15f)
        }
        oc.addView(output)
        val orow = ui.hbox()
        orow.addView(ui.btn(L("کپی ترجمه"), false) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("tr", output.text))
            toast(L("کپی شد"))
        }, ui.hlp())
        orow.addView(ui.btn(L("ترجمه دوباره"), false) {
            if (txtRunning) stopTranslate()
            doTranslate(true)
        }, ui.hlp(1f, 8))
        oc.addView(orow, ui.lp(top = 10))
        oc.addView(ui.btn(L("اصلاح ترجمه (برنامه یاد می‌گیرد)"), false) { correctTranslation() }, ui.lp(top = 8))
        // One tap for the best quality: the same text through Google Translate (needs internet), whatever the mode is.
        oc.addView(ui.btn(L("ترجمه با اینترنت (کیفیت گوگل)"), false) {
            if (txtRunning) stopTranslate()
            doTranslate(true, true)
        }, ui.lp(top = 8))
        col.addView(oc, ui.lp(top = 6))
        // Mode / speed / connection are set once and rarely: they sit under the result so the text box and the result are always on top.
        col.addView(modeHolder, ui.lp(top = 12))
        col.addView(ui.btn(L("تاریخچه ترجمه"), false) { show(7) }, ui.lp(top = 10))
        return sv
    }

    /** "Translate while typing": runs shortly after the last key; waits if a translation is still running. */
    private val liveRun = object : Runnable {
        override fun run() {
            if (cfg.live != 1 || input.text.isNullOrBlank()) return
            if (txtRunning) { h.postDelayed(this, 400); return }
            doTranslate()
        }
    }

    /** The user fixes a wrong translation; the app remembers it for this English text (English -> Persian) in every mode. */
    private fun correctTranslation() {
        val src = input.text.toString().trim()
        val cur = output.text.toString().trim()
        if (src.isEmpty() || cur.isEmpty()) { toast(L("اول یک متن را ترجمه کن.")); return }
        if (cfg.src != "en" || cfg.dst != "fa") { toast(L("اصلاح فقط برای انگلیسی به فارسی است.")); return }
        val e = ui.edit("", 4)
        e.setText(cur)
        AlertDialog.Builder(this).setTitle(L("ترجمهٔ درست چیست؟")).setView(e)
            .setPositiveButton(L("ذخیره")) { _, _ ->
                val fix = e.text.toString().trim().replace("\n", " ")
                if (fix.isNotEmpty()) {
                    val line = src.replace("\n", " ").replace("|", " ") + "|" + fix
                    cfg.userPhr = (cfg.userPhr + "\n" + line).trim()
                    Idm.loadMine(cfg.userPhr)
                    output.text = fix
                    toast(L("ذخیره شد؛ دفعهٔ بعد همین ترجمه می‌آید."))
                }
            }
            .setNegativeButton(L("بستن"), null).show()
    }

    /** Stop button (the Translate button turns into Stop while a translation runs). */
    private fun stopTranslate() {
        txtJob++
        txtRunning = false
        tr.cancelAi()
        goBtn.text = L("ترجمه")
        status.text = L("متوقف شد.")
    }

    private fun doTranslate(fresh: Boolean = false, online: Boolean = false) {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        if (txtRunning) tr.cancelAi()   // a newer request replaces the one still running
        val job = ++txtJob
        txtRunning = true
        goBtn.text = L("توقف")
        status.text = L("در حال ترجمه…")
        output.text = ""
        if (cfg.autoLang == 1) {
            val g = Fa.guess(text)
            if (g != null && g != cfg.src) {
                if (g == cfg.dst) cfg.dst = cfg.src
                cfg.src = g
                refreshLang()
            }
        }
        val s = cfg.src
        val d = cfg.dst
        // Shows what is happening and how many seconds have passed (the AI can take a while on a phone).
        val t0 = System.currentTimeMillis()
        var lastProg = L("در حال ترجمه…")
        val tick = object : Runnable {
            override fun run() {
                if (txtJob == job && txtRunning) {
                    status.text = lastProg + " · " + (System.currentTimeMillis() - t0) / 1000 + "s"
                    h.postDelayed(this, 1000)
                }
            }
        }
        h.postDelayed(tick, 1000)
        tr.exec.execute {
            val r = tr.translate(if (s == "en" && tr.cfg.preFix == 1) Pre.unwrap(text) else text, s, d, "", fresh, online) { p -> h.post { if (txtJob == job) { lastProg = p; status.text = p } } }
            h.post {
                if (txtJob != job) return@post
                txtRunning = false
                goBtn.text = L("ترجمه")
                if (r.text != null) { output.text = r.text; status.text = r.info; saveHist("text", s, d, text, r.text) } else { status.text = L("خطا: ") + r.err }
            }
        }
    }

    // ------------------------------------------------------------------ IMAGE PAGE
    private fun buildImagePage(): View {
        val sv = ScrollView(this)
        val col = ui.vbox()
        sv.addView(col)
        col.addView(ui.tv(L("عکس (مانگا، اسکرین‌شات، متن روی تصویر) را انتخاب کن. متن خوانده، ترجمه و روی خود عکس نوشته می‌شود؛ می‌توانی بین «روی عکس»، «ترجمه» و «متن اصلی» جابه‌جا شوی. زبان مبدأ را از تب «متن» انتخاب کن (انگلیسی، ژاپنی یا فارسی)."), 12f, C.SUB))
        val lrow = ui.hbox()
        imgSrcBtn = ui.btn("", false) { pickLang(true) }
        imgDstBtn = ui.btn("", false) { pickLang(false) }
        val isw = ui.iconBtn("swap", 44, true) { val a = cfg.src; cfg.src = cfg.dst; cfg.dst = a; refreshLang() }
        lrow.addView(imgSrcBtn, ui.hlp())
        lrow.addView(isw, LinearLayout.LayoutParams(ui.dp(44), ui.dp(44)).apply { marginStart = ui.dp(4); marginEnd = ui.dp(4) })
        lrow.addView(imgDstBtn, ui.hlp())
        col.addView(lrow, ui.lp(top = 10))
        refreshLang()
        val pickRow = ui.hbox()
        pickRow.addView(ui.btn(L("انتخاب عکس از گالری")) {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "image/*" }
            startActivityForResult(i, 1)
        }, ui.hlp())
        pickRow.addView(ui.btn(L("گرفتن عکس با دوربین")) { takePhoto() }, ui.hlp(1f, 8))
        col.addView(pickRow, ui.lp(top = 10))
        col.addView(ui.btn(L("ترجمهٔ زندهٔ دوربین (مثل Google Lens)")) {
            startActivityForResult(Intent(this, LiveCamActivity::class.java), 21)
        }, ui.lp(top = 8))
        imgStatus = ui.tv("", 12f, C.SUB)
        col.addView(imgStatus, ui.lp(top = 8))
        imgSegHolder = FrameLayout(this)
        imgSegHolder.visibility = View.GONE
        col.addView(imgSegHolder, ui.lp(top = 8))
        imgView = ImageView(this).apply { adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER; visibility = View.GONE }
        imgView.setOnClickListener { openViewer() }
        col.addView(imgView, ui.lp(top = 8))
        col.addView(ui.tv(L("روی عکس بزن تا تمام‌صفحه باز شود (بزرگ‌نمایی با دو انگشت؛ روی هر نوشته بزنی متن اصلی و ترجمه‌اش را می‌بینی و کپی می‌کنی)."), 11f, C.SUB).also { imgHint = it; it.visibility = View.GONE }, ui.lp(top = 4))

        val oc = ui.card()
        imgText = ui.tv("", 15f, C.TXT).apply { setTextIsSelectable(true); textDirection = View.TEXT_DIRECTION_FIRST_STRONG; setLineSpacing(0f, 1.15f) }
        oc.addView(imgText)
        oc.addView(ui.btn(L("کپی"), false) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("img", imgText.text))
            toast(L("کپی شد"))
        }, ui.lp(top = 10))
        oc.visibility = View.GONE
        imgTextCard = oc
        col.addView(oc, ui.lp(top = 10))

        val act = ui.vbox()
        val act1 = ui.hbox()
        act1.addView(ui.btn(L("ذخیره عکس ترجمه‌شده"), false) {
            if (imgOut == null) toast(L("اول یک عکس ترجمه کن"))
            else startActivityForResult(
                Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "image/png"; putExtra(Intent.EXTRA_TITLE, "translated.png") }, 8
            )
        }, ui.hlp())
        act1.addView(ui.btn(L("لغو انتخاب عکس"), false) { clearImage() }, ui.hlp(1f, 8))
        act.addView(act1)
        act.addView(ui.btn(L("ترجمه دوباره"), false) {
            val u = imgUri
            if (u == null) toast(L("اول یک عکس انتخاب کن")) else runImage(u, true)
        }, ui.lp(top = 8))
        // Text size of the translation on the picture: redraws the picture, no new translation.
        act.addView(ui.slider(L("اندازهٔ متن ترجمه"), 60, 160, cfg.fontScale) { v ->
            cfg.fontScale = v
            h.removeCallbacks(redrawRun)
            h.postDelayed(redrawRun, 250)
        }, ui.lp(top = 8))
        act.visibility = View.GONE
        imgActions = act
        col.addView(act, ui.lp(top = 10))
        return sv
    }

    private lateinit var imgHint: TextView

    private val redrawRun = Runnable { redrawImage() }

    /** Draws the translations on the picture again (after the text size changed). */
    private fun redrawImage() {
        val orig = imgOrig ?: return
        if (imgBlocks.isEmpty() || imgOut == null) return
        try {
            val sc = cfg.fontScale / 100f
            val out = orig.copy(Bitmap.Config.ARGB_8888, true)
            val canvas = Canvas(out)
            for (b in imgBlocks) Ocr.draw(canvas, b, sc)
            imgOut = out
            applyImgMode()
        } catch (_: Throwable) {
            toast(L("حافظه کم است؛ اندازهٔ متن عوض نشد."))
        }
    }

    private fun pickGalleryImage() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "image/*" }
        startActivityForResult(i, 1)
    }
    private var camUri: Uri? = null
    private var customEdit: EditText? = null
    private var storagePathTv: TextView? = null

    /** Takes a picture with the phone's camera app (no camera permission needed) and translates it like a gallery picture. */
    private fun takePhoto() {
        // The app declares the camera permission (live camera), so the system camera app also needs it granted first.
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), 31)
            return
        }
        if (Build.VERSION.SDK_INT < 29 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 12)
            toast(L("اجازهٔ دسترسی به حافظه را بده و دوباره امتحان کن."))
            return
        }
        val v = android.content.ContentValues().apply {
            put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, "tarjoman_" + System.currentTimeMillis() + ".jpg")
            put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) put(android.provider.MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Tarjoman")
        }
        val u = try { contentResolver.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) } catch (_: Throwable) { null }
        if (u == null) { toast(L("ساخت فایل عکس ممکن نشد.")); return }
        camUri = u
        val i = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE)
            .putExtra(android.provider.MediaStore.EXTRA_OUTPUT, u)
            .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try { startActivityForResult(i, 20) } catch (_: Throwable) {
            camUri = null
            try { contentResolver.delete(u, null, null) } catch (_: Throwable) {}
            toast(L("برنامهٔ دوربین پیدا نشد."))
        }
    }

    /** Full-screen viewer for the translated picture: zoom, move, tap a text to read / copy it, hold the button to compare with the original. */
    private fun openViewer() {
        val out = imgOut ?: return
        val orig = imgOrig ?: return
        val dlg = android.app.Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val root = FrameLayout(this)
        root.setBackgroundColor(android.graphics.Color.BLACK)
        val zv = ZoomView(this)
        zv.setBitmap(out)
        zv.onTap = { x, y ->
            val xi = x.toInt()
            val yi = y.toInt()
            val b = imgBlocks.firstOrNull { it.rect.contains(xi, yi) }
            if (b != null) {
                val msg = L("اصل:") + "\n" + b.text + "\n\n" + L("ترجمه:") + "\n" + b.out
                AlertDialog.Builder(this).setMessage(msg)
                    .setPositiveButton(L("کپی ترجمه")) { _, _ ->
                        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("tr", b.out)); toast(L("کپی شد"))
                    }
                    .setNeutralButton(L("کپی متن اصلی")) { _, _ ->
                        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("src", b.text)); toast(L("کپی شد"))
                    }
                    .setNegativeButton(L("بستن"), null).show()
            }
        }
        root.addView(zv, FrameLayout.LayoutParams(-1, -1))
        val bar = ui.hbox()
        bar.setPadding(ui.dp(12), ui.dp(32), ui.dp(12), ui.dp(8))
        bar.addView(ui.btn(L("بستن"), false) { dlg.dismiss() }, ui.hlp())
        val cmp = ui.btn(L("نگه دار: عکس اصلی"), false) {}
        cmp.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { zv.setBitmap(orig, true); v.isPressed = true }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { zv.setBitmap(out, true); v.isPressed = false }
            }
            true
        }
        bar.addView(cmp, ui.hlp(1.4f, 8))
        bar.addView(ui.btn(L("عکس دیگر"), false) { dlg.dismiss(); pickGalleryImage() }, ui.hlp(1f, 8))
        root.addView(bar, FrameLayout.LayoutParams(-1, -2).apply { gravity = android.view.Gravity.TOP })
        dlg.setContentView(root)
        dlg.show()
    }

    private fun setImgMode(m: Int) {
        imgMode = m
        imgSegHolder.removeAllViews()
        imgSegHolder.addView(ui.seg(listOf(L("روی عکس"), L("ترجمه"), L("متن اصلی")), m) { setImgMode(it) })
        applyImgMode()
    }

    private fun applyImgMode() {
        val has = imgOrig != null
        val done = imgOut != null
        imgSegHolder.visibility = if (done) View.VISIBLE else View.GONE
        imgActions.visibility = if (has) View.VISIBLE else View.GONE
        val showPic = has && (!done || imgMode == 0)
        imgView.visibility = if (showPic) View.VISIBLE else View.GONE
        if (showPic) imgView.setImageBitmap(if (done && imgMode == 0) imgOut else imgOrig)
        imgTextCard.visibility = if (done && imgMode != 0) View.VISIBLE else View.GONE
        imgHint.visibility = if (done && imgMode == 0) View.VISIBLE else View.GONE
        imgText.text = if (imgMode == 1) imgTransText else imgOrigText
    }

    /** Back to the empty page: forgets the picture, its text and any translation in progress. */
    private fun clearImage() {
        imgJob++
        imgUri = null
        imgOrig = null
        imgOut = null
        imgBlocks = emptyList()
        imgOrigText = ""
        imgTransText = ""
        imgStatus.text = ""
        imgView.setImageDrawable(null)
        imgMode = 0
        applyImgMode()
    }

    private fun decode(uri: Uri): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var sample = 1
        while (o.outWidth / sample > 2200 || o.outHeight / sample > 2200) sample *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) } ?: return null
        // Camera photos are often stored sideways with an orientation tag; turn them upright so the text can be read.
        val rot = try {
            contentResolver.openInputStream(uri)?.use { ins ->
                when (android.media.ExifInterface(ins).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
            } ?: 0f
        } catch (_: Throwable) { 0f }
        if (rot == 0f) return bmp
        val m = android.graphics.Matrix().apply { postRotate(rot) }
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }

    private fun runImage(uri: Uri, fresh: Boolean = false) {
        val s0 = cfg.src
        val d0 = cfg.dst
        val job = ++imgJob
        imgUri = uri
        imgStatus.text = L("در حال خواندن عکس…") + " (" + Lang.name(s0).substringBefore(" ·") + " → " + Lang.name(d0).substringBefore(" ·") + ")"
        imgOut = null
        imgOrigText = ""
        imgTransText = ""
        tr.exec.execute {
            try {
                val bmp = decode(uri) ?: throw IllegalStateException(L("عکس باز نشد"))
                // Show the chosen picture right away, before the text is read.
                h.post { if (imgJob == job) { imgOrig = bmp; setImgMode(0) } }
                val ar = Ocr.readAuto(bmp, s0)
                val blocks = ar.blocks
                if (imgJob != job) return@execute
                if (blocks.isEmpty()) { h.post { if (imgJob == job) imgStatus.text = L("متنی در عکس پیدا نشد.") }; return@execute }
                // If the text was found in another language than the chosen one, translate from that language.
                val s = ar.lang
                val d = if (s == d0) (if (s == "fa") "en" else "fa") else d0
                if (s != s0) h.post { if (imgJob == job) imgStatus.text = L("زبان متن تشخیص داده شد: ") + Lang.name(s).substringBefore(" ·") }
                val out = bmp.copy(Bitmap.Config.ARGB_8888, true)
                val canvas = Canvas(out)
                val all = StringBuilder()
                val orig = StringBuilder()
                val sc = cfg.fontScale / 100f
                h.post { if (imgJob == job) imgStatus.text = L("ترجمه…") + " (" + blocks.size + L(" بلوک)") }
                val (outs, firstErr) = tr.translateMany(blocks.map { it.text }, s, d, fresh) { p ->
                    h.post { if (imgJob == job) imgStatus.text = p }
                }
                if (imgJob != job) return@execute
                blocks.forEachIndexed { i, b ->
                    val t = outs[i]
                    b.out = t
                    Ocr.draw(canvas, b, sc)
                    all.append(t).append("\n\n")
                    orig.append(b.text).append("\n\n")
                }
                h.post {
                    if (imgJob == job) {
                        imgOut = out
                        imgBlocks = blocks
                        imgTransText = all.toString().trim()
                        imgOrigText = orig.toString().trim()
                        saveHist("image", s, d, imgOrigText, imgTransText)
                        imgStatus.text = L("تمام شد (") + blocks.size + L(" بلوک)") + (if (firstErr != null) " · " + L("خطا: ") + firstErr else "")
                        setImgMode(0)
                    }
                }
            } catch (e: Throwable) {
                h.post { if (imgJob == job) imgStatus.text = L("خطا: ") + (e.cause?.message ?: e.message) }
            }
        }
    }

    // ------------------------------------------------------------------ PDF PAGE
    private fun buildPdfPage(): View {
        val sv = ScrollView(this)
        val col = ui.vbox()
        sv.addView(col)
        col.addView(ui.tv(L("یک PDF (کتاب، مقاله، اسکن) انتخاب کن؛ صفحه‌به‌صفحه خوانده و ترجمه می‌شود (PDF متنی مستقیم، اسکن و فارسی با OCR). زبان و موتور ترجمه را از تب «متن» انتخاب کن (مبدأ انگلیسی یا ژاپنی). برای کتاب‌های بلند بهتر است Normal یا حالت سریع را بگذاری."), 12f, C.SUB))
        col.addView(ui.btn(L("انتخاب فایل PDF")) {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf" }
            startActivityForResult(i, 4)
        }, ui.lp(top = 10))
        pdfInfo = ui.tv("", 13f, C.TXT)
        col.addView(pdfInfo, ui.lp(top = 8))
        pdfFrom = ui.edit(L("از صفحهٔ… (پیش‌فرض ۱)"))
        pdfFrom.inputType = InputType.TYPE_CLASS_NUMBER
        col.addView(pdfFrom, ui.lp(top = 8))
        val r = ui.hbox()
        r.addView(ui.btn(L("شروع ترجمه")) { startPdf() }, ui.hlp())
        r.addView(ui.btn(L("توقف"), false) { pdfCancel = true; tr.cancelAi() }, ui.hlp(1f, 8))
        col.addView(r, ui.lp(top = 8))
        col.addView(ui.btn(L("ترجمه دوباره (از همین صفحه)"), false) { startPdf(true) }, ui.lp(top = 8))
        pdfStatus = ui.tv("", 12f, C.SUB)
        col.addView(pdfStatus, ui.lp(top = 8))
        col.addView(ui.seg(listOf(L("ترجمه"), L("متن اصلی"), L("هر دو")), pdfMode) { pdfMode = it; showPdf() }, ui.lp(top = 8))
        val oc = ui.card()
        pdfOut = ui.tv("", 15f, C.TXT).apply {
            setTextIsSelectable(true)
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            setLineSpacing(0f, 1.15f)
        }
        oc.addView(pdfOut)
        val br = ui.hbox()
        br.addView(ui.btn(L("کپی همه"), false) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("pdf", pdfCur().toString()))
            toast(L("کپی شد"))
        }, ui.hlp())
        br.addView(ui.btn(L("ذخیره txt"), false) {
            val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "text/plain"; putExtra(Intent.EXTRA_TITLE, "translation.txt") }
            startActivityForResult(i, 5)
        }, ui.hlp(1f, 8))
        oc.addView(br, ui.lp(top = 10))
        oc.addView(ui.btn(L("ذخیره به‌صورت PDF"), false) {
            if (pdfCur().isEmpty()) toast(L("هنوز چیزی ترجمه نشده"))
            else startActivityForResult(
                Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf"; putExtra(Intent.EXTRA_TITLE, "translation.pdf") }, 9
            )
        }, ui.lp(top = 8))
        col.addView(oc, ui.lp(top = 8))
        return sv
    }

    private fun pdfCur(): StringBuilder = when (pdfMode) { 1 -> pdfOrigSb; 2 -> pdfBiSb; else -> pdfSb }

    private fun showPdf() {
        val all = pdfCur().toString()
        pdfOut.text = if (all.length > 15000) "…\n" + all.substring(all.length - 15000) else all
    }

    private fun clearPdfText() { pdfSb.setLength(0); pdfOrigSb.setLength(0); pdfBiSb.setLength(0) }

    private fun onPdfPicked(uri: Uri) {
        var name = "PDF"
        contentResolver.query(uri, null, null, null, null)?.use {
            if (it.moveToFirst()) {
                val ix = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (ix >= 0) name = it.getString(ix)
            }
        }
        try {
            pdfPages = PdfTool.pageCount(this, uri)
            pdfUri = uri
            pdfInfo.text = name + " · " + pdfPages + L(" صفحه")
            clearPdfText()
            pdfOut.text = ""
            pdfStatus.text = ""
        } catch (e: Throwable) {
            pdfUri = null
            pdfInfo.text = L("این PDF باز نشد (شاید رمزدار یا خراب است): ") + (e.message ?: "")
        }
    }

    private fun startPdf(fresh: Boolean = false) {
        val uri = pdfUri
        if (uri == null) { toast(L("اول یک PDF انتخاب کن")); return }
        if (pdfRunning) { toast(L("ترجمه در حال انجام است")); return }
        val s = cfg.src
        val d = cfg.dst
        val from = (pdfFrom.text.toString().trim().toIntOrNull() ?: 1).coerceIn(1, maxOf(pdfPages, 1)) - 1
        if (from == 0 || fresh) { clearPdfText(); pdfOut.text = "" }
        pdfRunning = true
        pdfCancel = false
        Thread {
            try {
                PdfTool.translate(this, uri, from, s, d, tr, fresh, { pdfCancel }, { m -> h.post { pdfStatus.text = m } }) { i, t, o, bi ->
                    h.post {
                        val head = L("— صفحه ") + (i + 1) + " —\n"
                        pdfSb.append(head).append(t).append("\n\n")
                        pdfOrigSb.append(head).append(o).append("\n\n")
                        pdfBiSb.append(head).append(bi).append("\n\n")
                        showPdf()
                    }
                }
                h.post { pdfStatus.text = if (pdfCancel) L("متوقف شد. (برای ادامه، شمارهٔ صفحهٔ بعدی را بنویس)") else L("تمام شد.") }
            } catch (e: Throwable) {
                h.post { pdfStatus.text = L("خطا: ") + (e.cause?.message ?: e.message) }
            }
            pdfRunning = false
        }.start()
    }

    // ------------------------------------------------------------------ SUBTITLE PAGE
    private fun buildSrtPage(): View {
        val sv = ScrollView(this)
        val col = ui.vbox()
        sv.addView(col)
        col.addView(ui.tv(L("فایل زیرنویس (.srt یا .vtt یوتیوب) را انتخاب کن؛ جمله‌به‌جمله و با در نظر گرفتن دو خط قبلی ترجمه می‌شود (برای موتور AI)، زمان‌بندی دست‌نخورده می‌ماند و فایل جدید را ذخیره می‌کنی. زبان و موتور را از تب «متن» انتخاب کن. اسامی خاص را در تنظیمات ← واژه‌نامه بنویس."), 12f, C.SUB))
        col.addView(ui.btn(L("انتخاب فایل زیرنویس")) {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
            startActivityForResult(i, 6)
        }, ui.lp(top = 10))
        val ytIn = ui.edit(L("یا لینک ویدیوی یوتیوب را بچسبان…"))
        col.addView(ytIn, ui.lp(top = 8))
        col.addView(ui.btn(L("دریافت زیرنویس از لینک"), false) { fetchYt(ytIn.text.toString()) }, ui.lp(top = 8))
        srtInfo = ui.tv("", 13f, C.TXT)
        col.addView(srtInfo, ui.lp(top = 8))
        val r = ui.hbox()
        r.addView(ui.btn(L("شروع ترجمه")) { startSrt() }, ui.hlp())
        r.addView(ui.btn(L("توقف"), false) { srtCancel = true; tr.cancelAi() }, ui.hlp(1f, 8))
        col.addView(r, ui.lp(top = 8))
        col.addView(ui.btn(L("ترجمه دوباره"), false) { startSrt(true) }, ui.lp(top = 8))
        srtStatus = ui.tv("", 12f, C.SUB)
        col.addView(srtStatus, ui.lp(top = 8))
        val oc = ui.card()
        srtOut = ui.tv("", 14f, C.TXT).apply { setTextIsSelectable(true); textDirection = View.TEXT_DIRECTION_FIRST_STRONG }
        oc.addView(srtOut)
        oc.addView(ui.btn(L("ذخیره فایل .srt"), false) {
            val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/x-subrip"; putExtra(Intent.EXTRA_TITLE, "translated.srt") }
            startActivityForResult(i, 7)
        }, ui.lp(top = 10))
        col.addView(oc, ui.lp(top = 8))
        return sv
    }

    private fun fetchYt(link: String) {
        val id = Yt.id(link.trim())
        if (id == null) { toast(L("لینک یوتیوب معتبر نیست")); return }
        srtInfo.text = L("در حال دریافت زیرنویس…")
        val src = cfg.src
        Thread {
            try {
                val cues = SrtTool.parse(Yt.fetch(id, src, cfg))
                h.post {
                    srtCues = cues
                    srtTexts.clear()
                    srtOut.text = ""
                    srtInfo.text = if (cues.isEmpty()) L("زیرنویس معتبری پیدا نشد (فایل .srt یا .vtt لازم است).") else cues.size.toString() + L(" خط زیرنویس")
                }
            } catch (e: Throwable) {
                h.post { srtInfo.text = L("خطا: ") + (e.message ?: "") }
            }
        }.start()
    }

    private fun onSrtPicked(uri: Uri) {
        try {
            val raw = SrtTool.decode(contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: ByteArray(0), cfg.src)
            srtCues = SrtTool.parse(raw)
            srtTexts.clear()
            srtOut.text = ""
            srtInfo.text = if (srtCues.isEmpty()) L("زیرنویس معتبری پیدا نشد (فایل .srt یا .vtt لازم است).") else srtCues.size.toString() + L(" خط زیرنویس")
        } catch (e: Throwable) {
            srtInfo.text = L("خطا: ") + e.message
        }
    }

    private fun startSrt(fresh: Boolean = false) {
        val cues = srtCues
        if (cues.isEmpty()) { toast(L("اول یک فایل .srt انتخاب کن")); return }
        if (srtRunning) { toast(L("ترجمه در حال انجام است")); return }
        val s = cfg.src
        val d = cfg.dst
        srtRunning = true
        srtCancel = false
        srtTexts.clear()
        Thread {
            try {
                var i = 0
                while (i < cues.size && cfg.mode == "normal" && !srtCancel) {
                    val end = minOf(i + 20, cues.size)
                    val plains = (i until end).map { SrtTool.plain(cues[it].text) }
                    val r = if (plains.all { it.isEmpty() }) null else tr.translate(plains.joinToString("\n"), s, d, "", fresh) { }
                    val lines = r?.text?.split("\n")
                    if (r != null && r.text == null) throw IllegalStateException(r.err ?: L("خطا"))
                    if (r != null && (lines == null || lines.size != plains.size)) break   // line count changed: fall back to line-by-line
                    val batch = plains.indices.map { k -> if (plains[k].isEmpty()) null else lines!![k].trim() }
                    val upto = end
                    h.post {
                        srtTexts.addAll(batch)
                        srtStatus.text = upto.toString() + " / " + cues.size
                        val lastIx = batch.indexOfLast { it != null }
                        if (lastIx >= 0) srtOut.text = plains[lastIx] + "\n→ " + batch[lastIx]
                    }
                    i = end
                }
                while (i < cues.size) {
                    val c = cues[i]
                    if (srtCancel) break
                    val plain = SrtTool.plain(c.text)
                    var out: String? = null
                    if (plain.isNotEmpty()) {
                        val ctx = (maxOf(0, i - 2) until i).map { SrtTool.plain(cues[it].text) }.filter { it.isNotEmpty() }.joinToString("\n")
                        val r = tr.translate(plain, s, d, ctx, fresh) { }
                        out = r.text ?: throw IllegalStateException(r.err ?: L("خطا"))
                    }
                    val k = i + 1
                    i++
                    val shown = out
                    h.post {
                        srtTexts.add(shown)
                        srtStatus.text = k.toString() + " / " + cues.size
                        if (shown != null) srtOut.text = plain + "\n→ " + shown
                    }
                }
                h.post { srtStatus.text = if (srtCancel) L("متوقف شد؛ خطوط ترجمه‌نشده در فایل به‌صورت اصلی می‌مانند.") else L("تمام شد. حالا ذخیره کن.") }
            } catch (e: Throwable) {
                h.post { srtStatus.text = L("خطا: ") + (e.cause?.message ?: e.message) }
            }
            srtRunning = false
        }.start()
    }

    // ------------------------------------------------------------------ BUBBLE PAGE
    private fun buildBubblePage(): View {
        val sv = ScrollView(this)
        val col = ui.vbox()
        sv.addView(col)
        col.addView(ui.tv(L("حباب شناور · ترجمهٔ تمام‌صفحه"), 16f, C.TXT, true))
        col.addView(ui.tv(L("حباب را روشن کن و برو سراغ هر برنامه‌ای (مرورگر، مانگا، ویدیو…). با یک لمس روی حباب (و دوبار لمس برای برگشت به صفحهٔ اصلی)، یک لایهٔ شفاف روی کل صفحه می‌آید و ترجمه دقیقاً روی نوشتهٔ اصلی چاپ می‌شود. لمس طولانی روی حباب = تنظیمات (زبان، موتور، سرعت، آفلاین/آنلاین، شفافیت، اندازهٔ متن)."), 12f, C.SUB), ui.lp(top = 4))
        bubbleStatus = ui.tv("", 13f, C.TXT, true)
        col.addView(bubbleStatus, ui.lp(top = 10))
        bubbleToggle = ui.btn("") {
            if (BubbleService.running) {
                stopService(Intent(this, BubbleService::class.java))
                BubbleService.running = false
                updateBubbleUi()
            } else startBubble()
        }
        col.addView(bubbleToggle, ui.lp(top = 8))
        updateBubbleUi()
        val c = ui.card()
        c.addView(ui.tv(L("ترجمه زنده (ورق زدن)"), 12f, C.SUB))
        c.addView(ui.seg(listOf(L("خاموش"), L("روشن")), cfg.liveScr) { cfg.liveScr = it }, ui.lp(top = 3))
        c.addView(ui.tv(L("روشن باشد، با یک لمس حباب ترجمه روی صفحه می‌ماند و هر بار صفحه عوض شد (ورق زدن مانگا، اسکرول) و ثابت ماند، خودش دوباره ترجمه می‌کند؛ با دوبار لمس حباب متوقف می‌شود. هر چند ثانیه صفحه را بررسی می‌کند، پس مصرف باتری و پردازنده بیشتر است. با حالت Normal و سریع بهتر جواب می‌دهد."), 11f, C.SUB), ui.lp(top = 4))
        c.addView(ui.tv(L("حالت حباب"), 12f, C.SUB), ui.lp(top = 10))
        val bm = listOf("free", "lock", "sleep")
        c.addView(ui.seg(listOf(L("آزاد"), L("قفل"), L("خواب")), bm.indexOf(cfg.bubMode).coerceAtLeast(0)) { cfg.bubMode = bm[it] }, ui.lp(top = 3))
        c.addView(ui.tv(L("آزاد: هرجا رها کنی می‌ماند. قفل: خودکار به لبهٔ چپ یا راست می‌چسبد. خواب: کمی بیرون از لبه و کمرنگ. هر حالتی که باشد، حباب را به بیرون لبه بکشی فوراً به خواب می‌رود و هیچ‌وقت کامل از صفحه خارج نمی‌شود."), 11f, C.SUB), ui.lp(top = 4))
        c.addView(ui.slider(L("شفافیت لایه"), 20, 100, cfg.opacity) { v -> cfg.opacity = v }, ui.lp(top = 10))
        c.addView(ui.slider(L("اندازهٔ متن ترجمه"), 60, 160, cfg.fontScale) { v -> cfg.fontScale = v }, ui.lp(top = 8))
        col.addView(c, ui.lp(top = 12))
        col.addView(ui.tv(L("نکتهٔ شیائومی/MIUI: اگر حباب ظاهر نشد، در تنظیمات برنامه ← «سایر مجوزها» گزینه‌های «نمایش روی سایر برنامه‌ها» و «نمایش پنجره‌های بازشو هنگام اجرا در پس‌زمینه» را روشن کن، و بهینه‌سازی باتری ترجمان را روی «بدون محدودیت» بگذار."), 12f, C.SUB), ui.lp(top = 12))
        return sv
    }

    private fun startBubble() {
        if (!Settings.canDrawOverlays(this)) {
            toast(L("مجوز «نمایش روی سایر برنامه‌ها» را برای ترجمان روشن کن، بعد برگرد و دوباره بزن"))
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName)))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
            return
        }
        askProjection()
    }

    private fun askProjection() {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), 3)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10) askProjection()
        if (requestCode == 31) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) takePhoto() else toast(L("اجازهٔ دوربین داده نشد."))
        }
    }

    // ------------------------------------------------------------------ MODELS PAGE
    private fun buildModelsPage(): View {
        val sv = ScrollView(this)
        modelsBox = ui.vbox()
        sv.addView(modelsBox)
        return sv
    }

    private val bars = HashMap<String, android.widget.ProgressBar>()
    private val pct = HashMap<String, Int>()          // download progress in 1/1000
    private val packBusy = HashSet<String>()
    private val packOk = HashMap<String, Boolean>()

    private fun refreshModels() {
        renderModels()
        checkPacks()
    }

    private fun checkPacks() {
        Thread {
            for (c in listOf("fa", "ja")) {
                val ok: Boolean? = try { MlKit.isDownloaded(c) } catch (_: Throwable) { null }
                if (ok != null) h.post { packOk[c] = ok }
            }
            h.post { if (curTab == 5) renderModels() }
        }.start()
    }

    private fun mkBar(id: String, indeterminate: Boolean): android.widget.ProgressBar {
        val b = android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        b.max = 1000
        b.isIndeterminate = indeterminate
        b.progressTintList = android.content.res.ColorStateList.valueOf(C.ACC)
        b.progressBackgroundTintList = android.content.res.ColorStateList.valueOf(C.CARD2)
        b.indeterminateTintList = android.content.res.ColorStateList.valueOf(C.ACC)
        if (!indeterminate) b.progress = pct[id] ?: 0
        bars[id] = b
        return b
    }

    private fun impChip(required: Boolean): TextView =
        if (required) ui.chip(L("ضروری"), C.BAD) else ui.chip(L("اختیاری"), C.SUB)

    private fun dots(n: Int): String = "\u25CF".repeat(n) + "\u25CB".repeat(5 - n)

    private fun titleRow(title: String, vararg chips: TextView): LinearLayout {
        val hr = ui.hbox()
        hr.addView(ui.tv(title, 15f, C.TXT, true), ui.hlp())
        for (ch in chips) hr.addView(ch, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = ui.dp(6) })
        return hr
    }

    /** Card of one Persian OCR model (the fast one and the optional more accurate one share this code). */
    private fun ocrCard(id: String, name: String, title: String, note: String, f: File?, ok: Boolean, url: String): View {
        val ocr = ui.card()
        ocr.addView(titleRow(title, impChip(false)))
        ocr.addView(ui.tv(note, 12f, C.SUB), ui.lp(top = 4))
        val dl = Dl.jobs[id]
        val st = ui.tv(if (dl != null) L("در حال دانلود…") else if (ok) L("نصب شده") else if (Dl.partBytes(f ?: File("x")) > 0) L("دانلود ناقص ماند؛ با «ادامه دانلود» از همان‌جا ادامه پیدا می‌کند") else L("نصب نشده"), 12f, if (ok) C.OK else C.SUB)
        progress[id] = st
        ocr.addView(st, ui.lp(top = 6))
        if (dl != null) ocr.addView(mkBar(id, dl.total <= 0), ui.lp(MATCH, ui.dp(6), 8))
        if (f != null) {
            val part = Dl.partBytes(f)
            if (dl != null) {
                val rr = ui.hbox()
                rr.addView(ui.btn(L("توقف")) { Dl.cancel(id) }, ui.hlp())
                rr.addView(ui.btn(L("لغو"), false) { Dl.abort(id) }, ui.hlp(1f, 8))
                ocr.addView(rr, ui.lp(top = 8))
            } else if (ok) {
                ocr.addView(ui.btn(L("حذف"), false) { confirmDelete(name) { f.delete(); refreshModels() } }, ui.lp(top = 8))
            } else {
                ocr.addView(ui.btn(if (part > 0) L("ادامه دانلود") else L("دانلود")) {
                    f.parentFile?.mkdirs()
                    startDl(id, name, url, f)
                }, ui.lp(top = 8))
                if (part > 0) ocr.addView(ui.btn(L("حذف بخش نیمه‌دانلودشده"), false) { confirmDelete(name) { Dl.deletePart(f); refreshModels() } }, ui.lp(top = 6))
            }
        }
        return ocr
    }

    private fun packCard(code: String, title: String, note: String, required: Boolean): View {
        val c = ui.card()
        c.addView(titleRow(title, impChip(required)))
        c.addView(ui.tv(note, 12f, C.SUB), ui.lp(top = 4))
        val busy = packBusy.contains(code)
        val ok = packOk[code]
        val st = ui.tv(
            if (busy) L("در حال دانلود بسته… (برای بسته‌های گوگل درصد نمایش داده نمی‌شود)") else if (ok == true) L("نصب شده") else if (ok == false) L("نصب نشده") else "…",
            12f, if (ok == true && !busy) C.OK else C.SUB
        )
        c.addView(st, ui.lp(top = 6))
        if (busy) c.addView(mkBar("pack-$code", true), ui.lp(MATCH, ui.dp(6), 8))
        else if (ok != true) c.addView(ui.btn(L("دانلود")) { packDl(code) }, ui.lp(top = 8))
        else c.addView(ui.btn(L("حذف"), false) { confirmDelete(title) { packDelete(code) } }, ui.lp(top = 8))
        if (busy) c.addView(ui.btn(L("توقف")) { packStop = true; toast(L("بعد از اتمام مرحلهٔ فعلی متوقف می‌شود")) }, ui.lp(top = 8))
        return c
    }

    private fun sectionHead(title: String, sub: String) {
        modelsBox.addView(ui.tv(title, 16f, C.TXT, true), ui.lp(top = 20))
        if (sub.isNotEmpty()) modelsBox.addView(ui.tv(sub, 12f, C.SUB), ui.lp(top = 2))
    }

    private fun renderModels() {
        modelsBox.removeAllViews()
        progress.clear()
        bars.clear()

        val intro = ui.card()
        intro.addView(ui.tv(L("از کجا شروع کنم؟"), 16f, C.TXT, true))
        intro.addView(ui.tv(L("فقط مورد «ضروری» برای کار کردن ترجمهٔ معمولی (Normal) لازم است. بقیه اختیاری‌اند؛ هر کدام را فقط اگر آن قابلیت را می‌خواهی دانلود کن."), 12f, C.SUB), ui.lp(top = 4))
        intro.addView(ui.tv(L("محل ذخیرهٔ مدل‌ها (از تنظیمات می‌شود عوضش کرد):"), 11f, C.SUB), ui.lp(top = 8))
        intro.addView(ui.tv(Models.dir(this).absolutePath, 11f, C.TXT).apply { setTextIsSelectable(true); textDirection = View.TEXT_DIRECTION_LTR }, ui.lp(top = 2))
        intro.addView(ui.btn(L("لینک مستقیم دانلود همهٔ مدل‌ها"), false) { showAllLinks() }, ui.lp(top = 10))
        modelsBox.addView(intro)

        sectionHead(L("ضروری برای شروع"), "")
        modelsBox.addView(packCard("fa", L("انگلیسی ↔ فارسی"), L("بستهٔ زبانی گوگل (حدود ۳۰ مگابایت). یک‌بار با اینترنت دانلود کن، بعد آفلاین کار می‌کند. بدون آن ترجمهٔ آفلاین Normal کار نمی‌کند."), true), ui.lp(top = 8))

        sectionHead(L("اختیاری"), L("هر کدام فقط در صورت نیاز."))
        modelsBox.addView(packCard("ja", L("ژاپنی"), L("فقط اگر از یا به ژاپنی ترجمه می‌کنی (حدود ۳۰ مگابایت)."), false), ui.lp(top = 8))

        modelsBox.addView(ocrCard("ocr-en", L("OCR انگلیسی"), L("OCR انگلیسی · Tesseract (آفلاین)"),
            L("اختیاری و حدود ۴ مگابایت. خواندن عکس انگلیسی به‌طور پیش‌فرض با ML Kit انجام می‌شود؛ با نصب این مدل، هر دو می‌خوانند و بهترین نتیجه انتخاب می‌شود (حروف و علامت‌های اشتباه کمتر). پیشنهاد می‌شود."),
            Ocr.enFile(), Ocr.enReady(), "https://github.com/tesseract-ocr/tessdata_fast/raw/main/eng.traineddata"), ui.lp(top = 10))
        modelsBox.addView(ocrCard("ocr-en-best", L("OCR انگلیسی دقیق‌تر"), L("OCR انگلیسی دقیق‌تر · tessdata_best"),
            L("اختیاری، بزرگ‌تر (چند مگابایت) و دقیق‌تر از نسخهٔ معمولی. اگر نصب باشد به‌جای نسخهٔ سریع استفاده می‌شود؛ کمی کندتر است."),
            Ocr.enBestFile(), Ocr.enBestReady(), "https://github.com/tesseract-ocr/tessdata_best/raw/main/eng.traineddata"), ui.lp(top = 10))
        modelsBox.addView(ocrCard("ocr-fa", L("OCR فارسی"), L("OCR فارسی · Tesseract (آفلاین)"),
            L("فقط برای خواندن متن فارسی از عکس، صفحه (حباب) و PDF لازم است؛ حدود ۱ تا ۲ مگابایت از GitHub. اگر متن مبدأت انگلیسی یا ژاپنی است، لازم نیست. دقت روی متن تمیز خوب و روی متن کوچک یا خط‌دار متوسط است."),
            Ocr.faFile(), Ocr.faReady(), "https://github.com/tesseract-ocr/tessdata_fast/raw/main/fas.traineddata"), ui.lp(top = 10))
        modelsBox.addView(ocrCard("ocr-fa-best", L("OCR فارسی دقیق‌تر"), L("OCR فارسی دقیق‌تر · tessdata_best"),
            L("نسخهٔ دقیق‌تر و بزرگ‌تر همان OCR فارسی (چند مگابایت، حجم دقیقش را GitHub تعیین می‌کند). اگر نصبش کنی، به‌جای نسخهٔ سریع استفاده می‌شود: خواندن فارسی از عکس دقیق‌تر ولی کمی کندتر است. با اینترنت ضعیف بهتر است اول نسخهٔ معمولی را داشته باشی."),
            Ocr.faBestFile(), Ocr.faBestReady(), "https://github.com/tesseract-ocr/tessdata_best/raw/main/fas.traineddata"), ui.lp(top = 10))

        sectionHead(L("Advanced · مدل‌های AI روی گوشی"), L("اختیاری. مرتب‌شده از بهترین کیفیت به ضعیف‌ترین. هرچه مدل بزرگ‌تر، ترجمه بهتر ولی کندتر. برای مدل‌های Gemma باید در تنظیمات توکن Hugging Face بگذاری. اگر Hugging Face فیلتر است، در تنظیمات آینه یا پروکسی بگذار."))

        // models this build cannot run (.litertlm without LiteRT-LM) go to the end, with a warning on the card
        val list = Models.ranked.sortedBy { if (it.file.endsWith(".litertlm") && !LmBridge.available) 1 else 0 }
        list.forEachIndexed { i, m ->
            modelsBox.addView(
                modelCard(m.id, m.title + "  ·  " + m.tier, "≈ " + m.mb + " MB", m.note, Models.file(this, m), m.url, i + 1, m),
                ui.lp(top = 10)
            )
        }

        val manual = Models.manualFiles(this)
        if (manual.isNotEmpty()) {
            modelsBox.addView(ui.tv(L("مدل‌های دستی"), 14f, C.TXT, true), ui.lp(top = 18))
            for (f in manual) modelsBox.addView(modelCard("m:" + f.name, f.name, "", "", f, null, 0, null), ui.lp(top = 8))
        }

        val add = ui.card()
        add.addView(titleRow(L("افزودن مدل دستی"), impChip(false)))
        add.addView(ui.tv(L("فایل .task / .bin سازگار با MediaPipe (مثلاً از litert-community در Hugging Face)."), 12f, C.SUB), ui.lp(top = 4))
        val ar = ui.hbox()
        ar.addView(ui.btn(L("از فایل گوشی")) {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
            startActivityForResult(i, 2)
        }, ui.hlp())
        ar.addView(ui.btn(L("از لینک"), false) { addByUrl() }, ui.hlp(1f, 8))
        add.addView(ar, ui.lp(top = 8))
        modelsBox.addView(add, ui.lp(top = 18))
    }

    @Volatile private var packStop = false

    private fun packDelete(code: String) {
        tr.exec.execute {
            try { MlKit.delete(code); toast(L("حذف شد")) } catch (e: Throwable) { toast(L("خطا: ") + (e.cause?.message ?: e.message)) }
            h.post { packOk[code] = false; refreshModels() }
        }
    }

    /** Google's language pack: no percentage is available, but it keeps retrying and the service keeps it alive in the background. */
    private fun packDl(code: String) {
        if (!packBusy.add(code)) return
        packStop = false
        val app = applicationContext
        Dl.keepBegin(app)
        renderModels()
        tr.exec.execute {
            var okDone = false
            var tries = 0
            while (!okDone && !packStop && tries < 6) {
                tries++
                try {
                    MlKit.ensure("en", code)
                    okDone = true
                } catch (e: Throwable) {
                    if (tries >= 6 || packStop) { Dl.toast(app, L("خطا: ") + (e.cause?.message ?: e.message)); break }
                    var w = 0
                    while (w < 5 && !packStop) { try { Thread.sleep(1000) } catch (_: InterruptedException) {}; w++ }
                    while (!packStop && !Net.isOnline(app)) { try { Thread.sleep(2000) } catch (_: InterruptedException) {} }
                }
            }
            if (okDone) Dl.toast(app, L("بسته زبان آماده شد"))
            Dl.keepEnd(app)
            h.post { packBusy.remove(code); packOk[code] = okDone; refreshModels() }
        }
    }

    private fun modelCard(id: String, title: String, size: String, note: String, f: File, url: String?, rank: Int, m: Mdl?): View {
        val c = ui.card()
        val chips = ArrayList<TextView>()
        val needsLm = m != null && m.file.endsWith(".litertlm") && !LmBridge.available
        if (rank == 1 && !needsLm) chips.add(ui.chip(L("بهترین کیفیت"), C.ACC))
        else if (m != null && m.id == "gemma3-1b") chips.add(ui.chip(L("پیشنهاد ما"), C.ACC))
        chips.add(impChip(false))
        c.addView(titleRow(title, *chips.toTypedArray()))
        if (size.isNotEmpty()) c.addView(ui.tv(size, 12f, C.SUB))
        if (m != null) {
            c.addView(ui.tv(
                "#" + rank + "   " + L("کیفیت") + " " + dots(Models.quality(m.id)) + "    " + L("سرعت") + " " + dots(Models.speed(m.id)),
                12f, C.ACC, true
            ), ui.lp(top = 4))
        }
        if (note.isNotEmpty()) c.addView(ui.tv(note, 12f, C.SUB), ui.lp(top = 4))
        val installed = Models.isModelFile(f)
        val gatedHere = m != null && m.gated && !installed
        if (needsLm) c.addView(ui.tv(L("این نسخه از برنامه با LiteRT-LM ساخته نشده؛ این مدل را می‌توانی دانلود کنی ولی تا نسخهٔ LiteRT-LM نسازی اجرا نمی‌شود."), 12f, C.ACC), ui.lp(top = 4))
        if (gatedHere) c.addView(ui.tv(L("این مدل قفل است. برای دانلود: ۱) در huggingface.co ثبت‌نام کن ۲) در «صفحهٔ مدل» دکمهٔ Acknowledge license را بزن ۳) در huggingface.co/settings/tokens روی Create new token بزن، نوع Read را انتخاب کن و توکن را در «توکن» بگذار. مدل‌های Qwen و SmolLM بدون توکن دانلود می‌شوند."), 12f, C.ACC), ui.lp(top = 4))
        val dl = Dl.jobs[id]
        val part = File(f.path + ".part")
        val partBytes = if (part.exists()) part.length() else 0L
        val partPct = if (partBytes > 0) (if (m != null && m.mb > 0) (partBytes * 100 / (m.mb * 1048576L)).toInt().coerceIn(1, 99) else 1) else 0
        val st = ui.tv(
            if (dl != null) L("در حال دانلود…")
            else if (installed) L("نصب شده (") + (f.length() / 1048576) + " MB)"
            else if (partPct > 0) L("دانلود ناقص ماند: ") + (partBytes / 1048576) + " MB" + (if (m != null) " (" + L("حدود ") + partPct + "%)" else "") + L(" ذخیره شده؛ «ادامه دانلود» از همین‌جا ادامه می‌دهد")
            else L("نصب نشده"),
            12f, if (installed) C.OK else C.SUB
        )
        progress[id] = st
        c.addView(st, ui.lp(top = 6))
        if (dl != null) c.addView(mkBar(id, dl.total <= 0), ui.lp(MATCH, ui.dp(6), 8))
        val r = ui.hbox()
        if (dl != null) {
            r.addView(ui.btn(L("توقف")) { Dl.cancel(id) }, ui.hlp())
            r.addView(ui.btn(L("لغو"), false) { Dl.abort(id) }, ui.hlp(1f, 8))
        } else if (installed) {
            val active = tr.activeFile()?.name == f.name
            r.addView(ui.btn(if (active) L("فعال") else L("فعال‌سازی"), !active) { cfg.activeModel = f.name; refreshModels() }, ui.hlp())
            r.addView(ui.btn(L("حذف"), false) { confirmDelete(title) { f.delete(); Dl.deletePart(f); if (cfg.activeModel == f.name) cfg.activeModel = ""; refreshModels() } }, ui.hlp(1f, 8))
        } else if (url != null) {
            r.addView(ui.btn(if (partPct > 0) L("ادامه دانلود") else L("دانلود")) {
                if (gatedHere && cfg.hfToken.isBlank() && !Hf.signedIn(cfg)) askAccess(id, title, url, f) else startDl(id, title, url, f)
            }, ui.hlp())
            if (partBytes > 0) r.addView(ui.btn(L("حذف بخش نیمه‌دانلودشده"), false) { confirmDelete(title) { Dl.deletePart(f); refreshModels() } }, ui.hlp(1f, 8))
        }
        c.addView(r, ui.lp(top = 8))
        if (url != null) {
            val rl = ui.hbox()
            rl.addView(ui.btn(L("کپی لینک مستقیم"), false) { copyText(url) }, ui.hlp())
            rl.addView(ui.btn(L("باز کردن در مرورگر"), false) { openUrl(url) }, ui.hlp(1f, 8))
            c.addView(rl, ui.lp(top = 6))
        }
        if (gatedHere && dl == null && url != null) {
            val rs = ui.hbox()
            rs.addView(ui.btn(if (Hf.signedIn(cfg)) L("وارد شده‌ای ✓ (دوباره ورود)") else L("ورود با حساب Hugging Face"), !Hf.signedIn(cfg)) { openHfLogin(url.substringBefore("/resolve/")) }, ui.hlp())
            c.addView(rs, ui.lp(top = 6))
            val r2 = ui.hbox()
            r2.addView(ui.btn(L("صفحهٔ مدل (قبول لایسنس)"), false) { openUrl(url.substringBefore("/resolve/")) }, ui.hlp())
            r2.addView(ui.btn(L("توکن"), false) { askToken { startDl(id, title, url, f) } }, ui.hlp(1f, 8))
            c.addView(r2, ui.lp(top = 6))
        }
        return c
    }

    private fun copyText(t: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("link", t))
        toast(L("کپی شد"))
    }

    /** Direct download links of every model the app suggests, plus where to put the files by hand. */
    private fun allLinks(): String {
        val sb = StringBuilder()
        sb.append(L("پوشهٔ مدل‌ها در گوشی:")).append("\n").append(Models.dir(this).absolutePath).append("\n")
        sb.append(L("(مدل را دستی دانلود کردی؟ فایل را در همین پوشه بگذار تا برنامه ببیندش.)")).append("\n\n")
        sb.append("== ").append(L("مدل‌های AI (Hugging Face)")).append(" ==\n\n")
        for (m in Models.ranked) {
            sb.append(m.title).append("  ·  ≈ ").append(m.mb).append(" MB")
            if (m.gated) sb.append("  [").append(L("نیاز به حساب و قبول لایسنس")).append("]")
            sb.append("\n").append(m.url).append("\n\n")
        }
        sb.append("== OCR (Tesseract) ==\n\n")
        sb.append("eng (fast)\nhttps://github.com/tesseract-ocr/tessdata_fast/raw/main/eng.traineddata\n\n")
        sb.append("eng (best)\nhttps://github.com/tesseract-ocr/tessdata_best/raw/main/eng.traineddata\n\n")
        sb.append("fas (fast)\nhttps://github.com/tesseract-ocr/tessdata_fast/raw/main/fas.traineddata\n\n")
        sb.append("fas (best)\nhttps://github.com/tesseract-ocr/tessdata_best/raw/main/fas.traineddata\n")
        return sb.toString()
    }

    private fun showAllLinks() {
        val txt = allLinks()
        val tv = ui.tv(txt, 12f, C.TXT).apply { setTextIsSelectable(true); textDirection = View.TEXT_DIRECTION_LTR; setPadding(ui.dp(16), ui.dp(8), ui.dp(16), ui.dp(8)) }
        val sv = ScrollView(this)
        sv.addView(tv)
        AlertDialog.Builder(this).setTitle(L("لینک مستقیم دانلود")).setView(sv)
            .setPositiveButton(L("کپی همه")) { _, _ -> copyText(txt) }
            .setNeutralButton(L("اشتراک‌گذاری")) { _, _ ->
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, txt) }, null))
            }
            .setNegativeButton(L("بستن"), null)
            .show()
    }

    /** content://...externalstorage tree (what the folder picker returns) -> the real path of that folder. */
    private fun treeToPath(u: Uri): String? {
        val id = try { android.provider.DocumentsContract.getTreeDocumentId(u) } catch (_: Throwable) { return null }
        val i = id.indexOf(':')
        if (i < 0) return null
        val vol = id.substring(0, i)
        val rel = id.substring(i + 1)
        val base = if (vol == "primary") android.os.Environment.getExternalStorageDirectory().absolutePath else "/storage/" + vol
        return if (rel.isEmpty()) base else base + "/" + rel
    }

    private fun openUrl(u: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (_: Throwable) { toast(u) }
    }

    private var hfOpened = false

    override fun onResume() {
        super.onResume()
        if (hfOpened) { hfOpened = false; try { refreshModels() } catch (_: Throwable) {} }
    }

    private fun openHfLogin(page: String?) {
        hfOpened = true
        startActivity(Intent(this, HfLoginActivity::class.java).putExtra("next", page ?: ""))
    }

    /** Locked model without a token or a sign-in: offers the sign-in (no token needed) or the token. */
    private fun askAccess(id: String, title: String, url: String, f: File) {
        AlertDialog.Builder(this).setTitle(L("ورود به Hugging Face"))
            .setMessage(L("این مدل قفل است. وارد حساب Hugging Face شو (همان حسابی که ساخته‌ای)، در صفحهٔ مدل دکمهٔ Acknowledge license را بزن و بعد «تمام» را بزن؛ دانلود بدون توکن انجام می‌شود."))
            .setPositiveButton(L("ورود با حساب Hugging Face")) { _, _ -> openHfLogin(url.substringBefore("/resolve/")) }
            .setNeutralButton(L("استفاده از توکن")) { _, _ -> askToken { startDl(id, title, url, f) } }
            .setNegativeButton(L("بستن"), null).show()
    }

    /** Asks for the Hugging Face token (needed for Gemma models) and starts the download when it is saved. */
    private fun askToken(then: () -> Unit) {
        val e = ui.edit("HF token (hf_…)", 1, false).apply { setText(cfg.hfToken) }
        AlertDialog.Builder(this).setTitle(L("توکن Hugging Face"))
            .setMessage(L("توکن نوع Read را از huggingface.co/settings/tokens بساز و اینجا بچسبان. لایسنس همین مدل را هم باید در صفحهٔ مدل قبول کرده باشی."))
            .setView(e)
            .setPositiveButton(L("ذخیره و دانلود")) { _, _ ->
                cfg.hfToken = e.text.toString().trim()
                if (cfg.hfToken.isNotBlank()) then()
            }
            .setNeutralButton(L("ساخت توکن")) { _, _ -> openUrl("https://huggingface.co/settings/tokens") }
            .setNegativeButton(L("بستن"), null).show()
    }

    /** The download itself runs in a service (see Dl.kt): it goes on when the app is closed and retries by itself. */
    private fun startDl(id: String, title: String, url: String, dest: File) {
        if (Dl.jobs.containsKey(id)) return
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)   // only for the progress notification
        pct.remove(id)
        Dl.start(this, id, title, url, dest)
        renderModels()
    }

    /** Live update of one progress bar and its text while a download runs. */
    private fun updateProgress(id: String) {
        val j = Dl.jobs[id] ?: return
        val p = if (j.total > 0) (j.have * 1000 / j.total).toInt().coerceIn(0, 1000) else -1
        if (p >= 0) {
            pct[id] = p
            bars[id]?.let { bar -> bar.isIndeterminate = false; bar.progress = p }
        }
        val sp = if (j.speed > 0) "  ·  " + String.format("%.1f", j.speed / 1048576.0) + " MB/s" else ""
        progress[id]?.text = if (j.note.isNotEmpty()) j.note else
            L("دانلود: ") + (if (p >= 0) (p / 10).toString() + "% · " else "") + (j.have / 1048576) + " / " + (if (j.total > 0) (j.total / 1048576).toString() else "?") + " MB" + sp
    }

    /** Settings card: where the downloaded models are stored, with a move button. */
    private fun storageCard(): View {
        val c = ui.card()
        c.addView(ui.tv(L("پوشهٔ ذخیرهٔ مدل‌ها"), 16f, C.TXT, true))
        val pathTv = ui.tv("", 12f, C.SUB).apply { setTextIsSelectable(true); textDirection = View.TEXT_DIRECTION_LTR }
        storagePathTv = pathTv
        fun showPath() { pathTv.text = Models.dir(this).absolutePath }
        showPath()
        c.addView(pathTv, ui.lp(top = 6))
        val opts = listOf("", "ext", "custom")
        val cur = when { cfg.modelDir == "" -> 0; cfg.modelDir == "ext" -> 1; else -> 2 }
        val custom = ui.edit("/storage/emulated/0/Tarjoman/models", 1)
        custom.setText(if (cfg.modelDir.startsWith("/")) cfg.modelDir else "/storage/emulated/0/Tarjoman/models")
        custom.textDirection = View.TEXT_DIRECTION_LTR
        customEdit = custom
        val customRow = ui.vbox()
        customRow.addView(ui.btn(L("انتخاب پوشه از گوشی…")) {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), 30)
        }, ui.lp())
        customRow.addView(custom, ui.lp(top = 6))
        customRow.addView(ui.btn(L("استفاده از این مسیر و انتقال مدل‌ها")) {
            val p = custom.text.toString().trim().trimEnd('/')
            if (!p.startsWith("/")) { toast(L("مسیر باید با / شروع شود")); return@btn }
            if (needAllFiles()) return@btn
            switchModelDir(p)
            showPath()
        }, ui.lp(top = 6))
        customRow.visibility = if (cur == 2) View.VISIBLE else View.GONE
        c.addView(ui.seg(listOf(L("خصوصی (پیش‌فرض)"), L("پوشهٔ برنامه"), L("مسیر دلخواه")), cur) { i ->
            customRow.visibility = if (i == 2) View.VISIBLE else View.GONE
            if (i == 0) { switchModelDir(""); showPath() }
            if (i == 1) { switchModelDir("ext"); showPath() }
        }, ui.lp(top = 8))
        c.addView(customRow, ui.lp(top = 6))
        c.addView(ui.tv(L("خصوصی: امن‌ترین و بدون مجوز، ولی از بیرون برنامه دیده نمی‌شود (برای کپی کردن مدل‌ها مناسب نیست). پوشهٔ برنامه: Android/data/app.tarjoman/files/models (در اندروید ۱۱ به بعد بیشتر مدیر فایل‌ها اجازهٔ دیدنش را نمی‌دهند). مسیر دلخواه: هر پوشه‌ای که بنویسی، مثلاً /storage/emulated/0/Tarjoman/models که در مدیر فایل راحت دیده می‌شود؛ برای اندروید ۱۱ به بعد مجوز «دسترسی به همهٔ فایل‌ها» لازم است. با عوض کردن پوشه، مدل‌های دانلودشده (و نیمه‌کاره‌ها) به پوشهٔ جدید منتقل می‌شوند."), 11f, C.SUB), ui.lp(top = 8))
        return c
    }

    /** On Android 11+ a folder outside the app needs the "all files access" permission. */
    private fun needAllFiles(): Boolean {
        if (Build.VERSION.SDK_INT >= 30 && !android.os.Environment.isExternalStorageManager()) {
            toast(L("مجوز «دسترسی به همهٔ فایل‌ها» را برای ترجمان روشن کن و دوباره امتحان کن."))
            try {
                startActivity(Intent(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
            } catch (_: Throwable) {
                try { startActivity(Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) } catch (_: Throwable) {}
            }
            return true
        }
        if (Build.VERSION.SDK_INT in 23..29 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 12)
            toast(L("اجازهٔ دسترسی به حافظه را بده و دوباره امتحان کن."))
            return true
        }
        return false
    }

    /** Sets the new models folder and moves everything from the old one (models and half-finished downloads). */
    private fun switchModelDir(v: String) {
        if (Dl.jobs.isNotEmpty()) { toast(L("اول دانلودهای در حال انجام را متوقف کن.")); return }
        if (v == "ext" && getExternalFilesDir("models") == null) { toast(L("حافظهٔ خارجی در دسترس نیست.")); return }
        val from = Models.dir(this)
        val to = Models.dirFor(this, v)
        if (from.absolutePath == to.absolutePath) { cfg.modelDir = v; return }
        try { to.mkdirs(); if (!to.isDirectory || !to.canWrite()) throw IllegalStateException(L("روی این مسیر نمی‌شود نوشت.")) } catch (e: Throwable) { toast(e.message ?: "?"); return }
        cfg.modelDir = v
        toast(L("در حال انتقال مدل‌ها…"))
        tr.exec.execute {
            var moved = 0
            var failed = 0
            for (f in from.listFiles() ?: emptyArray()) {
                if (!f.isFile) continue
                val n = f.name
                if (!(n.endsWith(".task") || n.endsWith(".litertlm") || n.endsWith(".part") || n.endsWith(".meta") || n.endsWith(".bin"))) continue
                try {
                    val t = File(to, n)
                    f.inputStream().use { i -> t.outputStream().use { o -> i.copyTo(o, 256 * 1024) } }
                    if (t.length() == f.length()) { f.delete(); moved++ } else { t.delete(); failed++ }
                } catch (_: Throwable) { failed++ }
            }
            h.post {
                toast(L("منتقل شد: ") + moved + (if (failed > 0) L("، ناموفق: ") + failed else ""))
                if (curTab == 5) refreshModels()
            }
        }
    }

    /** Asks once before anything downloaded is deleted. */
    private fun confirmDelete(what: String, ok: () -> Unit) {
        AlertDialog.Builder(this).setTitle(L("حذف شود؟")).setMessage(what)
            .setPositiveButton(L("حذف")) { _, _ -> ok() }
            .setNegativeButton(L("بستن"), null).show()
    }

    private fun addByUrl() {
        val e = ui.edit("https://…/model.task")
        AlertDialog.Builder(this).setTitle(L("لینک مستقیم فایل مدل")).setView(e)
            .setPositiveButton(L("دانلود")) { _, _ ->
                val u = e.text.toString().trim()
                val name = u.substringBefore("?").substringAfterLast('/')
                if (u.isNotEmpty() && name.isNotEmpty()) {
                    if (name.endsWith(".litertlm") && !LmBridge.available) { toast(L("فرمت .litertlm فقط در نسخهٔ LiteRT-LM پشتیبانی می‌شود")); return@setPositiveButton }
                    askFamily(name)
                    startDl("m:$name", name, u, File(Models.dir(this), name))
                }
            }.setNegativeButton(L("بستن"), null).show()
    }

    private fun askFamily(name: String) {
        AlertDialog.Builder(this).setTitle(L("نوع قالب چت این مدل؟"))
            .setItems(arrayOf("Gemma", "Qwen / ChatML", L("خام (Raw)"))) { _, i ->
                cfg.setFam(name, arrayOf("gemma", "qwen", "raw")[i])
            }.show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 3) {
            if (resultCode == RESULT_OK && data != null) {
                val i = Intent(this, BubbleService::class.java).putExtra("code", resultCode).putExtra("data", data)
                startForegroundService(i)
                h.postDelayed({ updateBubbleUi() }, 800)
                toast(L("حباب روشن شد؛ به برنامهٔ دلخواه برو"))
            } else toast(L("اجازهٔ ضبط صفحه داده نشد"))
            return
        }
        if (requestCode == 20) {
            val u = camUri
            camUri = null
            if (u != null) {
                if (resultCode == RESULT_OK) runImage(u)
                else try { contentResolver.delete(u, null, null) } catch (_: Throwable) {}   // cancelled: do not leave an empty picture behind
            }
            return
        }
        if (requestCode == 21) {
            // picture taken in the live camera screen: read and translate it like a gallery picture
            val path = data?.getStringExtra("path")
            if (resultCode == RESULT_OK && path != null) { show(1); runImage(Uri.fromFile(File(path))) }
            return
        }
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        if (requestCode == 30) {
            val p = treeToPath(uri)
            if (p == null) { toast(L("این پوشه پشتیبانی نمی‌شود؛ پوشه‌ای از حافظهٔ داخلی یا کارت حافظه انتخاب کن.")); return }
            customEdit?.setText(p)
            if (needAllFiles()) return
            switchModelDir(p)
            storagePathTv?.text = Models.dir(this).absolutePath
            return
        }
        if (requestCode == 1) runImage(uri)
        if (requestCode == 2) importModel(uri)
        if (requestCode == 4) onPdfPicked(uri)
        if (requestCode == 6) onSrtPicked(uri)
        if (requestCode == 7) {
            try {
                val txt = "\uFEFF" + SrtTool.build(srtCues, srtTexts)
                contentResolver.openOutputStream(uri)?.use { it.write(txt.toByteArray(Charsets.UTF_8)) }
                toast(L("ذخیره شد"))
            } catch (e: Throwable) { toast(L("خطا: ") + e.message) }
        }
        if (requestCode == 9) {
            try {
                contentResolver.openOutputStream(uri)?.use { PdfTool.export(pdfCur().toString(), it) }
                toast(L("PDF ذخیره شد"))
            } catch (e: Throwable) { toast(L("خطا: ") + e.message) }
        }
        if (requestCode == 8) {
            try {
                val bm = imgOut
                if (bm != null) contentResolver.openOutputStream(uri)?.use { bm.compress(Bitmap.CompressFormat.PNG, 100, it) }
                toast(L("ذخیره شد"))
            } catch (e: Throwable) { toast(L("خطا: ") + e.message) }
        }
        if (requestCode == 5) {
            try {
                contentResolver.openOutputStream(uri)?.use { it.write(pdfCur().toString().toByteArray(Charsets.UTF_8)) }
                toast(L("ذخیره شد"))
            } catch (e: Throwable) { toast(L("خطا: ") + e.message) }
        }
    }

    private fun importModel(uri: Uri) {
        var name = "model_" + System.currentTimeMillis() + ".task"
        contentResolver.query(uri, null, null, null, null)?.use {
            if (it.moveToFirst()) {
                val ix = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (ix >= 0) name = it.getString(ix)
            }
        }
        if (name.endsWith(".litertlm") && !LmBridge.available) { toast(L("فرمت .litertlm فقط در نسخهٔ LiteRT-LM پشتیبانی می‌شود")); return }
        val fname = name
        toast(L("در حال کپی مدل… صبر کن"))
        Thread {
            try {
                val dest = File(Models.dir(this), fname)
                contentResolver.openInputStream(uri)?.use { ins -> FileOutputStream(dest).use { out -> ins.copyTo(out, 256 * 1024) } }
                h.post { askFamily(fname); refreshModels() }
                toast(L("مدل اضافه شد"))
            } catch (e: Throwable) {
                toast(L("خطا: ") + e.message)
            }
        }.start()
    }

    // ------------------------------------------------------------------ SETTINGS PAGE
    // ------------------------------------------------------------------ HISTORY PAGE
    /** Saves a finished translation in the background (the size limit is applied there). */
    private fun saveHist(kind: String, s: String, d: String, a: String, b: String) {
        val mb = cfg.histMb
        if (mb <= 0) return
        Thread { Hist.add(this, mb, kind, s, d, a, b) }.start()
    }

    private fun buildHistoryPage(): View {
        val sv = ScrollView(this)
        val col = ui.vbox()
        sv.addView(col)
        val top = ui.hbox()
        top.addView(ui.tv(L("تاریخچه ترجمه"), 18f, C.TXT, true), ui.hlp())
        top.addView(ui.btn(L("بازگشت"), false) { show(0) }, LinearLayout.LayoutParams(WRAP, WRAP))
        col.addView(top)
        histSearch = ui.edit(L("جستجو در تاریخچه…"))
        histSearch.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun afterTextChanged(e: android.text.Editable?) { h.removeCallbacks(histRun); h.postDelayed(histRun, 300) }
        })
        col.addView(histSearch, ui.lp(top = 10))
        histInfo = ui.tv("", 12f, C.SUB)
        col.addView(histInfo, ui.lp(top = 8))
        val r1 = ui.hbox()
        r1.addView(ui.btn(L("انتخاب همه"), false) { histSel.addAll(histShown.map { it.id }); renderHistory() }, ui.hlp())
        r1.addView(ui.btn(L("لغو انتخاب"), false) { histSel.clear(); renderHistory() }, ui.hlp(1f, 8))
        col.addView(r1, ui.lp(top = 8))
        val r2 = ui.hbox()
        r2.addView(ui.btn(L("حذف انتخاب‌شده"), false) {
            if (histSel.isEmpty()) { toast(L("اول چند مورد را انتخاب کن")); return@btn }
            val ids = HashSet(histSel)
            confirmDelete(L("موارد انتخاب‌شده پاک شوند؟") + " (" + ids.size + ")") {
                Thread { Hist.delete(this, ids); h.post { histSel.removeAll(ids); refreshHistory() } }.start()
            }
        }, ui.hlp())
        r2.addView(ui.btn(L("حذف همه")) {
            confirmDelete(L("همهٔ تاریخچهٔ ترجمه پاک شود؟")) {
                Thread { Hist.clear(this); h.post { histSel.clear(); refreshHistory() } }.start()
            }
        }, ui.hlp(1f, 8))
        col.addView(r2, ui.lp(top = 8))
        histBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(histBox, ui.lp(top = 10))
        return sv
    }

    private fun refreshHistory() {
        val q = histSearch.text.toString()
        val job = ++histJob
        Thread {
            val list = Hist.list(this, q, 150)
            val n = Hist.count(this)
            val sz = Hist.size(this)
            h.post {
                if (job == histJob) {
                    histShown.clear(); histShown.addAll(list)
                    histCount = n; histBytes = sz
                    renderHistory()
                }
            }
        }.start()
    }

    private fun renderHistory() {
        val cap = cfg.histMb
        histInfo.text = L("تعداد: ") + histCount + " · " + String.format(java.util.Locale.US, "%.2f MB", histBytes / 1048576.0) +
            (if (cap > 0) " / $cap MB" else " · " + L("ذخیره‌سازی خاموش است"))
        histBox.removeAllViews()
        if (histShown.isEmpty()) {
            histBox.addView(ui.tv(L("تاریخچه خالی است."), 13f, C.SUB))
            return
        }
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US)
        for (e in histShown) {
            val c = ui.card()
            val head = ui.hbox()
            head.addView(android.widget.CheckBox(this).apply {
                isChecked = e.id in histSel
                setOnCheckedChangeListener { _, on -> if (on) histSel.add(e.id) else histSel.remove(e.id) }
            }, LinearLayout.LayoutParams(WRAP, WRAP))
            val kind = if (e.kind == "image") L("عکس") + " · " else ""
            head.addView(ui.tv(kind + Lang.name(e.s).substringBefore(" ·") + " → " + Lang.name(e.d).substringBefore(" ·") + " · " + fmt.format(java.util.Date(e.id)), 11f, C.SUB, true), ui.hlp())
            c.addView(head)
            val a = ui.tv(e.src, 14f, C.TXT).apply {
                maxLines = 3; ellipsize = android.text.TextUtils.TruncateAt.END
                textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            }
            val b = ui.tv(e.out, 15f, C.ACC, true).apply {
                maxLines = 4; ellipsize = android.text.TextUtils.TruncateAt.END
                textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            }
            val toggle = View.OnClickListener {
                val open = a.maxLines == Int.MAX_VALUE
                a.maxLines = if (open) 3 else Int.MAX_VALUE
                b.maxLines = if (open) 4 else Int.MAX_VALUE
            }
            a.setOnClickListener(toggle); b.setOnClickListener(toggle)
            c.addView(a, ui.lp(top = 4))
            c.addView(b, ui.lp(top = 6))
            val br = ui.hbox()
            br.addView(ui.btn(L("استفاده"), false) {
                cfg.src = e.s; cfg.dst = e.d
                refreshLang()
                input.setText(e.src)
                output.text = e.out
                status.text = L("از تاریخچه")
                show(0)
            }, ui.hlp())
            br.addView(ui.btn(L("کپی"), false) {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("tr", e.out))
                toast(L("کپی شد"))
            }, ui.hlp(1f, 6))
            br.addView(ui.btn(L("حذف"), false) {
                Thread { Hist.delete(this, setOf(e.id)); h.post { histSel.remove(e.id); refreshHistory() } }.start()
            }, ui.hlp(1f, 6))
            c.addView(br, ui.lp(top = 8))
            histBox.addView(c, ui.lp(top = 8))
        }
    }

    private fun buildSettingsPage(): View {
        val sv = ScrollView(this)
        settingsScroll = sv
        val col = ui.vbox()
        sv.addView(col)

        val lang = ui.card()
        lang.addView(ui.tv(L("زبان برنامه"), 16f, C.TXT, true))
        lang.addView(ui.tv(L("زبان منوها و نوشته‌های خود برنامه (غیر از ترجمه). حباب شناور بعد از خاموش و روشن شدن زبان جدید را می‌گیرد."), 12f, C.SUB), ui.lp(top = 4))
        lang.addView(ui.seg(listOf(L("فارسی"), "English"), if (cfg.uiLang == "en") 1 else 0) {
            cfg.uiLang = if (it == 1) "en" else "fa"
            recreate()
        }, ui.lp(top = 8))
        col.addView(lang)

        val look = ui.card()
        look.addView(ui.tv(L("ظاهر برنامه"), 16f, C.TXT, true))
        look.addView(ui.tv(L("حالت رنگ"), 12f, C.SUB), ui.lp(top = 10))
        val tm = listOf("system", "light", "dark")
        look.addView(ui.seg(listOf(L("تم سیستم"), L("تم روشن"), L("تم تیره")), tm.indexOf(cfg.themeMode).coerceAtLeast(0)) {
            cfg.themeMode = tm[it]
            recreate()
        }, ui.lp(top = 3))
        look.addView(ui.tv(L("سبک ظاهر"), 12f, C.SUB), ui.lp(top = 10))
        look.addView(ui.seg(listOf(L("مدرن"), L("کلاسیک (کاغذی)")), if (cfg.look == "classic") 1 else 0) {
            cfg.look = if (it == 1) "classic" else "modern"
            recreate()
        }, ui.lp(top = 3))
        look.addView(ui.tv(L("«تم سیستم» از حالت روشن/تیرهٔ خود گوشی پیروی می‌کند. سبک کلاسیک ظاهر کاغذی با حروف سریف دارد و در هر دو حالت روشن (کاغذ) و تیره (کاغذ شب) کار می‌کند."), 11f, C.SUB), ui.lp(top = 6))
        col.addView(look, ui.lp(top = 12))

        val hs = ui.card()
        hs.addView(ui.tv(L("تاریخچه ترجمه"), 16f, C.TXT, true))
        hs.addView(ui.tv(L("متن‌ها و عکس‌هایی که ترجمه می‌کنی ذخیره می‌شوند تا بعداً دوباره ببینی. فقط روی خود گوشی می‌ماند. وقتی به سقف حجم برسد، قدیمی‌ترین‌ها خودکار پاک می‌شوند."), 12f, C.SUB), ui.lp(top = 4))
        hs.addView(ui.tv(L("حداکثر حجم تاریخچه (مگابایت)"), 12f, C.SUB), ui.lp(top = 10))
        val hv = listOf(0, 5, 10, 25, 50, 100)
        val hsize = ui.tv("", 12f, C.SUB)
        fun showUsed() { Thread { val b = Hist.size(this); h.post { hsize.text = L("حجم فعلی: ") + String.format(java.util.Locale.US, "%.2f MB", b / 1048576.0) } }.start() }
        hs.addView(ui.seg(listOf(L("خاموش"), "5", "10", "25", "50", "100"), hv.indexOf(cfg.histMb).let { if (it < 0) 2 else it }) {
            cfg.histMb = hv[it]
            if (it > 0) Thread { Hist.trim(this, hv[it]); showUsed() }.start()
        }, ui.lp(top = 3))
        hs.addView(hsize, ui.lp(top = 6))
        showUsed()
        val hr = ui.hbox()
        hr.addView(ui.btn(L("باز کردن تاریخچه"), false) { show(7) }, ui.hlp())
        hr.addView(ui.btn(L("پاک کردن همه"), false) {
            confirmDelete(L("همهٔ تاریخچهٔ ترجمه پاک شود؟")) { Thread { Hist.clear(this); showUsed() }.start() }
        }, ui.hlp(1f, 8))
        hs.addView(hr, ui.lp(top = 8))
        col.addView(hs, ui.lp(top = 12))

        val pref = ui.card()
        pref.addView(ui.tv(L("تشخیص خودکار زبان متن"), 16f, C.TXT, true))
        pref.addView(ui.tv(L("وقتی در تب «متن» ترجمه می‌زنی، اگر نوشته فارسی/انگلیسی/ژاپنی بود و با زبان مبدأ فرق داشت، خودش جابه‌جا می‌شود."), 12f, C.SUB), ui.lp(top = 4))
        pref.addView(ui.seg(listOf(L("خاموش"), L("روشن")), cfg.autoLang) { cfg.autoLang = it }, ui.lp(top = 8))
        col.addView(pref, ui.lp(top = 12))

        val imp = ui.card()
        imp.addView(ui.tv(L("بهبود ترجمه"), 16f, C.TXT, true))
        imp.addView(ui.tv(L("اصلاح انگلیسی قبل از ترجمهٔ آفلاین"), 12f, C.SUB), ui.lp(top = 8))
        imp.addView(ui.seg(listOf(L("خاموش"), L("روشن")), cfg.preFix) { cfg.preFix = it }, ui.lp(top = 3))
        imp.addView(ui.tv(L("حروف بزرگ مانگا را عادی می‌کند، i را I می‌کند، نقطه و علامت سؤال می‌گذارد و اصطلاحات عامیانه (مثل tripping یا cool) را به انگلیسی ساده تبدیل می‌کند تا ML Kit معنی را ترجمه کند، نه کلمه‌به‌کلمه."), 11f, C.SUB), ui.lp(top = 4))
        imp.addView(ui.tv(L("فارسی محاوره‌ای خودکار"), 12f, C.SUB), ui.lp(top = 10))
        imp.addView(ui.seg(listOf(L("خاموش"), L("روشن")), cfg.colloq) { cfg.colloq = it }, ui.lp(top = 3))
        imp.addView(ui.tv(L("وقتی «سبک ترجمه» محاوره‌ای است، فارسی رسمی را گفتاری می‌کند (مثلاً «می‌توانید» می‌شود «می‌تونید»، «را» می‌شود «رو»). برای ترجمهٔ همهٔ موتورها اعمال می‌شود."), 11f, C.SUB), ui.lp(top = 4))
        col.addView(imp, ui.lp(top = 12))

        val ocrC = ui.card()
        ocrC.addView(ui.tv(L("خواندن متن از عکس (OCR)"), 16f, C.TXT, true))
        ocrC.addView(ui.tv(L("برای هر زبان جدا تنظیم می‌شود، چون ابزار خواندن انگلیسی و فارسی یکی نیست. روی عکس‌های ترجمه، صفحه (حباب) و PDF اثر دارد."), 12f, C.SUB), ui.lp(top = 4))
        ocrC.addView(ui.tv(L("انگلیسی"), 14f, C.ACC, true), ui.lp(top = 12))
        ocrC.addView(ui.tv(L("ابزار خواندن"), 12f, C.SUB), ui.lp(top = 6))
        val enEng = listOf("auto", "mlkit", "tess")
        ocrC.addView(ui.seg(listOf(L("خودکار"), "ML Kit", "Tesseract"), enEng.indexOf(cfg.ocrEn).coerceAtLeast(0)) { cfg.ocrEn = enEng[it] }, ui.lp(top = 3))
        ocrC.addView(ui.tv(L("خودکار: ML Kit همیشه خوانده می‌شود و اگر مدل Tesseract انگلیسی را در تب «مدل‌ها» نصب کرده باشی، هر دو می‌خوانند و نتیجه‌ای که کلمات واقعی بیشتری دارد انتخاب می‌شود (دقیق‌تر ولی کمی کندتر). ML Kit: سریع و بدون مدل اضافه. Tesseract: فقط وقتی مدلش نصب است."), 11f, C.SUB), ui.lp(top = 4))
        ocrC.addView(ui.tv(L("بهتر کردن عکس قبل از خواندن (بزرگ‌کردن و کنتراست)"), 12f, C.SUB), ui.lp(top = 10))
        val enPre = listOf("auto", "on", "off")
        ocrC.addView(ui.seg(listOf(L("خودکار"), L("همیشه"), L("خاموش")), enPre.indexOf(cfg.ocrEnPre).coerceAtLeast(0)) { cfg.ocrEnPre = enPre[it] }, ui.lp(top = 3))
        ocrC.addView(ui.tv(L("خودکار: فقط وقتی خواندن اول مشکوک یا عکس کوچک است. «همیشه» برای متن ریز و کم‌رنگ؛ «خاموش» اگر عکست خودش تمیز و بزرگ است و سرعت می‌خواهی."), 11f, C.SUB), ui.lp(top = 4))
        ocrC.addView(ui.tv(L("اصلاح حروف شبیه هم با فهرست کلمات (مثلاً rn به جای m)"), 12f, C.SUB), ui.lp(top = 10))
        ocrC.addView(ui.seg(listOf(L("خاموش"), L("روشن")), cfg.ocrEnFix) { cfg.ocrEnFix = it }, ui.lp(top = 3))
        ocrC.addView(ui.tv(L("فارسی"), 14f, C.ACC, true), ui.lp(top = 16))
        ocrC.addView(ui.tv(L("مدل خواندن"), 12f, C.SUB), ui.lp(top = 6))
        val faMod = listOf("auto", "fast", "best")
        ocrC.addView(ui.seg(listOf(L("خودکار"), L("سریع"), L("دقیق")), faMod.indexOf(cfg.ocrFaModel).coerceAtLeast(0)) { cfg.ocrFaModel = faMod[it] }, ui.lp(top = 3))
        ocrC.addView(ui.tv(L("خودکار: اگر مدل «دقیق‌تر» نصب باشد همان را می‌گیرد. اگر مدل انتخابی نصب نباشد، مدل نصب‌شدهٔ دیگر استفاده می‌شود."), 11f, C.SUB), ui.lp(top = 4))
        ocrC.addView(ui.tv(L("آماده‌سازی عکس"), 12f, C.SUB), ui.lp(top = 10))
        val faPre = listOf("auto", "gray", "bw")
        ocrC.addView(ui.seg(listOf(L("خودکار"), L("خاکستری"), L("سیاه و سفید")), faPre.indexOf(cfg.ocrFaPre).coerceAtLeast(0)) { cfg.ocrFaPre = faPre[it] }, ui.lp(top = 3))
        ocrC.addView(ui.tv(L("خودکار: هر عکس به دو شکل خوانده می‌شود و نتیجهٔ مطمئن‌تر می‌ماند (کندتر). خاکستری: برای متن تیره روی زمینهٔ روشن. سیاه و سفید: برای مانگا و متن سفید روی زمینهٔ تیره؛ سریع‌تر."), 11f, C.SUB), ui.lp(top = 4))
        col.addView(ocrC, ui.lp(top = 12))

        col.addView(storageCard(), ui.lp(top = 12))
        crashCard()?.let { col.addView(it, ui.lp(top = 12)) }
        val mineC = ui.card()
        mineC.addView(ui.tv(L("ترجمه‌های اصلاح‌شدهٔ من"), 16f, C.TXT, true))
        val mineTv = ui.tv("", 12f, C.SUB)
        fun showMine() { mineTv.text = L("تعداد: ") + Idm.mineCount() + L(" · با دکمهٔ «اصلاح ترجمه» در صفحهٔ متن اضافه می‌شود.") }
        showMine()
        mineC.addView(mineTv, ui.lp(top = 4))
        mineC.addView(ui.btn(L("پاک کردن همه"), false) {
            confirmDelete(L("ترجمه‌های اصلاح‌شدهٔ من")) { cfg.userPhr = ""; Idm.loadMine(""); showMine() }
        }, ui.lp(top = 8))
        col.addView(mineC, ui.lp(top = 12))

        val live = ui.card()
        live.addView(ui.tv(L("ترجمه خودکار هنگام نوشتن"), 16f, C.TXT, true))
        live.addView(ui.tv(L("روشن باشد، بعد از چند لحظه که تایپ را رها کنی خودش ترجمه می‌کند و نیازی به دکمهٔ ترجمه نیست. با موتور AI کندتر است و برای Normal بهتر جواب می‌دهد."), 12f, C.SUB), ui.lp(top = 4))
        live.addView(ui.seg(listOf(L("خاموش"), L("روشن")), cfg.live) { cfg.live = it }, ui.lp(top = 8))
        col.addView(live, ui.lp(top = 12))

        val net = ui.card()
        net.addView(ui.tv(L("شبکه (پروکسی/فیلترشکن)"), 16f, C.TXT, true))
        net.addView(ui.tv(L("اگر فیلترشکن سیستمی روشن است همین کافی است؛ اگر فقط پروکسی داری اینجا بگذار. برای دانلود مدل و ترجمه آنلاین استفاده می‌شود."), 12f, C.SUB), ui.lp(top = 4))
        val types = listOf("none", "http", "socks")
        net.addView(ui.seg(listOf(L("بدون پروکسی"), "HTTP", "SOCKS5"), types.indexOf(cfg.proxyType).coerceAtLeast(0)) { cfg.proxyType = types[it] }, ui.lp(top = 8))
        val ph = ui.edit(L("آدرس (مثلاً 127.0.0.1)")).apply { setText(cfg.proxyHost) }
        val pp = ui.edit(L("پورت (مثلاً 10808)")).apply { setText(cfg.proxyPort) }
        net.addView(ph, ui.lp(top = 8))
        net.addView(pp, ui.lp(top = 8))
        col.addView(net, ui.lp(top = 12))

        val hf = ui.card()
        hf.addView(ui.tv(L("دانلود مدل (Hugging Face)"), 16f, C.TXT, true))
        hf.addView(ui.tv(L("توکن فقط برای مدل‌های Gemma لازم است (از huggingface.co/settings/tokens، نوع Read، و لایسنس مدل را در سایت قبول کن). آینه برای زمانی است که huggingface.co فیلتر است."), 12f, C.SUB), ui.lp(top = 4))
        hf.addView(ui.btn(if (Hf.signedIn(cfg)) L("وارد شده‌ای ✓ (دوباره ورود)") else L("ورود با حساب Hugging Face"), !Hf.signedIn(cfg)) { openHfLogin(null) }, ui.lp(top = 8))
        hf.addView(ui.tv(L("ورود با حساب فقط با نام کاربری و رمز کار می‌کند؛ ورود با Google/GitHub داخل برنامه ممکن است مسدود باشد."), 12f, C.SUB), ui.lp(top = 4))
        if (Hf.signedIn(cfg)) hf.addView(ui.btn(L("خروج از حساب"), false) { Hf.signOut(cfg); toast(L("خروج انجام شد")) }, ui.lp(top = 8))
        val tok = ui.edit("HF token (hf_…)", 1, true).apply { setText(cfg.hfToken) }
        val mir = ui.edit(L("آینه، پیش‌فرض huggingface.co")).apply { setText(cfg.mirror) }
        hf.addView(tok, ui.lp(top = 8))
        hf.addView(mir, ui.lp(top = 8))
        col.addView(hf, ui.lp(top = 12))

        val api = ui.card()
        api.addView(ui.tv(L("آنلاین پیشرفته (اختیاری)"), 16f, C.TXT, true))
        api.addView(ui.tv(L("اگر کلید API سازگار با OpenAI بگذاری (مثلاً Gemini رایگان)، در حالت آنلاین + Advanced با هوش مصنوعی ابری ترجمه می‌شود. خالی بماند، از ترجمه گوگل استفاده می‌شود."), 12f, C.SUB), ui.lp(top = 4))
        val au = ui.edit(L("آدرس API")).apply { setText(cfg.apiUrl) }
        val ak = ui.edit("API key", 1, true).apply { setText(cfg.apiKey) }
        val am = ui.edit(L("نام مدل")).apply { setText(cfg.apiModel) }
        api.addView(au, ui.lp(top = 8))
        api.addView(ak, ui.lp(top = 8))
        api.addView(am, ui.lp(top = 8))
        col.addView(api, ui.lp(top = 12))

        val gl = ui.card()
        gl.addView(ui.tv(L("واژه‌نامه (اسامی و اصطلاحات)"), 16f, C.TXT, true))
        gl.addView(ui.tv(L("هر خط یک مورد، به شکل  اصلی=ترجمه  مثلاً  Naruto=ناروتو . فقط روی موتور AI و API اثر دارد."), 12f, C.SUB), ui.lp(top = 4))
        val gle = ui.edit(L("Naruto=ناروتو"), 4).apply { setText(cfg.glossary) }
        gl.addView(gle, ui.lp(top = 8))
        col.addView(gl, ui.lp(top = 12))

        col.addView(ui.btn(L("ذخیره تنظیمات")) {
            cfg.glossary = gle.text.toString().trim()
            cfg.proxyHost = ph.text.toString().trim()
            cfg.proxyPort = pp.text.toString().trim()
            cfg.hfToken = tok.text.toString().trim()
            cfg.mirror = mir.text.toString().trim().ifEmpty { "huggingface.co" }
            cfg.apiUrl = au.text.toString().trim()
            cfg.apiKey = ak.text.toString().trim()
            cfg.apiModel = am.text.toString().trim()
            toast(L("ذخیره شد"))
        }, ui.lp(top = 14))

        col.addView(ui.tv(L("نسخه ۰.۱۶: ترجمه زنده با ورق زدن. نسخه ۰.۱۵: نوشتن «از/به» بالای زبان‌ها. نسخه ۰.۱۴: یک دکمه برای روشن/خاموش کردن حباب، لایهٔ ترجمه بدون جلوگیری از لمس، تنظیمات حباب فقط با لمس طولانی. نسخه ۰.۱۳: ترجمه خودکار هنگام نوشتن، حالت‌های حباب (آزاد/قفل/خواب)، نوار پایین جدید، مدل کوچک‌تر. نسخه ۰.۱۲: گزینهٔ «سبک ترجمه» (محاوره‌ای/رسمی) برای موتور AI. نسخه ۰.۱۱: زبان برنامه (فارسی/انگلیسی) در تنظیمات، اسم انگلیسی زیر آیکون، مدل سنگین‌تر Gemma 3n در فهرست مدل‌ها. نسخه ۰.۱۰: پشتیبانی اختیاری از مدل‌های .litertlm. نسخه ۰.۹: تم کلاسیک/مدرن و آیکون جدید. نسخه ۰.۸: PDFهای متنی بدون OCR. نسخه ۰.۷: خروجی PDF و حباب‌های عمودی مانگا. نسخه ۰.۶: تشخیص خودکار زبان، حافظهٔ ترجمه، اصلاح نگارش فارسی، حالت ترکیبی، .vtt یوتیوب."), 12f, C.SUB), ui.lp(top = 16))
        return sv
    }
}
