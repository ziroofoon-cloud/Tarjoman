package app.tarjoman

object Lang {
    val all = listOf("en", "fa", "ja", "ko", "zh", "ar", "es")

    /** Shown in menus. The part before " ·" is the short name used on small buttons. */
    fun name(c: String): String = if (S.en) when (c) {
        "en" -> "English"
        "fa" -> "فارسی · Persian"
        "ko" -> "한국어 · Korean"
        "zh" -> "中文 · Chinese"
        "ar" -> "العربية · Arabic"
        "es" -> "Español · Spanish"
        else -> "日本語 · Japanese"
    } else when (c) {
        "en" -> "English · انگلیسی"
        "fa" -> "فارسی · Persian"
        "ko" -> "한국어 · کره‌ای"
        "zh" -> "中文 · چینی"
        "ar" -> "العربية · عربی"
        "es" -> "Español · اسپانیایی"
        else -> "日本語 · ژاپنی"
    }

    fun english(c: String): String = when (c) {
        "en" -> "English"
        "fa" -> "Persian (Farsi)"
        "ko" -> "Korean"
        "zh" -> "Chinese (Simplified)"
        "ar" -> "Arabic"
        "es" -> "Spanish"
        else -> "Japanese"
    }
}
