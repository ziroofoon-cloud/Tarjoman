package app.tarjoman

object Lang {
    val all = listOf("en", "fa", "ja")
    fun name(c: String): String = when (c) {
        "en" -> "English · انگلیسی"
        "fa" -> "فارسی · Persian"
        else -> "日本語 · ژاپنی"
    }
    fun english(c: String): String = when (c) {
        "en" -> "English"
        "fa" -> "Persian (Farsi)"
        else -> "Japanese"
    }
}
