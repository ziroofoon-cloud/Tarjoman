package app.tarjoman

object Lang {
    val all = listOf("en", "fa", "ja")

    /** Shown in menus. The part before " ·" is the short name used on small buttons. */
    fun name(c: String): String = if (S.en) when (c) {
        "en" -> "English"
        "fa" -> "فارسی · Persian"
        else -> "日本語 · Japanese"
    } else when (c) {
        "en" -> "English · انگلیسی"
        "fa" -> "فارسی · Persian"
        else -> "日本語 · ژاپنی"
    }

    fun english(c: String): String = when (c) {
        "en" -> "English"
        "fa" -> "Persian (Farsi)"
        else -> "Japanese"
    }
}
