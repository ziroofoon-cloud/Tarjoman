package app.tarjoman

/**
 * A small list of very common English words. Used (1) to compare two OCR readings of the same picture and keep the one
 * with more real words, and (2) to repair a word the reader got wrong by one look-alike letter (rn / m, cl / d, 0 / o ...).
 * It is not a spell checker: unknown words are never changed unless exactly one look-alike repair gives a known word.
 */
object Lex {
    private val words: HashSet<String> by lazy {
        val s = HashSet<String>(2048)
        for (w in DATA.split(' ', '\n')) if (w.isNotEmpty()) s.add(w)
        s
    }

    /** True for a known word, also in common inflected forms (plural, -ed, -ing, -ly, 's). */
    fun has(raw: String): Boolean {
        var w = raw.lowercase().trim('\'', '"', '-')
        if (w.isEmpty()) return false
        if (w.endsWith("'s")) w = w.dropLast(2)
        if (w in words) return true
        fun base(b: String): Boolean = b.length >= 2 && b in words
        if (w.endsWith("s") && base(w.dropLast(1))) return true
        if (w.endsWith("es") && base(w.dropLast(2))) return true
        if (w.endsWith("ies") && base(w.dropLast(3) + "y")) return true
        if (w.endsWith("ed")) {
            val b = w.dropLast(2)
            if (base(b) || base(b + "e") || (b.length > 2 && b[b.length - 1] == b[b.length - 2] && base(b.dropLast(1)))) return true
            if (w.endsWith("ied") && base(w.dropLast(3) + "y")) return true
        }
        if (w.endsWith("d") && base(w.dropLast(1))) return true
        if (w.endsWith("ing")) {
            val b = w.dropLast(3)
            if (base(b) || base(b + "e") || (b.length > 2 && b[b.length - 1] == b[b.length - 2] && base(b.dropLast(1)))) return true
        }
        if (w.endsWith("ly") && base(w.dropLast(2))) return true
        if (w.endsWith("er") && (base(w.dropLast(2)) || base(w.dropLast(1)))) return true
        if (w.endsWith("est") && (base(w.dropLast(3)) || base(w.dropLast(2)))) return true
        if (w.endsWith("n't") ) return true
        return false
    }

    /** Share (0..1) of the letters that sit in known words; names and numbers count as neutral. */
    fun score(text: String): Float {
        var good = 0
        var all = 0
        for (tok in text.split(Regex("\\s+"))) {
            val core = tok.trim { !it.isLetterOrDigit() && it != '\'' }
            if (core.length < 2 || core.any { it.isDigit() }) continue
            if (core[0].isUpperCase() && core.drop(1).all { it.isLowerCase() } && core.length > 2 && !has(core)) continue   // probably a name
            all += core.length
            if (has(core)) good += core.length
        }
        return if (all == 0) 0f else good.toFloat() / all
    }

    // Only confusions that readers really make and that rarely turn a real word into another one. Single-letter
    // swaps (c/e, a/o, h/b ...) are left out on purpose: the list is small and would "repair" valid words (bat -> hat).
    private val swaps = listOf(
        "rn" to "m", "m" to "rn", "vv" to "w", "cl" to "d", "ii" to "u",
        "0" to "o", "1" to "l", "5" to "s", "8" to "b"
    )

    /** One look-alike repair that turns an unknown word into a known one; the word itself when there is none or it is ambiguous. */
    fun repair(w: String): String {
        if (w.length < 3 || has(w)) return w
        val low = w.lowercase()
        var found: String? = null
        for ((a, b) in swaps) {
            var from = 0
            while (true) {
                val i = low.indexOf(a, from)
                if (i < 0) break
                val cand = low.substring(0, i) + b + low.substring(i + a.length)
                if (cand != low && has(cand)) {
                    if (found != null && found != cand) return w     // two different answers: leave it
                    found = cand
                }
                from = i + 1
            }
        }
        val f = found ?: return w
        return if (w[0].isUpperCase()) f.replaceFirstChar { it.uppercase() } else if (w.all { it.isUpperCase() || !it.isLetter() }) f.uppercase() else f
    }

    private const val DATA = """
a about above across act actually add after again against age ago agree air all almost alone along already also always am among an and angry another answer any anyone anything anyway are area arm around arrive as ask at ate away baby back bad bag ball be beat beautiful because become bed been before began begin behind believe below best better between big bit black blood blue body book born both box boy break bring brother brought build burn busy but buy by call came can car care carry case catch cause chance change child children city class clean clear close cold color come company could country course cover cry cut dad dance dark daughter day dead dear death decide deep did die different dinner do doctor does dog done door down draw dream drink drive drop dry during each early earth easy eat else end enough even evening ever every everyone everything exactly eye face fact fall family far fast father fear feel felt few field fight fill final find fine finger finish fire first fish five floor fly follow food foot for forest forget form found four free friend from front full fun funny future game gave get girl give glad go god gold gone good got great green ground group grow guess gun guy had hair half hand happen happy hard has hat hate have he head hear heard heart heavy held hell hello help her here hide high him himself his hit hold home hope horse hot hour house how however human hundred hurt i idea if important in inside into is it its itself job join just keep kept kill kind king knew know land large last late laugh lay lead learn least leave left leg less let letter life light like line list listen little live long look lose lost lot loud love low lucky mad made make man many map mark matter may maybe me mean meet men met middle might mind mine minute miss mom money month moon more morning most mother mountain mouth move movie much music must my myself name near need never new next nice night no nobody none nor nose not nothing notice now number of off often oh ok okay old on once one only open or order other our out outside over own page pain paper part party pass past pay people perfect person pick picture piece place plan plant play please point poor power pretty probably problem promise pull put question quick quiet quite race rain ran reach read ready real really reason red remember rest return rich ride right ring river road rock room round run sad safe said same sat save saw say school sea second see seem sell send sense sent serious set seven several shall she ship shoot short should shout show shut sick side sign simple since sing sister sit six sleep slow small smile snow so some someone something sometimes son song soon sorry sound speak special spend stand star start stay step stick still stop store story straight strange street strong student study stupid such sudden suddenly summer sun sure surprise sweet table take talk tall teach teacher tell ten terrible than thank thanks that the their them then there these they thing think third this those though thought three through throw tie time tired to today together told tomorrow tonight too took top touch town train tree trouble true trust try turn two under understand until up upon us use usually very voice wait wake walk wall want war warm was wash watch water way we weak wear weather week welcome well went were west what when where whether which while white who whole whom whose why wife will win wind window winter wish with without woman won wonder wonderful word work world worry would write wrong yeah year yellow yes yesterday yet you young your yourself
able accept accident ahead alive allow ancient anymore appear apart arrived attack attention awful bank battle beat believe belong bird bite blow bone born boss bother brain brave bright broke brother bye captain card cat century chair chief choice church clothes club coffee color common cool copy corner cost count crazy cross crowd cup dangerous date deal destroy die dirty doubt dress dumb earlier empty enemy enjoy enter escape evil excuse eyes fail fair fault fellow figure fix flower force fool forever forgive freedom future garden gentle ghost gift glass goodbye grab grandma guard gym handle hang hello honest honor hurry husband idiot ignore imagine inside instead island join joke judge kid kiss knock lady language lazy lie lips lie loved lunch machine magic mama master member memory mercy message mistake modern monster mouth murder nature neck nervous noise normal nurse office officer ocean pardon parents partner peace phone pig pity plane pocket poison police pray prepare pride prince princess prison protect proud punish pure queen quit rabbit race reality remain remind repeat rescue respect rid risk robot rule rush safe sake scared scream secret seem shadow share shine shirt shock shoe shop shoulder silly silver sir skin sky smell smoke soldier solve space spirit stage stomach stone storm strength stuff succeed suit supposed sword system taste team tear tend test thick thief thirty thousand threat tiny tongue tool tough tower trade travel trap treat trick truth twenty ugly uncle unless useless victory village visit war wave weapon weird whatever whenever wherever whisper wild wing wolf worse worst worth wound yours zero
don't doesn't didn't can't won't isn't aren't wasn't weren't couldn't wouldn't shouldn't haven't hasn't hadn't i'm i'll i've i'd you're you'll you've you'd he's she's it's we're we'll we've they're they'll they've that's what's there's here's let's who's
"""
}
