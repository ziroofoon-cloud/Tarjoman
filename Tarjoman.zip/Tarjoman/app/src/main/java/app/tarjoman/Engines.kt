package app.tarjoman

import android.content.Context
import com.google.android.gms.tasks.Tasks
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInferenceSession
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslateRemoteModel
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.common.model.DownloadConditions
import java.io.File

/** Normal mode: Google ML Kit, fully offline after the language packs are downloaded. */
object MlKit {
    private val cache = HashMap<String, Translator>()

    private fun code(l: String): String = when (l) {
        "fa" -> TranslateLanguage.PERSIAN
        "ja" -> TranslateLanguage.JAPANESE
        "ko" -> TranslateLanguage.KOREAN
        "zh" -> TranslateLanguage.CHINESE
        "ar" -> TranslateLanguage.ARABIC
        "es" -> TranslateLanguage.SPANISH
        else -> TranslateLanguage.ENGLISH
    }

    @Synchronized
    private fun get(s: String, d: String): Translator = cache.getOrPut("$s>$d") {
        Translation.getClient(
            TranslatorOptions.Builder().setSourceLanguage(code(s)).setTargetLanguage(code(d)).build()
        )
    }

    /** Blocking. True when the language pack is on the phone (English is built in). */
    fun isDownloaded(l: String): Boolean {
        if (l == "en") return true
        val m = TranslateRemoteModel.Builder(code(l)).build()
        return Tasks.await(RemoteModelManager.getInstance().isModelDownloaded(m)) == true
    }

    /** Blocking. Removes a downloaded language pack from the phone (English cannot be removed). */
    fun delete(l: String) {
        if (l == "en") return
        val m = TranslateRemoteModel.Builder(code(l)).build()
        Tasks.await(RemoteModelManager.getInstance().deleteDownloadedModel(m))
    }

    /** Blocking: call from a worker thread only. */
    fun ensure(s: String, d: String, stop: () -> Boolean = { false }, maxSec: Int = 45) {
        val t = get(s, d).downloadModelIfNeeded(DownloadConditions.Builder().build())
        val end = System.currentTimeMillis() + maxSec * 1000L
        // Waits in short steps (a plain await can hang for ever when Google's servers are unreachable) so Stop and a time limit work.
        while (true) {
            try {
                Tasks.await(t, 2, java.util.concurrent.TimeUnit.SECONDS)
                return
            } catch (e: java.util.concurrent.TimeoutException) {
                if (stop()) throw java.util.concurrent.CancellationException(L("متوقف شد"))
                if (System.currentTimeMillis() > end) throw java.io.IOException(L("بستهٔ زبان دانلود نشد (اینترنت یا دسترسی به سرور گوگل را بررسی کن)"))
            }
        }
    }

    /** One short piece of text; call [ensure] first. */
    fun one(text: String, s: String, d: String): String =
        if (text.isBlank()) text else Tasks.await(get(s, d).translate(text))

    fun translate(text: String, s: String, d: String, prog: (String) -> Unit): String {
        prog(L("آماده‌سازی بسته زبان…"))
        ensure(s, d)
        val t = get(s, d)
        prog(L("ترجمه…"))
        return text.split("\n").joinToString("\n") { line ->
            if (line.isBlank()) line else Tasks.await(t.translate(line))
        }
    }
}

/** Advanced mode: on-device LLM through MediaPipe (.task models). */
class LlmEngine(private val ctx: Context) {
    private var llm: LlmInference? = null
    private var loaded: String? = null

    @Synchronized
    fun load(f: File) {
        if (loaded == f.absolutePath && llm != null) return
        try { llm?.close() } catch (_: Throwable) {}
        llm = null
        loaded = null
        val b = LlmInference.LlmInferenceOptions.builder().setModelPath(f.absolutePath).setMaxTokens(1024)
        // CPU is the safest backend on a Snapdragon 720G; set through reflection so a different library version cannot break the build.
        try {
            val be = Class.forName("com.google.mediapipe.tasks.genai.llminference.LlmInference\$Backend")
            val cpu = be.enumConstants!!.first { (it as Enum<*>).name == "CPU" }
            LlmInference.LlmInferenceOptions.Builder::class.java.getMethod("setPreferredBackend", be).invoke(b, cpu)
        } catch (_: Throwable) {
        }
        llm = try {
            LlmInference.createFromOptions(ctx.applicationContext, b.build())
        } catch (e: Throwable) {
            // a half-written or stale speed cache (e.g. after an interrupted first load or after the file was moved) makes the load fail: delete it and try once more
            Models.deleteCaches(f)
            LlmInference.createFromOptions(ctx.applicationContext, b.build())
        }
        loaded = f.absolutePath
    }

    @Synchronized
    fun gen(prompt: String, slow: Boolean, hot: Boolean = false): String {
        val engine = llm ?: throw IllegalStateException("model not loaded")
        val so = LlmInferenceSession.LlmInferenceSessionOptions.builder()
            .setTopK(if (hot) 40 else if (slow) 24 else 1)
            .setTemperature(if (hot) 0.8f else if (slow) 0.35f else 0.1f)
            .build()
        val s = LlmInferenceSession.createFromOptions(engine, so)
        try {
            s.addQueryChunk(prompt)
            return s.generateResponse()
        } finally {
            try { s.close() } catch (_: Throwable) {}
        }
    }
}
