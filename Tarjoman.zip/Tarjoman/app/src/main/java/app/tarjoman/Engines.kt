package app.tarjoman

import android.content.Context
import com.google.android.gms.tasks.Tasks
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInferenceSession
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.common.model.DownloadConditions
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.SamplerConfig
import java.io.File

/** Normal mode: Google ML Kit, fully offline after the language packs are downloaded. */
object MlKit {
    private val cache = HashMap<String, Translator>()

    private fun code(l: String): String = when (l) {
        "fa" -> TranslateLanguage.PERSIAN
        "ja" -> TranslateLanguage.JAPANESE
        else -> TranslateLanguage.ENGLISH
    }

    @Synchronized
    private fun get(s: String, d: String): Translator = cache.getOrPut("$s>$d") {
        Translation.getClient(
            TranslatorOptions.Builder().setSourceLanguage(code(s)).setTargetLanguage(code(d)).build()
        )
    }

    /** Blocking: call from a worker thread only. */
    fun ensure(s: String, d: String) {
        Tasks.await(get(s, d).downloadModelIfNeeded(DownloadConditions.Builder().build()))
    }

    fun translate(text: String, s: String, d: String, prog: (String) -> Unit): String {
        prog("آماده‌سازی بسته زبان…")
        ensure(s, d)
        val t = get(s, d)
        prog("ترجمه…")
        return text.split("\n").joinToString("\n") { line ->
            if (line.isBlank()) line else Tasks.await(t.translate(line))
        }
    }
}

/** Advanced mode: on-device LLM through MediaPipe (.task models). */
class LlmEngine(private val ctx: Context) {
    private var llm: LlmInference? = null
    private var loaded: String? = null

    @Synchronized
    fun load(f: File) {
        if (loaded == f.absolutePath && llm != null) return
        try { llm?.close() } catch (_: Throwable) {}
        llm = null
        loaded = null
        val b = LlmInference.LlmInferenceOptions.builder().setModelPath(f.absolutePath).setMaxTokens(1024)
        // CPU is the safest backend on a Snapdragon 720G; set through reflection so a different library version cannot break the build.
        try {
            val be = Class.forName("com.google.mediapipe.tasks.genai.llminference.LlmInference\$Backend")
            val cpu = be.enumConstants!!.first { (it as Enum<*>).name == "CPU" }
            LlmInference.LlmInferenceOptions.Builder::class.java.getMethod("setPreferredBackend", be).invoke(b, cpu)
        } catch (_: Throwable) {
        }
        llm = LlmInference.createFromOptions(ctx.applicationContext, b.build())
        loaded = f.absolutePath
    }

    @Synchronized
    fun gen(prompt: String, slow: Boolean): String {
        val engine = llm ?: throw IllegalStateException("model not loaded")
        val so = LlmInferenceSession.LlmInferenceSessionOptions.builder()
            .setTopK(if (slow) 24 else 1)
            .setTemperature(if (slow) 0.35f else 0.1f)
            .build()
        val s = LlmInferenceSession.createFromOptions(engine, so)
        try {
            s.addQueryChunk(prompt)
            return s.generateResponse()
        } finally {
            try { s.close() } catch (_: Throwable) {}
        }
    }
}

/** Advanced mode, newer format: .litertlm models through Google LiteRT-LM (chat template is built into the file). */
class LiteRtEngine(private val ctx: Context) {
    private var engine: Engine? = null
    private var loaded: String? = null

    @Synchronized
    fun load(f: File) {
        if (loaded == f.absolutePath && engine != null) return
        try { engine?.close() } catch (_: Throwable) {}
        engine = null
        loaded = null
        val e = Engine(EngineConfig(modelPath = f.absolutePath, backend = Backend.CPU(), cacheDir = ctx.cacheDir.path))
        e.initialize()
        engine = e
        loaded = f.absolutePath
    }

    @Synchronized
    fun gen(system: String, user: String, slow: Boolean): String {
        val e = engine ?: throw IllegalStateException("model not loaded")
        val cfg = ConversationConfig(
            systemInstruction = Contents.of(system),
            samplerConfig = SamplerConfig(topK = if (slow) 24 else 1, topP = 0.95, temperature = if (slow) 0.35 else 0.1)
        )
        e.createConversation(cfg).use { c ->
            return c.sendMessage(user).toString()
        }
    }
}
