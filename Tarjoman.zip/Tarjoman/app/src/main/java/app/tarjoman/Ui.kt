package app.tarjoman

import android.content.Context
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.drawable.RippleDrawable
import android.widget.FrameLayout
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

object C {
    var BG = 0xFF0E1116.toInt()
    var CARD = 0xFF161B22.toInt()
    var CARD2 = 0xFF1F2630.toInt()
    var ACC = 0xFF6C9EFF.toInt()
    var ONACC = 0xFF0B1220.toInt()   // text/icon colour on top of ACC
    var TXT = 0xFFE6EAF0.toInt()
    var SUB = 0xFF8B95A5.toInt()
    var OK = 0xFF3DDC84.toInt()
    var BAD = 0xFFFF6B6B.toInt()
    var WARN = 0xFFF2A93B.toInt()
    var STROKE = 0xFF252D39.toInt()  // card border
    var BAR = 0xFF12171E.toInt()     // bottom tab bar
    var LINE = 0xFF252D39.toInt()    // thin separator lines
    var classic = false
    var dark = true
    var R_CARD = 18
    var R_BTN = 14
    var R_IN = 12

    /** Four looks: modern light/dark and classic (paper) light/dark. Call before building any view. */
    fun apply(classic: Boolean, dark: Boolean) {
        this.classic = classic
        this.dark = dark
        if (classic) {
            R_CARD = 6; R_BTN = 4; R_IN = 4
            if (dark) {
                BG = 0xFF1A1612.toInt(); CARD = 0xFF241F19.toInt(); CARD2 = 0xFF302A21.toInt()
                ACC = 0xFFD4A464.toInt(); ONACC = 0xFF1A1612.toInt(); TXT = 0xFFEADFC8.toInt(); SUB = 0xFF9C8E75.toInt()
                OK = 0xFF8DBB7A.toInt(); BAD = 0xFFE07A6A.toInt(); WARN = 0xFFE0B25A.toInt()
                STROKE = 0xFF4A3F2F.toInt(); BAR = 0xFF211C16.toInt(); LINE = 0xFF4A3F2F.toInt()
            } else {
                BG = 0xFFF4ECD8.toInt(); CARD = 0xFFFBF6E9.toInt(); CARD2 = 0xFFEFE4CB.toInt()
                ACC = 0xFF8C2F39.toInt(); ONACC = 0xFFFFF8EA.toInt(); TXT = 0xFF2A2118.toInt(); SUB = 0xFF76674F.toInt()
                OK = 0xFF3F7A4F.toInt(); BAD = 0xFFA83232.toInt(); WARN = 0xFFA66A12.toInt()
                STROKE = 0xFFD2BE92.toInt(); BAR = 0xFFEBDFC2.toInt(); LINE = 0xFFC9B27E.toInt()
            }
        } else {
            R_CARD = 18; R_BTN = 14; R_IN = 12
            if (dark) {
                BG = 0xFF0E1116.toInt(); CARD = 0xFF161B22.toInt(); CARD2 = 0xFF1F2630.toInt()
                ACC = 0xFF6C9EFF.toInt(); ONACC = 0xFF0B1220.toInt(); TXT = 0xFFE6EAF0.toInt(); SUB = 0xFF8B95A5.toInt()
                OK = 0xFF3DDC84.toInt(); BAD = 0xFFFF6B6B.toInt(); WARN = 0xFFF2A93B.toInt()
                STROKE = 0xFF252D39.toInt(); BAR = 0xFF12171E.toInt(); LINE = 0xFF252D39.toInt()
            } else {
                BG = 0xFFF3F5F9.toInt(); CARD = 0xFFFFFFFF.toInt(); CARD2 = 0xFFEBEEF4.toInt()
                ACC = 0xFF2F6BFF.toInt(); ONACC = 0xFFFFFFFF.toInt(); TXT = 0xFF121722.toInt(); SUB = 0xFF667085.toInt()
                OK = 0xFF138A4B.toInt(); BAD = 0xFFD92D20.toInt(); WARN = 0xFFB54708.toInt()
                STROKE = 0xFFE1E5EC.toInt(); BAR = 0xFFFFFFFF.toInt(); LINE = 0xFFE1E5EC.toInt()
            }
        }
    }

    /** Reads the saved choice (system / light / dark  +  modern / classic) and applies it. Returns true when dark. */
    fun setup(ctx: Context, cfg: Cfg): Boolean {
        val d = when (cfg.themeMode) {
            "dark" -> true
            "light" -> false
            else -> (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        }
        apply(cfg.look == "classic", d)
        return d
    }
}

const val MATCH = -1
const val WRAP = -2

class Ui(private val ctx: Context) {
    private val dens = ctx.resources.displayMetrics.density
    fun dp(v: Int): Int = (v * dens).toInt()

    fun rect(color: Int, r: Int = 12, stroke: Int = 0): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    /** Fill + soft press ripple, clipped to the same rounded shape. */
    fun pressable(fill: Int, r: Int, stroke: Int, ripple: Int): android.graphics.drawable.Drawable =
        RippleDrawable(ColorStateList.valueOf(ripple), rect(fill, r, stroke), rect(Color.WHITE, r))

    private fun face(bold: Boolean): Typeface =
        if (C.classic) Typeface.create(Typeface.SERIF, if (bold) Typeface.BOLD else Typeface.NORMAL)
        else if (bold) Typeface.create("sans-serif-medium", Typeface.NORMAL)
        else Typeface.DEFAULT

    fun tv(t: String, size: Float = 14f, color: Int = C.TXT, bold: Boolean = false): TextView = TextView(ctx).apply {
        text = t
        textSize = size
        setTextColor(color)
        typeface = face(bold)
    }

    fun btn(t: String, filled: Boolean = true, onClick: () -> Unit): TextView =
        tv(t, 14f, if (filled) C.ONACC else C.ACC, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(11), dp(14), dp(11))
            background = if (filled) pressable(C.ACC, C.R_BTN, 0, 0x33FFFFFF)
            else pressable(Color.TRANSPARENT, C.R_BTN, C.ACC, (C.ACC and 0x00FFFFFF) or 0x22000000)
            setOnClickListener { onClick() }
        }

    /** Square button with a drawn icon (tonal = soft background, else filled with the accent colour). */
    fun iconBtn(kind: String, size: Int = 44, tonal: Boolean = true, onClick: () -> Unit): FrameLayout =
        FrameLayout(ctx).apply {
            background = if (tonal) pressable(C.CARD2, C.R_BTN, C.STROKE, (C.ACC and 0x00FFFFFF) or 0x22000000)
            else pressable(C.ACC, C.R_BTN, 0, 0x33FFFFFF)
            isClickable = true
            addView(IconView(ctx, kind, if (tonal) C.ACC else C.ONACC), FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
            layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
            setOnClickListener { onClick() }
        }

    /** Small rounded label: status ("installed"), importance ("required"), etc. */
    fun chip(t: String, color: Int): TextView = tv(t, 11f, color, true).apply {
        gravity = Gravity.CENTER
        setSingleLine(true)
        setPadding(dp(9), dp(3), dp(9), dp(3))
        background = rect((color and 0x00FFFFFF) or 0x26000000, if (C.classic) 4 else 10, (color and 0x00FFFFFF) or 0x55000000)
    }

    fun card(): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = rect(C.CARD, C.R_CARD, C.STROKE)
    }

    fun vbox(): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(10), dp(14), dp(14))
    }

    fun hbox(): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    fun lp(w: Int = MATCH, h: Int = WRAP, top: Int = 0, weight: Float = 0f): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(w, h, weight).apply { topMargin = dp(top) }

    fun hlp(weight: Float = 1f, start: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(0, WRAP, weight).apply { marginStart = dp(start) }

    fun edit(hint: String, lines: Int = 1, secret: Boolean = false): EditText = EditText(ctx).apply {
        this.hint = hint
        setHintTextColor(C.SUB)
        setTextColor(C.TXT)
        textSize = 16f
        setPadding(dp(12), dp(10), dp(12), dp(10))
        background = rect(C.CARD2, C.R_IN, C.STROKE)
        textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        if (lines > 1) {
            minLines = lines
            gravity = Gravity.TOP
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        } else {
            setSingleLine(true)
            inputType = if (secret) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_CLASS_TEXT
        }
    }

    fun seg(opts: List<String>, sel: Int, onSel: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rect(C.CARD2, C.R_BTN + 2, C.STROKE)
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }
        val views = ArrayList<TextView>()
        fun paint(s: Int) {
            views.forEachIndexed { i, v ->
                v.background = if (i == s) rect(C.ACC, C.R_BTN) else rect(Color.TRANSPARENT, C.R_BTN)
                v.setTextColor(if (i == s) C.ONACC else C.SUB)
            }
        }
        opts.forEachIndexed { i, o ->
            val v = tv(o, 13f, C.SUB, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(6), dp(9), dp(6), dp(9))
                setOnClickListener { paint(i); onSel(i) }
            }
            views.add(v)
            row.addView(v, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        paint(sel)
        return row
    }

    fun slider(label: String, lo: Int, hi: Int, cur: Int, onChange: (Int) -> Unit): LinearLayout {
        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val t = tv(label + ": " + cur + "%", 12f, C.SUB)
        val sb = SeekBar(ctx)
        sb.progressTintList = ColorStateList.valueOf(C.ACC)
        sb.thumbTintList = ColorStateList.valueOf(C.ACC)
        sb.max = hi - lo
        sb.progress = (cur - lo).coerceIn(0, hi - lo)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + lo
                t.text = label + ": " + v + "%"
                if (fromUser) onChange(v)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(t)
        box.addView(sb, LinearLayout.LayoutParams(MATCH, WRAP))
        return box
    }
}
