package app.tarjoman

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

object C {
    val BG = 0xFF0F1318.toInt()
    val CARD = 0xFF1A2029.toInt()
    val CARD2 = 0xFF262E3A.toInt()
    val ACC = 0xFF4F8CFF.toInt()
    val TXT = 0xFFE8ECF1.toInt()
    val SUB = 0xFF8A94A3.toInt()
    val OK = 0xFF3DDC84.toInt()
    val BAD = 0xFFFF6B6B.toInt()
}

const val MATCH = -1
const val WRAP = -2

class Ui(private val ctx: Context) {
    private val dens = ctx.resources.displayMetrics.density
    fun dp(v: Int): Int = (v * dens).toInt()

    fun rect(color: Int, r: Int = 12, stroke: Int = 0): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    fun tv(t: String, size: Float = 14f, color: Int = C.TXT, bold: Boolean = false): TextView = TextView(ctx).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    fun btn(t: String, filled: Boolean = true, onClick: () -> Unit): TextView =
        tv(t, 14f, if (filled) Color.WHITE else C.ACC, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = if (filled) rect(C.ACC, 20) else rect(Color.TRANSPARENT, 20, C.ACC)
            setOnClickListener { onClick() }
        }

    fun card(): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        background = rect(C.CARD, 16)
    }

    fun vbox(): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(10), dp(14), dp(14))
    }

    fun hbox(): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    fun lp(w: Int = MATCH, h: Int = WRAP, top: Int = 0, weight: Float = 0f): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(w, h, weight).apply { topMargin = dp(top) }

    fun hlp(weight: Float = 1f, start: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(0, WRAP, weight).apply { marginStart = dp(start) }

    fun edit(hint: String, lines: Int = 1, secret: Boolean = false): EditText = EditText(ctx).apply {
        this.hint = hint
        setHintTextColor(C.SUB)
        setTextColor(C.TXT)
        textSize = 16f
        setPadding(dp(12), dp(10), dp(12), dp(10))
        background = rect(C.CARD2, 12)
        textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        if (lines > 1) {
            minLines = lines
            gravity = Gravity.TOP
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        } else {
            setSingleLine(true)
            inputType = if (secret) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_CLASS_TEXT
        }
    }

    fun seg(opts: List<String>, sel: Int, onSel: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rect(C.CARD2, 18)
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }
        val views = ArrayList<TextView>()
        fun paint(s: Int) {
            views.forEachIndexed { i, v ->
                v.background = if (i == s) rect(C.ACC, 16) else rect(Color.TRANSPARENT, 16)
                v.setTextColor(if (i == s) Color.WHITE else C.SUB)
            }
        }
        opts.forEachIndexed { i, o ->
            val v = tv(o, 13f, C.SUB, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(6), dp(8), dp(6), dp(8))
                setOnClickListener { paint(i); onSel(i) }
            }
            views.add(v)
            row.addView(v, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        paint(sel)
        return row
    }
}
