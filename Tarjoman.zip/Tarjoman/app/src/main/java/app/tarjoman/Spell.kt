package app.tarjoman

import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

/** Small English spell helper (typing "helo" finds "hello"), the alphabet-letter answer, and written pronunciation. */
object Spell {
    private val vocab: HashSet<String> by lazy {
        val s = HashSet<String>(8192)
        s.addAll(Lex.all())
        s.addAll(Dic.enWords())
        for (w in Words.MORE) { val x = w.lowercase().trim(); if (x.isNotEmpty() && x.all { it in 'a'..'z' }) s.add(x) }
        for (w in Words2.LIST) { val x = w.lowercase().trim(); if (x.isNotEmpty() && x.all { it in 'a'..'z' }) s.add(x) }
        s
    }

    private const val ROWS = "qwertyuiop asdfghjkl zxcvbnm"
    private fun adjacent(a: Char, b: Char): Boolean {
        for (r in ROWS.split(' ')) {
            val i = r.indexOf(a); val j = r.indexOf(b)
            if (i >= 0 && j >= 0 && kotlin.math.abs(i - j) == 1) return true
        }
        val ra = ROWS.split(' ').indexOfFirst { a in it }; val rb = ROWS.split(' ').indexOfFirst { b in it }
        if (ra >= 0 && rb >= 0 && kotlin.math.abs(ra - rb) == 1) {
            val i = ROWS.split(' ')[ra].indexOf(a); val j = ROWS.split(' ')[rb].indexOf(b)
            return kotlin.math.abs(i - j) <= 1
        }
        return false
    }

    fun known(w: String): Boolean = w in vocab || Lex.has(w)

    /** The word itself is in the wide word list (no stem rules; see Lex.hasWide). */
    fun inVocab(w: String): Boolean = w in vocab

    class Fix(val from: String, val to: String, val cost: Int)

    /** Best correction of one lower-case word, or null (known word, too short, or nothing at distance 1). Lower cost = more likely typo. */
    fun suggest(word: String): Fix? {
        val w = word.lowercase()
        if (w.length < 3 || w.length > 20 || !w.all { it in 'a'..'z' } || known(w)) return null
        if (Abbr.whole(w) != null || Abbr.whole(w.uppercase()) != null) return null      // LOL, BRB, HD ... are not typos
        var best: Fix? = null
        fun consider(c: String, cost: Int) {
            if (c == w || (c !in vocab && !Lex.has(c))) return
            val common = if (Lex.has(c)) 0 else 1
            val total = cost * 2 + common
            if (best == null || total < best!!.cost) best = Fix(word, c, total)
        }
        val az = "abcdefghijklmnopqrstuvwxyz"
        for (i in 0 until w.length) {
            consider(w.removeRange(i, i + 1), if (i > 0 && w[i - 1] == w[i]) 1 else 3)             // an extra letter (a tripled letter first: "helllo")
            for (ch in az) {
                if (ch != w[i]) consider(w.substring(0, i) + ch + w.substring(i + 1), if (adjacent(ch, w[i])) 2 else 4)   // wrong letter
            }
        }
        for (i in 0..w.length) for (ch in az) consider(w.substring(0, i) + ch + w.substring(i), if (i > 0 && i <= w.length && (w[i - 1] == ch || (i < w.length && w[i] == ch))) 0 else 3)   // a missing letter (doubled letters first)
        for (i in 0 until w.length - 1) consider(w.substring(0, i) + w[i + 1] + w[i] + w.substring(i + 2), 1)   // two letters swapped
        return best
    }

    class Result(val text: String, val changes: List<Fix>, val suggestedOnly: List<Fix>)

    /** Corrects the words of [t]. A fix with cost <= [autoCost] is applied; others are only listed. A single word is always fixed. */
    fun fix(t: String, autoCost: Int = 4): Result {
        val toks = Regex("[A-Za-z]+").findAll(t).toList()
        val single = toks.size == 1 && t.trim().length <= 24
        val applied = ArrayList<Fix>()
        val only = ArrayList<Fix>()
        val sb = StringBuilder()
        var last = 0
        for ((i, m) in toks.withIndex()) {
            sb.append(t, last, m.range.first)
            last = m.range.last + 1
            val w = m.value
            val capital = w[0].isUpperCase() && !(single)
            val allCaps = w.length > 1 && w.all { it.isUpperCase() }
            val f = if (capital || allCaps) null else suggest(w)
            if (f == null) { sb.append(w); continue }
            // keep the first capital when the word was typed with one
            val to = if (w[0].isUpperCase()) f.to.replaceFirstChar { it.uppercaseChar() } else f.to
            // A lone word is fixed only when the fix is a very likely typo (doubled / swapped / neighbouring key); a rare word or
            // slang that merely looks like another word is left as typed and only suggested.
            if ((single && f.cost <= 5) || f.cost <= autoCost) { sb.append(to); applied.add(Fix(w, to, f.cost)) }
            else { sb.append(w); only.add(Fix(w, to, f.cost)) }
        }
        sb.append(t, last, t.length)
        return Result(sb.toString(), applied, only)
    }

    // ---- a single letter
    private val faOrd = listOf("اول", "دوم", "سوم", "چهارم", "پنجم", "ششم", "هفتم", "هشتم", "نهم", "دهم", "یازدهم", "دوازدهم", "سیزدهم", "چهاردهم", "پانزدهم", "شانزدهم", "هفدهم", "هجدهم", "نوزدهم", "بیستم", "بیست و یکم", "بیست و دوم", "بیست و سوم", "بیست و چهارم", "بیست و پنجم", "بیست و ششم")
    private fun enOrd(n: Int): String = n.toString() + when { n % 100 in 11..13 -> "th"; n % 10 == 1 -> "st"; n % 10 == 2 -> "nd"; n % 10 == 3 -> "rd"; else -> "th" }

    /** "S" -> the 19th letter of the English alphabet (null when [t] is not one Latin letter). */
    fun letter(t: String, d: String): String? {
        val x = t.trim()
        if (x.length != 1 || x[0].lowercaseChar() !in 'a'..'z') return null
        val n = x[0].lowercaseChar() - 'a' + 1
        val shown = x[0].uppercaseChar().toString() + " " + x[0].lowercaseChar()
        return when (d) {
            "fa" -> "حرف " + faOrd[n - 1] + " الفبای انگلیسی ($shown)"
            "ja" -> "英語のアルファベットの" + n + "番目の文字 ($shown)"
            else -> "the " + enOrd(n) + " letter of the English alphabet ($shown)"
        }
    }

    // ---- written pronunciation (needs the internet; one English word)
    private val ipaCache = HashMap<String, String>()

    fun ipa(word: String): String? {
        val w = word.trim().lowercase()
        if (w.isEmpty() || !w.all { it in 'a'..'z' || it == '\'' || it == '-' }) return null
        ipaCache[w]?.let { return it.ifEmpty { null } }
        var res = ""
        try {
            val c = URL("https://api.dictionaryapi.dev/api/v2/entries/en/" + java.net.URLEncoder.encode(w, "UTF-8")).openConnection() as HttpURLConnection
            c.connectTimeout = 5000; c.readTimeout = 5000
            if (c.responseCode == 200) {
                val arr = JSONArray(c.inputStream.bufferedReader().readText())
                outer@ for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val ph = o.optString("phonetic")
                    if (ph.isNotBlank()) { res = ph; break }
                    val ps = o.optJSONArray("phonetics") ?: continue
                    for (j in 0 until ps.length()) { val t = ps.getJSONObject(j).optString("text"); if (t.isNotBlank()) { res = t; break@outer } }
                }
            }
        } catch (_: Throwable) {
        }
        ipaCache[w] = res
        return res.ifEmpty { null }
    }
}
