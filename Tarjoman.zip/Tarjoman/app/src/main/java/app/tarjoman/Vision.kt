package app.tarjoman

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

/**
 * Optional: a cloud vision model (any OpenAI-compatible API, e.g. the free Gemini key) reads and translates the text boxes of a
 * picture. The phone still finds WHERE the text is (Ocr / Balloons); the model sees the whole page with the boxes drawn on it as
 * numbered red rectangles, reads each box exactly, and translates it with the whole page as context (names, who speaks, jokes).
 * This is what a small on-device reader cannot do. Off by default (the picture is sent to the API provider).
 */
object Vision {
    fun usable(c: Cfg, ctx: Context): Boolean = c.visionOcr == 1 && c.apiKey.isNotBlank() && Net.isOnline(ctx)

    private fun langName(l: String) = when (l) {
        "en" -> "English"; "fa" -> "Persian"; "ja" -> "Japanese"; "ko" -> "Korean"; "zh" -> "Chinese"; "ar" -> "Arabic"; "es" -> "Spanish"
        else -> l
    }

    // What was said on the pages before (chapter / ZIP): names and the story stay consistent from page to page.
    private val story = ArrayList<String>()
    @Synchronized fun resetStory() { story.clear() }
    @Synchronized private fun storyText(): String = story.takeLast(12).joinToString("\n")
    @Synchronized private fun remember(src: String, tr: String) {
        story.add(src.replace("\n", " ").take(160) + " => " + tr.replace("\n", " ").take(200))
        while (story.size > 40) story.removeAt(0)
    }

    private const val GROUP = 25        // boxes per request
    private const val LONG_SIDE = 1600  // the picture is sent at most this big

    /** The page with the group's boxes drawn as numbered red rectangles (scaled so the long side is at most [LONG_SIDE]). */
    private fun annotate(bmp: Bitmap, group: List<OBlock>): ByteArray {
        val k = minOf(1f, LONG_SIDE.toFloat() / maxOf(bmp.width, bmp.height))
        val w = (bmp.width * k).toInt().coerceAtLeast(1)
        val h = (bmp.height * k).toInt().coerceAtLeast(1)
        val img = Bitmap.createScaledBitmap(bmp, w, h, true).copy(Bitmap.Config.ARGB_8888, true)
        val cv = Canvas(img)
        val sw = maxOf(2f, w / 450f)
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = sw; color = Color.rgb(230, 30, 30) }
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.rgb(230, 30, 30) }
        val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = maxOf(16f, w / 38f); isFakeBoldText = true }
        group.forEachIndexed { i, b ->
            val r = Rect((b.rect.left * k).toInt(), (b.rect.top * k).toInt(), (b.rect.right * k).toInt(), (b.rect.bottom * k).toInt())
            r.inset(-(sw * 2).toInt(), -(sw * 2).toInt())
            cv.drawRect(r, line)
            val n = (i + 1).toString()
            val tw = txt.measureText(n)
            val lh = txt.textSize * 1.15f
            val x = r.left.toFloat().coerceIn(0f, maxOf(0f, w - tw - 8f))
            val y = (r.top - lh).coerceAtLeast(0f)
            cv.drawRect(x, y, x + tw + 8f, y + lh, fill)
            cv.drawText(n, x + 4f, y + lh - txt.textSize * 0.22f, txt)
        }
        val bo = ByteArrayOutputStream()
        img.compress(Bitmap.CompressFormat.JPEG, 82, bo)
        img.recycle()
        return bo.toByteArray()
    }

    private fun prompt(s: String, d: String, n: Int, glossary: String, story: String): String {
        val sb = StringBuilder()
        sb.append("This picture is a page from a comic / manga / webtoon / screenshot. ")
        sb.append("Red numbered rectangles (1 to ").append(n).append(") mark text regions found automatically; a rectangle can be a little too small, too big or wrong. ")
        sb.append("For every number: (1) read the text inside that region EXACTLY as written in the picture (language: ").append(langName(s))
        sb.append("); fix a letter only when the picture clearly shows the right one; do not add or invent words; if the region has no text, use an empty string. ")
        sb.append("(2) Translate it into ").append(langName(d)).append(" the way the character would really say it, using the whole page as context ")
        sb.append("(who speaks, names, jokes, sound effects); keep names consistent across the page and keep the tone (rude, polite, shouting). ")
        if (d == "fa") sb.append("Write natural, fluent Persian (colloquial for dialogue) with correct half-spaces (نیم‌فاصله) and Persian punctuation. ")
        if (glossary.isNotBlank()) sb.append("Always use these translations for these terms (one per line, original=translation):\n").append(glossary.trim()).append("\n")
        if (story.isNotBlank()) sb.append("The story so far on the previous pages (original => translation), for names and context only, do not translate it again:\n").append(story).append("\n")
        sb.append("Return ONLY a JSON array, no other text, no markdown: [{\"n\":1,\"src\":\"...\",\"tr\":\"...\"}, ...] with one object per number.")
        return sb.toString()
    }

    private fun parse(reply: String): Map<Int, Pair<String, String>> {
        var t = reply.trim()
        val a = t.indexOf('['); val b = t.lastIndexOf(']')
        if (a < 0 || b <= a) return emptyMap()
        t = t.substring(a, b + 1)
        val out = HashMap<Int, Pair<String, String>>()
        val arr = JSONArray(t)
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val n = o.optInt("n", -1)
            if (n < 1) continue
            out[n] = Pair(o.optString("src", "").trim(), o.optString("tr", "").trim())
        }
        return out
    }

    /** Network hiccups, rate limits (429) and busy servers (5xx) are common with free keys: try up to 3 times. */
    private fun ask(c: Cfg, prompt: String, jpeg: ByteArray): String {
        var last: Throwable? = null
        for (attempt in 1..3) {
            try { return ask1(c, prompt, jpeg) } catch (e: Throwable) {
                last = e
                val m = (e.message ?: "") + (e.cause?.message ?: "")
                if (m.contains("401") || m.contains("403") || m.contains("400") || m.contains("404")) break   // a wrong key / model does not get better by waiting
                try { Thread.sleep(2000L * attempt) } catch (_: InterruptedException) { break }
            }
        }
        throw last ?: IllegalStateException("API")
    }

    /** Tiny text request to check the address, the key and the model; returns "OK" or the error text. */
    fun test(c: Cfg): String = try {
        val r = Online.chatApi(c, "Reply with the single word OK.", "ping")
        "OK · " + c.apiModel + " · " + r.take(40)
    } catch (e: Throwable) { (e.cause?.message ?: e.message ?: e.javaClass.simpleName).take(300) }

    private fun ask1(c: Cfg, prompt: String, jpeg: ByteArray): String {
        val content = JSONArray()
            .put(JSONObject().put("type", "text").put("text", prompt))
            .put(JSONObject().put("type", "image_url").put("image_url",
                JSONObject().put("url", "data:image/jpeg;base64," + Base64.encodeToString(jpeg, Base64.NO_WRAP))))
        val msgs = JSONArray().put(JSONObject().put("role", "user").put("content", content))
        val body = JSONObject().put("model", c.apiModel).put("temperature", 0.2).put("messages", msgs).toString()
        val r = Net.postJson(c.apiUrl, body, mapOf("Authorization" to "Bearer " + c.apiKey.trim()), c, 120000)
        return JSONObject(r).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
    }

    /**
     * Reads (the texts of [blocks] are replaced by the model's reading when it gave one) and translates every block.
     * Returns the translations and the first error, or null when the model could not be used at all (the caller then
     * translates the normal way). Blocks the model skipped are translated by the normal engine.
     */
    fun translateBlocks(tr: Tr, c: Cfg, bmp: Bitmap, blocks: List<OBlock>, s: String, d: String, fresh: Boolean, useStory: Boolean = false, prog: (String) -> Unit): Pair<List<String>, String?>? {
        val outs = arrayOfNulls<String>(blocks.size)
        var okGroups = 0
        var err: String? = null
        var from = 0
        while (from < blocks.size) {
            val idx = (from until minOf(from + GROUP, blocks.size)).toList()
            from += GROUP
            prog(L("هوش مصنوعی صفحه را می‌خواند…") + " " + (idx.last() + 1) + "/" + blocks.size)
            try {
                val reply = ask(c, prompt(s, d, idx.size, c.glossary, if (useStory) storyText() else ""), annotate(bmp, idx.map { blocks[it] }))
                val m = parse(reply)
                if (m.isEmpty()) continue
                okGroups++
                idx.forEachIndexed { k, j ->
                    val p = m[k + 1] ?: return@forEachIndexed
                    var t = p.second
                    if (t.isBlank()) return@forEachIndexed
                    if (d == "fa") t = Fa.fix(t) else if (d == "en") t = Pre.enOut(t)
                    if (p.first.isNotBlank()) blocks[j].text = p.first
                    outs[j] = t
                    if (useStory) remember(blocks[j].text, t)
                }
            } catch (e: Throwable) {
                if (err == null) err = (e.cause?.message ?: e.message ?: e.javaClass.simpleName).take(120)
            }
        }
        if (okGroups == 0) return null
        // blocks the model skipped: the normal engine
        val miss = blocks.indices.filter { outs[it] == null }
        var firstErr: String? = null
        if (miss.isNotEmpty()) {
            val (o2, e2) = tr.translateMany(miss.map { blocks[it].text }, s, d, fresh, prog)
            miss.forEachIndexed { k, j -> outs[j] = o2[k] }
            firstErr = e2
        }
        return Pair(blocks.indices.map { outs[it] ?: blocks[it].text }, firstErr)
    }
}
