package app.tarjoman

/**
 * Names the translator leaves in Latin letters ("Sasaki", "Itadori") are written in Persian letters, the way Japanese names are
 * usually transliterated (ساساکی، ایتادوری). Only for translations into Persian, only capitalized words that are valid Japanese
 * romanization and are not English words, so ordinary English, abbreviations and brand names stay untouched.
 */
object Translit {
    private val word = Regex("\\b(?:[A-Z][A-Za-z]{2,15}|[a-z]{4,15})\\b")
    private val romaji = Regex("^(?:(?:[kgszjtdnhbpmr]?y[auo]|sh[aiueo]|ch[aiueo]|ts[u]|j[aiueo]|f[u]|[kgsztdnhbpmrwyf][aiueo]|[aiueo])(?:n(?![aiueoy]))?|n(?![aiueoy])|(?:kk|ss|tt|pp)[aiueo])+$")

    private fun cons(c: String): String = when (c) {
        "k" -> "ک"; "g" -> "گ"; "s" -> "س"; "sh" -> "ش"; "z" -> "ز"; "j" -> "ج"; "t" -> "ت"; "ch" -> "چ"; "ts" -> "ت‌س"
        "d" -> "د"; "n" -> "ن"; "h" -> "ه"; "f" -> "ف"; "b" -> "ب"; "p" -> "پ"; "m" -> "م"; "y" -> "ی"; "r" -> "ر"; "w" -> "و"
        else -> ""
    }

    /** One romaji word -> Persian letters (null when it is not a plausible Japanese name). */
    fun romajiToFa(w: String): String? {
        val low = w.lowercase()
        if (!romaji.matches(low)) return null
        if (Spell.known(low)) return null
        val sb = StringBuilder()
        var i = 0
        while (i < low.length) {
            var c = ""
            for (len in intArrayOf(2, 1)) {
                if (i + len <= low.length) {
                    val s = low.substring(i, i + len)
                    if (s in setOf("sh", "ch", "ts") || (len == 1 && s in setOf("k","g","s","z","j","t","d","n","h","f","b","p","m","y","r","w"))) { c = s; break }
                }
            }
            if (c.isNotEmpty()) {
                val after = i + c.length
                // doubled consonant: written once
                var skip = 0
                if (after < low.length && low[after] == c[0] && c.length == 1 && c != "n") skip = 1
                val v = if (after + skip < low.length && low[after + skip] in "aiueo") low[after + skip] else null
                if (c == "n" && v == null) { sb.append("ن"); i = after + skip; continue }
                sb.append(cons(c))
                i = after + skip
                if (v != null) {
                    sb.append(when (v) { 'a' -> "ا"; 'i' -> "ی"; 'u' -> "و"; 'o' -> "و"; else -> "" })
                    i++
                }
            } else {
                val v = low[i]
                val first = sb.isEmpty()
                sb.append(when (v) {
                    'a' -> "ا"
                    'i' -> if (first) "ای" else "ی"
                    'u' -> if (first) "او" else "و"
                    'o' -> if (first) "او" else "و"
                    else -> if (first) "ا" else ""
                })
                i++
            }
        }
        return sb.toString().ifEmpty { null }
    }

    /** Persian translation with leftover Latin names -> the names in Persian letters. Other text is returned unchanged. */
    fun names(t: String): String {
        if (t.none { it in '؀'..'ۿ' }) return t
        return word.replace(t) { m -> romajiToFa(m.value) ?: m.value }
    }
}
