package app.tarjoman

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

/** Online translation: several free sources tried in order (works with or without a proxy/VPN). */
object Online {
    class Out(val text: String, val provider: String)

    /** The source that worked last time is tried first. */
    @Volatile private var lastGood = ""
    private const val TO = 9000
    private val lingvaHosts = listOf("lingva.ml", "lingva.garudalinux.org", "translate.plausibility.cloud")

    fun translate(text: String, s: String, d: String, c: Cfg, alt: Boolean = false): Out {
        val errs = ArrayList<String>()
        val all: List<Triple<String, Int, (String) -> String>> = listOf(
            Triple("Google", 1000, { t: String -> gtx(t, s, d, c) }),
            Triple("Google-2", 1000, { t: String -> chromeEx(t, s, d, c) }),
            Triple("Google-3", 700, { t: String -> gmobile(t, s, d, c) }),
            Triple("Microsoft", 1500, { t: String -> msEdge(t, s, d, c) }),
            Triple("Lingva", 900, { t: String -> lingva(t, s, d, c) }),
            Triple("MyMemory", 450, { t: String -> myMemory(t, s, d, c) })
        )
        // "translate again" tries another source first, so the answer can differ
        val first = if (lastGood.isEmpty()) c.onProv else lastGood
        val providers = all.sortedBy { if ((it.first == first) != alt) 0 else 1 }
        var googleDown = false
        for ((name, limit, fn) in providers) {
            // If Google is unreachable (no VPN), do not wait for its other endpoints too.
            if (name.startsWith("Google") && googleDown) continue
            try {
                val out = Prompts.chunks(text, limit).joinToString("\n") { if (it.isBlank()) it else fn(it) }
                if (out.isNotBlank()) { lastGood = name; if (c.onProv != name) c.onProv = name; return Out(out, name) }
            } catch (e: Exception) {
                if (name.startsWith("Google")) googleDown = true
                errs.add(name + ": " + (e.message ?: "error"))
            }
        }
        throw IOException(errs.joinToString(" | "))
    }

    // Microsoft Edge's built-in translator: free, good Persian, and often reachable when Google is blocked.
    @Volatile private var msTok = ""
    @Volatile private var msExp = 0L

    private fun msToken(c: Cfg, force: Boolean): String {
        if (!force && msTok.isNotEmpty() && System.currentTimeMillis() < msExp) return msTok
        val t = Net.get("https://edge.microsoft.com/translate/auth", c, TO).trim()
        if (t.length < 20) throw IOException("no token")
        msTok = t
        msExp = System.currentTimeMillis() + 8 * 60 * 1000L
        return t
    }

    private fun msEdge(t: String, s: String, d: String, c: Cfg): String {
        val body = JSONArray().put(JSONObject().put("Text", t)).toString()
        val url = "https://api-edge.cognitive.microsofttranslator.com/translate?from=$s&to=$d&api-version=3.0"
        val r = try {
            Net.postJson(url, body, mapOf("Authorization" to "Bearer " + msToken(c, false)), c, TO)
        } catch (e: IOException) {
            // an expired token: get a new one once
            if ((e.message ?: "").contains("401")) Net.postJson(url, body, mapOf("Authorization" to "Bearer " + msToken(c, true)), c, TO) else throw e
        }
        return JSONArray(r).getJSONObject(0).getJSONArray("translations").getJSONObject(0).getString("text")
    }

    private fun gtx(t: String, s: String, d: String, c: Cfg): String {
        val body = Net.get("https://translate.googleapis.com/translate_a/single?client=gtx&sl=$s&tl=$d&dt=t&q=" + Net.enc(t), c, TO)
        val seg = JSONArray(body).getJSONArray(0)
        val sb = StringBuilder()
        for (i in 0 until seg.length()) {
            val item = seg.optJSONArray(i) ?: continue
            if (!item.isNull(0)) sb.append(item.getString(0))
        }
        return sb.toString()
    }

    private fun chromeEx(t: String, s: String, d: String, c: Cfg): String {
        val body = Net.get("https://clients5.google.com/translate_a/t?client=dict-chrome-ex&sl=$s&tl=$d&q=" + Net.enc(t), c, TO).trim()
        if (body.startsWith("{")) {
            val arr = JSONObject(body).getJSONArray("sentences")
            val sb = StringBuilder()
            for (i in 0 until arr.length()) sb.append(arr.getJSONObject(i).optString("trans", ""))
            return sb.toString()
        }
        val a = JSONArray(body)
        val f = a.get(0)
        return if (f is JSONArray) f.getString(0) else f.toString()
    }

    /** The light mobile page of Google Translate (different host, sometimes open when the API is not). */
    private fun gmobile(t: String, s: String, d: String, c: Cfg): String {
        val body = Net.get("https://translate.google.com/m?sl=$s&tl=$d&hl=en&q=" + Net.enc(t), c, TO)
        val m = Regex("class=\"result-container\">(.*?)</div>", RegexOption.DOT_MATCHES_ALL).find(body)
            ?: throw IOException("parse error")
        return android.text.Html.fromHtml(m.groupValues[1], android.text.Html.FROM_HTML_MODE_LEGACY).toString().trim()
    }

    private fun lingva(t: String, s: String, d: String, c: Cfg): String {
        var last: Exception = IOException("no host")
        for (host in lingvaHosts) {
            try {
                val body = Net.get("https://$host/api/v1/$s/$d/" + Net.enc(t).replace("+", "%20"), c, TO)
                return JSONObject(body).getString("translation")
            } catch (e: Exception) {
                last = e
            }
        }
        throw last
    }

    private fun myMemory(t: String, s: String, d: String, c: Cfg): String {
        val body = Net.get("https://api.mymemory.translated.net/get?q=" + Net.enc(t) + "&langpair=$s%7C$d", c, TO)
        return JSONObject(body).getJSONObject("responseData").getString("translatedText")
    }

    /** Optional: any OpenAI-compatible chat API (Gemini, OpenRouter, OpenAI...). */
    fun chatApi(c: Cfg, system: String, user: String): String {
        val msgs = JSONArray()
            .put(JSONObject().put("role", "system").put("content", system))
            .put(JSONObject().put("role", "user").put("content", user))
        val body = JSONObject().put("model", c.apiModel).put("temperature", 0.3).put("messages", msgs).toString()
        val r = Net.postJson(c.apiUrl, body, mapOf("Authorization" to "Bearer " + c.apiKey.trim()), c)
        return JSONObject(r).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim()
    }
}
