package app.tarjoman

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

/** Online translation: several free sources tried in order (works with or without a proxy/VPN). */
object Online {
    class Out(val text: String, val provider: String)

    fun translate(text: String, s: String, d: String, c: Cfg): Out {
        val errs = ArrayList<String>()
        val providers: List<Triple<String, Int, (String) -> String>> = listOf(
            Triple("Google", 1200, { t: String -> gtx(t, s, d, c) }),
            Triple("Google-2", 1200, { t: String -> chromeEx(t, s, d, c) }),
            Triple("Lingva", 900, { t: String -> lingva(t, s, d, c) }),
            Triple("MyMemory", 450, { t: String -> myMemory(t, s, d, c) })
        )
        for ((name, limit, fn) in providers) {
            try {
                val out = Prompts.chunks(text, limit).joinToString("\n") { if (it.isBlank()) it else fn(it) }
                if (out.isNotBlank()) return Out(out, name)
            } catch (e: Exception) {
                errs.add(name + ": " + (e.message ?: "error"))
            }
        }
        throw IOException(errs.joinToString(" | "))
    }

    private fun gtx(t: String, s: String, d: String, c: Cfg): String {
        val body = Net.get("https://translate.googleapis.com/translate_a/single?client=gtx&sl=$s&tl=$d&dt=t&q=" + Net.enc(t), c)
        val seg = JSONArray(body).getJSONArray(0)
        val sb = StringBuilder()
        for (i in 0 until seg.length()) {
            val item = seg.optJSONArray(i) ?: continue
            if (!item.isNull(0)) sb.append(item.getString(0))
        }
        return sb.toString()
    }

    private fun chromeEx(t: String, s: String, d: String, c: Cfg): String {
        val body = Net.get("https://clients5.google.com/translate_a/t?client=dict-chrome-ex&sl=$s&tl=$d&q=" + Net.enc(t), c).trim()
        if (body.startsWith("{")) {
            val arr = JSONObject(body).getJSONArray("sentences")
            val sb = StringBuilder()
            for (i in 0 until arr.length()) sb.append(arr.getJSONObject(i).optString("trans", ""))
            return sb.toString()
        }
        val a = JSONArray(body)
        val f = a.get(0)
        return if (f is JSONArray) f.getString(0) else f.toString()
    }

    private fun lingva(t: String, s: String, d: String, c: Cfg): String {
        val body = Net.get("https://lingva.ml/api/v1/$s/$d/" + Net.enc(t).replace("+", "%20"), c)
        return JSONObject(body).getString("translation")
    }

    private fun myMemory(t: String, s: String, d: String, c: Cfg): String {
        val body = Net.get("https://api.mymemory.translated.net/get?q=" + Net.enc(t) + "&langpair=$s%7C$d", c)
        return JSONObject(body).getJSONObject("responseData").getString("translatedText")
    }

    /** Optional: any OpenAI-compatible chat API (Gemini, OpenRouter, OpenAI...). */
    fun chatApi(c: Cfg, system: String, user: String): String {
        val msgs = JSONArray()
            .put(JSONObject().put("role", "system").put("content", system))
            .put(JSONObject().put("role", "user").put("content", user))
        val body = JSONObject().put("model", c.apiModel).put("temperature", 0.3).put("messages", msgs).toString()
        val r = Net.postJson(c.apiUrl, body, mapOf("Authorization" to "Bearer " + c.apiKey.trim()), c)
        return JSONObject(r).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim()
    }
}
