package app.tarjoman

import java.io.IOException

/** Subtitles straight from a YouTube link (only videos that have captions; YouTube may refuse some of them). */
object Yt {
    private val idRe = Regex("(?:[?&]v=|youtu\\.be/|shorts/|embed/|live/)([A-Za-z0-9_-]{11})")

    fun id(link: String): String? = idRe.find(link)?.groupValues?.get(1)

    /** Blocking. Returns WebVTT text; tries the chosen language, then English / Japanese / Persian, manual captions before automatic ones. */
    fun fetch(id: String, lang: String, c: Cfg): String {
        val langs = listOf(lang, "en", "ja", "fa").distinct()
        var last = ""
        for (l in langs) {
            for (kind in listOf("", "&kind=asr")) {
                try {
                    val body = Net.get("https://www.youtube.com/api/timedtext?v=$id&lang=$l&fmt=vtt$kind", c, 12000)
                    if (body.contains("-->")) return body
                } catch (e: Exception) {
                    last = e.message ?: ""
                }
            }
        }
        throw IOException(L("زیرنویسی از این لینک گرفته نشد (ویدیو زیرنویس ندارد یا یوتیوب اجازه نداد). زیرنویس را به‌صورت فایل .srt/.vtt بده.") + (if (last.isNotEmpty()) " ($last)" else ""))
    }
}
