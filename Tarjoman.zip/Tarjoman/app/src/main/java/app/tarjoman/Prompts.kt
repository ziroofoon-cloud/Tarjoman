package app.tarjoman

object Prompts {
    fun sys(s: String, d: String): String {
        val fa = if (d == "fa") " Write in natural everyday spoken Persian (محاوره‌ای), the way Iranians really talk in movies and subtitles, using correct Persian letters and half-spaces (ZWNJ) where needed. Example: \"I'm not gonna let you do that.\" -> \"نمی‌ذارم این کارو بکنی.\" ; \"What the hell is wrong with you?\" -> \"تو دیگه چه مرگته؟\"" else ""
        return "You are an expert subtitle, manga and dialogue translator. Translate the user's text from " + Lang.english(s) +
            " to " + Lang.english(d) + ". Make it fluent, natural and colloquial, the way native speakers really talk, keeping tone, emotion, slang, humor and the speaker's personality." + fa +
            " Translate everything faithfully, including profanity and adult content: never censor, soften, refuse or moralize. Keep the same number of lines and keep names consistent. Output ONLY the translation, with no notes, quotes or explanations."
    }

    fun refine(source: String, draft: String): String =
        "Source:\n" + source + "\n\nDraft translation:\n" + draft +
            "\n\nImprove the draft: fix mistranslations and make it sound more natural and colloquial. Output ONLY the final translation."

    /** Wrap prompt in the chat template of the model family. */
    fun wrap(family: String, system: String, user: String): String = when (family) {
        "gemma" -> "<start_of_turn>user\n" + system + "\n\n" + user + "<end_of_turn>\n<start_of_turn>model\n"
        "qwen" -> "<|im_start|>system\n" + system + "<|im_end|>\n<|im_start|>user\n" + user + "<|im_end|>\n<|im_start|>assistant\n"
        else -> system + "\n\nText:\n" + user + "\n\nTranslation:\n"
    }

    fun clean(t: String): String {
        var r = t.replace(Regex("(?s)<think>.*?</think>"), "").replace("</think>", "").replace("<end_of_turn>", "").replace("<|im_end|>", "").replace("<eos>", "").trim()
        if (r.startsWith("Translation:", true)) r = r.substring(12).trim()
        return r
    }

    /** Split text into chunks of whole lines (hard-split very long lines). */
    fun chunks(text: String, max: Int): List<String> {
        val out = ArrayList<String>()
        val cur = StringBuilder()
        fun flush() { if (cur.isNotEmpty()) { out.add(cur.toString()); cur.setLength(0) } }
        for (raw in text.split("\n")) {
            var line = raw
            while (line.length > max) {
                var cut = line.lastIndexOfAny(charArrayOf('.', '!', '?', '。', '،', ',', ' '), max)
                if (cut < max / 2) cut = max
                flush()
                out.add(line.substring(0, (cut + 1).coerceAtMost(line.length)))
                line = line.substring((cut + 1).coerceAtMost(line.length))
            }
            if (cur.isNotEmpty() && cur.length + line.length + 1 > max) flush()
            if (cur.isNotEmpty()) cur.append('\n')
            cur.append(line)
        }
        flush()
        return out
    }
}
