package app.tarjoman

object Prompts {
    fun sys(s: String, d: String, glossary: String = "", style: String = "casual"): String {
        val formal = style == "formal"
        val fa = if (d == "fa" && formal) " Write in clear, correct standard written Persian (نوشتاری) suitable for books and articles, with proper half-spaces (ZWNJ) and Persian punctuation." else if (d == "fa") " Write in natural everyday spoken Persian (محاوره‌ای), the way Iranians really talk in movies and subtitles, using correct Persian letters and half-spaces (ZWNJ) where needed. Example: \"I'm not gonna let you do that.\" -> \"نمی‌ذارم این کارو بکنی.\" ; \"What the hell is wrong with you?\" -> \"تو دیگه چه مرگته؟\"" else ""
        return "You are an expert subtitle, manga and dialogue translator. Translate the user's text from " + Lang.english(s) +
            " to " + Lang.english(d) + ". " + (if (formal) "Make it fluent, accurate and elegant in a clear standard written register, like a good published book translation, keeping the author's tone and terminology." else "Make it fluent, natural and colloquial, the way native speakers really talk, keeping tone, emotion, slang, humor and the speaker's personality.") + fa +
            " Translate everything faithfully, including profanity and adult content: never censor, soften, refuse or moralize. Keep the same number of lines and keep names consistent. Resolve omitted subjects and pronouns from context, translate honorifics, sound effects and idioms the way a skilled human subtitler would, and keep lines short and speakable." + gl(glossary) + " Output ONLY the translation, with no notes, quotes or explanations."
    }

    private fun gl(g: String): String {
        val items = g.lines().map { it.trim() }.filter { it.contains("=") }
        if (items.isEmpty()) return ""
        return " Always use these exact translations for names and terms: " + items.joinToString("; ") { it.replace("=", " -> ") } + "."
    }

    /** Previous lines are only context; the model must translate just the last part. */
    fun withCtx(ctx: String, text: String): String =
        if (ctx.isBlank()) text else "Previous lines (context only, do NOT translate or repeat them):\n" + ctx + "\n\nTranslate ONLY this line:\n" + text

    /** Hybrid mode: the model only rewrites an ML Kit draft so it sounds natural. */
    fun polish(source: String, draft: String, d: String): String =
        "Source:\n" + source + "\n\nMachine translation (correct in meaning but stiff):\n" + draft +
            "\n\nRewrite the machine translation so it sounds natural, fluent and colloquial in " + Lang.english(d) +
            ", the way a native speaker would say it. Keep exactly the same meaning, tone and number of lines; do not add or remove information. Output ONLY the final translation."

    fun refine(source: String, draft: String): String =
        "Source:\n" + source + "\n\nDraft translation:\n" + draft +
            "\n\nImprove the draft: fix mistranslations and make it sound more natural and colloquial. Output ONLY the final translation."

    /** Wrap prompt in the chat template of the model family. */
    fun wrap(family: String, system: String, user: String): String = when (family) {
        "gemma" -> "<start_of_turn>user\n" + system + "\n\n" + user + "<end_of_turn>\n<start_of_turn>model\n"
        "qwen3" -> "<|im_start|>system\n" + system + "<|im_end|>\n<|im_start|>user\n" + user + " /no_think<|im_end|>\n<|im_start|>assistant\n<think>\n\n</think>\n\n"
        "qwen" -> "<|im_start|>system\n" + system + "<|im_end|>\n<|im_start|>user\n" + user + "<|im_end|>\n<|im_start|>assistant\n"
        else -> system + "\n\nText:\n" + user + "\n\nTranslation:\n"
    }

    fun clean(t: String): String {
        var r = t.replace(Regex("(?s)<think>.*?</think>"), "").replace("</think>", "").replace("<end_of_turn>", "").replace("<|im_end|>", "").replace("<eos>", "").trim()
        if (r.startsWith("Translation:", true)) r = r.substring(12).trim()
        return r
    }

    /** Split text into chunks of whole lines (hard-split very long lines). */
    fun chunks(text: String, max: Int): List<String> {
        val out = ArrayList<String>()
        val cur = StringBuilder()
        fun flush() { if (cur.isNotEmpty()) { out.add(cur.toString()); cur.setLength(0) } }
        for (raw in text.split("\n")) {
            var line = raw
            while (line.length > max) {
                var cut = line.lastIndexOfAny(charArrayOf('.', '!', '?', '。', '،', ',', ' '), max)
                if (cut < max / 2) cut = max
                flush()
                out.add(line.substring(0, (cut + 1).coerceAtMost(line.length)))
                line = line.substring((cut + 1).coerceAtMost(line.length))
            }
            if (cur.isNotEmpty() && cur.length + line.length + 1 > max) flush()
            if (cur.isNotEmpty()) cur.append('\n')
            cur.append(line)
        }
        flush()
        return out
    }
}
