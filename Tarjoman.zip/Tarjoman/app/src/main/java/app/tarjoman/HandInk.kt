package app.tarjoman

import android.app.AlertDialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.vision.digitalink.DigitalInkRecognition
import com.google.mlkit.vision.digitalink.DigitalInkRecognitionModel
import com.google.mlkit.vision.digitalink.DigitalInkRecognitionModelIdentifier
import com.google.mlkit.vision.digitalink.DigitalInkRecognizer
import com.google.mlkit.vision.digitalink.DigitalInkRecognizerOptions
import com.google.mlkit.vision.digitalink.Ink

/** Handwriting: write a word with a finger, the phone (ML Kit digital ink, a small language model downloaded once) turns it into text. */
object HandInk {
    private val h = Handler(Looper.getMainLooper())

    private fun tag(l: String) = when (l) { "fa" -> "fa"; "ja" -> "ja"; "ko" -> "ko"; "zh" -> "zh-Hans-CN"; "ar" -> "ar"; "es" -> "es"; else -> "en" }

    private class Pad(ctx: Context, val onChange: () -> Unit) : View(ctx) {
        val strokes = ArrayList<Ink.Stroke>()
        private val paths = ArrayList<Path>()
        private var cur: Ink.Stroke.Builder? = null
        private var curPath: Path? = null
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 7f; color = Color.BLACK; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
        init { setBackgroundColor(Color.WHITE) }
        fun clear() { strokes.clear(); paths.clear(); invalidate() }
        fun ink(): Ink { val b = Ink.builder(); for (s in strokes) b.addStroke(s); return b.build() }
        override fun onDraw(c: Canvas) { for (x in paths) c.drawPath(x, p); curPath?.let { c.drawPath(it, p) } }
        override fun onTouchEvent(e: MotionEvent): Boolean {
            val t = System.currentTimeMillis()
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    parent?.requestDisallowInterceptTouchEvent(true)
                    cur = Ink.Stroke.builder().apply { addPoint(Ink.Point.create(e.x, e.y, t)) }
                    curPath = Path().apply { moveTo(e.x, e.y) }
                }
                MotionEvent.ACTION_MOVE -> { cur?.addPoint(Ink.Point.create(e.x, e.y, t)); curPath?.lineTo(e.x, e.y) }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    cur?.addPoint(Ink.Point.create(e.x, e.y, t))
                    cur?.let { strokes.add(it.build()) }
                    curPath?.let { paths.add(it) }
                    cur = null; curPath = null
                    onChange()
                }
            }
            invalidate()
            return true
        }
    }

    /** Opens the writing dialog; [onText] gets the recognized text when the user taps "use". */
    fun show(ctx: Context, ui: Ui, lang: String, onText: (String) -> Unit) {
        val id = try { DigitalInkRecognitionModelIdentifier.fromLanguageTag(tag(lang)) } catch (_: Throwable) { null }
        if (id == null) { android.widget.Toast.makeText(ctx, L("نوشتن با دست برای این زبان پشتیبانی نمی‌شود."), android.widget.Toast.LENGTH_LONG).show(); return }
        val model = DigitalInkRecognitionModel.builder(id).build()
        val rec: DigitalInkRecognizer = DigitalInkRecognition.getClient(DigitalInkRecognizerOptions.builder(model).build())
        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(ui.dp(16), ui.dp(8), ui.dp(16), 0) }
        val status = TextView(ctx).apply { text = L("آماده‌سازی مدل نوشتار (یک‌بار، با اینترنت)…"); textSize = 12f }
        val result = EditText(ctx).apply { hint = L("متن شناخته‌شده"); textSize = 18f }
        var ready = false
        var closed = false
        lateinit var pad: Pad
        var pending: Runnable? = null
        fun recognize() {
            if (closed || !ready || pad.strokes.isEmpty()) return
            rec.recognize(pad.ink()).addOnSuccessListener { r ->
                val t = r.candidates.firstOrNull()?.text ?: ""
                if (t.isNotEmpty()) result.setText(t)
            }.addOnFailureListener { status.text = L("خطا: ") + (it.message ?: "") }
        }
        pad = Pad(ctx) {
            pending?.let { h.removeCallbacks(it) }
            val r = Runnable { recognize() }
            pending = r
            h.postDelayed(r, 600)
        }
        box.addView(status)
        box.addView(pad, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, ui.dp(220)).apply { topMargin = ui.dp(8) })
        box.addView(result, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = ui.dp(8) })
        RemoteModelManager.getInstance().download(model, DownloadConditions.Builder().build())
            .addOnSuccessListener { ready = true; status.text = L("با انگشت بنویس؛ متن خودش شناخته می‌شود."); recognize() }
            .addOnFailureListener { status.text = L("مدل نوشتار دانلود نشد (اینترنت لازم است): ") + (it.message ?: "") }
        AlertDialog.Builder(ctx).setTitle(L("نوشتن با دست")).setView(box)
            .setPositiveButton(L("استفاده")) { _, _ -> val t = result.text.toString().trim(); if (t.isNotEmpty()) onText(t) }
            .setNeutralButton(L("پاک کردن"), null)
            .setNegativeButton(L("بستن"), null)
            .create().also { d ->
                d.setOnShowListener { d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener { pad.clear(); result.setText("") } }
                d.setOnDismissListener { closed = true; pending?.let { r -> h.removeCallbacks(r) }; try { rec.close() } catch (_: Throwable) {} }
            }.show()
    }
}
