package app.tarjoman

/**
 * Persian -> English, offline, no model. ML Kit is trained on formal written Persian: everyday thanks, blessings and
 * greetings ("خسته نباشی", "دستت درد نکنه", "قربونت") come out as nonsense word by word, so whole sentences found in
 * this table are answered directly. Everything else is first turned from spoken Persian into written Persian
 * (Fa.formal) and then goes to ML Kit.
 */
object FaEn {
    /** Spelling-independent form of a sentence: Persian letters fixed, no punctuation, no half-spaces, one space. */
    fun norm(s: String): String {
        var t = Fa.fix(s).replace('\u200c', ' ')
        t = t.replace(Regex("[\\u060C\\u061F.!?,;:\\u00AB\\u00BB\"'\\u2026()\\-]"), " ")
        t = t.replace(Regex("(?<![\\u0620-\\u064A\\u066E-\\u06D3])(ن?می) +(?=[\\u0620-\\u064A\\u066E-\\u06D3])"), "$1")
        return t.replace(Regex("\\s+"), " ").trim()
    }

    private val table: HashMap<String, String> by lazy {
        val m = HashMap<String, String>()
        for (line in DATA.lines()) {
            val i = line.indexOf('|')
            if (i <= 0) continue
            m[norm(line.substring(0, i))] = line.substring(i + 1).trim()
        }
        m
    }

    fun lookup(fa: String): String? {
        val k = norm(fa)
        return if (k.isEmpty()) null else table[k]
    }

    private const val DATA = """
سلام|Hi.
سلام علیکم|Hello.
درود|Greetings.
صبح بخیر|Good morning.
شب بخیر|Good night.
عصر بخیر|Good evening.
خوبی|How are you?
حالت چطوره|How are you?
حال شما چطوره|How are you?
چطوری|How are you?
چه خبر|What's up?
چی شده|What happened?
چی شد|What happened?
چیکار می‌کنی|What are you doing?
چی کار می‌کنی|What are you doing?
خوبم|I'm fine.
خوبم ممنون|I'm fine, thank you.
مرسی|Thanks.
ممنون|Thank you.
خیلی ممنون|Thank you very much.
مرسی که اومدی|Thanks for coming.
قربونت|Thank you, dear.
قربونت برم|Bless you, dear.
فدات شم|Bless you, dear.
جونم|Yes, dear?
دستت درد نکنه|Thank you for your effort.
دست شما درد نکنه|Thank you for your effort.
خسته نباشی|Thanks for your hard work.
خسته نباشید|Thanks for your hard work.
خدا قوت|Thanks for your hard work.
قابل نداره|It's nothing, don't mention it.
قابلی نداره|Don't mention it.
خواهش می‌کنم|You're welcome.
تعارف نکن|Don't be shy.
نوش جان|Enjoy your meal.
بفرمایید|Please, go ahead.
بفرما|Please, go ahead.
چشم|Yes, of course.
باشه|Okay.
حتما|Of course.
آره|Yeah.
اره|Yeah.
نه|No.
نخیر|No.
بله|Yes.
نمی‌دونم|I don't know.
نمی‌دانم|I don't know.
می‌بینمت|See you.
بعدا می‌بینمت|See you later.
فعلا|Bye for now.
خداحافظ|Goodbye.
به امید دیدار|Hope to see you again.
ایشالا|God willing.
انشاالله|God willing.
ان شاء الله|God willing.
ماشالله|God bless!
خدا رو شکر|Thank God.
خدا را شکر|Thank God.
به سلامتی|Cheers.
سلامت باشی|Stay well.
دمت گرم|Good on you!
آفرین|Well done.
عالیه|It's great.
عالی|Great.
خیلی خوبه|It's very good.
خیلی بده|It's very bad.
دلم برات تنگ شده|I miss you.
دلم برات تنگ شده بود|I missed you.
دوستت دارم|I love you.
عاشقتم|I love you.
ببخشید|Excuse me.
معذرت می‌خوام|I'm sorry.
معذرت می‌خواهم|I'm sorry.
متاسفم|I'm sorry.
شرمنده|I'm sorry about that.
ببخشید دیر کردم|Sorry I'm late.
اشکالی نداره|It's okay.
مشکلی نیست|No problem.
عیبی نداره|It doesn't matter.
مهم نیست|It doesn't matter.
برام مهم نیست|I don't care.
به من چه|It's none of my business.
به تو چه|It's none of your business.
به درک|Who cares.
گمشو|Get lost.
برو گمشو|Get lost.
ولم کن|Leave me alone.
بس کن|Stop it.
ساکت شو|Be quiet.
خفه شو|Shut up.
عجله کن|Hurry up.
زود باش|Hurry up.
بیا بریم|Let's go.
بریم|Let's go.
صبر کن|Wait.
یه لحظه صبر کن|Wait a moment.
یه لحظه|Just a moment.
نگران نباش|Don't worry.
نترس|Don't be afraid.
مواظب باش|Be careful.
مراقب باش|Be careful.
خدا نکنه|God forbid.
خدا بیامرزه|May God rest his soul.
تسلیت می‌گم|My condolences.
تسلیت|My condolences.
تبریک می‌گم|Congratulations.
تبریک|Congratulations.
مبارک باشه|Congratulations.
تولدت مبارک|Happy birthday.
سال نو مبارک|Happy New Year.
عید مبارک|Happy holidays.
موفق باشی|Good luck.
موفق باشید|Good luck.
قیمتش چنده|How much is it?
چنده|How much is it?
کجایی|Where are you?
کجا می‌ری|Where are you going?
چرا|Why?
یعنی چی|What do you mean?
منظورت چیه|What do you mean?
چی گفتی|What did you say?
جدی می‌گی|Are you serious?
شوخی می‌کنی|Are you kidding?
مطمئنی|Are you sure?
امکان نداره|No way.
نه بابا|No way!
واقعا|Really?
راست می‌گی|Really?
باور نمی‌کنم|I can't believe it.
نمی‌تونم باور کنم|I can't believe it.
ای بابا|Oh man.
ای وای|Oh no.
وای خدا|Oh my God.
خدای من|Oh my God.
یا خدا|Oh my God.
دیگه چی|What else?
همین|That's all.
بس|Enough.
"""
}
