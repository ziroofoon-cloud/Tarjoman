package app.tarjoman

import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.util.Locale

class Cue(val idx: String, val time: String, val text: String)

/** Subtitle parsing (.srt and .vtt) and rebuilding as .srt. */
object SrtTool {
    private val tm = Regex("(?:(\\d+):)?(\\d{1,2}):(\\d{2})[.,](\\d{1,3})")

    /** Reads file bytes: UTF-8 / UTF-16 (BOM), otherwise an old code page chosen from the source language. */
    fun decode(b: ByteArray, hint: String): String {
        if (b.size >= 3 && b[0] == 0xEF.toByte() && b[1] == 0xBB.toByte() && b[2] == 0xBF.toByte()) return String(b, 3, b.size - 3, Charsets.UTF_8)
        if (b.size >= 2 && b[0] == 0xFF.toByte() && b[1] == 0xFE.toByte()) return String(b, 2, b.size - 2, Charsets.UTF_16LE)
        if (b.size >= 2 && b[0] == 0xFE.toByte() && b[1] == 0xFF.toByte()) return String(b, 2, b.size - 2, Charsets.UTF_16BE)
        try {
            val dec = Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT)
            return dec.decode(ByteBuffer.wrap(b)).toString()
        } catch (e: CharacterCodingException) {
            // not UTF-8
        }
        val name = when (hint) { "fa" -> "windows-1256"; "ja" -> "Shift_JIS"; else -> "windows-1252" }
        return try { String(b, Charset.forName(name)) } catch (e: Exception) { String(b, Charsets.ISO_8859_1) }
    }

    private fun normTime(line: String): String {
        val m = tm.findAll(line).toList()
        if (m.size < 2) return line.trim()
        fun f(r: MatchResult): String {
            val h = r.groupValues[1].ifEmpty { "0" }.toInt()
            val mi = r.groupValues[2].toInt()
            val s = r.groupValues[3].toInt()
            val ms = r.groupValues[4].padEnd(3, '0').take(3).toInt()
            return String.format(Locale.US, "%02d:%02d:%02d,%03d", h, mi, s, ms)
        }
        return f(m[0]) + " --> " + f(m[1])
    }

    fun parse(raw: String): List<Cue> {
        val t = raw.replace("\r\n", "\n").replace("\r", "\n").removePrefix("\uFEFF")
        val out = ArrayList<Cue>()
        for (blk in t.split(Regex("\n\\s*\n"))) {
            val lines = blk.trim().split("\n")
            if (lines.size < 2) continue
            var i = 0
            var idx = ""
            if (!lines[0].contains("-->")) { idx = lines[0].trim(); i = 1 }
            if (i >= lines.size || !lines[i].contains("-->")) continue
            out.add(Cue(idx, normTime(lines[i]), lines.drop(i + 1).joinToString("\n")))
        }
        return out
    }

    /** Text without tags / ASS codes, on one line. */
    fun plain(s: String): String =
        s.replace(Regex("<[^>]+>"), "").replace(Regex("\\{[^}]*\\}"), "").replace("\n", " ").trim()

    fun build(cues: List<Cue>, texts: List<String?>): String {
        val sb = StringBuilder()
        for ((i, c) in cues.withIndex()) {
            val t = texts.getOrNull(i) ?: c.text
            sb.append(i + 1).append("\n").append(c.time).append("\n").append(t).append("\n\n")
        }
        return sb.toString()
    }
}
