package app.tarjoman

class Cue(val idx: String, val time: String, val text: String)

/** Subtitle (.srt) parsing and rebuilding. */
object SrtTool {
    fun parse(raw: String): List<Cue> {
        val t = raw.replace("\r\n", "\n").replace("\r", "\n").removePrefix("\uFEFF")
        val out = ArrayList<Cue>()
        for (blk in t.split(Regex("\n\\s*\n"))) {
            val lines = blk.trim().split("\n")
            if (lines.size < 2) continue
            var i = 0
            var idx = ""
            if (!lines[0].contains("-->")) { idx = lines[0].trim(); i = 1 }
            if (i >= lines.size || !lines[i].contains("-->")) continue
            out.add(Cue(idx, lines[i].trim(), lines.drop(i + 1).joinToString("\n")))
        }
        return out
    }

    /** Text without tags / ASS codes, on one line. */
    fun plain(s: String): String =
        s.replace(Regex("<[^>]+>"), "").replace(Regex("\\{[^}]*\\}"), "").replace("\n", " ").trim()

    fun build(cues: List<Cue>, texts: List<String?>): String {
        val sb = StringBuilder()
        for ((i, c) in cues.withIndex()) {
            val t = texts.getOrNull(i) ?: c.text
            sb.append(i + 1).append("\n").append(c.time).append("\n").append(t).append("\n\n")
        }
        return sb.toString()
    }
}
