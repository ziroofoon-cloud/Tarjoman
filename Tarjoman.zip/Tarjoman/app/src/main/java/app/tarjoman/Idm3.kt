package app.tarjoman

/** Manga / anime / webtoon style lines (fights, school life, romance, fantasy, mystery). Same format as Idm2. */
object Idm3 {
    const val DATA = """
are you sure|مطمئنی؟
are you sure about this|از این مطمئنی؟
are you guys sure|بچه‌ها مطمئنید؟
are you all right|حالت خوبه؟
are you two dating|شما دوتا با همید؟
are you really going to do this|واقعاً می_خوای این کارو بکنی؟
are you still alive|هنوز زنده‌ای؟
are you the one who did this|تو این کارو کردی؟
are you stupid|احمقی؟
are you an idiot|مگه احمقی؟
what the hell|این دیگه چیه؟
what the hell is that|اون دیگه چه کوفتیه؟
what the hell are you doing|داری چه غلطی می_کنی؟
what the hell is going on|اینجا چه خبره؟
what kind of person are you|تو چه جور آدمی هستی؟
what kind of monster is this|این دیگه چه هیولایی‌ست؟
what is this power|این چه قدرتیه؟
what is this feeling|این چه حسیه؟
what is this place|اینجا کجاست؟
what is that noise|اون صدا چیه؟
what is that smell|این بو چیه؟
what do you want from me|از من چی می_خوای؟
what do you want|چی می_خوای؟
what are you planning|چه نقشه_ای داری؟
what are you hiding|چی رو پنهون می_کنی؟
what are you trying to say|می_خوای چی بگی؟
what are you trying to do|می_خوای چیکار کنی؟
what are you waiting for|منتظر چی هستی؟
what are you so afraid of|از چی انقدر می_ترسی؟
what are we going to do|چیکار کنیم؟
what happened to him|بلایی سرش اومد؟
what happened to her|چه بلایی سرش اومده؟
what happened to everyone|برای همه چی شده؟
what did he do|اون چیکار کرد؟
what did you do to him|باهاش چیکار کردی؟
what did you do to her|باهاش چیکار کردی؟
what did you do to me|با من چیکار کردی؟
what was that|اون چی بود؟
what was that sound|اون صدا چی بود؟
what is your goal|هدفت چیه؟
what is your real name|اسم واقعیت چیه؟
what is your problem|مشکلت چیه؟
what is with you|تو چته؟
what is with that face|این چه قیافه_ایه؟
what is he doing here|اینجا چیکار می_کنه؟
what is she doing here|اینجا چیکار می_کنه؟
what is wrong with him|اون چش شده؟
what is wrong with her|اون چش شده؟
what is happening to me|چه اتفاقی داره برام می_افته؟
what is happening|چه خبره؟
what is this guy|این پسره چیه؟
what is this all about|همه این‌ها برای چیه؟
who the hell are you|لعنتی تو کی هستی؟
who the hell is that|اون لعنتی کیه؟
who are you people|شما کی هستید؟
who are they|اون‌ها کی هستن؟
who is he|اون کیه؟
who is she|اون کیه؟
who is that guy|اون پسره کیه؟
who is that girl|اون دختره کیه؟
who is behind this|پشت این ماجرا کیه؟
who is in charge here|اینجا مسئول کیه؟
who is your master|ارباب تو کیه؟
who sent you|کی تو رو فرستاده؟
who did this to you|کی این بلا رو سرت آورد؟
who do you think you are|فکر می_کنی کی هستی؟
who told you that|کی اینو بهت گفت؟
where are we|کجاییم؟
where am i|من کجام؟
where is everyone|همه کجان؟
where is my sister|خواهرم کجاست؟
where is my brother|برادرم کجاست؟
where did everyone go|همه کجا رفتن؟
where are you going|کجا می_ری؟
where do you think you are going|فکر می_کنی کجا می_ری؟
where have you been|کجا بودی؟
why are you crying|چرا گریه می_کنی؟
why are you laughing|چرا می_خندی؟
why are you smiling|چرا لبخند می_زنی؟
why are you so strong|چرا انقدر قوی هستی؟
why are you doing this|چرا داری این کارو می_کنی؟
why are you helping me|چرا داری کمکم می_کنی؟
why are you here|اینجا چیکار می_کنی؟
why would you do that|چرا این کارو کردی؟
why did you save me|چرا نجاتم دادی؟
why did you come|چرا اومدی؟
why did you lie to me|چرا بهم دروغ گفتی؟
why did you not tell me|چرا بهم نگفتی؟
why is this happening|چرا این اتفاق داره می_افته؟
why is this happening to me|چرا این اتفاق برای من داره می_افته؟
why do you care|چرا برات مهمه؟
why do you ask|چرا می_پرسی؟
why do i have to|چرا من باید؟
how is this possible|این چطور ممکنه؟
how did you know|از کجا می_دونستی؟
how did you find me|چطور پیدام کردی؟
how did you do that|چطور این کارو کردی؟
how strong is he|چقدر قویه؟
how long have you been here|چند وقته اینجایی؟
how long has it been|چقدر گذشته؟
how can this be|چطور ممکنه؟
how can you say that|چطور می_تونی اینو بگی؟
how can i trust you|چطور بهت اعتماد کنم؟
how do you know my name|اسممو از کجا می_دونی؟
how do you feel|چه حسی داری؟
how are you feeling|حالت چطوره؟
how did it come to this|کار به اینجا چطور کشید؟
i will not let you|نمی_ذارم
i will not let you die|نمی_ذارم بمیری
i will not let that happen|نمی_ذارم این اتفاق بیفته
i will not lose|نمی_بازم
i will not run away|فرار نمی_کنم
i will not forgive you|نمی_بخشمت
i will not forget this|این رو فراموش نمی_کنم
i will not give up|تسلیم نمی_شم
i will not allow it|اجازه نمی_دم
i will definitely win|حتماً می_برم
i will become stronger|قوی_تر می_شم
i will become the strongest|قوی_ترین می_شم
i will surpass you|ازت جلو می_زنم
i will change the world|دنیا رو عوض می_کنم
i will avenge them|انتقامشونو می_گیرم
i will take responsibility|مسئولیتشو می_پذیرم
i will do whatever it takes|هر کاری لازم باشه می_کنم
i will fight|می_جنگم
i will fight for you|برات می_جنگم
i will end this|این ماجرا رو تموم می_کنم
i will end this now|همین الان تمومش می_کنم
i will finish this|تمومش می_کنم
i will take you down|از پا درت میارم
i will crush you|له_ت می_کنم
i will make you pay|تقاصشو پس می_دی
i will never forgive myself|هیچ_وقت خودمو نمی_بخشم
i will leave it to you|به تو می_سپارم
i will leave this to you|این رو به تو می_سپارم
i will go first|من اول می_رم
i will go with you|با تو می_آم
i will stay here|من اینجا می_مونم
i will be waiting|منتظرت می_مونم
i will wait for you|منتظرت می_مونم
i will see to it|خودم رسیدگی می_کنم
i will take care of it|خودم حلش می_کنم
i will handle it|من حلش می_کنم
i will explain later|بعداً توضیح می_دم
i will not hold back|خودمو کنترل نمی_کنم
i will not hold back anymore|دیگه خودمو کنترل نمی_کنم
i am going all out|تمام قدرتمو به کار می_گیرم
i am going to protect everyone|از همه محافظت می_کنم
i am going to protect you|ازت محافظت می_کنم
i am going to end you|نابودت می_کنم
i am going to win this|این رو می_برم
i am going to see him|می_رم ببینمش
i am going to take him down|از پا درش میارم
i am the only one who can|من تنها کسی هستم که می_تونه
i am the only one left|من تنها کسی هستم که مونده
i am the one who will win|من برنده می_شم
i am the strongest|من از همه قوی_ترم
i am not done yet|هنوز کارم تموم نشده
i am not finished yet|هنوز تموم نشدم
i am still standing|هنوز سر پام
i am still fighting|هنوز می_جنگم
i am just getting started|تازه شروع کردم
i am not going to lose|نمی_بازم
i am not going to run|فرار نمی_کنم
i am not going to let you|نمی_ذارم
i am not going to hurt you|بهت آسیب نمی_زنم
i am not going to forgive you|نمی_بخشمت
i am not afraid anymore|دیگه نمی_ترسم
i am not the same as before|من مثل قبل نیستم
i am not weak anymore|دیگه ضعیف نیستم
i am sorry for everything|بابت همه چی متأسفم
i am sorry i could not protect you|متأسفم که نتونستم ازت محافظت کنم
i am sorry for being weak|ببخشید که ضعیف بودم
i am sorry for lying|ببخشید که دروغ گفتم
i am so happy you are safe|خیلی خوشحالم که سالمی
i am glad you are safe|خوشحالم که سالمی
i am glad you are alive|خوشحالم که زنده‌ای
i am happy to be alive|خوشحالم که زنده‌ام
i am just glad you are okay|فقط خوشحالم که حالت خوبه
i am back from the dead|از مرگ برگشتم
i can feel his power|قدرتشو حس می_کنم
i can feel her presence|حضورشو حس می_کنم
i can feel it coming|حس می_کنم داره میاد
i can feel something strange|یه چیز عجیب حس می_کنم
i can sense danger|خطر رو حس می_کنم
i can not lose here|نمی_تونم اینجا ببازم
i can not die here|نمی_تونم اینجا بمیرم
i can not let you go|نمی_تونم بذارم بری
i can not let this go on|نمی_تونم بذارم این ادامه پیدا کنه
i can not forgive him|نمی_تونم ببخشمش
i can not forgive myself|نمی_تونم خودمو ببخشم
i can not do this alone|تنهایی از پسش برنمیام
i can not do this anymore|دیگه نمی_تونم این کارو بکنم
i can not let anyone else die|نمی_تونم بذارم کس دیگه_ای بمیره
i can not lose anyone else|نمی_تونم کس دیگه_ای رو از دست بدم
i can not afford to lose|نمی_تونم ببازم
i can not remember anything|هیچی یادم نمیاد
i can not see anything|هیچی نمی_بینم
i can not hear anything|هیچی نمی_شنوم
i can not feel my legs|پاهامو حس نمی_کنم
i can not feel my arm|دستمو حس نمی_کنم
i can not understand you|نمی_تونم درکت کنم
i can not read this|نمی_تونم اینو بخونم
i can not trust anyone|نمی_تونم به کسی اعتماد کنم
i can not move my body|نمی_تونم بدنمو تکون بدم
i can not stop shaking|نمی_تونم جلوی لرزشمو بگیرم
i can not stop now|الان نمی_تونم متوقف بشم
i could not do anything|نتونستم هیچ کاری بکنم
i could not save anyone|نتونستم هیچ‌کس رو نجات بدم
i could not protect them|نتونستم ازشون محافظت کنم
i was too weak|خیلی ضعیف بودم
i was too late|خیلی دیر رسیدم
i was always alone|همیشه تنها بودم
i was wrong about you|درباره‌ت اشتباه می_کردم
i was so stupid|خیلی احمق بودم
i was just a kid|من فقط یه بچه بودم
i was born to do this|من برای این کار به دنیا اومدم
i was there|من اونجا بودم
i was not there|من اونجا نبودم
i was waiting for this|منتظر همین بودم
i was looking for you|دنبالت می_گشتم
i was only trying to help|فقط می_خواستم کمک کنم
i did not think|فکر نمی_کردم
i did not think it would be like this|فکر نمی_کردم این طوری بشه
i did not want to fight|نمی_خواستم بجنگم
i did not want you to see this|نمی_خواستم اینو ببینی
i did not want it to end like this|نمی_خواستم این طوری تموم بشه
i did not know you were here|نمی_دونستم اینجایی
i did not know it was you|نمی_دونستم تو بودی
i have never seen anything like this|تا حالا همچین چیزی ندیده بودم
i have never felt like this before|تا حالا همچین حسی نداشتم
i have never lost|هیچ_وقت نباخته_ام
i have never been so scared|هیچ_وقت انقدر نترسیده بودم
i have been waiting for this moment|منتظر این لحظه بودم
i have waited so long for this|خیلی وقته منتظر این بودم
i have no regrets|هیچ پشیمونی_ای ندارم
i have nothing left|هیچی برام نمونده
i have nothing to lose|چیزی برای از دست دادن ندارم
i have found you|پیدات کردم
i have finally found you|بالاخره پیدات کردم
i have decided|تصمیمم رو گرفتم
i have made up my mind|تصمیمم رو گرفتم
i have a bad feeling about this|حس بدی نسبت به این موضوع دارم
i have a favor to ask|یه خواهش ازت دارم
i have a request|یه درخواست دارم
i have something to tell you|یه چیزی هست که باید بهت بگم
i have something to show you|یه چیزی دارم که نشونت بدم
i have been training|دارم تمرین می_کنم
i have been training for this|برای این تمرین کرده_ام
i have gotten stronger|قوی_تر شدم
i have no time for this|برای این کار وقت ندارم
i have no one else|کس دیگه_ای ندارم
i have no idea what you are talking about|نمی_دونم درباره چی حرف می_زنی
i have heard a lot about you|خیلی درباره_ت شنیده_ام
i have to protect them|باید ازشون محافظت کنم
i have to get stronger|باید قوی_تر بشم
i have to save her|باید نجاتش بدم
i have to save him|باید نجاتش بدم
i have to find him|باید پیداش کنم
i have to find her|باید پیداش کنم
i have to do something|باید یه کاری بکنم
i have to see it for myself|باید خودم ببینم
i have to apologize|باید عذرخواهی کنم
i have to hurry|باید عجله کنم
i have to go now|الان باید برم
i have to win|باید ببرم
i need to get stronger|باید قوی_تر بشم
i need to protect her|باید ازش محافظت کنم
i need to protect him|باید ازش محافظت کنم
i need to know the truth|باید حقیقت رو بدونم
i need to get out of here|باید از اینجا برم
i need to find a way|باید یه راهی پیدا کنم
i need to tell you something|باید یه چیزی بهت بگم
i need to see her|باید ببینمش
i need your power|به قدرتت نیاز دارم
i need your strength|به قدرتت نیاز دارم
i need your help right now|همین الان به کمکت احتیاج دارم
i want to become stronger|می_خوام قوی_تر بشم
i want to protect everyone|می_خوام از همه محافظت کنم
i want to protect you|می_خوام ازت محافظت کنم
i want to see her smile|می_خوام لبخندشو ببینم
i want to know more about you|می_خوام بیشتر درباره_ت بدونم
i want to be with you|می_خوام با تو باشم
i want to be friends|می_خوام دوست بشیم
i want to be strong|می_خوام قوی باشم
i want to get stronger|می_خوام قوی_تر بشم
i want to go back|می_خوام برگردم
i want to go back home|می_خوام برگردم خونه
i want to see my family|می_خوام خانواده_مو ببینم
i want to tell you something|می_خوام یه چیزی بهت بگم
i want to try|می_خوام امتحان کنم
i want you to live|می_خوام زنده بمونی
i want you to stay|می_خوام بمونی
i want you to know|می_خوام بدونی
i want you to be happy|می_خوام خوشحال باشی
i want you to trust me|می_خوام بهم اعتماد کنی
i want answers|جواب می_خوام
i want the truth|حقیقت رو می_خوام
i want revenge|انتقام می_خوام
i want to end this|می_خوام این رو تموم کنم
i want to become a hero|می_خوام قهرمان بشم
i like you a lot|خیلی ازت خوشم میاد
i have always liked you|همیشه ازت خوشم میومد
i have liked you for a long time|مدت‌هاست ازت خوشم میاد
i love you more than anything|بیشتر از هر چیزی دوستت دارم
i think i am in love|فکر کنم عاشق شدم
i think i like you|فکر کنم ازت خوشم میاد
i think we should go|فکر کنم باید بریم
i think we should talk|فکر کنم باید حرف بزنیم
i think we are lost|فکر کنم گم شدیم
i think someone is following us|فکر کنم کسی داره تعقیبمون می_کنه
i think it is over|فکر کنم تموم شد
i think i know who it is|فکر کنم می_دونم کیه
i think you are right|فکر کنم حق با توئه
i think you should leave|فکر کنم باید بری
i think there is something wrong|فکر کنم یه چیزی درست نیست
i think i heard something|فکر کنم یه چیزی شنیدم
i do not think we can win|فکر نمی_کنم بتونیم ببریم
i do not think i can do this|فکر نمی_کنم بتونم این کارو بکنم
i do not know what to think|نمی_دونم چی فکر کنم
i do not know what is going on|نمی_دونم چه خبره
i do not know what happened|نمی_دونم چی شد
i do not know what i am doing|نمی_دونم دارم چیکار می_کنم
i do not know who i am anymore|دیگه نمی_دونم کی هستم
i do not know if i can|نمی_دونم می_تونم یا نه
i do not know if i can win|نمی_دونم می_تونم ببرم یا نه
i do not know how to say this|نمی_دونم چطور بگم
i do not even know your name|حتی اسمتو نمی_دونم
i do not even know why|حتی نمی_دونم چرا
i do not need your pity|ترحم تو رو نمی_خوام
i do not need anyone|به هیچ‌کس نیاز ندارم
i do not need friends|دوست نمی_خوام
i do not have the right|حقش رو ندارم
i do not have the strength|قدرتشو ندارم
i do not have much time|وقت زیادی ندارم
i do not have the courage|جرئتشو ندارم
i do not have anything to say to you|حرفی برای گفتن بهت ندارم
i do not care what you think|برام مهم نیست چی فکر می_کنی
i do not care about that|برام مهم نیست
i do not want to fight you|نمی_خوام باهات بجنگم
i do not want to lose you|نمی_خوام از دست بدمت
i do not want to lose anyone else|نمی_خوام کس دیگه_ای رو از دست بدم
i do not want to be alone|نمی_خوام تنها باشم
i do not want to be a burden|نمی_خوام سربار باشم
i do not want to cause trouble|نمی_خوام دردسر درست کنم
i do not want to die here|نمی_خوام اینجا بمیرم
i do not want to hurt anyone|نمی_خوام به کسی آسیب بزنم
i do not want to see that again|نمی_خوام دوباره اونو ببینم
i do not want to remember|نمی_خوام یادم بیاد
i do not want to talk|نمی_خوام حرف بزنم
i do not want your help|کمکتو نمی_خوام
i do not want to hear it|نمی_خوام بشنوم
i do not believe it|باورم نمی_شه
i do not believe this|باورم نمی_شه
i do not like this at all|اصلاً از این خوشم نمیاد
i do not like where this is going|از اینکه کار به کجا می_کشه خوشم نمیاد
i do not like the look of this|قیافه_ی این ماجرا رو دوست ندارم
i do not understand what you mean|نمی_فهمم منظورت چیه
i do not understand any of this|هیچ‌کدوم از اینا رو نمی_فهمم
you idiot|ای احمق
you fool|ای نادون
you bastard|ای عوضی
you jerk|ای بی_شعور
you coward|ای ترسو
you liar|ای دروغگو
you monster|ای هیولا
you traitor|ای خائن
you are a monster|تو یه هیولایی
you are a coward|تو یه ترسویی
you are a liar|تو یه دروغگویی
you are a traitor|تو یه خائنی
you are an idiot|تو یه احمقی
you are such a idiot|تو واقعاً احمقی
you are so annoying|خیلی اعصاب_خردکنی
you are so strong|خیلی قوی هستی
you are so cute|خیلی بامزه_ای
you are so kind|خیلی مهربونی
you are too naive|خیلی ساده_لوحی
you are too weak|خیلی ضعیفی
you are too slow for me|برای من خیلی کندی
you are no match for me|حریف من نیستی
you are not strong enough|به اندازه_ی کافی قوی نیستی
you are not my enemy|تو دشمن من نیستی
you are not alone anymore|دیگه تنها نیستی
you are the one i was looking for|تو همونی هستی که دنبالش می_گشتم
you are the reason|تو دلیلشی
you are the only one who|تو تنها کسی هستی که
you are the only friend i have|تو تنها دوستی هستی که دارم
you are really something|تو واقعاً یه چیزی هستی
you are different from the others|تو با بقیه فرق داری
you are not like the others|تو مثل بقیه نیستی
you are in my way|سر راه من هستی
you are in danger|در خطری
you are going to die|می_میری
you are going to pay|تقاصشو پس می_دی
you are going to regret this|پشیمون می_شی
you are going down|سقوط می_کنی
you are under my control|تو تحت کنترل منی
you are just a kid|تو فقط یه بچه_ای
you are just like him|تو مثل اونی
you are just like me|تو مثل منی
you are nothing|تو هیچی نیستی
you are everything to me|تو همه_چیز منی
you are important to me|تو برام مهمی
you are precious to me|تو برام عزیزی
you are my only hope|تو تنها امید منی
you are my best friend|تو بهترین دوست منی
you are my hero|تو قهرمان منی
you are my rival|تو رقیب منی
you are the strongest|تو قوی_ترینی
you did not have to do that|لازم نبود این کارو بکنی
you did not have to come|لازم نبود بیای
you did not have to save me|لازم نبود نجاتم بدی
you did not listen to me|به حرفم گوش ندادی
you did not tell me|بهم نگفتی
you did this to me|تو این بلا رو سرم آوردی
you will not get away with this|از این قسر در نمی_ری
you will never win|هیچ_وقت نمی_بری
you will never beat me|هیچ_وقت نمی_تونی منو شکست بدی
you will never understand|هیچ_وقت نمی_فهمی
you will never be able to|هیچ_وقت نمی_تونی
you will die here|اینجا می_میری
you will be the first to die|تو اولین نفری هستی که می_میره
you will not escape|فرار نمی_کنی
you will see what i mean|می_بینی منظورم چیه
you will understand someday|یه روز می_فهمی
you will understand soon|زود می_فهمی
you will have to kill me first|اول باید منو بکشی
you can not beat me|نمی_تونی منو شکست بدی
you can not win|نمی_تونی ببری
you can not protect everyone|نمی_تونی از همه محافظت کنی
you can not escape from me|نمی_تونی از دست من فرار کنی
you can not stop me|نمی_تونی جلوی منو بگیری
you can not die yet|هنوز نمی_تونی بمیری
you can not give up now|الان نمی_تونی تسلیم بشی
you can not leave|نمی_تونی بری
you can not be serious|نمی_تونی جدی باشی
you can not do this|نمی_تونی این کارو بکنی
you can not just|نمی_تونی فقط
you can not trust him|نمی_تونی بهش اعتماد کنی
you can not run forever|تا ابد نمی_تونی فرار کنی
you have grown|بزرگ شدی
you have grown stronger|قوی_تر شدی
you have gotten stronger|قوی_تر شدی
you have improved|پیشرفت کردی
you have a lot of guts|جرئت زیادی داری
you have some nerve|رو داری ها
you have no idea|هیچ نمی_دونی
you have no idea what you are talking about|هیچ نمی_دونی درباره چی حرف می_زنی
you have no right to say that|حق نداری اینو بگی
you have no right to judge me|حق نداری قضاوتم کنی
you have to be kidding me|حتماً داری شوخی می_کنی
you have to believe in yourself|باید به خودت ایمان داشته باشی
you have to run|باید فرار کنی
you have to live|باید زنده بمونی
you have to stop this|باید این رو متوقف کنی
you have to stay alive|باید زنده بمونی
you have to be strong|باید قوی باشی
you have done enough|به اندازه_ی کافی کار کردی
you have done well|خوب کار کردی
you have done a great job|کارت عالی بود
you have saved me|نجاتم دادی
you have always been there for me|همیشه کنارم بودی
you should be ashamed of yourself|باید از خودت خجالت بکشی
you should have told me|باید بهم می_گفتی
you should not be here|نباید اینجا باشی
you should not have done that|نباید این کارو می_کردی
you should run|باید فرار کنی
you should go home|باید بری خونه
you should get some sleep|باید یکم بخوابی
you should be careful|باید مواظب باشی
you must be strong|باید قوی باشی
you must not die|نباید بمیری
you must not give up|نباید تسلیم بشی
you must survive|باید زنده بمونی
you must live|باید زنده بمونی
you must be joking|حتماً داری شوخی می_کنی
you must be the new student|حتماً تو دانش_آموز جدیدی
you look familiar|آشنا به نظر می_رسی
you look scared|ترسیده به نظر می_رسی
you look happy|خوشحال به نظر می_رسی
you look sad|ناراحت به نظر می_رسی
you look like you have seen a ghost|انگار روح دیدی
you look like someone i know|شبیه یه نفر هستی که می_شناسم
you sound different|صدات فرق کرده
you seem different today|امروز فرق کردی
you seem tired|خسته به نظر می_رسی
you seem worried|نگران به نظر می_رسی
you seem to be enjoying yourself|انگار داری خوش می_گذرونی
you really are something|تو واقعاً چیزی هستی
you really are stupid|تو واقعاً احمقی
you really are the worst|تو واقعاً بدترینی
you always say that|همیشه همین رو می_گی
you never change|هیچ_وقت عوض نمی_شی
you never told me|هیچ_وقت بهم نگفتی
you never learn|هیچ_وقت یاد نمی_گیری
you never listen to me|هیچ_وقت به حرفم گوش نمی_دی
you do not have to do this|مجبور نیستی این کارو بکنی
you do not have to say anything|لازم نیست چیزی بگی
you do not have to apologize|لازم نیست عذرخواهی کنی
you do not have to worry|لازم نیست نگران باشی
you do not have to be afraid|لازم نیست بترسی
you do not have to hide it|لازم نیست پنهونش کنی
you do not know what you are talking about|نمی_دونی درباره چی داری حرف می_زنی
you do not know anything about me|هیچی درباره_ی من نمی_دونی
you do not know what it feels like|نمی_دونی چه حسی داره
you do not know what you have done|نمی_دونی چیکار کردی
you do not understand how i feel|نمی_فهمی چه حسی دارم
you do not get it do you|نمی_فهمی، مگه نه؟
you do not belong here|تو به اینجا تعلق نداری
you do not deserve to live|لیاقت زنده موندن رو نداری
you do not deserve it|لیاقتش رو نداری
you do not need to say it|لازم نیست بگی
you do not scare me|منو نمی_ترسونی
you do not stand a chance|هیچ شانسی نداری
you do not have a chance|هیچ شانسی نداری
you do not look so good|حالت خوب به نظر نمی_رسه
you do not look well|حالت خوب به نظر نمی_رسه
you do not even know me|تو حتی منو نمی_شناسی
you do not even care|تو حتی برات مهم نیست
you do not even try|تو حتی تلاش هم نمی_کنی
you do not need to explain|لازم نیست توضیح بدی
do not make me say it again|مجبورم نکن دوباره بگم
do not make me repeat myself|مجبورم نکن تکرار کنم
do not make me laugh|نخندون منو
do not make that face|اون قیافه رو درست نکن
do not look so surprised|انقدر تعجب نکن
do not look at me like that|این طوری بهم نگاه نکن
do not get in my way|سر راهم قرار نگیر
do not get any closer|نزدیک_تر نیا
do not come any closer|نزدیک_تر نیا
do not come near me|بهم نزدیک نشو
do not come closer|نزدیک نیا
do not get me involved|منو قاطی این ماجرا نکن
do not get carried away|زیاده_روی نکن
do not get cocky|پرو نشو
do not get too close|زیادی نزدیک نشو
do not just stand there|اونجا وایسا نکن
do not just sit there|اونجا نشین
do not mess with me|با من در نیفت
do not mess with her|باهاش در نیفت
do not joke around|شوخی نکن
do not joke with me|باهام شوخی نکن
do not take it personally|شخصی نگیر
do not take this the wrong way|اشتباه برداشت نکن
do not tell anyone|به کسی نگو
do not tell anyone about this|این رو به کسی نگو
do not tell me you forgot|نگو که یادت رفته
do not tell me what to do|بهم نگو چیکار کنم
do not tell me it is over|نگو که تموم شده
do not talk like that|این طوری حرف نزن
do not talk nonsense|مزخرف نگو
do not talk to me|باهام حرف نزن
do not you ever|هیچ_وقت جرئت نکن
do not you dare touch her|جرئت نکن بهش دست بزنی
do not you dare say that|جرئت نکن اینو بگی
do not ever say that again|دیگه هیچ_وقت اینو نگو
do not ever come back|دیگه هیچ_وقت برنگرد
do not ever do that again|دیگه هیچ_وقت این کارو نکن
do not even think about it|حتی بهش فکر هم نکن
do not even try|حتی تلاش هم نکن
do not worry about me|نگران من نباش
do not worry i will be fine|نگران نباش من خوب می_شم
do not worry about it|نگرانش نباش
do not worry i am here|نگران نباش من اینجام
do not underestimate us|مارو دست کم نگیر
do not run away|فرار نکن
do not run from me|از دستم فرار نکن
do not turn around|برنگرد
do not look back|به عقب نگاه نکن
do not stop|متوقف نشو
do not stop now|الان متوقف نشو
do not stand there|اونجا نایست
do not let your guard down|گاردتو پایین نیار
do not let him get away|نذار فرار کنه
do not let them escape|نذار فرار کنن
do not let go|ول نکن
do not let go of my hand|دستمو ول نکن
do not let anyone in|نذار کسی بیاد تو
do not die on me|جلوی چشمم نمیر
do not you die on me|تو نباید جلوی چشمم بمیری
do not leave me alone|تنهام نذار
do not leave me here|منو اینجا ول نکن
do not leave without me|بدون من نرو
do not go anywhere|هیچ جا نرو
do not go yet|هنوز نرو
do not go in there|اونجا نرو
do not open it|بازش نکن
do not open the door|در رو باز نکن
do not eat that|اون رو نخور
do not speak|حرف نزن
do not speak so loudly|انقدر بلند حرف نزن
do not push me|هلم نده
do not provoke him|تحریکش نکن
do not blame me|منو سرزنش نکن
do not blame him|اون رو سرزنش نکن
do not cry anymore|دیگه گریه نکن
do not be so hard on yourself|انقدر به خودت سخت نگیر
do not be so sure|انقدر مطمئن نباش
do not be so cocky|انقدر پرو نباش
do not be so loud|انقدر سر و صدا نکن
do not be so sad|انقدر ناراحت نباش
do not be so quick to judge|عجله نکن تو قضاوت کردن
do not be ridiculous|مسخره بازی در نیار
do not be stupid|احمق نباش
do not be an idiot|احمق نباش
do not be like that|این طوری نباش
do not be shy|خجالت نکش
do not be nervous|استرس نداشته باش
do not be afraid of me|از من نترس
do not be afraid to ask|نترس بپرس
do not be too hard on him|زیاد بهش سخت نگیر
do not you understand|نمی_فهمی؟
do not you see|نمی_بینی؟
do not you get it|نمی_فهمی؟
do not you remember|یادت نیست؟
do not you trust me|بهم اعتماد نداری؟
do not you want to know|نمی_خوای بدونی؟
do not you think so|این طور فکر نمی_کنی؟
do not you have anything better to do|کار بهتری نداری؟
let me go|ولم کن
let me go please|تو رو خدا ولم کن
let me through|بذار رد شم
let me pass|بذار رد شم
let me see your face|بذار صورتتو ببینم
let me hear it|بذار بشنوم
let me try|بذار امتحان کنم
let me do it|بذار من انجامش بدم
let me finish|بذار تموم کنم
let me tell you something|بذار یه چیزی بهت بگم
let me show you something|بذار یه چیزی نشونت بدم
let me ask you something|بذار یه چیزی ازت بپرسم
let me introduce myself|بذار خودمو معرفی کنم
let me say this|بذار اینو بگم
let me take a look|بذار یه نگاه بندازم
let me know if you need anything|اگه چیزی لازم داشتی بهم بگو
let me take care of this|بذار من از این مراقبت کنم
let me carry that for you|بذار اونو برات ببرم
let me protect you|بذار ازت محافظت کنم
let me help|بذار کمک کنم
let me have some|بذار یکم برام بمونه
let us begin|شروع کنیم
let us finish this|این رو تموم کنیم
let us end this|این رو تموم کنیم
let us end this once and for all|بیا این رو یه بار برای همیشه تموم کنیم
let us settle this|بیا این رو حل کنیم
let us settle this with a fight|بیا با یه دعوا حلش کنیم
let us fight|بیا بجنگیم
let us find out|بیا بفهمیم
let us go home|بریم خونه
let us go together|با هم بریم
let us go back|برگردیم
let us hurry|عجله کنیم
let us try again|دوباره امتحان کنیم
let us do our best|تمام تلاشمونو بکنیم
let us work together|با هم کار کنیم
let us be friends|بیا دوست بشیم
let us not fight|دعوا نکنیم
let us meet again|دوباره همدیگه رو ببینیم
let us not waste time|وقت رو تلف نکنیم
let us get started|شروع کنیم
let us see what you got|بذار ببینم چی داری
let us see how strong you are|بذار ببینم چقدر قوی هستی
let us take a break|یه استراحت بکنیم
let us eat together|با هم غذا بخوریم
let us just go|فقط بریم
let us just forget it|بیخیالش بشیم
let us talk about it later|بعداً درباره_ش حرف می_زنیم
let us stay together|با هم بمونیم
let us make a promise|یه قول بذاریم
let us do it|بیا انجامش بدیم
let us do this together|با هم انجامش بدیم
please do not go|تو رو خدا نرو
please do not leave me|تو رو خدا ترکم نکن
please do not die|تو رو خدا نمیر
please do not cry|لطفاً گریه نکن
please do not hurt him|لطفاً بهش آسیب نزن
please do not kill me|لطفاً منو نکش
please do not tell anyone|لطفاً به کسی نگو
please help me|لطفاً کمکم کن
please forgive me|لطفاً منو ببخش
please listen to me|لطفاً به من گوش کن
please wait|لطفاً صبر کن
please wait a moment|لطفاً یه لحظه صبر کنید
please stop|لطفاً بس کن
please stay|لطفاً بمون
please come in|لطفاً بیا تو
please sit down|لطفاً بنشین
please be careful|لطفاً مواظب باش
please trust me|لطفاً بهم اعتماد کن
please believe me|لطفاً باور کن
please understand|لطفاً درک کن
please let me|لطفاً بذار
please do not do this|لطفاً این کارو نکن
please give me another chance|لطفاً یه فرصت دیگه بهم بده
please save him|لطفاً نجاتش بده
please save her|لطفاً نجاتش بده
please save my friend|لطفاً دوستمو نجات بده
please take care of her|لطفاً ازش مراقبت کن
please take care of him|لطفاً ازش مراقبت کن
please take care of my family|لطفاً از خانواده_م مراقبت کن
please say something|لطفاً یه چیزی بگو
please look at me|لطفاً به من نگاه کن
please open your eyes|لطفاً چشماتو باز کن
please wake up|لطفاً بیدار شو
please hurry|لطفاً عجله کن
senpai|سنپای
senpai notice me|سنپای منو ببین
sensei|سنسی
please teach me|لطفاً بهم یاد بده
please train me|لطفاً منو تمرین بده
please make me stronger|لطفاً منو قوی_تر کن
please accept my feelings|لطفاً احساسمو بپذیر
this is my first time|این اولین بارمه
this is my last chance|این آخرین شانسمه
this is my fault|این تقصیر منه
this is my final move|این آخرین حرکتمه
this is my true power|این قدرت واقعی منه
this is my true form|این شکل واقعی منه
this is my answer|این جواب منه
this is my resolve|این عزم منه
this is my promise|این قول منه
this is my duty|این وظیفه_ی منه
this is my mission|این ماموریت منه
this is my decision|این تصمیم منه
this is not the end|این پایان نیست
this is not what i wanted|این چیزی نیست که می_خواستم
this is not what i expected|این چیزی نیست که انتظار داشتم
this is not what it looks like|این اون چیزی نیست که به نظر میاد
this is not right|این درست نیست
this is not good|این خوب نیست
this is not over yet|این هنوز تموم نشده
this is not the time for this|الان وقتش نیست
this is not the place for that|اینجا جای این حرفا نیست
this is not funny at all|اصلاً خنده_دار نیست
this is not a dream|این خواب نیست
this is not a drill|این تمرین نیست
this is not possible|این امکان نداره
this is not happening|این داره اتفاق نمی_افته
this is not real|این واقعی نیست
this is all my fault|همه_ی این‌ها تقصیر منه
this is all your fault|همه_ی این‌ها تقصیر توئه
this is all a lie|همه_ی اینا دروغه
this is too much|این دیگه زیادیه
this is too dangerous|این خیلی خطرناکه
this is too good to be true|این زیادی خوبه که واقعی باشه
this is insane|این دیوونگیه
this is ridiculous|این مسخره_ست
this is unbelievable|باورنکردنیه
this is amazing|فوق_العاده_ست
this is incredible|باورنکردنیه
this is terrible|وحشتناکه
this is the worst|این بدترینه
this is the best day ever|این بهترین روز زندگیمه
this is the first time|این اولین باره
this is the last time|این آخرین باره
this is the only way|این تنها راهه
this is the end of the line|این آخر خطه
this is the final battle|این نبرد نهاییه
this is the real deal|این واقعیه
this is the moment|این همون لحظه_ست
this is where it ends|اینجا تموم می_شه
this is where we part|اینجا از هم جدا می_شیم
this is going to be fun|خیلی خوش می_گذره
this is going to hurt|درد داره
this is going to be a long night|شب طولانی_ای می_شه
this is going to end badly|بد تموم می_شه
this is going nowhere|این به جایی نمی_رسه
this is so embarrassing|خیلی خجالت_آوره
this is so annoying|خیلی اعصاب_خردکنه
this is so unfair|خیلی ناعادلانه_ست
this is so cool|خیلی باحاله
this is so scary|خیلی ترسناکه
this is so exciting|خیلی هیجان_انگیزه
this is so delicious|خیلی خوشمزه_ست
this is so sad|خیلی غم_انگیزه
this place is huge|این جا خیلی بزرگه
this place is creepy|این جا ترسناکه
this place is dangerous|این جا خطرناکه
this place is haunted|این جا جن_زده_ست
this place gives me the creeps|این جا ازش خوشم نمیاد، مو به تنم سیخ می_شه
this place is strange|این جا عجیبه
this power is incredible|این قدرت باورنکردنیه
this power is not normal|این قدرت عادی نیست
this energy is incredible|این انرژی باورنکردنیه
this aura is strong|این هاله قویه
this feeling is strange|این حس عجیبه
this feeling is real|این حس واقعیه
this smell is familiar|این بو آشناست
this sound is familiar|این صدا آشناست
this can not be|این نمی_تونه باشه
this can not go on|این نمی_تونه ادامه پیدا کنه
this can not be real|این نمی_تونه واقعی باشه
this can not be the end|این نمی_تونه پایان باشه
this changes everything|این همه چیز رو عوض می_کنه
this will be the end of you|این پایان توئه
this will not end well|این خوب تموم نمی_شه
this will only take a moment|فقط یه لحظه طول می_کشه
this will hurt a little|یه کم درد داره
this will do|همین کافیه
this might hurt|شاید درد داشته باشه
this should be enough|این باید کافی باشه
this should do it|این باید جواب بده
this must be a dream|حتماً این یه خوابه
this must be a mistake|حتماً این یه اشتباهه
this must be some kind of joke|حتماً این یه جور شوخیه
that is impossible|این غیرممکنه
that is dangerous|اون خطرناکه
that is so cool|اون خیلی باحاله
that is so cute|اون خیلی بامزه_ست
that is so sad|اون خیلی غم_انگیزه
that is so unfair|اون خیلی ناعادلانه_ست
that is so like you|دقیقاً مثل خودته
that is just like you|درست مثل خودته
that is not like you|این به تو نمیاد
that is not funny|این خنده_دار نیست
that is not the point|موضوع این نیست
that is not my problem|اون مشکل من نیست
that is not my concern|به من ربطی نداره
that is not how it works|این طوری کار نمی_کنه
that is not what i wanted|اون چیزی نیست که می_خواستم
that is not what i said|اون چیزی نیست که گفتم
that is not what happened|اون چیزی نیست که اتفاق افتاد
that is not enough|این کافی نیست
that is not all|همین نیست
that is not possible for you|این برای تو ممکن نیست
that is not a bad idea|ایده_ی بدی نیست
that is not true at all|اصلاً درست نیست
that is exactly what i mean|منظورم دقیقاً همینه
that is exactly what i thought|دقیقاً همین رو فکر می_کردم
that is exactly why|دقیقاً برای همین
that is why i am here|برای همینه که اینجام
that is why i said|برای همین گفتم
that is why i hate you|برای همین ازت متنفرم
that is the problem|مشکل همینه
that is the reason|دلیلش همینه
that is the truth|حقیقت همینه
that is all i know|همه_ی اون چیزی که می_دونم همینه
that is all i can say|همه_ی اون چیزی که می_تونم بگم همینه
that is all for today|برای امروز همین کافیه
that is more like it|حالا شد
that is a relief|چه آرامشی
that is a lot|خیلی زیاده
that is a good one|خوب بود
that is a great idea|ایده_ی عالیه
that is a bit much|کمی زیاده
that is a big problem|مشکل بزرگیه
that is a promise|این یه قوله
that is a strange thing to say|گفتن همچین چیزی عجیبه
that is quite enough|کافیه دیگه
that is one way to put it|یه جور می_شه این طور گفت
that sounds good|خوب به نظر می_رسه
that sounds fun|خوش می_گذره
that sounds like a plan|بد نیست
that sounds dangerous|خطرناک به نظر می_رسه
that sounds familiar|آشنا به نظر می_رسه
that sounds impossible|غیرممکن به نظر می_رسه
that sounds like you|مثل خودته
that looks painful|دردناک به نظر می_رسه
that looks delicious|خوشمزه به نظر می_رسه
that looks bad|بد به نظر می_رسه
that looks dangerous|خطرناک به نظر می_رسه
that looks good on you|بهت میاد
that looks great on you|خیلی بهت میاد
that makes two of us|منم همین طور
that reminds me|یادم انداخت
that hurts|درد داره
that hurt|درد داشت
that was a close one|نزدیک بود
that was fast|سریع بود
that was dangerous|خطرناک بود
that was scary|ترسناک بود
that was close|نزدیک بود
that was a mistake|اشتباه بود
that was a lie|دروغ بود
that was a great fight|مبارزه_ی عالی_ای بود
that was a joke|شوخی بود
that was amazing|فوق_العاده بود
that was impressive|تأثیرگذار بود
that was my first kiss|اون اولین بوسه_م بود
that was not a joke|شوخی نبود
that was not so bad|خیلی بد نبود
that was my line|اون حرف من بود
that was the last straw|اون آخرین قطره بود
that was easy|آسون بود
that was a trap|اون یه تله بود
that was just a dream|اون فقط یه خواب بود
that was unexpected|غیرمنتظره بود
that would be a problem|اون یه مشکل می_شه
that would be nice|خوب می_شه
that would be great|عالی می_شه
that would be a waste|اون هدر دادنه
that would be a mistake|اون یه اشتباه می_شه
that will not happen|این اتفاق نمی_افته
that will not be necessary|لازم نمی_شه
that will not work on me|این رو من جواب نمی_ده
that will be enough|همین کافیه
that will do for now|فعلاً همین کافیه
that should be enough|همین باید کافی باشه
that should not be possible|این نباید ممکن باشه
that can not be right|این نمی_تونه درست باشه
that can not be true|این نمی_تونه درست باشه
that is it for today|برای امروز همین
that is enough of that|دیگه بس کن
that is the spirit|همینه که می_خوام
that is the power of friendship|این قدرت دوستیه
that is the power of love|این قدرت عشقه
that is the end of the story|داستان همین جا تموم می_شه
that is too bad|حیف شد
that is too much for me|برای من زیاده
that is too far|اون خیلی دوره
that is no good|این خوب نیست
that is no joke|شوخی نیست
that is my answer|جواب من همینه
that is my decision|تصمیم من همینه
that is my dream|این رؤیای منه
that is my goal|این هدف منه
that is my job|این کار منه
that is none of my business|به من ربطی نداره
that is wonderful|عالیه
that is weird|عجیبه
that is strange|عجیبه
that is odd|عجیبه
that is sad|غم_انگیزه
that is scary|ترسناکه
that is gross|چندش_آوره
that is cute|بامزه_ست
that is cool|باحاله
that is funny|خنده_داره
that is rude|بی_ادبانه_ست
that is cruel|بی_رحمانه_ست
that is unfair|ناعادلانه_ست
that is not fair at all|اصلاً منصفانه نیست
that is just wrong|این فقط اشتباهه
that is just great|عالی شد
that is just perfect|عالی شد
that is so typical|خیلی معمولیه
that is easy for you to say|برای تو گفتنش آسونه
that is hard to believe|باورش سخته
that is hard to say|گفتنش سخته
that is a surprise|سورپرایزه
that is a shame|حیف شد
that is a pity|حیف شد
that is a first|اولین بار بود
that is a bad habit|عادت بدیه
that is quite a story|داستان جالبیه
that is a long story|داستانش طولانیه
that is a secret|یه رازه
that is a scary thought|فکر ترسناکیه
that is a big mistake|اشتباه بزرگیه
that is a good point|نکته_ی خوبیه
that is a nice name|اسم قشنگیه
that is a nice try|تلاش خوبی بود
that is a nice smile|لبخند قشنگیه
that is a lie and you know it|دروغه و خودت می_دونی
"""
}
