package app.tarjoman

import android.content.Context
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class Res(val text: String?, val info: String, val err: String?)

/** Routes a translation to the right engine according to the Normal/Advanced, Fast/Slow, Offline/Online settings. */
class Tr(private val ctx: Context) {
    val cfg = Cfg(ctx)
    val exec: ExecutorService = Executors.newSingleThreadExecutor()
    private val llm = LlmEngine(ctx)

    fun activeFile(): File? {
        val n = cfg.activeModel
        if (n.isNotBlank()) {
            val f = File(Models.dir(ctx), n)
            if (Models.isModelFile(f)) return f
        }
        return Models.installedFiles(ctx).firstOrNull()
    }

    /** Blocking. Call from a worker thread. */
    fun translate(text: String, s: String, d: String, prog: (String) -> Unit): Res {
        if (s == d || text.isBlank()) return Res(text, "-", null)
        val t0 = System.currentTimeMillis()
        val slow = cfg.speed == "slow"
        fun fin(out: String, eng: String): Res =
            Res(out, eng + " · " + ((System.currentTimeMillis() - t0) / 100) / 10.0 + "s", null)
        try {
            if (cfg.net == "online") {
                try {
                    if (cfg.mode == "advanced" && cfg.apiKey.isNotBlank()) {
                        return fin(viaApi(text, s, d, slow, prog), "API " + cfg.apiModel)
                    }
                    prog("اتصال به اینترنت…")
                    val o = Online.translate(text, s, d, cfg)
                    return fin(o.text, "آنلاین/" + o.provider)
                } catch (e: Exception) {
                    prog("آنلاین ناموفق بود (" + (e.message ?: "") + ")؛ رفتن به آفلاین…")
                }
            }
            if (cfg.mode == "advanced") {
                val f = activeFile()
                if (f != null) return fin(viaLlm(text, s, d, slow, prog, f), "AI/" + Models.titleOf(f))
                prog("مدل AI نصب نشده؛ استفاده از Normal")
            }
            return fin(MlKit.translate(text, s, d, prog), "ML Kit")
        } catch (e: Throwable) {
            return Res(null, "", friendly(e))
        }
    }

    private fun friendly(e: Throwable): String {
        val m = (e.cause?.message ?: e.message ?: e.toString())
        return if (m.contains("download", true) || m.contains("model", true) && m.contains("not", true))
            "بسته زبان/مدل در دسترس نیست. یک‌بار با اینترنت از تب «مدل‌ها» دانلود کن. ($m)" else m
    }

    private fun viaLlm(text: String, s: String, d: String, slow: Boolean, prog: (String) -> Unit, f: File): String {
        prog("بارگذاری مدل (بار اول چند ثانیه طول می‌کشد)…")
        llm.load(f)
        val fam = Models.famOf(cfg, f)
        val sys = Prompts.sys(s, d)
        val parts = Prompts.chunks(text, 380)
        val outs = ArrayList<String>()
        parts.forEachIndexed { i, ch ->
            if (ch.isBlank()) { outs.add(ch); return@forEachIndexed }
            prog("ترجمه " + (i + 1) + "/" + parts.size + "…")
            var out = Prompts.clean(llm.gen(Prompts.wrap(fam, sys, ch), slow))
            if (slow) {
                prog("ویرایش دقیق " + (i + 1) + "/" + parts.size + "…")
                out = Prompts.clean(llm.gen(Prompts.wrap(fam, sys, Prompts.refine(ch, out)), true))
            }
            outs.add(out)
        }
        return outs.joinToString("\n")
    }

    private fun viaApi(text: String, s: String, d: String, slow: Boolean, prog: (String) -> Unit): String {
        val sys = Prompts.sys(s, d)
        val parts = Prompts.chunks(text, 3000)
        val outs = ArrayList<String>()
        parts.forEachIndexed { i, ch ->
            if (ch.isBlank()) { outs.add(ch); return@forEachIndexed }
            prog("API " + (i + 1) + "/" + parts.size + "…")
            var out = Online.chatApi(cfg, sys, ch)
            if (slow) out = Online.chatApi(cfg, sys, Prompts.refine(ch, out))
            outs.add(out)
        }
        return outs.joinToString("\n")
    }
}
