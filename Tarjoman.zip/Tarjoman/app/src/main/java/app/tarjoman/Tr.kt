package app.tarjoman

import android.content.Context
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class Res(val text: String?, val info: String, val err: String?)

/** Routes a translation to the right engine according to the Normal/Advanced, Fast/Slow, Offline/Online settings. */
class Tr(private val ctx: Context) {
    companion object {
        @Volatile private var inst: Tr? = null
        fun get(ctx: Context): Tr = inst ?: synchronized(this) { inst ?: Tr(ctx.applicationContext).also { inst = it } }
    }

    val cfg = Cfg(ctx)

    init { Ocr.base = File(ctx.filesDir, "ocr"); Ocr.cfg = cfg; Idm.loadMine(cfg.userPhr) }
    // The AI model runs one job at a time on its own thread; Normal / online jobs never wait behind a slow AI job.
    private val execAi: ExecutorService = Executors.newSingleThreadExecutor()
    private val execFast: ExecutorService = Executors.newFixedThreadPool(2)
    val exec: java.util.concurrent.Executor = java.util.concurrent.Executor { r ->
        if (cfg.mode == "advanced" && cfg.net != "online") execAi.execute(r) else execFast.execute(r)
    }

    /** Raised by [cancelAi]: running AI jobs stop at their next checkpoint (between pieces of text). */
    @Volatile private var epoch = 0
    fun cancelAi() { epoch++ }
    private fun check(my: Int) { if (epoch != my) throw java.util.concurrent.CancellationException(L("متوقف شد")) }
    private val llm = LlmEngine(ctx)

    /** Small memory of finished translations: pressing "translate again" is instant. */
    private val cache = object : LinkedHashMap<String, String>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean = size > 300
    }

    fun activeFile(): File? {
        val n = cfg.activeModel
        if (n.isNotBlank()) {
            val f = File(Models.dir(ctx), n)
            if (Models.isModelFile(f)) return f
        }
        return Models.installedFiles(ctx).firstOrNull()
    }

    private fun cacheKey(text: String, s: String, d: String): String =
        listOf(cfg.mode, cfg.speed, cfg.net, if (cfg.mode == "advanced") (activeFile()?.name ?: "-") else "-",
            cfg.hybrid, cfg.style, cfg.preFix, cfg.colloq, cfg.glossary.hashCode(), cfg.userPhr.hashCode(), s, d).joinToString("|") + "\u0000" + text

    /** Blocking. Call from a worker thread. */
    fun translate(text: String, s: String, d: String, ctx: String = "", fresh: Boolean = false, online: Boolean = false, prog: (String) -> Unit): Res {
        val my = epoch
        if (s == d || text.isBlank()) return Res(text, "-", null)
        val t0 = System.currentTimeMillis()
        val slow = cfg.speed == "slow"
        val key = if (ctx.isBlank()) cacheKey(text, s, d) + (if (online) "\u0001on" else "") else null
        if (key != null) {
            val hit = if (fresh) null else synchronized(cache) { cache[key] }
            if (hit != null) return Res(hit, L("حافظه · فوری"), null)
        }
        // A translation the user corrected by hand always wins, in every mode.
        if (s == "en" && d == "fa") Idm.mineLookup(text)?.let { return Res(it, L("اصلاح من"), null) }
        fun fin(out0: String, eng: String): Res {
            var out = when (d) { "fa" -> Fa.fix(out0); "en" -> Pre.enOut(out0); else -> out0 }
            if (d == "fa" && cfg.colloq == 1 && cfg.style == "casual") out = Fa.casual(out)
            if (key != null && out.isNotBlank()) synchronized(cache) { cache[key] = out }
            return Res(out, eng + " · " + ((System.currentTimeMillis() - t0) / 100) / 10.0 + "s", null)
        }
        try {
            // online: always the internet; auto: the internet in Normal mode (or with an API key), the phone's own AI in Advanced
            val useNet = online || when (cfg.net) { "online" -> true; "auto" -> cfg.mode == "normal" || cfg.apiKey.isNotBlank(); else -> false }
            if (useNet) {
                if (!Net.isOnline(this.ctx)) {
                    if (cfg.net == "online" || online) prog(L("اینترنت وصل نیست؛ رفتن به آفلاین…"))
                } else {
                    try {
                        if (cfg.mode == "advanced" && cfg.apiKey.isNotBlank()) {
                            return fin(viaApi(text, s, d, slow, prog, ctx), "API " + cfg.apiModel)
                        }
                        prog(L("اتصال به اینترنت…"))
                        var prov = ""
                        val got = gloss(text) { t -> val o = Online.translate(t, s, d, cfg, fresh); prov = o.provider; o.text }
                        return fin(got, L("آنلاین/") + prov)
                    } catch (e: Exception) {
                        prog(L("آنلاین ناموفق بود (") + (e.message ?: "") + L(")؛ رفتن به آفلاین…"))
                    }
                }
            }
            if (cfg.mode == "advanced") {
                val f = activeFile()
                if (f != null) return fin(viaLlm(text, s, d, slow, prog, f, ctx, fresh, my), "AI/" + Models.titleOf(f))
                prog(L("مدل AI نصب نشده؛ استفاده از Normal"))
            }
            return fin(gloss(text) { t -> mk(t, s, d, fresh, prog) }, "ML Kit")
        } catch (e: java.util.concurrent.CancellationException) {
            return Res(null, "", L("متوقف شد"))
        } catch (e: Throwable) {
            return Res(null, "", friendly(e))
        }
    }

    /**
     * Many short blocks (manga bubbles, image text). In AI mode they go in one call, because every AI call has to read
     * the whole prompt again; if the model returns a different number of lines, each block is translated alone.
     * Returns the translations (the original text where one failed) and the first error, if any.
     */
    fun translateMany(texts: List<String>, s: String, d: String, fresh: Boolean, ctx: String = "", prog: (String) -> Unit): Pair<List<String>, String?> {
        if (cfg.mode == "advanced" && texts.size > 1) {
            val r = translate(texts.joinToString("\n") { it.replace("\n", " ").trim() }, s, d, ctx, fresh, prog)
            val lines = r.text?.split("\n")
            if (lines != null && lines.size == texts.size && lines.none { it.isBlank() }) return Pair(lines.map { it.trim() }, null)
            if (r.text == null && r.err == L("متوقف شد")) return Pair(texts, r.err)
        }
        var err: String? = null
        val out = ArrayList<String>()
        texts.forEachIndexed { i, t ->
            prog(L("ترجمه بلوک ") + (i + 1) + L(" از ") + texts.size + "…")
            val r = translate(t, s, d, if (cfg.speed == "slow" && i > 0) texts[i - 1] else "", fresh) { }
            if (r.text == null && err == null) err = r.err
            out.add(r.text ?: t)
        }
        return Pair(out, err)
    }

    /**
     * ML Kit. English input (with the clean-up on) is translated one short sentence at a time; known idioms and slang
     * are answered from the phrase table (Idm.kt) and only the rest goes to ML Kit, which is much better on short pieces.
     */
    private fun mk(text: String, s: String, d: String, fresh: Boolean = false, prog: (String) -> Unit): String {
        // "translate again" uses the plain ML Kit path (no clean-up / phrase table), which gives a different wording
        if (cfg.preFix != 1 || fresh) return MlKit.translate(text, s, d, prog)
        prog(L("آماده‌سازی بسته زبان…"))
        // Japanese -> Persian goes through English so the English clean-up and the phrase table can help
        val viaEn = s == "ja" && d == "fa"
        if (viaEn) { MlKit.ensure("ja", "en"); MlKit.ensure("en", "fa") } else MlKit.ensure(s, d)
        prog(L("ترجمه…"))
        val src = if (s == "fa") Fa.fix(text) else text
        val sep = if (d == "ja") "" else " "
        return src.split("\n").joinToString("\n") { line ->
            if (line.isBlank()) line else pieces(line, s).joinToString(sep) { seg ->
                when {
                    s == "en" -> enPiece(seg, d)
                    viaEn -> try { enPiece(MlKit.one(seg, "ja", "en"), "fa") } catch (e: Exception) { MlKit.one(seg, s, d) }
                    s == "fa" -> {
                        val hit = FaEn.lookup(seg)
                        if (hit != null) (if (d == "en") hit else MlKit.one(hit, "en", d)) else MlKit.one(Fa.formal(seg), s, d)
                    }
                    else -> MlKit.one(seg, s, d)
                }
            }
        }
    }

    private val jaSplit = Regex("(?<=[\u3002\uFF01\uFF1F])(?![\u300D\u300F\uFF09)\u201D\uFF01\uFF1F!?\u2026])\\s*")
    private val faSplit = Regex("(?<=[.!?\u061F\u2026])\\s+")

    /** One sentence at a time: ML Kit drops or merges sentences when a long line is given at once. */
    private fun pieces(line: String, s: String): List<String> = when (s) {
        "en" -> Idm.sentences(line)
        "ja" -> line.trim().split(jaSplit).filter { it.isNotBlank() }
        else -> line.trim().split(faSplit).filter { it.isNotBlank() }
    }

    private fun enPiece(sent: String, d: String): String {
        if (d == "fa") {
            val p = Idm.plan(sent)
            if (p != null) return Idm.assemble(p) { MlKit.one(Pre.line(it), "en", d) }
        }
        return MlKit.one(Pre.line(sent), "en", d)
    }

    /**
     * Glossary for the engines that cannot take instructions (ML Kit, online): the listed source words are swapped for
     * placeholders before translating and replaced by your translation afterwards (names, terms).
     */
    private fun gloss(text: String, run: (String) -> String): String {
        val es = cfg.glossary.lines().mapNotNull { l ->
            val i = l.indexOf('=')
            if (i <= 0) null else {
                val a = l.substring(0, i).trim()
                val b = l.substring(i + 1).trim()
                if (a.isEmpty() || b.isEmpty()) null else a to b
            }
        }.sortedByDescending { it.first.length }
        if (es.isEmpty()) return run(text)
        var t = text
        val used = ArrayList<String>()
        for ((a, b) in es) {
            val re = if (a.all { it.code < 128 }) Regex("\\b" + Regex.escape(a) + "\\b", RegexOption.IGNORE_CASE) else Regex(Regex.escape(a))
            if (re.containsMatchIn(t)) {
                val k = used.size
                used.add(b)
                t = re.replace(t, "TJ" + k + "X")
            }
        }
        if (used.isEmpty()) return run(text)
        var out = run(t)
        used.forEachIndexed { k, b ->
            out = Regex("TJ\\s?" + k + "\\s?X", RegexOption.IGNORE_CASE).replace(out, java.util.regex.Matcher.quoteReplacement(b))
        }
        return out
    }

    private fun friendly(e: Throwable): String {
        val m = (e.cause?.message ?: e.message ?: e.toString())
        if (m.contains("TensorBuffer", true) || m.contains("litert_lm", true))
            return L("این فایل مدل با موتور LiteRT-LM این نسخه سازگار نیست. مدل «Qwen 3 · 0.6B (LiteRT-LM)» (نسخهٔ رسمی ۶۰۰ مگابایتی) را امتحان کن.") + " ($m)"
        return if (m.contains("download", true) || m.contains("model", true) && m.contains("not", true))
            L("بسته زبان/مدل در دسترس نیست. یک‌بار با اینترنت از تب «مدل‌ها» دانلود کن.") + " ($m)" else m
    }

    /** ML Kit draft used by the hybrid mode; null when the language pack is not available. */
    private fun hybridDraft(text: String, s: String, d: String): String? =
        try { mk(text, s, d) { }.takeIf { it.isNotBlank() } } catch (_: Throwable) { null }

    private fun viaLlm(text: String, s: String, d: String, slow: Boolean, prog: (String) -> Unit, f: File, ctx: String, fresh: Boolean, my: Int): String {
        prog(L("بارگذاری مدل (بار اول چند ثانیه طول می‌کشد)…"))
        val lm = f.name.endsWith(".litertlm")
        if (lm) LmBridge.load(this.ctx, f) else llm.load(f)
        val fam = Models.famOf(cfg, f)
        // Fast = short prompt, one pass. Slow = full prompt (examples), context from earlier lines, and a second editing pass.
        val sys = if (slow) Prompts.sys(s, d, cfg.glossary, cfg.style) else Prompts.sysFast(s, d, cfg.glossary, cfg.style)
        val cx = if (slow) ctx else ""
        val noThink = lm && f.name.lowercase().contains("qwen3")
        // .litertlm models apply their own chat template; MediaPipe models need ours.
        fun g(user: String, sl: Boolean): String {
            check(my)
            return Prompts.clean(
                if (lm) LmBridge.gen(sys, if (noThink) "$user /no_think" else user, sl || fresh)
                else llm.gen(Prompts.wrap(fam, sys, user), sl, fresh)
            )
        }
        val parts = Prompts.chunks(text, if (slow) 300 else 520)
        // Small models are weakest at Persian, so the hybrid mode is only used when Persian is involved.
        val hybrid = cfg.hybrid == 1 && (s == "fa" || d == "fa")
        val outs = ArrayList<String>()
        parts.forEachIndexed { i, ch ->
            if (ch.isBlank()) { outs.add(ch); return@forEachIndexed }
            prog(L("ترجمه ") + (i + 1) + "/" + parts.size + "…")
            val draft = if (hybrid) hybridDraft(ch, s, d) else null
            var out: String
            if (draft != null) {
                out = g(Prompts.polish(ch, draft, d), slow)
                // If the model rambles, refuses or returns nothing, keep the safe ML Kit draft.
                if (out.isBlank() || out.length > draft.length * 3 + 40 || Prompts.refused(out, ch)) out = draft
            } else {
                out = g(Prompts.withCtx(cx, ch), slow)
                var fell = false
                if (Prompts.refused(out, ch)) {
                    // The model refused (profanity / adult words): ask again as fictional dialogue, else use ML Kit.
                    prog(L("مدل ترجمه را رد کرد؛ تلاش دوباره…"))
                    out = g(Prompts.framed(ch), true)
                    if (Prompts.refused(out, ch)) { out = hybridDraft(ch, s, d) ?: ch; fell = true }
                }
                // Small models often leave the text in English or mix scripts when asked for Persian: use the ML Kit draft instead.
                if (!fell && d == "fa" && Fa.looksBad(out)) {
                    val dr = hybridDraft(ch, s, d)
                    if (dr != null && !Fa.looksBad(dr)) { out = dr; fell = true }
                }
                if (slow && !fell && out.isNotBlank()) {
                    prog(L("ویرایش دقیق ") + (i + 1) + "/" + parts.size + "…")
                    val better = g(Prompts.refine(ch, out), true)
                    if (better.isNotBlank()) out = better
                }
                if (out.isBlank()) out = ch
            }
            outs.add(out)
        }
        return outs.joinToString("\n")
    }

    private fun viaApi(text: String, s: String, d: String, slow: Boolean, prog: (String) -> Unit, ctx: String): String {
        val sys = Prompts.sys(s, d, cfg.glossary, cfg.style)
        val parts = Prompts.chunks(text, 3000)
        val outs = ArrayList<String>()
        parts.forEachIndexed { i, ch ->
            if (ch.isBlank()) { outs.add(ch); return@forEachIndexed }
            prog("API " + (i + 1) + "/" + parts.size + "…")
            var out = Online.chatApi(cfg, sys, Prompts.withCtx(ctx, ch))
            if (slow) out = Online.chatApi(cfg, sys, Prompts.refine(ch, out))
            outs.add(out)
        }
        return outs.joinToString("\n")
    }
}
