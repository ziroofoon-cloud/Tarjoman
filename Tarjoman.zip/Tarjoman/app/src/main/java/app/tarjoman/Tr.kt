package app.tarjoman

import android.content.Context
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class Res(val text: String?, val info: String, val err: String?)

/** Routes a translation to the right engine according to the Normal/Advanced, Fast/Slow, Offline/Online settings. */
class Tr(private val ctx: Context) {
    companion object {
        @Volatile private var inst: Tr? = null
        fun get(ctx: Context): Tr = inst ?: synchronized(this) { inst ?: Tr(ctx.applicationContext).also { inst = it } }
    }

    val cfg = Cfg(ctx)

    init { Ocr.base = File(ctx.filesDir, "ocr") }
    val exec: ExecutorService = Executors.newSingleThreadExecutor()
    private val llm = LlmEngine(ctx)

    /** Small memory of finished translations: pressing "translate again" is instant. */
    private val cache = object : LinkedHashMap<String, String>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean = size > 300
    }

    fun activeFile(): File? {
        val n = cfg.activeModel
        if (n.isNotBlank()) {
            val f = File(Models.dir(ctx), n)
            if (Models.isModelFile(f)) return f
        }
        return Models.installedFiles(ctx).firstOrNull()
    }

    private fun cacheKey(text: String, s: String, d: String): String =
        listOf(cfg.mode, cfg.speed, cfg.net, if (cfg.mode == "advanced") (activeFile()?.name ?: "-") else "-",
            cfg.hybrid, cfg.style, cfg.preFix, cfg.colloq, cfg.glossary.hashCode(), s, d).joinToString("|") + "\u0000" + text

    /** Blocking. Call from a worker thread. */
    fun translate(text: String, s: String, d: String, ctx: String = "", prog: (String) -> Unit): Res {
        if (s == d || text.isBlank()) return Res(text, "-", null)
        val t0 = System.currentTimeMillis()
        val slow = cfg.speed == "slow"
        val key = if (ctx.isBlank()) cacheKey(text, s, d) else null
        if (key != null) {
            val hit = synchronized(cache) { cache[key] }
            if (hit != null) return Res(hit, L("حافظه · فوری"), null)
        }
        fun fin(out0: String, eng: String): Res {
            var out = if (d == "fa") Fa.fix(out0) else out0
            if (d == "fa" && cfg.colloq == 1 && cfg.style == "casual") out = Fa.casual(out)
            if (key != null && out.isNotBlank()) synchronized(cache) { cache[key] = out }
            return Res(out, eng + " · " + ((System.currentTimeMillis() - t0) / 100) / 10.0 + "s", null)
        }
        try {
            if (cfg.net == "online") {
                if (!Net.isOnline(this.ctx)) {
                    prog(L("اینترنت وصل نیست؛ رفتن به آفلاین…"))
                } else {
                    try {
                        if (cfg.mode == "advanced" && cfg.apiKey.isNotBlank()) {
                            return fin(viaApi(text, s, d, slow, prog, ctx), "API " + cfg.apiModel)
                        }
                        prog(L("اتصال به اینترنت…"))
                        val o = Online.translate(text, s, d, cfg)
                        return fin(o.text, L("آنلاین/") + o.provider)
                    } catch (e: Exception) {
                        prog(L("آنلاین ناموفق بود (") + (e.message ?: "") + L(")؛ رفتن به آفلاین…"))
                    }
                }
            }
            if (cfg.mode == "advanced") {
                val f = activeFile()
                if (f != null) return fin(viaLlm(text, s, d, slow, prog, f, ctx), "AI/" + Models.titleOf(f))
                prog(L("مدل AI نصب نشده؛ استفاده از Normal"))
            }
            return fin(mk(text, s, d, prog), "ML Kit")
        } catch (e: Throwable) {
            return Res(null, "", friendly(e))
        }
    }

    /**
     * ML Kit. English input (with the clean-up on) is translated one short sentence at a time; known idioms and slang
     * are answered from the phrase table (Idm.kt) and only the rest goes to ML Kit, which is much better on short pieces.
     */
    private fun mk(text: String, s: String, d: String, prog: (String) -> Unit): String {
        if (s != "en" || cfg.preFix != 1) return MlKit.translate(text, s, d, prog)
        prog(L("آماده‌سازی بسته زبان…"))
        MlKit.ensure(s, d)
        prog(L("ترجمه…"))
        return text.split("\n").joinToString("\n") { line ->
            if (line.isBlank()) line else Idm.sentences(line).joinToString(" ") { enPiece(it, d) }
        }
    }

    private fun enPiece(sent: String, d: String): String {
        if (d == "fa") {
            val p = Idm.plan(sent)
            if (p != null) return Idm.assemble(p) { MlKit.one(Pre.line(it), "en", d) }
        }
        return MlKit.one(Pre.line(sent), "en", d)
    }

    private fun friendly(e: Throwable): String {
        val m = (e.cause?.message ?: e.message ?: e.toString())
        return if (m.contains("download", true) || m.contains("model", true) && m.contains("not", true))
            L("بسته زبان/مدل در دسترس نیست. یک‌بار با اینترنت از تب «مدل‌ها» دانلود کن.") + " ($m)" else m
    }

    /** ML Kit draft used by the hybrid mode; null when the language pack is not available. */
    private fun hybridDraft(text: String, s: String, d: String): String? =
        try { mk(text, s, d) { }.takeIf { it.isNotBlank() } } catch (_: Throwable) { null }

    private fun viaLlm(text: String, s: String, d: String, slow: Boolean, prog: (String) -> Unit, f: File, ctx: String): String {
        prog(L("بارگذاری مدل (بار اول چند ثانیه طول می‌کشد)…"))
        val lm = f.name.endsWith(".litertlm")
        if (lm) LmBridge.load(this.ctx, f) else llm.load(f)
        val fam = Models.famOf(cfg, f)
        val sys = Prompts.sys(s, d, cfg.glossary, cfg.style)
        val noThink = lm && f.name.lowercase().contains("qwen3")
        // .litertlm models apply their own chat template; MediaPipe models need ours.
        fun g(user: String, sl: Boolean): String = Prompts.clean(
            if (lm) LmBridge.gen(sys, if (noThink) "$user /no_think" else user, sl)
            else llm.gen(Prompts.wrap(fam, sys, user), sl)
        )
        val parts = Prompts.chunks(text, 380)
        // Small models are weakest at Persian, so the hybrid mode is only used when Persian is involved.
        val hybrid = cfg.hybrid == 1 && (s == "fa" || d == "fa")
        val outs = ArrayList<String>()
        parts.forEachIndexed { i, ch ->
            if (ch.isBlank()) { outs.add(ch); return@forEachIndexed }
            prog(L("ترجمه ") + (i + 1) + "/" + parts.size + "…")
            val draft = if (hybrid) hybridDraft(ch, s, d) else null
            var out: String
            if (draft != null) {
                out = g(Prompts.polish(ch, draft, d), slow)
                // If the model rambles or returns nothing, keep the safe ML Kit draft.
                if (out.isBlank() || out.length > draft.length * 3 + 40) out = draft
            } else {
                out = g(Prompts.withCtx(ctx, ch), slow)
                if (slow && out.isNotBlank()) {
                    prog(L("ویرایش دقیق ") + (i + 1) + "/" + parts.size + "…")
                    val better = g(Prompts.refine(ch, out), true)
                    if (better.isNotBlank()) out = better
                }
                if (out.isBlank()) out = ch
            }
            outs.add(out)
        }
        return outs.joinToString("\n")
    }

    private fun viaApi(text: String, s: String, d: String, slow: Boolean, prog: (String) -> Unit, ctx: String): String {
        val sys = Prompts.sys(s, d, cfg.glossary, cfg.style)
        val parts = Prompts.chunks(text, 3000)
        val outs = ArrayList<String>()
        parts.forEachIndexed { i, ch ->
            if (ch.isBlank()) { outs.add(ch); return@forEachIndexed }
            prog("API " + (i + 1) + "/" + parts.size + "…")
            var out = Online.chatApi(cfg, sys, Prompts.withCtx(ctx, ch))
            if (slow) out = Online.chatApi(cfg, sys, Prompts.refine(ch, out))
            outs.add(out)
        }
        return outs.joinToString("\n")
    }
}
