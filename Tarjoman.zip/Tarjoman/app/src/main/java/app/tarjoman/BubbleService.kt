package app.tarjoman

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Floating bubble. Tap = translate the whole screen (a transparent layer is drawn over it),
 * long-press = settings panel. Screen pixels come from MediaProjection, text from ML Kit OCR.
 */
class BubbleService : Service() {
    companion object {
        const val ACTION_STOP = "app.tarjoman.STOP"
        @Volatile var running = false
    }

    private lateinit var wm: WindowManager
    private lateinit var cfg: Cfg
    private lateinit var tr: Tr
    private lateinit var ui: Ui
    private val h = Handler(Looper.getMainLooper())

    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var held: Image? = null
    private var sw = 0
    private var shh = 0
    private var dpi = 0

    private var bubble: View? = null
    private var overlay: FrameLayout? = null
    private var overlayView: View? = null
    private var panel: View? = null
    @Volatile private var job = 0
    private var busy = false
    private var bubLp: WindowManager.LayoutParams? = null
    private var bubSize = 0
    private var bubAnim: android.animation.ValueAnimator? = null

    /**
     * Puts the bubble where its mode says (called after every drag and when the mode changes).
     * free = stays where it is (kept on screen), lock = sticks to the left/right edge, sleep = at the edge, ~38% outside and faded.
     * forceSleep = the user pulled it out of the edge, so it sleeps right away whatever the mode is.
     */
    private fun bubSnap(animate: Boolean, forceSleep: Boolean = false) {
        val v = bubble ?: return
        val lp = bubLp ?: return
        val size = bubSize
        val mode = cfg.bubMode
        val sleep = forceSleep || mode == "sleep"
        val left = lp.x + size / 2 < sw / 2
        val hide = (size * 0.38f).toInt()
        val tx: Int = when {
            sleep -> if (left) -hide else sw - size + hide
            mode == "lock" -> if (left) 0 else sw - size
            else -> lp.x.coerceIn(-(size * 0.2f).toInt(), sw - size + (size * 0.2f).toInt())
        }
        val ty = lp.y.coerceIn(0, maxOf(0, shh - size))
        v.alpha = if (sleep) 0.45f else 0.92f
        bubAnim?.cancel()
        if (!animate) {
            lp.x = tx; lp.y = ty
            try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
            return
        }
        val x0 = lp.x
        val y0 = lp.y
        val an = android.animation.ValueAnimator.ofFloat(0f, 1f)
        an.duration = 160
        an.addUpdateListener {
            val f = it.animatedValue as Float
            lp.x = x0 + ((tx - x0) * f).toInt()
            lp.y = y0 + ((ty - y0) * f).toInt()
            try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
        }
        bubAnim = an
        an.start()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (projection != null) return START_NOT_STICKY
        startFg()
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data: Intent? = projData(intent)
        if (code != Activity.RESULT_OK || data == null) { stopSelf(); return START_NOT_STICKY }
        try {
            wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            cfg = Cfg(this)
            C.setup(this, cfg)
            tr = Tr.get(this)
            ui = Ui(this)
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mp = mpm.getMediaProjection(code, data)
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { h.post { stopSelf() } }
            }, h)
            projection = mp
            val dm = realMetrics()
            sw = dm.widthPixels; shh = dm.heightPixels; dpi = dm.densityDpi
            val r = ImageReader.newInstance(sw, shh, PixelFormat.RGBA_8888, 2)
            attachReader(r)
            reader = r
            vd = mp.createVirtualDisplay("tarjoman", sw, shh, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null)
            // Idle = no screen recording: the virtual display only gets a surface while a screenshot is being taken.
            try { vd?.setSurface(null) } catch (_: Exception) {}
            addBubble()
            running = true
        } catch (e: Throwable) {
            toast(L("شروع حباب ممکن نشد: ") + (e.message ?: e.toString()))
            stopSelf()
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun projData(i: Intent?): Intent? {
        if (i == null) return null
        return if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra("data", Intent::class.java) else i.getParcelableExtra<Intent>("data")
    }

    private fun startFg() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("bubble", "Tarjoman bubble", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 1, Intent(this, BubbleService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val open = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, "bubble")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle(L("ترجمان — حباب فعال است"))
            .setContentText(L("برای بستن حباب، دکمهٔ «بستن» را بزن"))
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, L("بستن"), stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    private fun toast(m: String) { h.post { Toast.makeText(this, m, Toast.LENGTH_LONG).show() } }

    private fun realMetrics(): DisplayMetrics {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        return dm
    }

    // ------------------------------------------------------------ screen capture
    private fun attachReader(r: ImageReader) {
        r.setOnImageAvailableListener({ rd ->
            val img = try { rd.acquireLatestImage() } catch (e: Exception) { null }
            if (img != null) {
                val old = held
                held = img
                try { old?.close() } catch (_: Exception) {}
            }
        }, h)
    }

    private fun ensureDisplay() {
        val dm = realMetrics()
        if (dm.widthPixels == sw && dm.heightPixels == shh) return
        sw = dm.widthPixels; shh = dm.heightPixels; dpi = dm.densityDpi
        try { held?.close() } catch (_: Exception) {}
        held = null
        val old = reader
        val nr = ImageReader.newInstance(sw, shh, PixelFormat.RGBA_8888, 2)
        attachReader(nr)
        vd?.resize(sw, shh, dpi)
        vd?.setSurface(nr.surface)
        reader = nr
        try { old?.close() } catch (_: Exception) {}
    }

    private fun frameBitmap(): Bitmap? {
        val img = held ?: return null
        return try {
            val p = img.planes[0]
            p.buffer.rewind()
            val bw = p.rowStride / p.pixelStride
            val raw = Bitmap.createBitmap(bw, img.height, Bitmap.Config.ARGB_8888)
            raw.copyPixelsFromBuffer(p.buffer)
            if (bw == img.width) raw else Bitmap.createBitmap(raw, 0, 0, img.width, img.height).also { raw.recycle() }
        } catch (e: Throwable) {
            null
        }
    }

    // ------------------------------------------------------------ bubble
    private fun overlayType() = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    private fun addBubble() {
        val size = ui.dp(54)
        val v = TextView(this).apply {
            text = "A文"
            textSize = 15f
            setTextColor(C.ONACC)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = ui.rect(C.ACC, 27)
            alpha = 0.92f
        }
        val lp = WindowManager.LayoutParams(
            size, size, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 0
        lp.y = ui.dp(220)
        bubLp = lp
        bubSize = size
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        v.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
            var moved = false; var longFired = false
            val longRun = Runnable { longFired = true; openPanel() }
            override fun onTouch(view: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        bubAnim?.cancel()
                        sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y
                        moved = false; longFired = false
                        view.alpha = 0.92f
                        h.postDelayed(longRun, 550)
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - sx
                        val dy = e.rawY - sy
                        if (!moved && (Math.abs(dx) > slop || Math.abs(dy) > slop)) { moved = true; h.removeCallbacks(longRun) }
                        if (moved) {
                            // The bubble can never leave the screen completely: at least 40% stays visible.
                            lp.x = (ox + dx.toInt()).coerceIn(-(size * 0.6f).toInt(), sw - size + (size * 0.6f).toInt())
                            lp.y = (oy + dy.toInt()).coerceIn(0, maxOf(0, shh - size))
                            try { wm.updateViewLayout(view, lp) } catch (_: Exception) {}
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        h.removeCallbacks(longRun)
                        // Pulled out of the screen edge = go to sleep quickly.
                        val pulledOut = moved && (lp.x < -(size * 0.2f) || lp.x > sw - size + (size * 0.2f))
                        bubSnap(true, pulledOut)
                        if (!moved && !longFired) onBubbleTap()
                    }
                    MotionEvent.ACTION_CANCEL -> { h.removeCallbacks(longRun); bubSnap(true, false) }
                }
                return true
            }
        })
        wm.addView(v, lp)
        bubble = v
        bubSnap(false, false)
    }

    // ------------------------------------------------------------ tap = translate, double tap = back to the original screen
    private var tapPending = false
    private val tapRun = Runnable {
        tapPending = false
        if (cfg.liveScr == 1) liveStart()
        translateScreen()
    }

    private fun onBubbleTap() {
        if (tapPending) {
            h.removeCallbacks(tapRun)
            tapPending = false
            liveStop()
            closeOverlay()
            return
        }
        tapPending = true
        h.postDelayed(tapRun, 300)
    }

    // ------------------------------------------------------------ rotation
    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        if (bubble == null) return
        h.removeCallbacks(tapRun)
        tapPending = false
        liveStop()
        closePanel()
        closeOverlay()
        h.postDelayed({ onRotated() }, 250)
    }

    /** New screen size: resize the (idle) capture, keep the bubble on screen and bring it back if the system hid it. */
    private fun onRotated() {
        val v = bubble ?: return
        val lp = bubLp ?: return
        val dm = realMetrics()
        sw = dm.widthPixels; shh = dm.heightPixels; dpi = dm.densityDpi
        try { held?.close() } catch (_: Exception) {}
        held = null
        try {
            val old = reader
            val nr = ImageReader.newInstance(sw, shh, PixelFormat.RGBA_8888, 2)
            attachReader(nr)
            vd?.resize(sw, shh, dpi)
            vd?.setSurface(null)
            reader = nr
            try { old?.close() } catch (_: Exception) {}
        } catch (_: Throwable) {}
        v.visibility = View.VISIBLE
        lp.y = lp.y.coerceIn(0, maxOf(0, shh - bubSize))
        bubSnap(false, false)
        try { wm.removeView(v) } catch (_: Exception) {}
        try { wm.addView(v, lp) } catch (_: Exception) {}
    }

    // ------------------------------------------------------------ translate screen
    private fun translateScreen() {
        if (busy) return
        busy = true
        closePanel()
        closeOverlay()
        bubble?.visibility = View.INVISIBLE
        capture(0) { bmp ->
            if (bmp == null) {
                bubble?.visibility = View.VISIBLE
                busy = false
                toast(L("تصویر صفحه گرفته نشد؛ دوباره امتحان کن."))
                liveResume(1800)
            } else {
                bubble?.visibility = View.VISIBLE
                showOverlay(bmp)
                busy = false
            }
        }
    }

    /** One screenshot: the capture is switched on only for this moment (no constant screen recording). */
    private fun capture(attempt: Int, cb: (Bitmap?) -> Unit) {
        if (attempt == 0) {
            ensureDisplay()
            try { held?.close() } catch (_: Exception) {}
            held = null
            try { vd?.setSurface(reader?.surface) } catch (_: Exception) {}
        }
        h.postDelayed({
            val bmp = frameBitmap()
            if (bmp == null && attempt < 8) { capture(attempt + 1, cb); return@postDelayed }
            try { vd?.setSurface(null) } catch (_: Exception) {}
            try { held?.close() } catch (_: Exception) {}
            held = null
            cb(bmp)
        }, if (attempt == 0) 350L else 500L)
    }

    // ------------------------------------------------------------ live mode (page turns are translated again by themselves)
    @Volatile private var liveActive = false
    private var liveBase: IntArray? = null
    private var livePending = false
    private var translating = false

    private fun sigOf(b: Bitmap): IntArray {
        val sm = Bitmap.createScaledBitmap(b, 36, 72, true)
        val px = IntArray(36 * 72)
        sm.getPixels(px, 0, 36, 0, 0, 36, 72)
        if (sm !== b) sm.recycle()
        return IntArray(px.size) { i -> ((px[i] shr 16 and 0xFF) * 3 + (px[i] shr 8 and 0xFF) * 6 + (px[i] and 0xFF)) / 10 }
    }

    private fun sigDiff(a: IntArray, b: IntArray): Float {
        var n = 0
        for (i in a.indices) if (Math.abs(a[i] - b[i]) > 28) n++
        return n.toFloat() / a.size
    }

    private fun liveStart() { liveActive = true; liveBase = null; livePending = false }

    private fun liveStop() {
        liveActive = false
        h.removeCallbacks(liveTick)
    }

    private fun liveResume(delay: Long) {
        if (!liveActive) return
        liveBase = null
        livePending = false
        h.removeCallbacks(liveTick)
        h.postDelayed(liveTick, delay)
    }

    /** Every ~2 s: look at the screen; when it changed and then stayed still (a new page), translate it. */
    private val liveTick = object : Runnable {
        override fun run() {
            if (!liveActive) return
            if (busy || translating || panel != null) { h.postDelayed(this, 1200); return }
            capture(0) { bmp ->
                if (!liveActive) { bmp?.recycle(); return@capture }
                if (bmp == null) { h.postDelayed(this, 2000); return@capture }
                val sig = sigOf(bmp)
                bmp.recycle()
                val base = liveBase
                liveBase = sig
                if (base != null) {
                    if (sigDiff(base, sig) > 0.06f) livePending = true
                    else if (livePending) { livePending = false; translateScreen(); return@capture }
                }
                h.postDelayed(this, 1600)
            }
        }
    }

    private inner class OverlayView(ctx: Context) : View(ctx) {
        var blocks: List<OBlock> = emptyList()
        override fun onDraw(c: Canvas) {
            val sc = cfg.fontScale / 100f
            for (b in blocks) Ocr.draw(c, b, sc)
        }
    }

    private fun showOverlay(bmp: Bitmap) {
        val s = cfg.src
        val d = cfg.dst
        val ov = OverlayView(this)
        ov.alpha = cfg.opacity / 100f
        val root = FrameLayout(this)
        root.addView(ov, FrameLayout.LayoutParams(-1, -1))

        // No control bar on the layer: the bubble shows progress, touches go straight through to the app below.
        // Tap the bubble again to hide the layer; long-press it for settings, copy and "translate again".
        val st = TextView(this)
        st.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun afterTextChanged(e: android.text.Editable?) { bubbleStatus(e?.toString() ?: "") }
        })
        st.text = L("در حال خواندن متن…")

        val lp = WindowManager.LayoutParams(
            sw, shh, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        wm.addView(root, lp)
        // keep the bubble above the layer
        bubble?.let { b -> try { wm.removeView(b); wm.addView(b, bubLp) } catch (_: Exception) {} }
        overlay = root
        overlayView = ov

        val myJob = ++job
        translating = true
        tr.exec.execute {
            try {
                val blocks = Ocr.read(bmp, s)
                bmp.recycle()
                if (job != myJob) return@execute
                if (blocks.isEmpty()) { h.post { st.text = L("متنی روی صفحه پیدا نشد.") }; return@execute }
                h.post { ov.blocks = blocks; st.text = L("ترجمه… 0/") + blocks.size }
                var info = ""
                val prev = ArrayList<String>()
                for ((i, b) in blocks.withIndex()) {
                    if (job != myJob) return@execute
                    // In slow mode the previous blocks go to the AI as context (same scene / same page).
                    val cx = if (cfg.speed == "slow") prev.takeLast(2).joinToString("\n") else ""
                    val r = tr.translate(b.text, s, d, cx) { }
                    prev.add(b.text)
                    val t = r.text
                    if (t == null) { h.post { st.text = L("خطا: ") + r.err }; return@execute }
                    b.out = t
                    info = r.info
                    val k = i + 1
                    h.post { ov.invalidate(); st.text = k.toString() + "/" + blocks.size + " · " + info }
                }
                h.post { st.text = L("تمام شد · ") + info }
            } catch (e: Throwable) {
                h.post { st.text = L("خطا: ") + (e.cause?.message ?: e.message) }
            } finally {
                h.post { if (job == myJob) { translating = false; liveResume(2000) } }
            }
        }
    }

    /** Progress on the bubble itself (no bar on the layer): "…" while working, "3/12" per block, back to the icon when done. */
    private fun bubbleStatus(t: String) {
        val b = bubble as? TextView ?: return
        when {
            t.startsWith(L("تمام شد")) -> { b.text = "A文"; b.textSize = 15f }
            t.startsWith(L("خطا")) || t == L("متنی روی صفحه پیدا نشد.") -> { b.text = "A文"; b.textSize = 15f; toast(t) }
            t.matches(Regex("\\d+/\\d+.*")) -> { b.text = t.substringBefore(" ·"); b.textSize = 11f }
            else -> { b.text = "…"; b.textSize = 15f }
        }
    }

    private fun closeOverlay() {
        job++
        translating = false
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        overlay = null
        overlayView = null
        bubble?.visibility = View.VISIBLE
    }

    // ------------------------------------------------------------ settings panel
    private fun nextLang(cur: String, other: String): String {
        val all = Lang.all
        var i = all.indexOf(cur)
        repeat(all.size) {
            i = (i + 1) % all.size
            if (all[i] != other) return all[i]
        }
        return cur
    }

    private fun openPanel() {
        if (panel != null) return
        C.setup(this, cfg)   // pick up a theme change made while the bubble was running
        val root = FrameLayout(this).apply {
            setBackgroundColor(0x99000000.toInt())
            setOnClickListener { closePanel() }
        }
        val card = ui.card().apply {
            layoutDirection = S.dir
            isClickable = true
        }
        card.addView(ui.tv(L("ترجمان · تنظیمات حباب"), 16f, C.TXT, true))

        val lr = ui.hbox()
        val sBtn = ui.btn("", false) { }
        val dBtn = ui.btn("", false) { }
        fun refresh() {
            sBtn.text = L("از") + ": " + Lang.name(cfg.src).substringBefore(" ·")
            dBtn.text = L("به") + ": " + Lang.name(cfg.dst).substringBefore(" ·")
        }
        sBtn.setOnClickListener { cfg.src = nextLang(cfg.src, cfg.dst); refresh() }
        dBtn.setOnClickListener { cfg.dst = nextLang(cfg.dst, cfg.src); refresh() }
        val sw2 = ui.iconBtn("swap", 44, true) { val a = cfg.src; cfg.src = cfg.dst; cfg.dst = a; refresh() }
        lr.addView(sBtn, ui.hlp())
        lr.addView(sw2, LinearLayout.LayoutParams(ui.dp(44), ui.dp(44)).apply { marginStart = ui.dp(6) })
        lr.addView(dBtn, ui.hlp(1f, 6))
        refresh()
        card.addView(lr, ui.lp(top = 10))

        fun row(label: String, opts: List<String>, sel: Int, on: (Int) -> Unit) {
            card.addView(ui.tv(label, 12f, C.SUB), ui.lp(top = 8))
            card.addView(ui.seg(opts, sel, on), ui.lp(top = 3))
        }
        row(L("موتور ترجمه"), listOf(L("Normal (سبک)"), "Advanced (AI)"), if (cfg.mode == "advanced") 1 else 0) { cfg.mode = if (it == 1) "advanced" else "normal" }
        row(L("سرعت / دقت"), listOf(L("سریع"), L("کند و دقیق")), if (cfg.speed == "slow") 1 else 0) { cfg.speed = if (it == 1) "slow" else "fast" }
        row(L("اتصال"), listOf(L("آفلاین"), L("آنلاین")), if (cfg.net == "online") 1 else 0) { cfg.net = if (it == 1) "online" else "offline" }

        row(L("ترکیب ML Kit + AI (آزمایشی)"), listOf(L("خاموش"), L("روشن")), cfg.hybrid) { cfg.hybrid = it }
        row(L("ترجمه زنده (ورق زدن)"), listOf(L("خاموش"), L("روشن")), cfg.liveScr) { cfg.liveScr = it; if (it == 0) liveStop() }
        val bm = listOf("free", "lock", "sleep")
        row(L("حالت حباب"), listOf(L("آزاد"), L("قفل"), L("خواب")), bm.indexOf(cfg.bubMode).coerceAtLeast(0)) { cfg.bubMode = bm[it]; bubSnap(true, false) }

        val inst = Models.installedFiles(this)
        if (inst.isNotEmpty()) {
            val mb = ui.btn(L("مدل AI: ") + (tr.activeFile()?.let { Models.titleOf(it) } ?: "-"), false) { }
            mb.setOnClickListener {
                val list = Models.installedFiles(this)
                if (list.isNotEmpty()) {
                    val cur = list.indexOfFirst { it.name == tr.activeFile()?.name }
                    val n = list[(cur + 1) % list.size]
                    cfg.activeModel = n.name
                    mb.text = L("مدل AI: ") + Models.titleOf(n)
                }
            }
            card.addView(mb, ui.lp(top = 10))
        }

        card.addView(ui.slider(L("شفافیت لایه"), 20, 100, cfg.opacity) { v -> cfg.opacity = v; overlayView?.alpha = v / 100f }, ui.lp(top = 10))
        card.addView(ui.slider(L("اندازه متن ترجمه"), 60, 160, cfg.fontScale) { v -> cfg.fontScale = v; overlayView?.invalidate() }, ui.lp(top = 6))

        val ar = ui.hbox()
        ar.addView(ui.btn(L("دوباره"), false) { translateScreen() }, ui.hlp())
        ar.addView(ui.btn(L("کپی"), false) {
            val txt = (overlayView as? OverlayView)?.blocks?.filter { it.out.isNotEmpty() }?.joinToString("\n\n") { it.out } ?: ""
            if (txt.isNotEmpty()) {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("tr", txt))
                toast(L("متن ترجمه کپی شد"))
            }
        }, ui.hlp(1f, 6))
        ar.addView(ui.btn(L("بستن لایه"), false) { closePanel(); liveStop(); closeOverlay() }, ui.hlp(1f, 6))
        card.addView(ar, ui.lp(top = 12))

        val br = ui.hbox()
        br.addView(ui.btn(L("خاموش کردن حباب"), false) { stopSelf() }, ui.hlp())
        br.addView(ui.btn(L("بستن پنل")) { closePanel() }, ui.hlp(1f, 8))
        card.addView(br, ui.lp(top = 12))

        // Smaller panel that scrolls: about 62% of the height in portrait, almost full height in landscape.
        val land = sw > shh
        val pw = if (land) (sw * 0.6f).toInt() else (sw * 0.84f).toInt()
        val ph = if (land) (shh * 0.9f).toInt() else (shh * 0.62f).toInt()
        val sv = ScrollView(this).apply {
            isVerticalScrollBarEnabled = true
            isFillViewport = false
            background = ui.rect(C.CARD, C.R_CARD, C.STROKE)
        }
        card.background = null
        sv.addView(card)
        root.addView(sv, FrameLayout.LayoutParams(pw, ph, Gravity.CENTER))

        val lp = WindowManager.LayoutParams(
            sw, shh, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        wm.addView(root, lp)
        panel = root
    }

    private fun closePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
    }

    override fun onDestroy() {
        running = false
        job++
        bubAnim?.cancel()
        h.removeCallbacks(tapRun)
        liveStop()
        closePanel()
        closeOverlay()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        try { held?.close() } catch (_: Exception) {}
        held = null
        try { vd?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
        super.onDestroy()
    }
}
