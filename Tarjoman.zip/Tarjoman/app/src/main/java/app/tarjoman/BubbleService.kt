package app.tarjoman

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Floating bubble. Tap = translate the whole screen (a transparent layer is drawn over it),
 * long-press = settings panel. Screen pixels come from MediaProjection, text from ML Kit OCR.
 */
class BubbleService : Service() {
    companion object {
        const val ACTION_STOP = "app.tarjoman.STOP"
        @Volatile var running = false
    }

    private lateinit var wm: WindowManager
    private lateinit var cfg: Cfg
    private lateinit var tr: Tr
    private lateinit var ui: Ui
    private val h = Handler(Looper.getMainLooper())

    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var held: Image? = null
    private var sw = 0
    private var shh = 0
    private var dpi = 0

    private var bubble: View? = null
    private var overlay: FrameLayout? = null
    private var overlayView: View? = null
    private var panel: View? = null
    @Volatile private var job = 0
    private var busy = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (projection != null) return START_NOT_STICKY
        startFg()
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data: Intent? = projData(intent)
        if (code != Activity.RESULT_OK || data == null) { stopSelf(); return START_NOT_STICKY }
        try {
            wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            cfg = Cfg(this)
            C.apply(cfg.theme == "classic")
            tr = Tr.get(this)
            ui = Ui(this)
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mp = mpm.getMediaProjection(code, data)
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { h.post { stopSelf() } }
            }, h)
            projection = mp
            val dm = realMetrics()
            sw = dm.widthPixels; shh = dm.heightPixels; dpi = dm.densityDpi
            val r = ImageReader.newInstance(sw, shh, PixelFormat.RGBA_8888, 2)
            attachReader(r)
            reader = r
            vd = mp.createVirtualDisplay("tarjoman", sw, shh, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null)
            addBubble()
            running = true
        } catch (e: Throwable) {
            toast("شروع حباب ممکن نشد: " + (e.message ?: e.toString()))
            stopSelf()
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun projData(i: Intent?): Intent? {
        if (i == null) return null
        return if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra("data", Intent::class.java) else i.getParcelableExtra<Intent>("data")
    }

    private fun startFg() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("bubble", "Tarjoman bubble", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 1, Intent(this, BubbleService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val open = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, "bubble")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("ترجمان — حباب فعال است")
            .setContentText("برای بستن حباب، دکمهٔ «بستن» را بزن")
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "بستن", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    private fun toast(m: String) { h.post { Toast.makeText(this, m, Toast.LENGTH_LONG).show() } }

    private fun realMetrics(): DisplayMetrics {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        return dm
    }

    // ------------------------------------------------------------ screen capture
    private fun attachReader(r: ImageReader) {
        r.setOnImageAvailableListener({ rd ->
            val img = try { rd.acquireLatestImage() } catch (e: Exception) { null }
            if (img != null) {
                val old = held
                held = img
                try { old?.close() } catch (_: Exception) {}
            }
        }, h)
    }

    private fun ensureDisplay() {
        val dm = realMetrics()
        if (dm.widthPixels == sw && dm.heightPixels == shh) return
        sw = dm.widthPixels; shh = dm.heightPixels; dpi = dm.densityDpi
        try { held?.close() } catch (_: Exception) {}
        held = null
        val old = reader
        val nr = ImageReader.newInstance(sw, shh, PixelFormat.RGBA_8888, 2)
        attachReader(nr)
        vd?.resize(sw, shh, dpi)
        vd?.setSurface(nr.surface)
        reader = nr
        try { old?.close() } catch (_: Exception) {}
    }

    private fun frameBitmap(): Bitmap? {
        val img = held ?: return null
        return try {
            val p = img.planes[0]
            p.buffer.rewind()
            val bw = p.rowStride / p.pixelStride
            val raw = Bitmap.createBitmap(bw, img.height, Bitmap.Config.ARGB_8888)
            raw.copyPixelsFromBuffer(p.buffer)
            if (bw == img.width) raw else Bitmap.createBitmap(raw, 0, 0, img.width, img.height).also { raw.recycle() }
        } catch (e: Throwable) {
            null
        }
    }

    // ------------------------------------------------------------ bubble
    private fun overlayType() = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    private fun addBubble() {
        val size = ui.dp(54)
        val v = TextView(this).apply {
            text = "A文"
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = ui.rect(C.ACC, 27)
            alpha = 0.92f
        }
        val lp = WindowManager.LayoutParams(
            size, size, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = ui.dp(8)
        lp.y = ui.dp(220)
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        v.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
            var moved = false; var longFired = false
            val longRun = Runnable { longFired = true; openPanel() }
            override fun onTouch(view: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y
                        moved = false; longFired = false
                        h.postDelayed(longRun, 550)
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - sx
                        val dy = e.rawY - sy
                        if (!moved && (Math.abs(dx) > slop || Math.abs(dy) > slop)) { moved = true; h.removeCallbacks(longRun) }
                        if (moved) {
                            lp.x = ox + dx.toInt()
                            lp.y = oy + dy.toInt()
                            try { wm.updateViewLayout(view, lp) } catch (_: Exception) {}
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        h.removeCallbacks(longRun)
                        if (!moved && !longFired) translateScreen()
                    }
                    MotionEvent.ACTION_CANCEL -> h.removeCallbacks(longRun)
                }
                return true
            }
        })
        wm.addView(v, lp)
        bubble = v
    }

    // ------------------------------------------------------------ translate screen
    private fun translateScreen() {
        if (busy) return
        busy = true
        closePanel()
        closeOverlay()
        bubble?.visibility = View.INVISIBLE
        ensureDisplay()
        grab(0)
    }

    private fun grab(attempt: Int) {
        h.postDelayed({
            val bmp = frameBitmap()
            if (bmp == null && attempt < 4) { grab(attempt + 1); return@postDelayed }
            if (bmp == null) {
                bubble?.visibility = View.VISIBLE
                busy = false
                toast("تصویر صفحه گرفته نشد؛ دوباره امتحان کن.")
                return@postDelayed
            }
            bubble?.visibility = View.GONE
            showOverlay(bmp)
            busy = false
        }, if (attempt == 0) 350L else 500L)
    }

    private inner class OverlayView(ctx: Context) : View(ctx) {
        var blocks: List<OBlock> = emptyList()
        override fun onDraw(c: Canvas) {
            val sc = cfg.fontScale / 100f
            for (b in blocks) Ocr.draw(c, b, sc)
        }
    }

    private fun showOverlay(bmp: Bitmap) {
        val s = cfg.src
        val d = cfg.dst
        val ov = OverlayView(this)
        ov.alpha = cfg.opacity / 100f
        val root = FrameLayout(this)
        root.addView(ov, FrameLayout.LayoutParams(-1, -1))

        val st = ui.tv("در حال خواندن متن…", 12f, C.TXT)
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = ui.rect((C.CARD and 0x00FFFFFF) or 0xEE000000.toInt(), 18, C.STROKE)
            setPadding(ui.dp(12), ui.dp(10), ui.dp(12), ui.dp(10))
        }
        bar.addView(st)
        bar.addView(ui.slider("شفافیت لایه", 20, 100, cfg.opacity) { v -> cfg.opacity = v; ov.alpha = v / 100f }, ui.lp(top = 4))
        val row = ui.hbox()
        row.addView(ui.btn("دوباره", false) { translateScreen() }, ui.hlp())
        row.addView(ui.btn("کپی", false) {
            val txt = (overlayView as? OverlayView)?.blocks?.filter { it.out.isNotEmpty() }?.joinToString("\n\n") { it.out } ?: ""
            if (txt.isNotEmpty()) {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("tr", txt))
                toast("متن ترجمه کپی شد")
            }
        }, ui.hlp(1f, 6))
        row.addView(ui.btn("تنظیمات", false) { openPanel() }, ui.hlp(1f, 6))
        row.addView(ui.btn("✕") { closeOverlay() }, ui.hlp(1f, 6))
        bar.addView(row, ui.lp(top = 6))
        root.addView(bar, FrameLayout.LayoutParams((sw * 0.94f).toInt(), -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = ui.dp(40) })

        val lp = WindowManager.LayoutParams(
            sw, shh, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        wm.addView(root, lp)
        overlay = root
        overlayView = ov

        val myJob = ++job
        tr.exec.execute {
            try {
                val blocks = Ocr.read(bmp, s)
                bmp.recycle()
                if (job != myJob) return@execute
                if (blocks.isEmpty()) { h.post { st.text = "متنی روی صفحه پیدا نشد." }; return@execute }
                h.post { ov.blocks = blocks; st.text = "ترجمه… 0/" + blocks.size }
                var info = ""
                val prev = ArrayList<String>()
                for ((i, b) in blocks.withIndex()) {
                    if (job != myJob) return@execute
                    // In slow mode the previous blocks go to the AI as context (same scene / same page).
                    val cx = if (cfg.speed == "slow") prev.takeLast(2).joinToString("\n") else ""
                    val r = tr.translate(b.text, s, d, cx) { }
                    prev.add(b.text)
                    val t = r.text
                    if (t == null) { h.post { st.text = "خطا: " + r.err }; return@execute }
                    b.out = t
                    info = r.info
                    val k = i + 1
                    h.post { ov.invalidate(); st.text = k.toString() + "/" + blocks.size + " · " + info }
                }
                h.post { st.text = "تمام شد · " + info }
            } catch (e: Throwable) {
                h.post { st.text = "خطا: " + (e.cause?.message ?: e.message) }
            }
        }
    }

    private fun closeOverlay() {
        job++
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        overlay = null
        overlayView = null
        bubble?.visibility = View.VISIBLE
    }

    // ------------------------------------------------------------ settings panel
    private fun nextLang(cur: String, other: String): String {
        val all = Lang.all
        var i = all.indexOf(cur)
        repeat(all.size) {
            i = (i + 1) % all.size
            if (all[i] != other) return all[i]
        }
        return cur
    }

    private fun openPanel() {
        if (panel != null) return
        val root = FrameLayout(this).apply {
            setBackgroundColor(0x99000000.toInt())
            setOnClickListener { closePanel() }
        }
        val card = ui.card().apply {
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            isClickable = true
        }
        card.addView(ui.tv("ترجمان · تنظیمات حباب", 16f, C.TXT, true))

        val lr = ui.hbox()
        val sBtn = ui.btn("", false) { }
        val dBtn = ui.btn("", false) { }
        fun refresh() {
            sBtn.text = Lang.name(cfg.src).substringBefore(" ·")
            dBtn.text = Lang.name(cfg.dst).substringBefore(" ·")
        }
        sBtn.setOnClickListener { cfg.src = nextLang(cfg.src, cfg.dst); refresh() }
        dBtn.setOnClickListener { cfg.dst = nextLang(cfg.dst, cfg.src); refresh() }
        val sw2 = ui.btn("⇄") { val a = cfg.src; cfg.src = cfg.dst; cfg.dst = a; refresh() }
        lr.addView(sBtn, ui.hlp())
        lr.addView(sw2, LinearLayout.LayoutParams(-2, -2).apply { marginStart = ui.dp(6) })
        lr.addView(dBtn, ui.hlp(1f, 6))
        refresh()
        card.addView(lr, ui.lp(top = 10))

        fun row(label: String, opts: List<String>, sel: Int, on: (Int) -> Unit) {
            card.addView(ui.tv(label, 12f, C.SUB), ui.lp(top = 8))
            card.addView(ui.seg(opts, sel, on), ui.lp(top = 3))
        }
        row("موتور ترجمه", listOf("Normal (سبک)", "Advanced (AI)"), if (cfg.mode == "advanced") 1 else 0) { cfg.mode = if (it == 1) "advanced" else "normal" }
        row("سرعت / دقت", listOf("سریع", "کند و دقیق"), if (cfg.speed == "slow") 1 else 0) { cfg.speed = if (it == 1) "slow" else "fast" }
        row("اتصال", listOf("آفلاین", "آنلاین"), if (cfg.net == "online") 1 else 0) { cfg.net = if (it == 1) "online" else "offline" }

        row("ترکیب ML Kit + AI (آزمایشی)", listOf("خاموش", "روشن"), cfg.hybrid) { cfg.hybrid = it }

        val inst = Models.installedFiles(this)
        if (inst.isNotEmpty()) {
            val mb = ui.btn("مدل AI: " + (tr.activeFile()?.let { Models.titleOf(it) } ?: "-"), false) { }
            mb.setOnClickListener {
                val list = Models.installedFiles(this)
                if (list.isNotEmpty()) {
                    val cur = list.indexOfFirst { it.name == tr.activeFile()?.name }
                    val n = list[(cur + 1) % list.size]
                    cfg.activeModel = n.name
                    mb.text = "مدل AI: " + Models.titleOf(n)
                }
            }
            card.addView(mb, ui.lp(top = 10))
        }

        card.addView(ui.slider("شفافیت لایه", 20, 100, cfg.opacity) { v -> cfg.opacity = v; overlayView?.alpha = v / 100f }, ui.lp(top = 10))
        card.addView(ui.slider("اندازه متن ترجمه", 60, 160, cfg.fontScale) { v -> cfg.fontScale = v; overlayView?.invalidate() }, ui.lp(top = 6))

        val br = ui.hbox()
        br.addView(ui.btn("خاموش کردن حباب", false) { stopSelf() }, ui.hlp())
        br.addView(ui.btn("بستن پنل") { closePanel() }, ui.hlp(1f, 8))
        card.addView(br, ui.lp(top = 12))

        val sv = ScrollView(this)
        sv.addView(card)
        root.addView(sv, FrameLayout.LayoutParams((sw * 0.9f).toInt(), -2, Gravity.CENTER))

        val lp = WindowManager.LayoutParams(
            sw, shh, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        wm.addView(root, lp)
        panel = root
    }

    private fun closePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
    }

    override fun onDestroy() {
        running = false
        job++
        closePanel()
        closeOverlay()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        try { held?.close() } catch (_: Exception) {}
        held = null
        try { vd?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
        super.onDestroy()
    }
}
