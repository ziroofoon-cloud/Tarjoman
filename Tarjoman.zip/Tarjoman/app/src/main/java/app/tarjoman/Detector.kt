package app.tarjoman

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import java.io.File
import java.nio.FloatBuffer
import java.nio.LongBuffer

/**
 * Finds where the text is on a comic / manga / webtoon page: speech bubbles with text, and free text (narration, sound effects).
 * Model: comic-text-and-bubble-detector (RT-DETR small, int8, 11 MB, Apache-2.0, by ogkalu), run with ONNX Runtime.
 * It does not read anything: it only says "there is text here". The reader (ML Kit / Tesseract / the cloud model) then reads those places,
 * so a line or a caption that the normal reader overlooked is still found.
 */
object Detector {
    class Box(val rect: Rect, val cls: Int, val score: Float)   // cls: 0 empty bubble, 1 bubble with text, 2 free text

    @Volatile var base: File? = null    // the "detect" side folder of the models folder
    fun file(): File? = base?.let { File(it, "comic_detector.onnx") }
    fun ready(): Boolean = file()?.let { it.isFile && it.length() > 5_000_000L } ?: false

    private const val N = 640
    private var env: OrtEnvironment? = null
    private var session: OrtSession? = null
    private var imgName = "images"
    private var sizeName = "orig_target_sizes"
    private val idle = Handler(Looper.getMainLooper())
    private val idleRun = Runnable { release() }

    @Synchronized
    private fun open(): OrtSession {
        session?.let { return it }
        val f = file() ?: throw IllegalStateException("model missing")
        val e = OrtEnvironment.getEnvironment()
        val so = OrtSession.SessionOptions()
        so.setIntraOpNumThreads(4)
        val s = e.createSession(f.absolutePath, so)
        val names = s.inputNames.toList()
        sizeName = names.firstOrNull { it.contains("size", true) } ?: names.getOrElse(1) { "orig_target_sizes" }
        imgName = names.firstOrNull { it != sizeName } ?: names[0]
        env = e
        session = s
        return s
    }

    @Synchronized
    fun release() {
        try { session?.close() } catch (_: Throwable) {}
        session = null
    }

    /** Text places on the page (score at least [minScore]). Throws when the model cannot run; the caller then goes on without it. */
    @Synchronized
    fun detect(src: Bitmap, minScore: Float = 0.3f): List<Box> {
        val s = open()
        val e = env ?: return emptyList()
        try {
            val small = Bitmap.createScaledBitmap(src, N, N, true)      // the model wants the whole page stretched to 640 x 640
            val px = IntArray(N * N)
            small.getPixels(px, 0, N, 0, 0, N, N)
            if (small !== src) small.recycle()
            val nn = N * N
            val a = FloatArray(3 * nn)
            for (i in 0 until nn) {
                val c = px[i]
                a[i] = Color.red(c) / 255f
                a[nn + i] = Color.green(c) / 255f
                a[2 * nn + i] = Color.blue(c) / 255f
            }
            val t1 = OnnxTensor.createTensor(e, FloatBuffer.wrap(a), longArrayOf(1, 3, N.toLong(), N.toLong()))
            val t2 = OnnxTensor.createTensor(e, LongBuffer.wrap(longArrayOf(src.width.toLong(), src.height.toLong())), longArrayOf(1, 2))
            try {
                val res = s.run(mapOf(imgName to t1, sizeName to t2))
                try {
                    var boxes: Array<FloatArray>? = null
                    var scores: FloatArray? = null
                    var labels: IntArray? = null
                    for (entry in res) {
                        val v = entry.value.value
                        if (v !is Array<*> || v.isEmpty()) continue
                        val first = v[0]
                        when {
                            first is Array<*> && first.isNotEmpty() && first[0] is FloatArray -> {
                                @Suppress("UNCHECKED_CAST")
                                val bb = first as Array<FloatArray>
                                boxes = bb
                            }
                            first is FloatArray -> scores = first
                            first is LongArray -> labels = IntArray(first.size) { first[it].toInt() }
                            first is IntArray -> labels = first
                        }
                    }
                    val bx = boxes ?: return emptyList()
                    val sc = scores ?: return emptyList()
                    val lb = labels ?: IntArray(sc.size) { 1 }
                    val n = minOf(bx.size, sc.size, lb.size)
                    // The answer should be in page pixels; a model export that answers 0..1 or in the 640 square is converted.
                    var maxC = 0f
                    for (i in 0 until n) if (sc[i] >= minScore) for (k in 0 until 4) if (bx[i][k] > maxC) maxC = bx[i][k]
                    val fx: Float
                    val fy: Float
                    if (maxC in 0.0001f..1.5f) { fx = src.width.toFloat(); fy = src.height.toFloat() }
                    else if (maxC <= 641f && (src.width > 700 || src.height > 700)) { fx = src.width / N.toFloat(); fy = src.height / N.toFloat() }
                    else { fx = 1f; fy = 1f }
                    val out = ArrayList<Box>()
                    for (i in 0 until n) {
                        if (sc[i] < minScore) continue
                        val b = bx[i]
                        val r = Rect((b[0] * fx).toInt(), (b[1] * fy).toInt(), (b[2] * fx).toInt(), (b[3] * fy).toInt())
                        if (!r.intersect(0, 0, src.width, src.height)) continue
                        if (r.width() < 8 || r.height() < 8) continue
                        out.add(Box(r, lb[i], sc[i]))
                    }
                    return out
                } finally {
                    res.close()
                }
            } finally {
                t1.close()
                t2.close()
            }
        } finally {
            idle.removeCallbacks(idleRun)
            idle.postDelayed(idleRun, 45000)
        }
    }
}
