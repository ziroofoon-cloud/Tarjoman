package app.tarjoman

/**
 * Curses, insults and rude slang (English -> Persian). Offline ML Kit often drops, stars out or mistranslates such words,
 * and AI models sometimes soften them. Here every known word has a real, spoken Persian equivalent:
 *  - ML Kit / API path: the word is swapped for a placeholder before translating and replaced by the Persian word afterwards;
 *  - AI path: the matching pairs are added to the prompt as "always use these translations".
 * Whole phrases ("shut the fuck up", "what the hell") are answered by the phrase table (Idm.kt) first.
 */
object Prof {
    private class E(val re: Regex, val fa: String)

    private fun e(p: String, fa: String) = E(Regex("\\b(?:$p)\\b", RegexOption.IGNORE_CASE), fa)

    // Longer / more specific entries first: a matched word is replaced by a placeholder and cannot match again.
    private val list: List<E> = listOf(
        e("holy (?:shit|fuck|crap|hell|cow|moly)", "وای خدا"),
        e("pain in the (?:ass|arse|neck)", "دردسر"),
        e("suck it up", "تحمل کن"),
        e("son of a bitch|sons of bitches|son of a whore", "پدرسوخته"),
        e("piece of (?:shit|crap|garbage|trash)", "آشغال"),
        e("fuck you|fuck u|screw you", "گور بابات"),
        e("fuck off|piss off|bugger off|sod off", "گمشو"),
        e("fuck it|screw it", "به درک"),
        e("kiss my ass|kiss my arse", "برو بمیر"),
        e("shut up|shut it", "خفه شو"),
        e("go to hell", "برو به جهنم"),
        e("burn in hell", "تو جهنم بسوزی"),
        e("rot in hell", "تو جهنم بپوسی"),
        e("what the (?:fuck|hell|f)", "این دیگه چه کوفتیه"),
        e("wtf", "این دیگه چه کوفتیه"),
        e("stfu", "خفه شو"),
        e("omfg", "وای خدا"),
        e("motherfuckers?|mother fuckers?", "عوضی"),
        e("motherfucking|goddamn|goddamned|god damn|bloody", "لعنتی"),
        e("cocksuckers?|shitheads?|shit heads?|knobheads?|numbnuts|wankers?|tossers?|twats?|bollocks", "عوضی"),
        e("airheads?|dimwits?|nitwits?|halfwits?|numbskulls?|blockheads?|knuckleheads?|retards?|retarded", "خنگ"),
        e("pussy|pussies", "کس"),
        e("boobs?|titties|tits", "ممه"),
        e("horny", "شهوتی"),
        e("fuckers?|fuckface|fuckhead|dickhead|asshole|assholes|arsehole|douchebag|douche|cunt|prick", "عوضی"),
        e("dumbass|jackass|smartass|dipshit|dumbshit", "احمق"),
        e("badass", "خفن"),
        e("fucking|fuckin|fuckin'", "لعنتی"),
        e("freaking|freakin|freakin'|friggin|friggin'|effing", "خیلی"),
        e("fucks?|fucked", "لعنتی"),
        e("bullshit|bull shit|horseshit", "چرت"),
        e("shitty|crappy|lousy", "مزخرف"),
        e("shits?", "گه"),
        e("crap", "مزخرف"),
        e("bitchy", "بدجنس"),
        e("bitch|bitches", "عوضی"),
        e("bastards?", "حرومزاده"),
        e("pissed off|pissed", "عصبانی"),
        e("damn|damned|dammit|damnit", "لعنتی"),
        e("idiots?|imbecile|cretin", "احمق"),
        e("morons?", "ابله"),
        e("jerks?", "عوضی"),
        e("scumbags?|scum|lowlife", "آشغال"),
        e("losers?", "بازنده"),
        e("whores?|sluts?", "جنده"),
        e("perverts?", "منحرف")
    )

    private const val PRE = "TP"
    private const val POST = "X"

    /** Text with every known word replaced by a placeholder, and the Persian words to put back (index = placeholder number). */
    fun protect(text: String): Pair<String, List<String>> {
        var t = text
        val subs = ArrayList<String>()
        for (en in list) {
            t = en.re.replace(t) { subs.add(en.fa); PRE + (subs.size - 1) + POST }
        }
        return Pair(t, subs)
    }

    fun restore(out: String, subs: List<String>): String {
        var r = out
        subs.forEachIndexed { k, fa ->
            r = Regex(PRE + "\\s?" + k + "\\s?" + POST, RegexOption.IGNORE_CASE).replace(r, java.util.regex.Matcher.quoteReplacement(fa))
        }
        return r
    }

    /** "word=Persian" lines for the AI prompt: only the words that really occur in [text]. */
    fun glossary(text: String): String {
        val sb = StringBuilder()
        val seen = HashSet<String>()
        for (en in list) {
            for (m in en.re.findAll(text)) {
                val w = m.value.lowercase()
                if (seen.add(w)) sb.append(w).append('=').append(en.fa).append('\n')
            }
        }
        return sb.toString().trim()
    }
}
