package app.tarjoman

/**
 * Curses, insults and rude slang (English -> Persian). Offline ML Kit often drops, stars out or mistranslates such words,
 * and AI models sometimes soften them. Here every known word has a real, spoken Persian equivalent:
 *  - ML Kit / API path: the word is swapped for a placeholder before translating and replaced by the Persian word afterwards;
 *  - AI path: the matching pairs are added to the prompt as "always use these translations".
 * Whole phrases ("shut the fuck up", "what the hell") are answered by the phrase table (Idm.kt) first.
 */
object Prof {
    /**
     * [fa] = the Persian word; [vul] = the very rude spoken form, used instead when Settings -> "very rude words" is on.
     * [lead] = English put in front of the placeholder ("do ", "doing " ...) for verbs, so ML Kit builds a verb phrase around the noun;
     * [light] / [vlight] = "present|past" stems of the Persian light verb that replaces ML Kit's "انجام دادن" (کن|کرد, زن|زد ...).
     */
    private class E(
        val re: Regex, val fa: String, val vul: String? = null, val lead: String = "",
        val light: String? = null, val vlight: String? = null
    )

    /** True = the very rude spoken words are used (set from Settings before every translation). */
    @Volatile var explicit = false

    private fun e(p: String, fa: String) = E(Regex("\\b(?:$p)\\b", RegexOption.IGNORE_CASE), fa)

    /** Sexual / body words: a plain form (default) and a very rude spoken form (when switched on). */
    private fun x(p: String, n: String, v: String, lead: String = "", light: String? = null, vlight: String? = null) =
        E(Regex("\\b(?:$p)\\b", RegexOption.IGNORE_CASE), n, v, lead, light, vlight)

    private fun sub(en: E): String {
        val w = if (explicit && en.vul != null) en.vul else en.fa
        val l = if (explicit && en.vlight != null) en.vlight else en.light
        return if (l == null) w else w + "\u0001" + l
    }

    // Longer / more specific entries first: a matched word is replaced by a placeholder and cannot match again.
    private val list: List<E> = listOf(
        // --- very rude sentences (plain form / very rude spoken form)
        x("go fuck yourself|go fuck your self", "گمشو", "برو بکن تو کونت"),
        x("suck my (?:dick|cock)", "گمشو", "کیرمو بخور"),
        x("eat shit", "گمشو", "گه بخور"),
        // --- verbs: noun + light verb ("I masturbate" -> "من خودارضایی می‌کنم" / "من جق می‌زنم")
        x("masturbated", "خودارضایی", "جق", "did ", "کن|کرد", "زن|زد"),
        x("masturbates", "خودارضایی", "جق", "does ", "کن|کرد", "زن|زد"),
        x("masturbating|jerking off|jacking off|wanking", "خودارضایی", "جق", "doing ", "کن|کرد", "زن|زد"),
        x("masturbate|jerk off|jack off|wank", "خودارضایی", "جق", "do ", "کن|کرد", "زن|زد"),
        x("cummed", "ارگاسم", "آب", "did ", "کن|کرد", "ریز|ریخت"),
        x("cums", "ارگاسم", "آب", "does ", "کن|کرد", "ریز|ریخت"),
        x("cumming", "ارگاسم", "آب", "doing ", "کن|کرد", "ریز|ریخت"),
        // --- nouns
        x("masturbation|self[- ]pleasure", "خودارضایی", "جق زدن"),
        x("cum|cumshots?|semen|sperm", "منی", "آبکیر"),
        x("blow ?jobs?", "رابطهٔ دهانی", "ساک"),
        x("hand ?jobs?", "تحریک با دست", "جق"),
        x("dicks?|cocks?|penis(?:es)?", "آلت تناسلی", "کیر"),
        x("vagina|pussy|pussies", "واژن", "کس"),
        x("boobs?|titties|tits", "سینه", "ممه"),
        x("ass|asses|arse|arses", "باسن", "کون"),
        x("horny", "تحریک‌شده", "حشری"),
        x("boners?|erections?|hard-?ons?", "نعوظ", "کیر شق‌شده"),
        e("holy (?:shit|fuck|crap|hell|cow|moly)", "وای خدا"),
        e("pain in the (?:ass|arse|neck)", "دردسر"),
        e("suck it up", "تحمل کن"),
        e("son of a bitch|sons of bitches|son of a whore", "پدرسوخته"),
        e("piece of (?:shit|crap|garbage|trash)", "آشغال"),
        e("fuck you|fuck u|screw you", "گور بابات"),
        e("fuck off|piss off|bugger off|sod off", "گمشو"),
        e("fuck it|screw it", "به درک"),
        e("kiss my ass|kiss my arse", "برو بمیر"),
        e("shut up|shut it", "خفه شو"),
        e("go to hell", "برو به جهنم"),
        e("burn in hell", "تو جهنم بسوزی"),
        e("rot in hell", "تو جهنم بپوسی"),
        e("what the (?:fuck|hell|f)", "این دیگه چه کوفتیه"),
        e("wtf", "این دیگه چه کوفتیه"),
        e("stfu", "خفه شو"),
        e("omfg", "وای خدا"),
        e("motherfuckers?|mother fuckers?", "عوضی"),
        e("motherfucking|goddamn|goddamned|god damn|bloody", "لعنتی"),
        e("cocksuckers?|shitheads?|shit heads?|knobheads?|numbnuts|wankers?|tossers?|twats?|bollocks", "عوضی"),
        e("airheads?|dimwits?|nitwits?|halfwits?|numbskulls?|blockheads?|knuckleheads?|retards?|retarded", "خنگ"),
        e("fuckers?|fuckface|fuckhead|dickhead|asshole|assholes|arsehole|douchebag|douche|cunt|prick", "عوضی"),
        e("dumbass|jackass|smartass|dipshit|dumbshit", "احمق"),
        e("badass", "خفن"),
        e("fucking|fuckin|fuckin'", "لعنتی"),
        e("freaking|freakin|freakin'|friggin|friggin'|effing", "خیلی"),
        e("fucks?|fucked", "لعنتی"),
        e("bullshit|bull shit|horseshit", "چرت"),
        e("shitty|crappy|lousy", "مزخرف"),
        e("shits?", "گه"),
        e("crap", "مزخرف"),
        e("bitchy", "بدجنس"),
        e("bitch|bitches", "عوضی"),
        e("bastards?", "حرومزاده"),
        e("pissed off|pissed", "عصبانی"),
        e("damn|damned|dammit|damnit", "لعنتی"),
        e("idiots?|imbecile|cretin", "احمق"),
        e("morons?", "ابله"),
        e("jerks?", "عوضی"),
        e("scumbags?|scum|lowlife", "آشغال"),
        e("losers?", "بازنده"),
        e("whores?|sluts?", "جنده"),
        e("perverts?", "منحرف")
    )

    private const val PRE = "TP"
    private const val POST = "X"

    /** Text with every known word replaced by a placeholder, and the Persian words to put back (index = placeholder number). */
    fun protect(text: String): Pair<String, List<String>> {
        var t = text
        val subs = ArrayList<String>()
        for (en in list) {
            t = en.re.replace(t) { subs.add(sub(en)); en.lead + PRE + (subs.size - 1) + POST }
        }
        return Pair(t, subs)
    }

    private val presSuf = mapOf("دهم" to "م", "دهی" to "ی", "دهد" to "د", "دهیم" to "یم", "دهید" to "ید", "دهند" to "ند")
    private val pastSuf = mapOf("دادم" to "م", "دادی" to "ی", "داد" to "", "دادیم" to "یم", "دادید" to "ید", "دادند" to "ند")

    fun restore(out: String, subs: List<String>): String {
        var r = out
        subs.forEachIndexed { k, s0 ->
            val noun = s0.substringBefore('\u0001')
            val light = if (s0.contains('\u0001')) s0.substringAfter('\u0001').split("|") else null
            val ph = PRE + "\\s?" + k + "\\s?" + POST
            if (light != null && light.size == 2) {
                // ML Kit wrote "<noun> انجام می‌دهم": turn the light verb into the right one (می‌کنم / می‌زنم / آب می‌ریزم ...)
                val re = Regex("(" + ph + ")(?:\\s*را)?\\s+انجام\\s+(?:(?:می[\\u200c ]?(دهم|دهی|دهد|دهیم|دهید|دهند))|(دادم|دادی|داد|دادیم|دادید|دادند))", RegexOption.IGNORE_CASE)
                r = re.replace(r) { m ->
                    val pres = m.groupValues[2]
                    val past = m.groupValues[3]
                    val verb = if (pres.isNotEmpty()) "می\u200c" + light[0] + (presSuf[pres] ?: "") else light[1] + (pastSuf[past] ?: "")
                    m.groupValues[1] + " " + verb
                }
            }
            r = Regex(ph, RegexOption.IGNORE_CASE).replace(r, java.util.regex.Matcher.quoteReplacement(noun))
        }
        return r
    }

    /** "word=Persian" lines for the AI prompt: only the words that really occur in [text]. */
    fun glossary(text: String): String {
        val sb = StringBuilder()
        val seen = HashSet<String>()
        for (en in list) {
            for (m in en.re.findAll(text)) {
                val w = m.value.lowercase()
                if (seen.add(w)) sb.append(w).append('=').append(sub(en).substringBefore('\u0001')).append('\n')
            }
        }
        return sb.toString().trim()
    }
}
