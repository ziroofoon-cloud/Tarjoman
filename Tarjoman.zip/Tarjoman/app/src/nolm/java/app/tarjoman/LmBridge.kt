package app.tarjoman

import android.content.Context
import java.io.File

/** Default build: LiteRT-LM (.litertlm models) is not compiled in. See src/lm for the real implementation. */
object LmBridge {
    const val available = false

    fun load(ctx: Context, f: File) {
        throw IllegalStateException(L("این مدل با فرمت .litertlm است و این APK موتور LiteRT-LM ندارد. از GitHub Actions فایل «Tarjoman-apk-litertlm» را دانلود و نصب کن (روی همین نسخه نصب می‌شود و مدل‌هایت می‌مانند)."))
    }

    fun gen(system: String, user: String, slow: Boolean): String = throw IllegalStateException(L("LiteRT-LM در این نسخه فعال نیست"))
}
