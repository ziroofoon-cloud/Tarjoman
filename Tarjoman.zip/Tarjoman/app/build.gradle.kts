plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Optional LiteRT-LM engine (.litertlm models): build with  gradle assembleDebug -Plitertlm
val withLm = project.hasProperty("litertlm")

android {
    namespace = "app.tarjoman"
    compileSdk = 34

    defaultConfig {
        applicationId = "app.tarjoman"
        minSdk = 26
        targetSdk = 34
        versionCode = (System.currentTimeMillis() / 60000L).toInt()
        versionName = "0.55.1"
        // Redmi Note 9 Pro is arm64
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    // Fixed signing key so new builds install over old ones as updates.
    signingConfigs {
        create("tj") {
            storeFile = file("tarjoman.keystore")
            storePassword = "tarjoman123"
            keyAlias = "tarjoman"
            keyPassword = "tarjoman123"
        }
    }

    buildTypes {
        getByName("debug") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("tj")
        }
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("tj")
        }
    }

    sourceSets {
        getByName("main").java.srcDir(if (withLm) "src/lm/java" else "src/nolm/java")
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
        // The LiteRT-LM library may be built with a newer Kotlin than this project: do not stop on the metadata version.
        if (withLm) freeCompilerArgs += listOf("-Xskip-metadata-version-check")
    }

    packaging {
        resources.excludes += listOf("META-INF/*.version", "META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*")
        jniLibs.pickFirsts += listOf("**/libc++_shared.so", "**/libtensorflowlite_jni.so")
    }
}

// Keep the Kotlin runtime at the compiler's version, whatever a library asks for.
configurations.all {
    resolutionStrategy.eachDependency {
        if (requested.group == "org.jetbrains.kotlin" && requested.name.startsWith("kotlin-stdlib")) useVersion("1.9.24")
    }
}

dependencies {
    // Normal mode: offline Google ML Kit translation (EN, FA, JA)
    implementation("com.google.mlkit:translate:17.0.3")
    // Image translation: on-device OCR (Latin + Japanese)
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("com.google.mlkit:text-recognition-japanese:16.0.1")
    implementation("com.google.android.gms:play-services-tasks:18.2.0")
    // Advanced mode: on-device LLM (Gemma / Qwen .task models)
    implementation("com.google.mediapipe:tasks-genai:0.10.24")
    // Persian OCR (Tesseract, offline; fas.traineddata is downloaded inside the app)
    implementation("cz.adaptech.tesseract4android:tesseract4android:4.9.0")
    // PDF text extraction (text PDFs are read directly, scans fall back to OCR)
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
    // Optional: LiteRT-LM (.litertlm models). Only with -Plitertlm.
    if (withLm) implementation("com.google.ai.edge.litertlm:litertlm-android:0.15.0")
}
