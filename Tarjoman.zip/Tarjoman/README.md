# ترجمان (Tarjoman) — v0.55.0
Offline/online translator for Android (EN <-> FA, JA optional), tuned for Redmi Note 9 Pro (arm64).

- Normal: Google ML Kit offline packs
- Advanced: on-device LLM (.task via MediaPipe), downloadable in-app or added manually
- Fast / Slow (+refine pass), Offline / Online (Google x3, Lingva x3, MyMemory; optional proxy; optional OpenAI-compatible API)
- Image translate (OCR EN/JA/FA) drawn over the picture, save as PNG
- Floating bubble: tap = translate whole screen on an adjustable transparent layer, long-press = settings
- PDF translation (page by page, OCR), subtitles (.srt / .vtt -> .srt), glossary

## v0.55.0
- Faster first translation: when the app opens in Normal mode and both language packs are installed, the ML Kit engine is loaded in the background (no download is started by this).

## v0.54.0
- Online translation: new source "Microsoft" (Edge translator, free, good Persian) next to Google; it is often reachable when Google is blocked (no VPN). The source that worked last is remembered across app restarts, so the first translation no longer waits for a blocked Google to time out.
- Pictures / bubble / live camera: with an online engine all text blocks go in ONE request (before: one request per block), like the AI mode; falls back to one by one if the line count differs.

## v0.53.0
- Faster picture reading: the ML Kit text readers are created once and reused (before, one was created and closed for every picture and every live-camera frame).
- Image tab: slider "Translation text size" under the picture buttons redraws the translations at once (no new translation); the full-screen viewer has an "Another picture" button that opens the gallery.

## v0.52.0
- Live camera translation (Image tab -> "Live camera translation (like Google Lens)", `LiveCamActivity.kt`): the camera preview with the translation drawn on top of the text. About twice a second one frame is read (ML Kit for English / Japanese, Tesseract for Persian) and only new texts are translated; unchanged texts keep their translation. Buttons: language pick / swap, light, Freeze (tap a text to copy the original or the translation), "High quality photo" (full size picture -> Image tab with the zoom viewer, save, translate again). While this screen is open the fast Normal engine is used (AI is too slow for live), then your mode comes back.
- The app now declares the CAMERA permission (live camera uses the classic Camera API, no new library); the "Take a photo" button asks for it first.

## v0.51.0
- Models tab: every model card has "Copy direct link" and "Open in browser"; the top card has "Direct download links of all models" (copy / share; includes the OCR files and the exact models folder).
- Settings -> Models folder -> "Custom path": new "Choose a folder on the phone" button (system folder picker), no need to type the path.

## v0.50.0
- "Correct translation (the app learns)": under the result on the Text tab you can fix a wrong English -> Persian translation. The app remembers it and uses it every time that English text comes again, in every mode (offline, online, AI), also for text blocks in pictures. Settings -> "My corrected translations" shows the count and can delete them all. Stored in the settings (`userPhr`, one "english|persian" per line).

## v0.49.0
- Faster English picture reading: ML Kit and Tesseract (when the English model is installed) now read at the same time.
- Crash report: if the app closes suddenly, the cause is saved and shown in Settings ("Last app error") with a copy button, so it can be sent and fixed.

## v0.48.0
- Image tab: "Take a photo" button next to the gallery button. It opens the phone's camera app (no camera permission needed), then reads and translates the photo like any picture (Lens-style viewer included). Photos are saved in Pictures/Tarjoman; a cancelled shot is removed.

## v0.47.0
- Image tab, Lens-style viewer: tap the translated picture to open it full screen (`ZoomView.kt`): pinch to zoom, drag, double tap to zoom in / out. Tap any translated text on the picture to see the original and the translation and copy either. Hold the "original picture" button to compare, release to go back to the translation.

## v0.46.0
- Text tab: button "Translate online (Google quality)" under the result: the same text through Google Translate with one tap, whatever Offline / Online / Auto is set to (needs internet; falls back to offline if there is none).

## v0.45.0
- Text tab: language row, text box, buttons and the result are now on top; the mode / speed / connection card moved under the result (no scrolling when in a hurry).
- Settings -> "Models folder": private (default), app folder on shared storage, or any folder you type (e.g. /storage/emulated/0/Tarjoman/models, needs "All files access" on Android 11+). Changing it moves the downloaded models and half-finished downloads. The current path is shown in Settings and on the Models tab.

## v0.44.3
- Back to LiteRT-LM 0.15.0: v0.44.2 (with `latest.release`) crashed at start on the phone, 0.15.0 starts fine. Do not use `latest.release` again without testing on a device.

## v0.44.2
- LiteRT-LM library is `latest.release` again (the 0.15.0 pin was too old for the int4 Qwen file: "The given map is missing some output TensorBuffers"). That error now gets its own message instead of "language pack not available", and the int4 model card says it is experimental; the official Qwen 3 0.6B (600 MB) is the safe choice.

## v0.44
- Better text reading from pictures, English first. New Settings card "OCR" with separate options per language:
  - English: reader (Auto / ML Kit / Tesseract), picture clean-up (Auto / Always / Off), look-alike letter repair with a word list (rn -> m, cl -> d, 0 -> o, 1 -> l ...).
  - Persian: model (Auto / Fast / Accurate), picture preparation (Auto = both versions, best wins / Grey / Black & white).
- Optional English Tesseract models in the Models tab (`OCR انگلیسی` ~4 MB, `OCR انگلیسی دقیق‌تر` tessdata_best). When installed, Auto reads each picture with ML Kit and Tesseract, scores both by real English words, keeps the better reading and adds blocks only the other reader found. Code: `Ocr.kt`, `Lex.kt`, `OcrFix.kt`.
- Applies to image translation, the bubble (screen) and PDF scans.

## v0.43
- Fix: ".litertlm models need the LiteRT-LM build". The GitHub workflow (`.github/workflows/build.yml`, in the outer zip) now builds TWO APKs on every run: `Tarjoman-apk` (normal) and `Tarjoman-apk-litertlm` (with the LiteRT-LM engine). Install the `litertlm` one to use Qwen 3 0.6B int4, Gemma 4 E2B and other .litertlm models. There is no checkbox any more. If the LiteRT-LM build fails, the normal APK is still produced.
- LiteRT-LM library pinned to 0.15.0 (was `latest.release`) and the Kotlin metadata check is skipped for that build only, so a newer library cannot break the build.

## v0.42
- Persian OCR: each picture is read in two versions (grey + contrast, and black-on-white with an Otsu threshold; white text on a dark background is inverted) and the version Tesseract is more confident about is used. Dark-mode / manga pages with light text should read much better.
- New optional "More accurate Persian OCR" (tessdata_best) in the Models tab; used instead of the fast model when installed.

## v0.41
- Translation history (page opened from the Text tab or Settings -> Translation history): Text-tab and Image-tab translations are saved on the phone only. Settings has a size limit (off / 5 / 10 / 25 / 50 / 100 MB, default 10): when it is reached the oldest entries are dropped. Search, select several, delete selected, delete all, reuse (loads source + result back into the Text tab), copy. Code: `Hist.kt`.
- Image OCR (English): look-alike letters fixed (l / I / | / 1, O / 0, e.g. "l'm" -> "I'm", "wiII" -> "will"), curly quotes, spaces before punctuation, hyphenated line breaks, stray marks dropped; a lone "I" / "A" is kept. When the first reading looks doubtful (or the picture is small) a second pass on an enlarged, grey, higher-contrast copy runs and the better result is used. Code: `OcrFix.kt`, `Ocr.kt`.
- Persian OCR (Tesseract): stray Latin letters / bars between Persian words, tatweel, direction marks and spaces before ، ؟ . are removed (`OcrFix.fa`).

## v0.40
- Sign in with your Hugging Face account inside the app (no token): the Models tab (locked models) and Settings have a "Sign in with Hugging Face" button. It opens huggingface.co in a small in-app browser; sign in, press "Acknowledge license" on the model page, press "Done". The app keeps the session cookie and uses it for the download. The token option still works. Google/GitHub sign-in may be blocked inside a WebView: use username + password.

## v0.39
- English -> Persian (Normal, offline): phrase table +99 everyday sentences (questions, commands, feelings, "you are ...", "that is ...").
- English clean-up before ML Kit: chat spellings (dunno, gimme, lemme, u, ur, idk, omg, btw...), missing apostrophes (dont, im, thats...), and ~30 idioms rewritten as plain English (kick the bucket, spill the beans, it sucks, fed up...).
- Text and PDF tabs: lines broken in the middle of a sentence (text copied from a PDF/book) are joined before translating, and hyphenated line breaks are removed. Short lines (lists, subtitles) are left alone.
- Persian output typography: « » for quotes, one … for three dots, ؛ after Persian words.

## v0.38
- Persian -> English (Normal, offline): new phrase table `FaEn.kt` for everyday thanks, blessings, greetings and curses that ML Kit gets wrong word by word (خسته نباشی, دستت درد نکنه, قربونت, ...).
- Spoken Persian is turned into written Persian before ML Kit (`Fa.formal`): می‌خوام -> می‌خواهم, اون -> آن, خوبه -> خوب است, برام -> برای من, ... ML Kit is trained on formal text, so this helps chat and subtitles.
- Persian letter checks no longer treat ، and ؟ as letters, so words right before them are also fixed.

## v0.37
- Normal (offline ML Kit): Persian and Japanese text is now translated one sentence at a time (before, only English was); Persian input is normalised first (Arabic letters, spacing).
- Japanese -> Persian goes through English, so the English clean-up and the phrase table (Idm.kt) also help there.
- Persian output: half-space after می / نمی and before ها / های / ترین, no space before ، ؟ and full stops. English output: spacing, lone "i", capital after a full stop.
- Phrase table: 42 more everyday phrases and idioms.
- Gemma token help now uses the real English button names on Hugging Face (Acknowledge license, Create new token, type Read).

## v0.36
- English app language: the texts added in v0.31-v0.35 (token dialog, model cards, errors) now have English versions; every L("...") text was checked against the translation table.

## v0.35
- Catalog: Gemma 3 1B q8 (1.07 GB, gated, more precise than int4) and Qwen 3 0.6B int4 (345 MB, not gated, LiteRT-LM build). Qwen 3 0.6B quality raised (better Persian than Qwen 2.5 0.5B).

## v0.34
- New catalog model: Gemma 4 E2B (.litertlm, 2.6 GB, Apache-2.0) from litert-community: NOT gated, no token or license needed. It needs the LiteRT-LM build; .litertlm models are now listed in every build (at the end, with a warning) instead of being hidden.

## v0.33
- Gemma downloads: locked models now show the exact steps, a "Model page (accept license)" button, a "Token" button (dialog that saves the token and starts the download) and a clearer error (no token / token not accepted for this model).

## v0.32
- Japanese pages: blocks are ordered like manga (top to bottom, right to left) so the AI gets the story in the right order.
- Slow AI mode uses smaller chunks (300 characters) so the longer prompt plus the answer always fit in the model's 1024-token window.

## v0.31
- Subtitle tab: paste a YouTube link to fetch its captions directly (manual captions first, then automatic; chosen language, then English / Japanese / Persian). If YouTube refuses, the app says so and the .srt/.vtt file still works.

## v0.30
- Persian OCR (Tesseract): the picture is made grayscale, contrast-stretched and enlarged (up to 3x, ~1800 px) before reading; the result is mapped back to the original picture and cleaned (Arabic letters -> Persian).
- Small AI models: when a Persian answer is mostly English / non-Persian letters, the app uses the ML Kit draft for that piece instead of showing a bad answer.

## v0.29
- Image / bubble: the text found by OCR is checked against the chosen language; if the wrong reader produced junk (for example the Latin reader on a Persian or Japanese page) the other languages are tried. Noise boxes (single marks, scribbles) are dropped.
- AI mode: all blocks of an image or screen are translated in ONE AI call (each call re-reads the prompt, so many small calls were very slow). If the model returns a different number of lines the app falls back to one block at a time.
- Persian output clean-up: tatweel, Arabic vowel marks, ta marbuta and a few leaked Arabic words (هذا, لكن, ماذا...) are fixed.
- Phrase table (`Idm.kt`) grew from ~230 to ~600 entries: curses, insults, commands, everyday questions, exclamations (uncensored).
- AI prompt: more Persian examples (curses, manga lines), "no Arabic letters/words", fast prompt keeps the line count.

## v0.28
- Glossary now also works with Normal (ML Kit) and online translation: listed names/terms are protected before translating and replaced by your version afterwards.
- Text tab shows the elapsed seconds while translating; AI answers wrapped in quotes are cleaned; short AI prompt asks for Persian letters and no leftover English words.

## v0.27
- Image tab: From / To buttons (with swap) on the page itself; photos taken sideways (EXIF orientation) are turned upright before OCR; if no text is found in the chosen language the app tries the other ones (English / Japanese / Persian) and translates from the one that worked; translation errors (for example a missing language pack) are shown instead of silently leaving the original text.

## v0.26
- No more censoring: the English clean-up no longer rewrites "what the fuck" / "shut up" into polite words; the phrase table has uncensored entries for common curses. If an AI model refuses, the app asks again as fictional dialogue and, if it still refuses, uses ML Kit.
- Translate button turns into Stop while running; Stop and switching AI -> Normal now really cancel the AI job, and Normal / online jobs run on their own thread (they no longer wait behind a slow AI job).
- Fast vs Slow for the AI: Fast = short prompt, one pass (much faster); Slow = full prompt with examples, context from earlier lines and a second editing pass.
- "Translate again" in Text, Image, PDF, Subtitle and Bubble: skips the memory and gives a different answer (another online source / plain ML Kit / hotter AI sampling).
- Connection: new "Auto" (default): Normal uses the internet when it works (Google quality), Advanced keeps using the phone's AI.

## v0.25
- Cancel button next to Stop: Stop keeps the downloaded part (resume later), Cancel stops and deletes it.

## v0.24
- Stop / Resume buttons for every download (Models tab and the notification). Stopping keeps the downloaded part; "Resume download" continues from it.

## v0.23
- Downloads rewritten for weak / cut internet: the partly downloaded file is always kept; after a timeout or lost connection the app waits (and waits for the network to return), retries by itself and continues from the same byte (HTTP Range + ETag check). It only starts over when the server says the file changed. A slow but moving download never gives up; after many retries without new data it stops, and "Resume" continues from the saved part.
- Downloads run in a foreground service (`Dl.kt`, notification with percentage and a Cancel action): they continue when you leave the app or lock the screen. Progress, speed (MB/s) and retry status are shown on the Models tab.
- Delete (with a confirmation) for everything downloaded: AI models, Persian OCR, Google language packs (Persian / Japanese) and half-finished downloads.

## v0.22
- Translation quality (offline EN -> FA): English is now translated one short sentence at a time, and a built-in phrase table (`Idm.kt`, ~250 everyday phrases, slang and idioms) answers known expressions directly ("Can you be cool?" -> "می‌تونی باحال باشی؟", "Am I dead or am I tripping?" -> "مردم یا دارم توهم می‌زنم؟"). Sentences that contain a known clause are split at "or / and / but / ," and only the unknown clauses go to ML Kit.
- Grammar slips such as "am I died" are fixed to "am I dead" before translating.
- Spoken Persian clean-up: no leading "آیا", "می‌باشد" -> "هست", "نیز" -> "هم".
- Same pipeline is used by the Text, Image, PDF, Subtitle and Bubble tabs (they all call `Tr.translate`).

## v0.21
- Translation boost (Settings): English clean-up before offline ML Kit (ALL CAPS -> normal case, i -> I, full stops / question marks, slang such as "tripping" and "cool" rewritten as plain English); spoken Persian conversion for the casual style (all engines).
- AI prompt: slang/idioms are translated by meaning; new Persian examples.

## v0.20
- Image tab: switch between "On picture", "Translation" and "Original text"; the chosen picture shows at once; "Remove picture" resets the page (and stops a running translation).
- PDF tab: show Translation / Original text / Both (paragraph by paragraph); copy and save use the shown version.

## v0.19
- Models tab: items marked Required / Optional, "start here" note; AI models sorted best-first with quality and speed dots, "Best quality" and "Recommended" tags.
- Real download progress bar + percentage for models and Persian OCR; partial downloads show their percentage and "Resume". Google language packs show installed / not installed (Google gives no percentage, so a moving bar is shown).

## v0.18
- Bubble: one tap translates, double tap goes back to the original screen (also stops live mode).
- Bubble survives rotation (landscape): it is re-placed and the capture is resized.
- Bubble settings panel is smaller (~62% height portrait) and scrolls; in landscape it is 90% height and scrolls.

## v0.17
- New look: no emoji (drawn line icons), cleaner modern style, redesigned classic paper style (serif, burgundy/gold).
- Theme: System (follows the phone) / Light / Dark, and Modern / Classic style (classic also has a night-paper dark version).
- Changing a setting (theme, language) keeps you on the Settings tab at the same scroll position.
- Fixed the language swap button that sat lower than the language buttons.

## v0.7 changes
- Auto-detect source language of typed/shared text (can be turned off in Settings)
- Translation memory: repeated translations are instant
- Persian output clean-up (Arabic ي/ك, digits, ؟ and ،)
- Hybrid mode (experimental): ML Kit draft polished by the AI model for more natural Persian
- Online: more sources, remembers the one that worked, skips Google fast when it is blocked, offline check
- Subtitles: .vtt (YouTube) support, UTF-16 / Windows-1256 / Shift-JIS detection, UTF-8 BOM on save
- Image: uses the same drawing as the bubble (text size setting), "save translated image"
- Bubble: copy-all button, model switcher and hybrid toggle in its settings, context from previous blocks in slow mode
- Qwen3 chat template fixed for manually added models

## v0.7
- Save the PDF translation as a PDF file; wider translation box for vertical manga bubbles

## v0.8
- Text PDFs are read directly (pdfbox-android); scans and Persian use OCR

## v0.9
- Classic (paper) theme next to the modern dark one (Settings), new launcher icon

## v0.16
- Live screen translation (bubble setting): after one tap the translation stays; when the screen changes and settles (manga page turn, scroll) it is translated again. Tap the bubble again to stop.

## v0.15
- "From / To" labels above the language buttons (text tab) and in the bubble settings

## v0.14.1
- Bubble no longer records the screen all the time: the capture is switched on only for the moment of a screenshot (idle load ~0)

## v0.14
- One On/Off button for the bubble; the translation layer is not touchable (touches go to the app below); tap on the bubble only translates (tap again hides the layer), settings by long-press

## v0.13
- Translate while typing (Settings), new bottom bar (icons, separator, selected pill)
- Bubble modes: free / lock (snaps to left-right edge) / sleep (38% outside, faded); pulling it out of the edge = instant sleep; it can no longer leave the screen
- Smallest catalog model: SmolLM 135M

## v0.12
- Translation style (casual for subtitles/manga, formal for books/articles) changes the AI prompt; shown in the Text tab and used by image, PDF, subtitle and bubble.

## v0.11
- App language (Persian / English) in Settings -> App language; layout flips RTL / LTR. All texts go through `L("...")` (`I18n.kt`).
- Launcher name under the icon is always English: "Tarjoman".
- Heavier model in the catalog: Gemma 3n E2B (.litertlm, LiteRT-LM build only).
- The GitHub workflow now really has the "Build with LiteRT-LM" checkbox (it was documented but missing).

## v0.10
- Optional LiteRT-LM engine for `.litertlm` models (Qwen3 0.6B in the catalog). Off by default so the normal build is not affected.
  Enable it: GitHub -> Actions -> build -> Run workflow -> tick "Build with LiteRT-LM". (Local: `gradle assembleDebug -Plitertlm`.)
  Code: `app/src/lm` (real) / `app/src/nolm` (stub).

## Next
- Test on the phone and report: bubble accuracy, speed per model, Persian quality
- Better vertical manga text, per-app presets for the bubble
- Speed-up for the AI engine (GPU/NNAPI where it helps on Snapdragon 720G)
