# ترجمان (Tarjoman) — v0.2 (phase 2)
Offline/online translator for Android (EN <-> FA, JA optional).
- Normal: Google ML Kit offline packs
- Advanced: on-device LLM (.task via MediaPipe), downloadable in-app or added manually
- Fast / Slow(+refine pass), Offline / Online (multi-source, optional proxy)
- Image translate (OCR EN/JA) drawn over the picture
- NEW: floating bubble -> tap = translate whole screen on a transparent overlay (adjustable opacity/text size), long-press = settings
- NEW: PDF translation (page by page, OCR EN/JA), copy / save as txt
Next: Persian OCR, quality improvements (context, glossary), model recommendations.
