# ترجمان (Tarjoman) — v0.1 (phase 1)
Offline/online translator for Android (EN <-> FA, JA optional).
- Normal: Google ML Kit offline packs
- Advanced: on-device LLM (.task via MediaPipe), downloadable in-app or added manually
- Fast / Slow(+refine pass), Offline / Online (multi-source, optional proxy)
- Image translate (OCR EN/JA) drawn over the picture
Phase 2: floating bubble + full-screen overlay, PDF, Persian OCR.
