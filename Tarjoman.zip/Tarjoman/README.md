# ترجمان (Tarjoman) — v0.16
Offline/online translator for Android (EN <-> FA, JA optional), tuned for Redmi Note 9 Pro (arm64).

- Normal: Google ML Kit offline packs
- Advanced: on-device LLM (.task via MediaPipe), downloadable in-app or added manually
- Fast / Slow (+refine pass), Offline / Online (Google x3, Lingva x3, MyMemory; optional proxy; optional OpenAI-compatible API)
- Image translate (OCR EN/JA/FA) drawn over the picture, save as PNG
- Floating bubble: tap = translate whole screen on an adjustable transparent layer, long-press = settings
- PDF translation (page by page, OCR), subtitles (.srt / .vtt -> .srt), glossary

## v0.7 changes
- Auto-detect source language of typed/shared text (can be turned off in Settings)
- Translation memory: repeated translations are instant
- Persian output clean-up (Arabic ي/ك, digits, ؟ and ،)
- Hybrid mode (experimental): ML Kit draft polished by the AI model for more natural Persian
- Online: more sources, remembers the one that worked, skips Google fast when it is blocked, offline check
- Subtitles: .vtt (YouTube) support, UTF-16 / Windows-1256 / Shift-JIS detection, UTF-8 BOM on save
- Image: uses the same drawing as the bubble (text size setting), "save translated image"
- Bubble: copy-all button, model switcher and hybrid toggle in its settings, context from previous blocks in slow mode
- Qwen3 chat template fixed for manually added models

## v0.7
- Save the PDF translation as a PDF file; wider translation box for vertical manga bubbles

## v0.8
- Text PDFs are read directly (pdfbox-android); scans and Persian use OCR

## v0.9
- Classic (paper) theme next to the modern dark one (Settings), new launcher icon

## v0.16
- Live screen translation (bubble setting): after one tap the translation stays; when the screen changes and settles (manga page turn, scroll) it is translated again. Tap the bubble again to stop.

## v0.15
- "From / To" labels above the language buttons (text tab) and in the bubble settings

## v0.14.1
- Bubble no longer records the screen all the time: the capture is switched on only for the moment of a screenshot (idle load ~0)

## v0.14
- One On/Off button for the bubble; the translation layer is not touchable (touches go to the app below); tap on the bubble only translates (tap again hides the layer), settings by long-press

## v0.13
- Translate while typing (Settings), new bottom bar (icons, separator, selected pill)
- Bubble modes: free / lock (snaps to left-right edge) / sleep (38% outside, faded); pulling it out of the edge = instant sleep; it can no longer leave the screen
- Smallest catalog model: SmolLM 135M

## v0.12
- Translation style (casual for subtitles/manga, formal for books/articles) changes the AI prompt; shown in the Text tab and used by image, PDF, subtitle and bubble.

## v0.11
- App language (Persian / English) in Settings -> App language; layout flips RTL / LTR. All texts go through `L("...")` (`I18n.kt`).
- Launcher name under the icon is always English: "Tarjoman".
- Heavier model in the catalog: Gemma 3n E2B (.litertlm, LiteRT-LM build only).
- The GitHub workflow now really has the "Build with LiteRT-LM" checkbox (it was documented but missing).

## v0.10
- Optional LiteRT-LM engine for `.litertlm` models (Qwen3 0.6B in the catalog). Off by default so the normal build is not affected.
  Enable it: GitHub -> Actions -> build -> Run workflow -> tick "Build with LiteRT-LM". (Local: `gradle assembleDebug -Plitertlm`.)
  Code: `app/src/lm` (real) / `app/src/nolm` (stub).

## Next
- Test on the phone and report: bubble accuracy, speed per model, Persian quality
- Better vertical manga text, per-app presets for the bubble
- Speed-up for the AI engine (GPU/NNAPI where it helps on Snapdragon 720G)
