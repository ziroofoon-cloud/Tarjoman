# ترجمان (Tarjoman) — v0.16
Offline/online translator for Android (EN <-> FA, JA optional), tuned for Redmi Note 9 Pro (arm64).

- Normal: Google ML Kit offline packs
- Advanced: on-device LLM (.task via MediaPipe), downloadable in-app or added manually
- Fast / Slow (+refine pass), Offline / Online (Google x3, Lingva x3, MyMemory; optional proxy; optional OpenAI-compatible API)
- Image translate (OCR EN/JA/FA) drawn over the picture, save as PNG
- Floating bubble: tap = translate whole screen on an adjustable transparent layer, long-press = settings
- PDF translation (page by page, OCR), subtitles (.srt / .vtt -> .srt), glossary

## v0.25
- Cancel button next to Stop: Stop keeps the downloaded part (resume later), Cancel stops and deletes it.

## v0.24
- Stop / Resume buttons for every download (Models tab and the notification). Stopping keeps the downloaded part; "Resume download" continues from it.

## v0.23
- Downloads rewritten for weak / cut internet: the partly downloaded file is always kept; after a timeout or lost connection the app waits (and waits for the network to return), retries by itself and continues from the same byte (HTTP Range + ETag check). It only starts over when the server says the file changed. A slow but moving download never gives up; after many retries without new data it stops, and "Resume" continues from the saved part.
- Downloads run in a foreground service (`Dl.kt`, notification with percentage and a Cancel action): they continue when you leave the app or lock the screen. Progress, speed (MB/s) and retry status are shown on the Models tab.
- Delete (with a confirmation) for everything downloaded: AI models, Persian OCR, Google language packs (Persian / Japanese) and half-finished downloads.

## v0.22
- Translation quality (offline EN -> FA): English is now translated one short sentence at a time, and a built-in phrase table (`Idm.kt`, ~250 everyday phrases, slang and idioms) answers known expressions directly ("Can you be cool?" -> "می‌تونی باحال باشی؟", "Am I dead or am I tripping?" -> "مردم یا دارم توهم می‌زنم؟"). Sentences that contain a known clause are split at "or / and / but / ," and only the unknown clauses go to ML Kit.
- Grammar slips such as "am I died" are fixed to "am I dead" before translating.
- Spoken Persian clean-up: no leading "آیا", "می‌باشد" -> "هست", "نیز" -> "هم".
- Same pipeline is used by the Text, Image, PDF, Subtitle and Bubble tabs (they all call `Tr.translate`).

## v0.21
- Translation boost (Settings): English clean-up before offline ML Kit (ALL CAPS -> normal case, i -> I, full stops / question marks, slang such as "tripping" and "cool" rewritten as plain English); spoken Persian conversion for the casual style (all engines).
- AI prompt: slang/idioms are translated by meaning; new Persian examples.

## v0.20
- Image tab: switch between "On picture", "Translation" and "Original text"; the chosen picture shows at once; "Remove picture" resets the page (and stops a running translation).
- PDF tab: show Translation / Original text / Both (paragraph by paragraph); copy and save use the shown version.

## v0.19
- Models tab: items marked Required / Optional, "start here" note; AI models sorted best-first with quality and speed dots, "Best quality" and "Recommended" tags.
- Real download progress bar + percentage for models and Persian OCR; partial downloads show their percentage and "Resume". Google language packs show installed / not installed (Google gives no percentage, so a moving bar is shown).

## v0.18
- Bubble: one tap translates, double tap goes back to the original screen (also stops live mode).
- Bubble survives rotation (landscape): it is re-placed and the capture is resized.
- Bubble settings panel is smaller (~62% height portrait) and scrolls; in landscape it is 90% height and scrolls.

## v0.17
- New look: no emoji (drawn line icons), cleaner modern style, redesigned classic paper style (serif, burgundy/gold).
- Theme: System (follows the phone) / Light / Dark, and Modern / Classic style (classic also has a night-paper dark version).
- Changing a setting (theme, language) keeps you on the Settings tab at the same scroll position.
- Fixed the language swap button that sat lower than the language buttons.

## v0.7 changes
- Auto-detect source language of typed/shared text (can be turned off in Settings)
- Translation memory: repeated translations are instant
- Persian output clean-up (Arabic ي/ك, digits, ؟ and ،)
- Hybrid mode (experimental): ML Kit draft polished by the AI model for more natural Persian
- Online: more sources, remembers the one that worked, skips Google fast when it is blocked, offline check
- Subtitles: .vtt (YouTube) support, UTF-16 / Windows-1256 / Shift-JIS detection, UTF-8 BOM on save
- Image: uses the same drawing as the bubble (text size setting), "save translated image"
- Bubble: copy-all button, model switcher and hybrid toggle in its settings, context from previous blocks in slow mode
- Qwen3 chat template fixed for manually added models

## v0.7
- Save the PDF translation as a PDF file; wider translation box for vertical manga bubbles

## v0.8
- Text PDFs are read directly (pdfbox-android); scans and Persian use OCR

## v0.9
- Classic (paper) theme next to the modern dark one (Settings), new launcher icon

## v0.16
- Live screen translation (bubble setting): after one tap the translation stays; when the screen changes and settles (manga page turn, scroll) it is translated again. Tap the bubble again to stop.

## v0.15
- "From / To" labels above the language buttons (text tab) and in the bubble settings

## v0.14.1
- Bubble no longer records the screen all the time: the capture is switched on only for the moment of a screenshot (idle load ~0)

## v0.14
- One On/Off button for the bubble; the translation layer is not touchable (touches go to the app below); tap on the bubble only translates (tap again hides the layer), settings by long-press

## v0.13
- Translate while typing (Settings), new bottom bar (icons, separator, selected pill)
- Bubble modes: free / lock (snaps to left-right edge) / sleep (38% outside, faded); pulling it out of the edge = instant sleep; it can no longer leave the screen
- Smallest catalog model: SmolLM 135M

## v0.12
- Translation style (casual for subtitles/manga, formal for books/articles) changes the AI prompt; shown in the Text tab and used by image, PDF, subtitle and bubble.

## v0.11
- App language (Persian / English) in Settings -> App language; layout flips RTL / LTR. All texts go through `L("...")` (`I18n.kt`).
- Launcher name under the icon is always English: "Tarjoman".
- Heavier model in the catalog: Gemma 3n E2B (.litertlm, LiteRT-LM build only).
- The GitHub workflow now really has the "Build with LiteRT-LM" checkbox (it was documented but missing).

## v0.10
- Optional LiteRT-LM engine for `.litertlm` models (Qwen3 0.6B in the catalog). Off by default so the normal build is not affected.
  Enable it: GitHub -> Actions -> build -> Run workflow -> tick "Build with LiteRT-LM". (Local: `gradle assembleDebug -Plitertlm`.)
  Code: `app/src/lm` (real) / `app/src/nolm` (stub).

## Next
- Test on the phone and report: bubble accuracy, speed per model, Persian quality
- Better vertical manga text, per-app presets for the bubble
- Speed-up for the AI engine (GPU/NNAPI where it helps on Snapdragon 720G)
