pluginManagement {
    repositories { google(); mavenCentral(); gradlePluginPortal() }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven {
            url = uri("https://jitpack.io")
            content { includeGroupByRegex("cz\\.adaptech.*") }
        }
    }
}
rootProject.name = "Tarjoman"
include(":app")
project(":app").projectDir = file("Tarjoman/app")
